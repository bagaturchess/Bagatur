
This is the folder containing Gaviota Endgame Tablebases,
which Bagatur chess engine currently supports.
Initially only some important 1-2 pieces tablebases are presented into the distribution.

You may want to download more tablebases (3-4-5-6-7+ pieces).
If so than put them in this folder or set the GaviotaTbPath UCI option
of Bagatur chess engine to point to the correct folder location.

As the internet is dynamic, the download locations of Gaviota Endgame Tablebases may change.
Here are some known working locations:
 
ftp://ftp.cis.uab.edu/pub/hyatt/TB
http://www.olympuschess.com/egtb/gaviota/

If they don't work you may need to find them by your own.

News and updated regarding the Gaviota Endgame Tablebases software and creation:
https://sites.google.com/site/gaviotachessengine/Home/endgame-tablebases-1
