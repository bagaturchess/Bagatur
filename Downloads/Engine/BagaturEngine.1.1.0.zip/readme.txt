

/*
 *  BagaturChess (UCI chess engine and tools)
 *  Copyright (C) 2005 Krasimir I. Topchiyski (k_topchiyski@yahoo.com)
 *  
 *  Open Source project location: http://sourceforge.net/projects/bagaturchess/develop
 *  SVN repository https://bagaturchess.svn.sourceforge.net/svnroot/bagaturchess
 *
 *  This file is part of BagaturChess program.
 * 
 *  BagaturChess is open software: you can redistribute it and/or modify
 *  it under the terms of the Eclipse Public License version 1.0 as published by
 *  the Eclipse Foundation.
 *
 *  BagaturChess is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Eclipse Public License for more details.
 *
 *  You should have received a copy of the Eclipse Public License version 1.0
 *  along with BagaturChess. If not, see <http://www.eclipse.org/legal/epl-v10.html/>.
 *
 */


For the latest and greatest version of this readme file you can visit the SVN repository and check the Ants sub-project:
SVN repository https://bagaturchess.svn.sourceforge.net/svnroot/bagaturchess


As a chess player,
you want to play chess against a computer program (chess engine) which is able to be integrated inside UCI compliant user interfaces (like Arena).
This distribution is exactly what you want.

Here are the steps necessary to run the engine:
1. Download an arbitrary UCI user interface. For example the most popular one is Arena - http://www.playwitharena.com/
2. Install the UCI user interface on your computer
3. Install Java platform (JDK or JRE) on your computer
4. Unpack this distribution somewhere (Arena has a sub-folder called 'engines', you can extract it there)
5. Edit BagaturEngine_singlecore.bat and BagaturEngine_multicore.bat so that the full path to java.exe is valid (or just ensure that the java.exe is added to the path variable)
6. Open the UCI user interface and register the engine inside (You should become familiar with the installed UCI user interface anyway). You may use the single-core or mutli-core version depending on your choice.
7. E2-E4 and enjoy :-)


Have a nice usage ... and feel free to contribute http://sourceforge.net/projects/bagaturchess/develop


Clarifications:
  1. By default Bagatur runs with 256M of memory for the whole program (you may want to check the *.bat file's property 'PROCESS_MEMORY').
     When Bagatur runs in a user interface (e.g. Arena), it shows 0M - 2M consumed memory. That is not the correct size of the used memory.
     You can check the started java process' memory to check how much memory it really consumes.
     The issue happens because Bagatur is written in Java programming language and hence uses Java runtime as an execution environment.
     UCI user interfaces doesn't show correctly the used memory of the engines running on java platform and started via *.bat file (probably because they fork a new process for java.exe).

  2. Bagatur doesn't use endgame tablebases (neither Nalimov nor Gaviota nor Scorpio) and hence sometimes it still makes "non-perfect" moves in endgames. This feature is in the to-do list. Feel free to contribute some java code. :-)


Credits:
  I am working on this program for 10 years in my spare time as a hobby.
  In the beginning there were not a lot in the Internet, although, most of the time I purposely avoided heaving look at the
  other open source softwares and articles regarding the search and game theory.
  Because of that, in many aspects I have re-invented the wheel (for good or bad, it is obvious, if you have a look at the code).
  Anyway, without the ideas, support and help from the following people and web sites, Bagatur would not be as it is now:
  
  1. My Wife, for supporting me in this asocial and profitless hobby.
  2. Ivo Simeonov, for all the ideas, support, discussions, tests and contributed source code for the initial version of pawn structure evaluation.
  3. Iavor Stoimenov, for the support and helpful discussions about the chess stuffs. He feeds me with all the chess' news around the world.
  4. Dusan Stamenkovic, http://www.chessmosaic.com/, for the new Bagatur's Logo.
  5. Google.com and Internet, you know how much it brings and gets nowadays.
  6. All UCI compatible GUIs and UCI protocol itself.
  7. REBEL, http://www.top-5000.nl/authors/rebel/chess840.htm, very helpful web page. Unfortunately it appeared after i realized most of the things in the hard way.
  8. MTD(f), http://plaat.nl/mtdf.html, the parallel search of Bagatur is based on this idea.
  9. Glaurung, http://www.glaurungchess.com/, nice idea for king safety.
  10. Fruit, http://www.fruitchess.com/, legendary program, nice and simple design.

