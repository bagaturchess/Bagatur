import java.util.*;
import java.io.*;

/// MainThread is a derived class specific for main thread

public class MainThread extends Thread
{

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to C++ 'using' declarations which operate on base class members:
  using Thread.Thread;

//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  override void search();
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  void check_time();

  public double bestMoveChanges;
  public double previousTimeReduction;
  public Value previousScore;
  public int callsCnt;
}