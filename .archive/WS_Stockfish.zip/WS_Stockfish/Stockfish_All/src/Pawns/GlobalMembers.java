package Pawns;

public class GlobalMembers
{


	/// Pawns::init() initializes some tables needed by evaluation. Instead of using
	/// hard-coded tables, when makes sense, we prefer to calculate them with a formula
	/// to reduce independent parameters and to allow easier tuning and better insight.



	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static final init_int[] Seed = {0, 13, 24, 18, 65, 100, 175, 330};

	public static void init()
	{

//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
//	  static constexpr int Seed[RANK_NB] = { 0, 13, 24, 18, 65, 100, 175, 330 };

	  for (init_int opposed = 0; opposed <= 1; ++opposed)
	  {
		  for (init_int phalanx = 0; phalanx <= 1; ++phalanx)
		  {
			  for (init_int support = 0; support <= 2; ++support)
			  {
				  for (Rank r = Rank.RANK_2; r.getValue() < Rank.RANK_8.getValue(); ++r)
				  {
		  init_int v = 17 * support;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  v += (Seed[r.getValue()] + (phalanx != 0 ? (Seed[r.getValue() + 1] - Seed[r.getValue()]) / 2 : 0)) >> opposed;

		  GlobalMembers.Connected[opposed][phalanx][support][r.getValue()] = GlobalMembers.make_score(v, v * (r - 2) / 4);
				  }
			  }
		  }
	  }
	}

	/// Pawns::probe() looks up the current position's pawns configuration in
	/// the pawns hash table. It returns a pointer to the Entry if the position
	/// is found. Otherwise a new Entry is computed and stored there, so we don't
	/// have to recompute all when the same pawns configuration occurs again.


	public static Entry probe(Position pos)
	{

	  long key = pos.pawn_key();
	  Entry e = pos.this_thread().pawnsTable[key];

	  if (e.key == key)
	  {
		  return e;
	  }

	  e.key = key;
	  e.scores[Color.WHITE.getValue()] = GlobalMembers.<Color.WHITE.getValue()>evaluate(pos, e);
	  e.scores[Color.BLACK.getValue()] = GlobalMembers.<Color.BLACK.getValue()>evaluate(pos, e);
	  e.openFiles = GlobalMembers.popcount((long)(e.semiopenFiles[Color.WHITE.getValue()] & e.semiopenFiles[Color.BLACK.getValue()]));
	  e.asymmetry = GlobalMembers.popcount((e.passedPawns[Color.WHITE.getValue()] | e.passedPawns[Color.BLACK.getValue()]) | (e.semiopenFiles[Color.WHITE.getValue()] ^ e.semiopenFiles[Color.BLACK.getValue()]));

	  return e;
	}



	// Explicit template instantiation
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: template Score Entry::do_king_safety<WHITE>(const Position& pos);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	template Score Entry::do_king_safety(Position pos);
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: template Score Entry::do_king_safety<BLACK>(const Position& pos);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	template Score Entry::do_king_safety(Position pos);
}