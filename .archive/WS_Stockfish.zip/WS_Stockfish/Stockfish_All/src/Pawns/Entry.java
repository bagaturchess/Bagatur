package Pawns;

/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/




/// Pawns::Entry contains various information about a pawn structure. A lookup
/// to the pawn hash table (performed by calling the probe function) returns a
/// pointer to an Entry object.

public class Entry
{

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Score pawn_score(Color c) const
  public final Score pawn_score(Color c)
  {
	  return scores[c.getValue()];
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong pawn_attacks(Color c) const
  public final long pawn_attacks(Color c)
  {
	  return pawnAttacks[c.getValue()];
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong passed_pawns(Color c) const
  public final long passed_pawns(Color c)
  {
	  return passedPawns[c.getValue()];
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong pawn_attacks_span(Color c) const
  public final long pawn_attacks_span(Color c)
  {
	  return pawnAttacksSpan[c.getValue()];
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int weak_unopposed(Color c) const
  public final int weak_unopposed(Color c)
  {
	  return weakUnopposed[c.getValue()];
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int pawn_asymmetry() const
  public final int pawn_asymmetry()
  {
	  return asymmetry;
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int open_files() const
  public final int open_files()
  {
	  return openFiles;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int semiopen_file(Color c, File f) const
  public final int semiopen_file(Color c, File f)
  {
	return semiopenFiles[c.getValue()] & (1 << f.getValue());
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int pawns_on_same_color_squares(Color c, Square s) const
  public final int pawns_on_same_color_squares(Color c, Square s)
  {
	return pawnsOnSquares[c.getValue()][(boolean)(GlobalMembers.DarkSquares & s.getValue())];
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>
  public final <Us> Score king_safety(Position pos)
  {
	return kingSquares[Us] == pos.<PieceType.KING.getValue()>square(Us) && castlingRights[Us] == pos.can_castle(Us) ? kingSafety[Us] : (kingSafety[Us] = this.<Us>do_king_safety(pos));
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>

  /// Entry::do_king_safety() calculates a bonus for king safety. It is called only
  /// when king square changes, which is about 20% of total king_safety() calls.

  public final <Us> Score do_king_safety(Position pos)
  {

	Square ksq = pos.<PieceType.KING.getValue()>square(Us);
	kingSquares[Us] = ksq;
	castlingRights[Us] = pos.can_castle(Us);
	int minKingPawnDistance = 0;

	long pawns = pos.pieces(Us, PieceType.PAWN);
	if (pawns != 0)
	{
		while ((DistanceRingBB[ksq.getValue()][++minKingPawnDistance] & pawns) == 0)
		{
		}
	}

	Value bonus = this.<Us>evaluate_shelter(pos, ksq);

	// If we can castle use the bonus after the castling if it is bigger
	if (pos.can_castle(Us | CastlingSide.KING_SIDE) != 0)
	{
		bonus = Math.max(bonus, this.<Us>evaluate_shelter(pos, GlobalMembers.relative_square(Us, Square.SQ_G1)));
	}

	if (pos.can_castle(Us | CastlingSide.QUEEN_SIDE) != 0)
	{
		bonus = Math.max(bonus, this.<Us>evaluate_shelter(pos, GlobalMembers.relative_square(Us, Square.SQ_C1)));
	}

	return GlobalMembers.make_score(bonus.getValue(), -16 * minKingPawnDistance);
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>

  /// Entry::evaluate_shelter() calculates the shelter bonus and the storm
  /// penalty for a king, looking at the king file and the two closest files.

  public final <Us> Value evaluate_shelter(Position pos, Square ksq)
  {

	final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	final Direction Down = (Us == Color.WHITE ? Direction.SOUTH : Direction.NORTH);
	final long BlockRanks = (Us == Color.WHITE ? GlobalMembers.Rank1BB | GlobalMembers.Rank2BB : GlobalMembers.Rank8BB | GlobalMembers.Rank7BB);

	long b = (long)(pos.pieces(PieceType.PAWN) &)~GlobalMembers.forward_ranks_bb(Them, ksq);
	long ourPawns = b & pos.pieces(Us);
	long theirPawns = b & pos.pieces(Them);

	Value safety = (GlobalMembers.<Down>shift(theirPawns) & (GlobalMembers.FileABB | GlobalMembers.FileHBB) & BlockRanks & ksq.getValue()) != 0 ? Value(374) : Value(5);

	File center = Math.max(File.FILE_B, Math.min(File.FILE_G, GlobalMembers.file_of(ksq)));
	for (File f = File(center - 1); f.getValue() <= File(center + 1); ++f)
	{
		b = ourPawns & GlobalMembers.file_bb(f);
		int ourRank = b != 0 ? GlobalMembers.relative_rank(Us, GlobalMembers.backmost_sq(Us, b)).getValue() : 0;

		b = theirPawns & GlobalMembers.file_bb(f);
		int theirRank = b != 0 ? GlobalMembers.relative_rank(Us, GlobalMembers.frontmost_sq(Them, b)).getValue() : 0;

		int d = Math.min(f, ~f);
		safety += ShelterStrength[d][ourRank];
		safety -= (ourRank != 0 && (ourRank == theirRank - 1)) ? 66 * (theirRank == Rank.RANK_3.getValue()) : UnblockedStorm[d][theirRank];
	}

	return safety;
  }

  public long key;
  public Score[] scores = new Score[Color.COLOR_NB.getValue()];
  public long[] passedPawns = new long[Color.COLOR_NB.getValue()];
  public long[] pawnAttacks = new long[Color.COLOR_NB.getValue()];
  public long[] pawnAttacksSpan = new long[Color.COLOR_NB.getValue()];
  public Square[] kingSquares = new Square[Color.COLOR_NB.getValue()];
  public Score[] kingSafety = new Score[Color.COLOR_NB.getValue()];
  public int[] weakUnopposed = new int[Color.COLOR_NB.getValue()];
  public int[] castlingRights = new int[Color.COLOR_NB.getValue()];
  public int[] semiopenFiles = new int[Color.COLOR_NB.getValue()];
  public int[][] pawnsOnSquares = new int[Color.COLOR_NB.getValue()][Color.COLOR_NB.getValue()]; // [color][light/dark squares]
  public int asymmetry;
  public int openFiles;
}
//C++ TO JAVA CONVERTER TODO TASK: The following package should be saved to a separate file:


