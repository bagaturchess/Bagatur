  public enum TimeType
  {
	  OptimumTime,
	  MaxTime;

	  public static final int SIZE = java.lang.Integer.SIZE;

	  public int getValue()
	  {
		  return this.ordinal();
	  }

	  public static TimeType forValue(int value)
	  {
		  return values()[value];
	  }
  }