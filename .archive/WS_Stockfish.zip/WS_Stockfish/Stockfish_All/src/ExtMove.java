public class ExtMove
{
  public Move move;
  public int value;

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: operator Move() const
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
  operator Move()
  {
	  return move;
  }
//C++ TO JAVA CONVERTER NOTE: This 'copyFrom' method was converted from the original copy assignment operator:
//ORIGINAL LINE: void operator =(Move m)
  public final void copyFrom(Move m)
  {
	  move = m;
  }

  // Inhibit unwanted implicit conversions to Move
  // with an ambiguity that yields to a compile error.
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
//  operator float() const = delete;
}