public enum Value
{
  VALUE_ZERO(0),
  VALUE_DRAW(0),
  VALUE_KNOWN_WIN(10000),
  VALUE_MATE(32000),
  VALUE_INFINITE(32001),
  VALUE_NONE(32002),

  VALUE_MATE_IN_MAX_PLY(VALUE_MATE - 2 * MAX_PLY),
  VALUE_MATED_IN_MAX_PLY(-VALUE_MATE + 2 * MAX_PLY),

  PawnValueMg(136),
  PawnValueEg(208),
  KnightValueMg(782),
  KnightValueEg(865),
  BishopValueMg(830),
  BishopValueEg(918),
  RookValueMg(1289),
  RookValueEg(1378),
  QueenValueMg(2529),
  QueenValueEg(2687),

  MidgameLimit(15258),
  EndgameLimit(3915);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Value> mappings;
	private static java.util.HashMap<Integer, Value> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Value.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Value>();
				}
			}
		}
		return mappings;
	}

	private Value(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Value forValue(int value)
	{
		return getMappings().get(value);
	}
}