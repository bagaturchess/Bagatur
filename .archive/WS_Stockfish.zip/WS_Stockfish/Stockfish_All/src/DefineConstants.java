final class DefineConstants
{
	public static final int _WIN32_WINNT = 0x0601; // Force to include needed API prototypes
}