import java.util.*;
import java.io.*;

@FunctionalInterface
interface fun2_t
{
	boolean invoke(short UnnamedParameter, PGROUP_AFFINITY UnnamedParameter2);
}