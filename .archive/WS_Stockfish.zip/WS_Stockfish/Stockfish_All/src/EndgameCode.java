import String;
import java.util.*;
import java.io.*;

/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/





/// EndgameCode lists all supported endgame functions by corresponding codes

public enum EndgameCode
{

  EVALUATION_FUNCTIONS,
  KNNK, // KNN vs K
  KXK, // Generic "mate lone king" eval
  KBNK, // KBN vs K
  KPK, // KP vs K
  KRKP, // KR vs KP
  KRKB, // KR vs KB
  KRKN, // KR vs KN
  KQKP, // KQ vs KP
  KQKR, // KQ vs KR

  SCALING_FUNCTIONS,
  KBPsK, // KB and pawns vs K
  KQKRPs, // KQ vs KR and pawns
  KRPKR, // KRP vs KR
  KRPKB, // KRP vs KB
  KRPPKRP, // KRPP vs KRP
  KPsK, // K and pawns vs K
  KBPKB, // KBP vs KB
  KBPPKB, // KBPP vs KB
  KBPKN, // KBP vs KN
  KNPK, // KNP vs K
  KNPKB, // KNP vs KB
  KPKP; // KP vs KP

	public static final int SIZE = java.lang.Integer.SIZE;

	public int getValue()
	{
		return this.ordinal();
	}

	public static EndgameCode forValue(int value)
	{
		return values()[value];
	}
}