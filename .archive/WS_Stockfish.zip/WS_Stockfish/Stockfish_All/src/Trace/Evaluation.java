package Trace;

  public class Evaluation<T>
  {

//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
//	Evaluation() = delete;
	public Evaluation(Position p)
	{
		this.pos = new Position(p);
	}
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
//	Evaluation& operator =(const Evaluation&) = delete;

	// Evaluation::value() is the main function of the class. It computes the various
	// parts of the evaluation and returns the value of the position from the point
	// of view of the side to move.

	public final Value value()
	{

	  assert!pos.checkers();

	  // Probe the material hash table
	  me = Material.probe(pos);

	  // If we have a specialized evaluation function for the current material
	  // configuration, call it and return.
	  if (me.specialized_eval_exists())
	  {
		  return me.evaluate(pos);
	  }

	  // Initialize score by reading the incrementally updated scores included in
	  // the position object (material + piece square tables) and the material
	  // imbalance. Score is computed internally from the white point of view.
	  Score score = pos.psq_score() + me.imbalance() + pos.this_thread().contempt;

	  // Probe the pawn hash table
	  pe = Pawns.probe(pos);
	  score += pe.pawn_score(Color.WHITE) - pe.pawn_score(Color.BLACK);

	  // Early exit if score is high
	  Value v = (GlobalMembers.mg_value(score) + GlobalMembers.eg_value(score)) / 2;
	  if (Math.abs(v) > GlobalMembers.LazyThreshold.getValue())
	  {
		 return pos.side_to_move() == Color.WHITE ? v : -v;
	  }

	  // Main evaluation begins here

	  this.<Color.WHITE.getValue()>initialize();
	  this.<Color.BLACK.getValue()>initialize();

	  // Pieces should be evaluated first (populate attack tables)
	  score += this.<Color.WHITE.getValue(), PieceType.KNIGHT.getValue()>pieces() - this.<Color.BLACK.getValue(), PieceType.KNIGHT.getValue()>pieces() + this.<Color.WHITE.getValue(), PieceType.BISHOP.getValue()>pieces() - this.<Color.BLACK.getValue(), PieceType.BISHOP.getValue()>pieces() + this.<Color.WHITE.getValue(), PieceType.ROOK.getValue() >pieces() - this.<Color.BLACK.getValue(), PieceType.ROOK.getValue() >pieces() + this.<Color.WHITE.getValue(), PieceType.QUEEN.getValue() >pieces() - this.<Color.BLACK.getValue(), PieceType.QUEEN.getValue() >pieces();

	  score += mobility[Color.WHITE.getValue()] - mobility[Color.BLACK.getValue()];

	  score += this.< Color.WHITE.getValue()>king() - this.< Color.BLACK.getValue()>king() + this.<Color.WHITE.getValue()>threats() - this.<Color.BLACK.getValue()>threats() + this.< Color.WHITE.getValue()>passed() - this.< Color.BLACK.getValue()>passed() + this.< Color.WHITE.getValue()>space() - this.< Color.BLACK.getValue()>space();

	  score += initiative(GlobalMembers.eg_value(score));

	  // Interpolate between a middlegame and a (scaled by 'sf') endgame score
	  ScaleFactor sf = scale_factor(GlobalMembers.eg_value(score));
	  v = GlobalMembers.mg_value(score) * me.game_phase().getValue() + GlobalMembers.eg_value(score) * (int)(Phase.PHASE_MIDGAME - me.game_phase()) * sf / ScaleFactor.SCALE_FACTOR_NORMAL;

	  v /= Phase.PHASE_MIDGAME.getValue();

	  // In case of tracing add all remaining individual evaluation terms
	  if (T)
	  {
		  Trace.GlobalMembers.add(MATERIAL, pos.psq_score());
		  Trace.GlobalMembers.add(IMBALANCE, me.imbalance());
		  Trace.GlobalMembers.add(PieceType.PAWN.getValue(), pe.pawn_score(Color.WHITE), pe.pawn_score(Color.BLACK));
		  Trace.GlobalMembers.add(MOBILITY, mobility[Color.WHITE.getValue()], mobility[Color.BLACK.getValue()]);
		  Trace.GlobalMembers.add(TOTAL, score);
	  }

	  return (pos.side_to_move() == Color.WHITE ? v : -v) + Eval.GlobalMembers.Tempo;
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us> void initialize();
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>

	// Evaluation::initialize() computes king and pawn attacks, and the king ring
	// bitboard for a given color. This is done at the beginning of the evaluation.
	private <Us> void initialize()
	{

	  final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	  final Direction Up = (Us == Color.WHITE ? Direction.NORTH : Direction.SOUTH);
	  final Direction Down = (Us == Color.WHITE ? Direction.SOUTH : Direction.NORTH);
	  final uint64_t LowRanks = (Us == Color.WHITE ? GlobalMembers.Rank2BB | GlobalMembers.Rank3BB: GlobalMembers.Rank7BB | GlobalMembers.Rank6BB);

	  // Find our pawns that are blocked or on the first two ranks
	  uint64_t b = pos.pieces(Us, PieceType.PAWN) & (GlobalMembers.<Down>shift(pos.pieces()) | LowRanks);

	  // Squares occupied by those pawns, by our king or queen, or controlled by enemy pawns
	  // are excluded from the mobility area.
	  mobilityArea[Us] = ~(b | pos.pieces(Us, PieceType.KING, PieceType.QUEEN) | pe.pawn_attacks(Them));

	  // Initialise attackedBy bitboards for kings and pawns
	  attackedBy[Us][PieceType.KING.getValue()] = pos.<PieceType.KING.getValue()>attacks_from(pos.<PieceType.KING.getValue()>square(Us));
	  attackedBy[Us][PieceType.PAWN.getValue()] = pe.pawn_attacks(Us);
	  attackedBy[Us][PieceType.ALL_PIECES.getValue()] = attackedBy[Us][PieceType.KING.getValue()] | attackedBy[Us][PieceType.PAWN.getValue()];
	  attackedBy2[Us] = attackedBy[Us][PieceType.KING.getValue()] & attackedBy[Us][PieceType.PAWN.getValue()];

	  kingRing[Us] = kingAttackersCount[Them.getValue()] = 0;

	  // Init our king safety tables only if we are going to use them
	  if (pos.non_pawn_material(Them) >= Value.RookValueMg.getValue() + Value.KnightValueMg)
	  {
		  kingRing[Us] = attackedBy[Us][PieceType.KING.getValue()];
		  if (GlobalMembers.relative_rank(Us, pos.<PieceType.KING.getValue()>square(Us)) == Rank.RANK_1)
		  {
			  kingRing[Us] |= GlobalMembers.<Up>shift(kingRing[Us]);
		  }

		  if (GlobalMembers.file_of(pos.<PieceType.KING.getValue()>square(Us)) == File.FILE_H)
		  {
			  kingRing[Us] |= GlobalMembers.<Direction.WEST.getValue()>shift(kingRing[Us]);
		  }

		  else if (GlobalMembers.file_of(pos.<PieceType.KING.getValue()>square(Us)) == File.FILE_A)
		  {
			  kingRing[Us] |= GlobalMembers.<Direction.EAST.getValue()>shift(kingRing[Us]);
		  }

		  kingAttackersCount[Them.getValue()] = GlobalMembers.popcount(kingRing[Us] & pe.pawn_attacks(Them));
		  kingAttacksCount[Them.getValue()] = kingAttackersWeight[Them.getValue()] = 0;
	  }
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us, PieceType Pt> Score pieces();
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename Us, PieceType Pt>

	// Evaluation::pieces() scores pieces of a given color and type
	private <Us, PieceType Pt> Score pieces()
	{

	  final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	  final Direction Down = (Us == Color.WHITE ? Direction.SOUTH : Direction.NORTH);
	  final uint64_t OutpostRanks = (Us == Color.WHITE ? GlobalMembers.Rank4BB | GlobalMembers.Rank5BB | GlobalMembers.Rank6BB : GlobalMembers.Rank5BB | GlobalMembers.Rank4BB | GlobalMembers.Rank3BB);
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
	  Square * pl = pos.<Pt>squares(Us);

	  uint64_t b = new uint64_t();
	  uint64_t bb = new uint64_t();
	  Square s;
	  Score score = Score.SCORE_ZERO;

	  attackedBy[Us][Pt] = 0;

	  while ((s = *pl++) != Square.SQ_NONE)
	  {
		  // Find attacked squares, including x-ray attacks for bishops and rooks
		  b = Pt == PieceType.BISHOP ? GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s, pos.pieces() ^ pos.pieces(PieceType.QUEEN)) : Pt == PieceType.ROOK ? GlobalMembers.< PieceType.ROOK.getValue()>attacks_bb(s, pos.pieces() ^ pos.pieces(PieceType.QUEEN) ^ pos.pieces(Us, PieceType.ROOK)) : pos.<Pt>attacks_from(s);

		  if (pos.blockers_for_king(Us) & s != null)
		  {
			  b &= LineBB[pos.<PieceType.KING.getValue().getValue()>square(Us)][s.getValue()];
		  }

		  attackedBy2[Us] |= attackedBy[Us][PieceType.ALL_PIECES.getValue()] & b;
		  attackedBy[Us][Pt] |= b;
		  attackedBy[Us][PieceType.ALL_PIECES.getValue()] |= b;

		  if (b & kingRing[Them.getValue()] != null)
		  {
			  kingAttackersCount[Us]++;
			  kingAttackersWeight[Us] += GlobalMembers.KingAttackWeights[Pt];
			  kingAttacksCount[Us] += GlobalMembers.popcount(b & attackedBy[Them.getValue()][PieceType.KING.getValue()]);
		  }

		  int mob = GlobalMembers.popcount(b & mobilityArea[Us]);

		  mobility[Us] += GlobalMembers.MobilityBonus[Pt - 2][mob];

		  if (Pt == PieceType.BISHOP || Pt == PieceType.KNIGHT)
		  {
			  // Bonus if piece is on an outpost square or can reach one
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: bb = OutpostRanks & ~pe->pawn_attacks_span(Them);
			  bb.copyFrom(OutpostRanks & ~pe.pawn_attacks_span(Them));
			  if (bb & s != null)
			  {
				  score += GlobalMembers.Outpost[Pt == PieceType.BISHOP][(boolean)(attackedBy[Us][PieceType.PAWN.getValue()] & s)] * 2;
			  }

			  else if (bb &= b & ~pos.pieces(Us))
			  {
				  score += GlobalMembers.Outpost[Pt == PieceType.BISHOP][(boolean)(attackedBy[Us][PieceType.PAWN.getValue()] & bb)];
			  }

			  // Knight and Bishop bonus for being right behind a pawn
			  if (GlobalMembers.<Down>shift(pos.pieces(PieceType.PAWN)) & s != null)
			  {
				  score += GlobalMembers.MinorBehindPawn;
			  }

			  // Penalty if the piece is far from the king
			  score -= GlobalMembers.KingProtector * GlobalMembers.distance(s, pos.<PieceType.KING.getValue()>square(Us));

			  if (Pt == PieceType.BISHOP)
			  {
				  // Penalty according to number of pawns on the same color square as the
				  // bishop, bigger when the center files are blocked with pawns.
				  uint64_t blocked = pos.pieces(Us, PieceType.PAWN) & GlobalMembers.<Down>shift(pos.pieces());

				  score -= GlobalMembers.BishopPawns * pe.pawns_on_same_color_squares(Us, s) * (1 + GlobalMembers.popcount(blocked & GlobalMembers.CenterFiles));

				  // Bonus for bishop on a long diagonal which can "see" both center squares
				  if (GlobalMembers.more_than_one(GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s, pos.pieces(PieceType.PAWN)) & GlobalMembers.Center))
				  {
					  score += GlobalMembers.LongDiagonalBishop;
				  }
			  }

			  // An important Chess960 pattern: A cornered bishop blocked by a friendly
			  // pawn diagonally in front of it is a very serious problem, especially
			  // when that pawn is also blocked.
			  if (Pt == PieceType.BISHOP && pos.is_chess960() && (s == GlobalMembers.relative_square(Us, Square.SQ_A1) || s == GlobalMembers.relative_square(Us, Square.SQ_H1)))
			  {
				  Direction d = GlobalMembers.pawn_push(Us) + (GlobalMembers.file_of(s) == File.FILE_A ? Direction.EAST : Direction.WEST);
				  if (pos.piece_on(s + d) == GlobalMembers.make_piece(Us, PieceType.PAWN))
				  {
					  score -= !pos.empty(s + d + GlobalMembers.pawn_push(Us)) ? GlobalMembers.CorneredBishop * 4 : pos.piece_on(s + d + d) == GlobalMembers.make_piece(Us, PieceType.PAWN) ? GlobalMembers.CorneredBishop * 2 : GlobalMembers.CorneredBishop;
				  }
			  }
		  }

		  if (Pt == PieceType.ROOK)
		  {
			  // Bonus for aligning rook with enemy pawns on the same rank/file
			  if (GlobalMembers.relative_rank(Us, s) >= Rank.RANK_5.getValue())
			  {
				  score += GlobalMembers.RookOnPawn * GlobalMembers.popcount(pos.pieces(Them, PieceType.PAWN) & PseudoAttacks[PieceType.ROOK.getValue()][s.getValue()]);
			  }

			  // Bonus for rook on an open or semi-open file
			  if (pe.semiopen_file(Us, GlobalMembers.file_of(s)) != 0)
			  {
				  score += GlobalMembers.RookOnFile[(boolean)pe.semiopen_file(Them, GlobalMembers.file_of(s))];
			  }

			  // Penalty when trapped by the king, even more if the king cannot castle
			  else if (mob <= 3)
			  {
				  File kf = GlobalMembers.file_of(pos.<PieceType.KING.getValue()>square(Us));
				  if ((kf.getValue() < File.FILE_E.getValue()) == (GlobalMembers.file_of(s) < kf.getValue()))
				  {
					  score -= (GlobalMembers.TrappedRook - GlobalMembers.make_score(mob * 22, 0)) * (1 + !pos.can_castle(Us));
				  }
			  }
		  }

		  if (Pt == PieceType.QUEEN)
		  {
			  // Penalty if any relative pin or discovered attack against the queen
			  uint64_t queenPinners = new uint64_t();
			  if (pos.slider_blockers(pos.pieces(Them, PieceType.ROOK, PieceType.BISHOP), s, queenPinners) != null)
			  {
				  score -= GlobalMembers.WeakQueen;
			  }
		  }
	  }
	  if (T)
	  {
		  Trace.GlobalMembers.add(Pt, Us, score);
	  }

	  return score;
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us> Score king() const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>

	// Evaluation::king() assigns bonuses and penalties to a king of a given color
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Score king() const
	private <Us> Score king()
	{

	  final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	  final uint64_t Camp = (Us == Color.WHITE ? GlobalMembers.AllSquares ^ GlobalMembers.Rank6BB ^ GlobalMembers.Rank7BB ^ GlobalMembers.Rank8BB : GlobalMembers.AllSquares ^ GlobalMembers.Rank1BB ^ GlobalMembers.Rank2BB ^ GlobalMembers.Rank3BB);

	  final Square ksq = pos.<PieceType.KING.getValue()>square(Us);
	  uint64_t kingFlank = new uint64_t();
	  uint64_t weak = new uint64_t();
	  uint64_t b = new uint64_t();
	  uint64_t b1 = new uint64_t();
	  uint64_t b2 = new uint64_t();
	  uint64_t safe = new uint64_t();
	  uint64_t unsafeChecks = new uint64_t();

	  // King shelter and enemy pawns storm
	  Score score = pe.<Us>king_safety(pos);

	  // Find the squares that opponent attacks in our king flank, and the squares
	  // which are attacked twice in that flank.
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: kingFlank = KingFlank[file_of(ksq)];
	  kingFlank.copyFrom(GlobalMembers.KingFlank[GlobalMembers.file_of(ksq).getValue()]);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b1 = attackedBy[Them][ALL_PIECES] & kingFlank & Camp;
	  b1.copyFrom(attackedBy[Them.getValue()][PieceType.ALL_PIECES.getValue()] & kingFlank & Camp);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b2 = b1 & attackedBy2[Them];
	  b2.copyFrom(b1 & attackedBy2[Them.getValue()]);

	  int tropism = GlobalMembers.popcount(new uint64_t(b1)) + GlobalMembers.popcount(new uint64_t(b2));

	  // Main king safety evaluation
	  if (kingAttackersCount[Them.getValue()] > 1 - pos.<PieceType.QUEEN.getValue()>count(Them))
	  {
		  int kingDanger = 0;
		  unsafeChecks = 0;

		  // Attacked squares defended at most once by our queen or king
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: weak = attackedBy[Them][ALL_PIECES] & ~attackedBy2[Us] & (~attackedBy[Us][ALL_PIECES] | attackedBy[Us][KING] | attackedBy[Us][QUEEN]);
		  weak.copyFrom(attackedBy[Them.getValue()][PieceType.ALL_PIECES.getValue()] & ~attackedBy2[Us] & (~attackedBy[Us][PieceType.ALL_PIECES.getValue()] | attackedBy[Us][PieceType.KING.getValue()] | attackedBy[Us][PieceType.QUEEN.getValue()]));

		  // Analyse the safe enemy's checks which are possible on next move
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: safe = ~pos.pieces(Them);
		  safe.copyFrom(~pos.pieces(Them));
		  safe &= ~attackedBy[Us][PieceType.ALL_PIECES.getValue()] | (weak & attackedBy2[Them.getValue()]);

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b1 = attacks_bb<ROOK >(ksq, pos.pieces() ^ pos.pieces(Us, QUEEN));
		  b1.copyFrom(GlobalMembers.<PieceType.ROOK.getValue() >attacks_bb(ksq, pos.pieces() ^ pos.pieces(Us, PieceType.QUEEN)));
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b2 = attacks_bb<BISHOP>(ksq, pos.pieces() ^ pos.pieces(Us, QUEEN));
		  b2.copyFrom(GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(ksq, pos.pieces() ^ pos.pieces(Us, PieceType.QUEEN)));

		  // Enemy queen safe checks
		  if ((b1 | b2) & attackedBy[Them.getValue()][PieceType.QUEEN.getValue()] & safe & ~attackedBy[Us][PieceType.QUEEN.getValue()] != null)
		  {
			  kingDanger += GlobalMembers.QueenSafeCheck;
		  }

		  b1 &= attackedBy[Them.getValue()][PieceType.ROOK.getValue()];
		  b2 &= attackedBy[Them.getValue()][PieceType.BISHOP.getValue()];

		  // Enemy rooks checks
		  if (b1 & safe != null)
		  {
			  kingDanger += GlobalMembers.RookSafeCheck;
		  }
		  else
		  {
			  unsafeChecks |= b1;
		  }

		  // Enemy bishops checks
		  if (b2 & safe != null)
		  {
			  kingDanger += GlobalMembers.BishopSafeCheck;
		  }
		  else
		  {
			  unsafeChecks |= b2;
		  }

		  // Enemy knights checks
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = pos.attacks_from<KNIGHT>(ksq) & attackedBy[Them][KNIGHT];
		  b.copyFrom(pos.<PieceType.KNIGHT.getValue()>attacks_from(ksq) & attackedBy[Them.getValue()][PieceType.KNIGHT.getValue()]);
		  if (b & safe != null)
		  {
			  kingDanger += GlobalMembers.KnightSafeCheck;
		  }
		  else
		  {
			  unsafeChecks |= b;
		  }

		  // Unsafe or occupied checking squares will also be considered, as long as
		  // the square is in the attacker's mobility area.
		  unsafeChecks &= mobilityArea[Them.getValue()];

		  kingDanger += kingAttackersCount[Them.getValue()] * kingAttackersWeight[Them.getValue()] + 69 * kingAttacksCount[Them.getValue()] + 185 * GlobalMembers.popcount(kingRing[Us] & weak) + 150 * GlobalMembers.popcount(pos.blockers_for_king(Us) | unsafeChecks) + tropism * tropism / 4 - 873 * !pos.<PieceType.QUEEN.getValue()>count(Them) - 6 * GlobalMembers.mg_value(score) / 8 + GlobalMembers.mg_value(mobility[Them.getValue()] - mobility[Us]) - 30;

		  // Transform the kingDanger units into a Score, and subtract it from the evaluation
		  if (kingDanger > 0)
		  {
			  score -= GlobalMembers.make_score(kingDanger * kingDanger / 4096, kingDanger / 16);
		  }
	  }

	  // Penalty when our king is on a pawnless flank
	  if ((pos.pieces(PieceType.PAWN) & kingFlank) == null)
	  {
		  score -= GlobalMembers.PawnlessFlank;
	  }

	  // King tropism bonus, to anticipate slow motion attacks on our king
	  score -= GlobalMembers.CloseEnemies * tropism;

	  if (T)
	  {
		  Trace.GlobalMembers.add(PieceType.KING.getValue(), Us, score);
	  }

	  return score;
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us> Score threats() const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>

	// Evaluation::threats() assigns bonuses according to the types of the
	// attacking and the attacked pieces.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Score threats() const
	private <Us> Score threats()
	{

	  final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	  final Direction Up = (Us == Color.WHITE ? Direction.NORTH : Direction.SOUTH);
	  final uint64_t TRank3BB = (Us == Color.WHITE ? GlobalMembers.Rank3BB : GlobalMembers.Rank6BB);

	  uint64_t b = new uint64_t();
	  uint64_t weak = new uint64_t();
	  uint64_t defended = new uint64_t();
	  uint64_t nonPawnEnemies = new uint64_t();
	  uint64_t stronglyProtected = new uint64_t();
	  uint64_t safe = new uint64_t();
	  uint64_t restricted = new uint64_t();
	  Score score = Score.SCORE_ZERO;

	  // Non-pawn enemies
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: nonPawnEnemies = pos.pieces(Them) ^ pos.pieces(Them, PAWN);
	  nonPawnEnemies.copyFrom(pos.pieces(Them) ^ pos.pieces(Them, PieceType.PAWN));

	  // Squares strongly protected by the enemy, either because they defend the
	  // square with a pawn, or because they defend the square twice and we don't.
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: stronglyProtected = attackedBy[Them][PAWN] | (attackedBy2[Them] & ~attackedBy2[Us]);
	  stronglyProtected.copyFrom(attackedBy[Them.getValue()][PieceType.PAWN.getValue()] | (attackedBy2[Them.getValue()] & ~attackedBy2[Us]));

	  // Non-pawn enemies, strongly protected
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: defended = nonPawnEnemies & stronglyProtected;
	  defended.copyFrom(nonPawnEnemies & stronglyProtected);

	  // Enemies not strongly protected and under our attack
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: weak = pos.pieces(Them) & ~stronglyProtected & attackedBy[Us][ALL_PIECES];
	  weak.copyFrom(pos.pieces(Them) & ~stronglyProtected & attackedBy[Us][PieceType.ALL_PIECES.getValue()]);

	  // Safe or protected squares
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: safe = ~attackedBy[Them][ALL_PIECES] | attackedBy[Us][ALL_PIECES];
	  safe.copyFrom(~attackedBy[Them.getValue()][PieceType.ALL_PIECES.getValue()] | attackedBy[Us][PieceType.ALL_PIECES.getValue()]);

	  // Bonus according to the kind of attacking pieces
	  if (defended | weak != null)
	  {
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = (defended | weak) & (attackedBy[Us][KNIGHT] | attackedBy[Us][BISHOP]);
		  b.copyFrom((defended | weak) & (attackedBy[Us][PieceType.KNIGHT.getValue()] | attackedBy[Us][PieceType.BISHOP.getValue()]));
		  while (b != null)
		  {
			  Square s = GlobalMembers.pop_lsb(b);
			  score += GlobalMembers.ThreatByMinor[GlobalMembers.type_of(pos.piece_on(s)).getValue()];
			  if (GlobalMembers.type_of(pos.piece_on(s)) != PieceType.PAWN)
			  {
				  score += GlobalMembers.ThreatByRank * GlobalMembers.relative_rank(Them, s).getValue();
			  }
		  }

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = weak & attackedBy[Us][ROOK];
		  b.copyFrom(weak & attackedBy[Us][PieceType.ROOK.getValue()]);
		  while (b != null)
		  {
			  Square s = GlobalMembers.pop_lsb(b);
			  score += GlobalMembers.ThreatByRook[GlobalMembers.type_of(pos.piece_on(s)).getValue()];
			  if (GlobalMembers.type_of(pos.piece_on(s)) != PieceType.PAWN)
			  {
				  score += GlobalMembers.ThreatByRank * GlobalMembers.relative_rank(Them, s).getValue();
			  }
		  }

		  if (weak & attackedBy[Us][PieceType.KING.getValue()] != null)
		  {
			  score += GlobalMembers.ThreatByKing;
		  }

		  score += GlobalMembers.Hanging * GlobalMembers.popcount(weak & ~attackedBy[Them.getValue()][PieceType.ALL_PIECES.getValue()]);

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = weak & nonPawnEnemies & attackedBy[Them][ALL_PIECES];
		  b.copyFrom(weak & nonPawnEnemies & attackedBy[Them.getValue()][PieceType.ALL_PIECES.getValue()]);
		  score += GlobalMembers.Overload * GlobalMembers.popcount(new uint64_t(b));
	  }

	  // Bonus for restricting their piece moves
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: restricted = attackedBy[Them][ALL_PIECES] & ~attackedBy[Them][PAWN] & ~attackedBy2[Them] & attackedBy[Us][ALL_PIECES];
	  restricted.copyFrom(attackedBy[Them.getValue()][PieceType.ALL_PIECES.getValue()] & ~attackedBy[Them.getValue()][PieceType.PAWN.getValue()] & ~attackedBy2[Them.getValue()] & attackedBy[Us][PieceType.ALL_PIECES.getValue()]);
	  score += GlobalMembers.RestrictedPiece * GlobalMembers.popcount(new uint64_t(restricted));

	  // Bonus for enemy unopposed weak pawns
	  if (pos.pieces(Us, PieceType.ROOK, PieceType.QUEEN) != null)
	  {
		  score += GlobalMembers.WeakUnopposedPawn * pe.weak_unopposed(Them);
	  }

	  // Find squares where our pawns can push on the next move
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = shift<Up>(pos.pieces(Us, PAWN)) & ~pos.pieces();
	  b.copyFrom(GlobalMembers.<Up>shift(pos.pieces(Us, PieceType.PAWN)) & ~pos.pieces());
	  b |= GlobalMembers.<Up>shift(b & TRank3BB) & ~pos.pieces();

	  // Keep only the squares which are relatively safe
	  b &= ~attackedBy[Them.getValue()][PieceType.PAWN.getValue()] & safe;

	  // Bonus for safe pawn threats on the next move
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = pawn_attacks_bb<Us>(b) & pos.pieces(Them);
	  b.copyFrom(GlobalMembers.<Us>pawn_attacks_bb(new uint64_t(b)) & pos.pieces(Them));
	  score += GlobalMembers.ThreatByPawnPush * GlobalMembers.popcount(new uint64_t(b));

	  // Our safe or protected pawns
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = pos.pieces(Us, PAWN) & safe;
	  b.copyFrom(pos.pieces(Us, PieceType.PAWN) & safe);

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = pawn_attacks_bb<Us>(b) & nonPawnEnemies;
	  b.copyFrom(GlobalMembers.<Us>pawn_attacks_bb(new uint64_t(b)) & nonPawnEnemies);
	  score += GlobalMembers.ThreatBySafePawn * GlobalMembers.popcount(new uint64_t(b));

	  // Bonus for threats on the next moves against enemy queen
	  if (pos.<PieceType.QUEEN.getValue()>count(Them) == 1)
	  {
		  Square s = pos.<PieceType.QUEEN.getValue()>square(Them);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: safe = mobilityArea[Us] & ~stronglyProtected;
		  safe.copyFrom(mobilityArea[Us] & ~stronglyProtected);

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = attackedBy[Us][KNIGHT] & pos.attacks_from<KNIGHT>(s);
		  b.copyFrom(attackedBy[Us][PieceType.KNIGHT.getValue()] & pos.<PieceType.KNIGHT.getValue()>attacks_from(s));

		  score += GlobalMembers.KnightOnQueen * GlobalMembers.popcount(b & safe);

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = (attackedBy[Us][BISHOP] & pos.attacks_from<BISHOP>(s)) | (attackedBy[Us][ROOK] & pos.attacks_from<ROOK >(s));
		  b.copyFrom((attackedBy[Us][PieceType.BISHOP.getValue()] & pos.<PieceType.BISHOP.getValue()>attacks_from(s)) | (attackedBy[Us][PieceType.ROOK.getValue()] & pos.<PieceType.ROOK.getValue() >attacks_from(s)));

		  score += GlobalMembers.SliderOnQueen * GlobalMembers.popcount(b & safe & attackedBy2[Us]);
	  }

	  if (T)
	  {
		  Trace.GlobalMembers.add(THREAT, Us, score);
	  }

	  return score;
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us> Score passed() const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>

	// Evaluation::passed() evaluates the passed pawns and candidate passed
	// pawns of the given color.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Score passed() const
	private <Us> Score passed()
	{

	  final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	  final Direction Up = (Us == Color.WHITE ? Direction.NORTH : Direction.SOUTH);

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
	  auto king_proximity = (Color c, Square s) ->
	  {
		return Math.min(distance(pos.<PieceType.KING.getValue()>square(c), s), 5);
	  };

	  uint64_t b = new uint64_t();
	  uint64_t bb = new uint64_t();
	  uint64_t squaresToQueen = new uint64_t();
	  uint64_t defendedSquares = new uint64_t();
	  uint64_t unsafeSquares = new uint64_t();
	  Score score = Score.SCORE_ZERO;

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = pe->passed_pawns(Us);
	  b.copyFrom(pe.passed_pawns(Us));

	  while (b != null)
	  {
		  Square s = GlobalMembers.pop_lsb(b);

		  assert!(pos.pieces(Them, PieceType.PAWN) & GlobalMembers.forward_file_bb(Us, s + Up));

		  int r = GlobalMembers.relative_rank(Us, s).getValue();

		  Score bonus = GlobalMembers.PassedRank[r];

		  if (r > Rank.RANK_3.getValue())
		  {
			  int w = (r - 2) * (r - 2) + 2;
			  Square blockSq = s + Up;

			  // Adjust bonus based on the king's proximity
			  bonus += GlobalMembers.make_score(0, (king_proximity(Them, blockSq) * 5 - king_proximity(Us, blockSq) * 2) * w);

			  // If blockSq is not the queening square then consider also a second push
			  if (r != Rank.RANK_7.getValue())
			  {
				  bonus -= GlobalMembers.make_score(0, king_proximity(Us, blockSq + Up) * w);
			  }

			  // If the pawn is free to advance, then increase the bonus
			  if (pos.empty(blockSq))
			  {
				  // If there is a rook or queen attacking/defending the pawn from behind,
				  // consider all the squaresToQueen. Otherwise consider only the squares
				  // in the pawn's path attacked or occupied by the enemy.
				  defendedSquares = unsafeSquares = squaresToQueen = GlobalMembers.forward_file_bb(Us, s);

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: bb = forward_file_bb(Them, s) & pos.pieces(ROOK, QUEEN) & pos.attacks_from<ROOK>(s);
				  bb.copyFrom(GlobalMembers.forward_file_bb(Them, s) & pos.pieces(PieceType.ROOK, PieceType.QUEEN) & pos.<PieceType.ROOK.getValue()>attacks_from(s));

				  if ((pos.pieces(Us) & bb) == null)
				  {
					  defendedSquares &= attackedBy[Us][PieceType.ALL_PIECES.getValue()];
				  }

				  if ((pos.pieces(Them) & bb) == null)
				  {
					  unsafeSquares &= attackedBy[Them.getValue()][PieceType.ALL_PIECES.getValue()] | pos.pieces(Them);
				  }

				  // If there aren't any enemy attacks, assign a big bonus. Otherwise
				  // assign a smaller bonus if the block square isn't attacked.
				  int k = unsafeSquares == null ? 20 : (unsafeSquares & blockSq) == null ? 9 : 0;

				  // If the path to the queen is fully defended, assign a big bonus.
				  // Otherwise assign a smaller bonus if the block square is defended.
				  if (defendedSquares == squaresToQueen)
				  {
					  k += 6;
				  }

				  else if (defendedSquares & blockSq)
				  {
					  k += 4;
				  }

				  bonus += GlobalMembers.make_score(k * w, k * w);
			  }
		  } // rank > RANK_3

		  // Scale down bonus for candidate passers which need more than one
		  // pawn push to become passed, or have a pawn in front of them.
		  if (!pos.pawn_passed(Us, s + Up) || (pos.pieces(PieceType.PAWN) & GlobalMembers.forward_file_bb(Us, s)) != null)
		  {
			  bonus = bonus / 2;
		  }

		  score += bonus + GlobalMembers.PassedFile[GlobalMembers.file_of(s).getValue()];
	  }

	  if (T)
	  {
		  Trace.GlobalMembers.add(PASSED, Us, score);
	  }

	  return score;
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us> Score space() const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>

	// Evaluation::space() computes the space evaluation for a given side. The
	// space evaluation is a simple bonus based on the number of safe squares
	// available for minor pieces on the central four files on ranks 2--4. Safe
	// squares one, two or three squares behind a friendly pawn are counted
	// twice. Finally, the space bonus is multiplied by a weight. The aim is to
	// improve play on game opening.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Score space() const
	private <Us> Score space()
	{

	  if (pos.non_pawn_material() < GlobalMembers.SpaceThreshold.getValue())
	  {
		  return Score.SCORE_ZERO;
	  }

	  final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	  final uint64_t SpaceMask = Us == Color.WHITE ? GlobalMembers.CenterFiles & (GlobalMembers.Rank2BB | GlobalMembers.Rank3BB | GlobalMembers.Rank4BB) : GlobalMembers.CenterFiles & (GlobalMembers.Rank7BB | GlobalMembers.Rank6BB | GlobalMembers.Rank5BB);

	  // Find the available squares for our pieces inside the area defined by SpaceMask
	  uint64_t safe = SpaceMask & ~pos.pieces(Us, PieceType.PAWN) & ~attackedBy[Them.getValue()][PieceType.PAWN.getValue()];

	  // Find all squares which are at most three squares behind some friendly pawn
	  uint64_t behind = pos.pieces(Us, PieceType.PAWN);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  behind |= (Us == Color.WHITE ? behind >> 8 : behind << 8);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  behind |= (Us == Color.WHITE ? behind >> 16 : behind << 16);

	  int bonus = GlobalMembers.popcount(new uint64_t(safe)) + GlobalMembers.popcount(behind & safe);
	  int weight = pos.<PieceType.ALL_PIECES.getValue()>count(Us) - 2 * pe.open_files();

	  Score score = GlobalMembers.make_score(bonus * weight * weight / 16, 0);

	  if (T)
	  {
		  Trace.GlobalMembers.add(SPACE, Us, score);
	  }

	  return score;
	}


	// Evaluation::scale_factor() computes the scale factor for the winning side

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor scale_factor(Value eg) const
	private ScaleFactor scale_factor(Value eg)
	{

	  Color strongSide = eg.getValue() > Value.VALUE_DRAW.getValue() ? Color.WHITE : Color.BLACK;
	  int sf = me.scale_factor(pos, strongSide).getValue();

	  // If scale is not already specific, scale down the endgame via general heuristics
	  if (sf == ScaleFactor.SCALE_FACTOR_NORMAL.getValue())
	  {
		  if (pos.opposite_bishops() && pos.non_pawn_material(Color.WHITE) == Value.BishopValueMg && pos.non_pawn_material(Color.BLACK) == Value.BishopValueMg)
		  {
			  sf = 8 + 4 * pe.pawn_asymmetry();
		  }
		  else
		  {
			  sf = Math.min(40 + (pos.opposite_bishops() ? 2 : 7) * pos.<PieceType.PAWN.getValue()>count(strongSide), sf);
		  }

	  }

	  return ScaleFactor(sf);
	}


	// Evaluation::initiative() computes the initiative correction value
	// for the position. It is a second order bonus/malus based on the
	// known attacking/defending status of the players.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Score initiative(Value eg) const
	private Score initiative(Value eg)
	{

	  int outflanking = GlobalMembers.<File>distance(pos.<PieceType.KING.getValue()>square(Color.WHITE), pos.<PieceType.KING.getValue()>square(Color.BLACK)) - GlobalMembers.<Rank>distance(pos.<PieceType.KING.getValue()>square(Color.WHITE), pos.<PieceType.KING.getValue()>square(Color.BLACK));

	  boolean pawnsOnBothFlanks = (pos.pieces(PieceType.PAWN) & GlobalMembers.QueenSide) != null && (pos.pieces(PieceType.PAWN) & GlobalMembers.KingSide) != null;

	  // Compute the initiative bonus for the attacking side
	  int complexity = 8 * pe.pawn_asymmetry() + 12 * pos.<PieceType.PAWN.getValue()>count() + 12 * outflanking + 16 * pawnsOnBothFlanks + 48 * !pos.non_pawn_material() - 118;

	  // Now apply the bonus: note that we find the attacking side by extracting
	  // the sign of the endgame value, and that we carefully cap the bonus so
	  // that the endgame score will never change sign after the bonus.
	  int v = ((eg.getValue() > 0) - (eg.getValue() < 0)) * Math.max(complexity, -Math.abs(eg));

	  if (T)
	  {
		  Trace.GlobalMembers.add(INITIATIVE, GlobalMembers.make_score(0, v));
	  }

	  return GlobalMembers.make_score(0, v);
	}

	private final Position pos;
	private Material.Entry me;
	private Pawns.Entry pe;
	private uint64_t[] mobilityArea = tangible.Arrays.initializeWithDefaultuint64_tInstances(Color.COLOR_NB.getValue());
	private Score[] mobility = {Score.SCORE_ZERO, Score.SCORE_ZERO};

	// attackedBy[color][piece type] is a bitboard representing all squares
	// attacked by a given color and piece type. Special "piece types" which
	// is also calculated is ALL_PIECES.
	private uint64_t[][] attackedBy = new uint64_t[Color.COLOR_NB.getValue()][PieceType.PIECE_TYPE_NB.getValue()];

	// attackedBy2[color] are the squares attacked by 2 pieces of a given color,
	// possibly via x-ray or by one pawn and one piece. Diagonal x-ray through
	// pawn or squares attacked by 2 pawns are not explicitly added.
	private uint64_t[] attackedBy2 = tangible.Arrays.initializeWithDefaultuint64_tInstances(Color.COLOR_NB.getValue());

	// kingRing[color] are the squares adjacent to the king, plus (only for a
	// king on its first rank) the squares two ranks in front. For instance,
	// if black's king is on g8, kingRing[BLACK] is f8, h8, f7, g7, h7, f6, g6
	// and h6. It is set to 0 when king safety evaluation is skipped.
	private uint64_t[] kingRing = tangible.Arrays.initializeWithDefaultuint64_tInstances(Color.COLOR_NB.getValue());

	// kingAttackersCount[color] is the number of pieces of the given color
	// which attack a square in the kingRing of the enemy king.
	private int[] kingAttackersCount = new int[Color.COLOR_NB.getValue()];

	// kingAttackersWeight[color] is the sum of the "weights" of the pieces of
	// the given color which attack a square in the kingRing of the enemy king.
	// The weights of the individual piece types are given by the elements in
	// the KingAttackWeights array.
	private int[] kingAttackersWeight = new int[Color.COLOR_NB.getValue()];

	// kingAttacksCount[color] is the number of attacks by the given color to
	// squares directly adjacent to the enemy king. Pieces which attack more
	// than one square are counted multiple times. For instance, if there is
	// a white knight on g5 and black's king is on g8, this white knight adds 2
	// to kingAttacksCount[WHITE].
	private int[] kingAttacksCount = new int[Color.COLOR_NB.getValue()];
  }