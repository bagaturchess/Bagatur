package Trace;

public class GlobalMembers
{
  public static Score[][] scores = new Score[Term.TERM_NB.getValue()][Color.COLOR_NB.getValue()];

  public static double to_cp(Value v)
  {
	  return (double)v.getValue() / Value.PawnValueEg;
  }

  public static void add(int idx, Color c, Score s)
  {
	scores[idx][c.getValue()] = s;
  }
  public static void add(int idx, Score w)
  {
	  add(idx, w, Score.SCORE_ZERO);
  }

//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: void add(int idx, Score w, Score b = SCORE_ZERO)
  public static void add(int idx, Score w, Score b)
  {
	scores[idx][Color.WHITE.getValue()] = w;
	scores[idx][Color.BLACK.getValue()] = b;
  }

  private std::ostream leftShift(std::ostream os, Score s)
  {
	os << std::setw(5) << to_cp(GlobalMembers.mg_value(s)) << " " << std::setw(5) << to_cp(GlobalMembers.eg_value(s));
	return os;
  }

  private std::ostream leftShift(std::ostream os, Term t)
  {

	if (t == Term.MATERIAL || t == Term.IMBALANCE || t == Term.INITIATIVE || t == Term.TOTAL)
	{
		os << " ----  ----" << " | " << " ----  ----";
	}
	else
	{
		os << scores[t.getValue()][Color.WHITE.getValue()].getValue() << " | " << scores[t.getValue()][Color.BLACK.getValue()].getValue();
	}

	os << " | " << scores[t.getValue()][Color.WHITE.getValue()].getValue() - scores[t.getValue()][Color.BLACK.getValue()].getValue() << "\n";
	return os;
  }
}