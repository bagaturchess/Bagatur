public class MoveList<T>
{

  public MoveList(Position pos)
  {
	  this.last = GlobalMembers.<T>generate(pos, moveList);
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: const ExtMove* begin() const
  public final ExtMove begin()
  {
	  return moveList;
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: const ExtMove* end() const
  public final ExtMove end()
  {
	  return last;
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: size_t size() const
  public final size_t size()
  {
	  return last - moveList;
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean contains(Move move) const
  public final boolean contains(Move move)
  {
	return std::find(begin(), end(), move) != end();
  }

  private ExtMove[] moveList = tangible.Arrays.initializeWithDefaultExtMoveInstances(MAX_MOVES);
  private ExtMove last;
}
//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us, CastlingSide Cs, bool Checks, bool Chess960>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename Us, CastlingSide Cs, boolean Checks, boolean Chess960>