package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

// Possible states after a probing operation
public enum ProbeState
{
	FAIL(0), // Probe failed (missing file table)
	OK(1), // Probe succesful
	CHANGE_STM(-1), // DTZ should check the other side
	ZEROING_BEST_MOVE(2); // Best move zeroes DTZ (capture or pawn move)

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, ProbeState> mappings;
	private static java.util.HashMap<Integer, ProbeState> getMappings()
	{
		if (mappings == null)
		{
			synchronized (ProbeState.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, ProbeState>();
				}
			}
		}
		return mappings;
	}

	private ProbeState(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static ProbeState forValue(int value)
	{
		return getMappings().get(value);
	}
}