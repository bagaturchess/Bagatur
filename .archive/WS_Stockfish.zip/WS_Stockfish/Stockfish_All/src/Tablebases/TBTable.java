package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

// struct TBTable contains indexing information to access the corresponding TBFile.
// There are 2 types of TBTable, corresponding to a WDL or a DTZ file. TBTable
// is populated at init time but the nested PairsData records are populated at
// first access, when the corresponding file is memory mapped.
//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<TBType Type>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Type>
public class TBTable<Type> implements Closeable
{
//C++ TO JAVA CONVERTER TODO TASK: Conditional typedefs are not handled by C++ to Java Converter:
//    typedef typename std::conditional<Type == WDL, WDLScore, int>::type Ret;

//C++ TO JAVA CONVERTER TODO TASK: Java does not allow bit fields:
	public static constexpr int Sides = Type == TBType.WDL ? 2 : 1;

	public std::atomic_bool ready = new std::atomic_bool();
	public Object baseAddress;
	public uint8_t[] map;
	public uint64_t mapping = new uint64_t();
	public Key key = new Key();
	public Key key2 = new Key();
	public int pieceCount;
	public boolean hasPawns;
	public boolean hasUniquePieces;
	public uint8_t[] pawnCount = tangible.Arrays.initializeWithDefaultuint8_tInstances(2); // [Lead color / other color]
	public PairsData[][] items = new PairsData[Sides][4]; // [wtm / btm][FILE_A..FILE_D or 0]

	public final PairsData get(int stm, int f)
	{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return &items[stm % Sides][hasPawns ? f : 0];
		return new PairsData(items[stm % Sides][hasPawns ? f : 0]);
	}

	public TBTable()
	{
		this.ready = false;
		this.baseAddress = null;
	}
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	TBTable(String code);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	TBTable(TBTable<WDL> wdl);

	public final void close()
	{
		if (baseAddress)
		{
			TBFile.unmap(baseAddress, new uint64_t(mapping));
		}
	}
}