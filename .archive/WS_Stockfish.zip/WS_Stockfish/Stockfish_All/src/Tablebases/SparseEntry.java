package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

//C++ TO JAVA CONVERTER TODO TASK: Unions are not supported in Java:
//static const union

// Numbers in little endian used by sparseIndex[] to point into blockLength[]
public class SparseEntry
{
	public String block = new String(new char[4]); // Number of block
	public String offset = new String(new char[2]); // Offset within the block
}