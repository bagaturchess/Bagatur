package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

//C++ TO JAVA CONVERTER NOTE: Enums must be named in Java, so the following enum has been named by the converter:
public enum AnonymousEnum2
{
	Split(1),
	HasPawns(2);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, AnonymousEnum2> mappings;
	private static java.util.HashMap<Integer, AnonymousEnum2> getMappings()
	{
		if (mappings == null)
		{
			synchronized (AnonymousEnum2.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, AnonymousEnum2>();
				}
			}
		}
		return mappings;
	}

	private AnonymousEnum2(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static AnonymousEnum2 forValue(int value)
	{
		return getMappings().get(value);
	}
}