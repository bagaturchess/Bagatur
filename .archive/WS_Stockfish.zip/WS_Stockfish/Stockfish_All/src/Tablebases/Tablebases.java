package Tablebases;
import java.util.*;

public class Tablebases
{
	public void rank_root_moves(Position pos, Search.RootMoves rootMoves)
	{
    
		GlobalMembers.RootInTB = false;
		GlobalMembers.UseRule50 = (boolean)Options["Syzygy50MoveRule"];
		GlobalMembers.ProbeDepth = (int)Options["SyzygyProbeDepth"] * Depth.ONE_PLY;
		GlobalMembers.Cardinality = (int)Options["SyzygyProbeLimit"];
		boolean dtz_available = true;
    
		// Tables with fewer pieces than SyzygyProbeLimit are searched with
		// ProbeDepth == DEPTH_ZERO
		if (GlobalMembers.Cardinality > MaxCardinality)
		{
			GlobalMembers.Cardinality = MaxCardinality;
			GlobalMembers.ProbeDepth = Depth.DEPTH_ZERO;
		}
    
		if (GlobalMembers.Cardinality >= popcount(pos.pieces()) && pos.can_castle(CastlingRight.ANY_CASTLING) == 0)
		{
			// Rank moves using DTZ tables
			GlobalMembers.RootInTB = root_probe(pos, rootMoves);
    
			if (!GlobalMembers.RootInTB)
			{
				// DTZ tables are missing; try to rank moves using WDL tables
				dtz_available = false;
				GlobalMembers.RootInTB = root_probe_wdl(pos, rootMoves);
			}
		}
    
		if (GlobalMembers.RootInTB)
		{
			// Sort moves according to TB rank
			std::sort(rootMoves.begin(), rootMoves.end(), (RootMove a, RootMove b) ->
			{
				return a.tbRank > b.tbRank;
			});
    
			// Probe during search only if DTZ is not available and we are winning
			if (dtz_available || rootMoves[0].tbScore <= Value.VALUE_DRAW.getValue())
			{
				GlobalMembers.Cardinality = 0;
			}
		}
		else
		{
			// Assign the same rank to all moves
	//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
			for (auto m : rootMoves)
			{
				m.tbRank = 0;
			}
		}
	}
}