package Tablebases;
import java.util.*;

public class Thread
{
	public void search()
	{
    
	  Stack[] stack = tangible.Arrays.initializeWithDefaultStackInstances(MAX_PLY + 7); // To reference from (ss-4) to (ss+2)
	  Stack ss = stack + 4;
	  Value bestValue;
	  Value alpha;
	  Value beta;
	  Value delta;
	  Move lastBestMove = Move.MOVE_NONE;
	  Depth lastBestMoveDepth = Depth.DEPTH_ZERO;
	  MainThread mainThread = (this == Threads.main() ? Threads.main() : null);
	  double timeReduction = 1.0;
	  Color us = rootPos.side_to_move();
	  boolean failedLow;
    
	//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	  memset(ss - 4, 0, 7 * sizeof(Stack));
	  for (int i = 4; i > 0; i--)
	  {
		 (ss - i).continuationHistory = &this.continuationHistory[Piece.NO_PIECE.getValue()][0]; // Use as sentinel
	  }
    
	  bestValue = delta = alpha = -Value.VALUE_INFINITE;
	  beta = Value.VALUE_INFINITE;
    
	  if (mainThread != null)
	  {
		  mainThread.bestMoveChanges = 0, failedLow = false;
	  }
    
	  int multiPV = Options["MultiPV"];
	  Skill skill = new Skill(Options["Skill Level"]);
    
	  // When playing with strength handicap enable MultiPV search that we will
	  // use behind the scenes to retrieve a set of possible moves.
	  if (skill.enabled())
	  {
		  multiPV = Math.max(multiPV, (int)4);
	  }
    
	  multiPV = Math.min(multiPV, rootMoves.size());
    
	  int ct = (int)Options["Contempt"] * Value.PawnValueEg / 100; // From centipawns
    
	  // In analysis mode, adjust contempt in accordance with user preference
	  if (GlobalMembers.Limits.infinite != 0 || Options["UCI_AnalyseMode"])
	  {
		  ct = Options["Analysis Contempt"].equals("Off") ? 0 : Options["Analysis Contempt"].equals("Both") ? ct : Options["Analysis Contempt"].equals("White") && us == Color.BLACK ? -ct : Options["Analysis Contempt"].equals("Black") && us == Color.WHITE ? -ct : ct;
	  }
    
	  // In evaluate.cpp the evaluation is from the white point of view
	  contempt = (us == Color.WHITE ? make_score(ct, ct / 2) : -make_score(ct, ct / 2));
    
	  // Iterative deepening loop until requested to stop or the target depth is reached
	  while ((rootDepth += Depth.ONE_PLY) < Depth.DEPTH_MAX.getValue() && !Threads.stop && !(GlobalMembers.Limits.depth != 0 && mainThread != null && rootDepth / Depth.ONE_PLY.getValue() > GlobalMembers.Limits.depth))
	  {
		  // Distribute search depths across the helper threads
		  if (idx > 0)
		  {
			  int i = (idx - 1) % 20;
			  if (((rootDepth / Depth.ONE_PLY + SkipPhase[i]) / SkipSize[i]) % 2)
			  {
				  continue; // Retry with an incremented rootDepth
			  }
		  }
    
		  // Age out PV variability metric
		  if (mainThread != null)
		  {
			  mainThread.bestMoveChanges *= 0.517, failedLow = false;
		  }
    
		  // Save the last iteration's scores before first PV line is searched and
		  // all the move scores except the (new) PV are set to -VALUE_INFINITE.
		  for (RootMove rm : rootMoves)
		  {
			  rm.previousScore = rm.score;
		  }
    
		  int pvFirst = 0;
		  pvLast = 0;
    
		  // MultiPV loop. We perform a full root search for each PV line
		  for (pvIdx = 0; pvIdx < multiPV && !Threads.stop; ++pvIdx)
		  {
			  if (pvIdx == pvLast)
			  {
				  pvFirst = pvLast;
				  for (pvLast++; pvLast < rootMoves.size(); pvLast++)
				  {
					  if (rootMoves[pvLast].tbRank != rootMoves[pvFirst].tbRank)
					  {
						  break;
					  }
				  }
			  }
    
			  // Reset UCI info selDepth for each depth and each PV line
			  selDepth = 0;
    
			  // Reset aspiration window starting size
			  if (rootDepth >= 5 * Depth.ONE_PLY)
			  {
				  Value previousScore = rootMoves[pvIdx].previousScore;
				  delta = Value(20);
				  alpha = Math.max(previousScore - delta,-Value.VALUE_INFINITE);
				  beta = Math.min(previousScore + delta, Value.VALUE_INFINITE);
    
				  // Adjust contempt based on root move's previousScore (dynamic contempt)
				  int dct = ct + 88 * previousScore / (Math.abs(previousScore) + 200);
    
				  contempt = (us == Color.WHITE ? make_score(dct, dct / 2) : -make_score(dct, dct / 2));
			  }
    
			  // Start with a small aspiration window and, in the case of a fail
			  // high/low, re-search with a bigger window until we don't fail
			  // high/low anymore.
			  int failedHighCnt = 0;
			  while (true)
			  {
				  Depth adjustedDepth = Math.max(Depth.ONE_PLY, rootDepth - failedHighCnt * Depth.ONE_PLY.getValue());
				  bestValue = GlobalMembers.<NodeType.PV.getValue()>search(rootPos, ss, alpha, beta, adjustedDepth, false);
    
				  // Bring the best move to the front. It is critical that sorting
				  // is done with a stable algorithm because all the values but the
				  // first and eventually the new best one are set to -VALUE_INFINITE
				  // and we want to keep the same order for all the moves except the
				  // new PV that goes to the front. Note that in case of MultiPV
				  // search the already searched PV lines are preserved.
				  std::stable_sort(rootMoves.begin() + pvIdx, rootMoves.begin() + pvLast);
    
				  // If search has been stopped, we break immediately. Sorting is
				  // safe because RootMoves is still valid, although it refers to
				  // the previous iteration.
				  if (Threads.stop)
				  {
					  break;
				  }
    
				  // When failing high/low give some update (without cluttering
				  // the UI) before a re-search.
				  if (mainThread != null && multiPV == 1 && (bestValue.getValue() <= alpha.getValue() || bestValue.getValue() >= beta.getValue()) && Time.elapsed() > 3000)
				  {
					  System.out.print(SyncCout.IO_LOCK);
					  System.out.print(UCI.GlobalMembers.pv(rootPos, rootDepth, alpha, beta));
					  System.out.print("\n");
					  System.out.print(SyncCout.IO_UNLOCK);
				  }
    
				  // In case of failing low/high increase aspiration window and
				  // re-search, otherwise exit the loop.
				  if (bestValue.getValue() <= alpha.getValue())
				  {
					  beta = (alpha + beta) / 2;
					  alpha = Math.max(bestValue - delta, -Value.VALUE_INFINITE);
    
					  if (mainThread != null)
					  {
						  failedHighCnt = 0;
						  failedLow = true;
						  Threads.stopOnPonderhit = false;
					  }
				  }
				  else if (bestValue.getValue() >= beta.getValue())
				  {
					  beta = Math.min(bestValue + delta, Value.VALUE_INFINITE);
					  if (mainThread != null)
					  {
						  ++failedHighCnt;
					  }
				  }
				  else
				  {
					  break;
				  }
    
				  delta += delta / 4 + 5;
    
				  assert alpha.getValue() >= -Value.VALUE_INFINITE && beta.getValue() <= Value.VALUE_INFINITE.getValue();
			  }
    
			  // Sort the PV lines searched so far and update the GUI
			  std::stable_sort(rootMoves.begin() + pvFirst, rootMoves.begin() + pvIdx + 1);
    
			  if (mainThread != null && (Threads.stop || pvIdx + 1 == multiPV || Time.elapsed() > 3000))
			  {
				  System.out.print(SyncCout.IO_LOCK);
				  System.out.print(UCI.GlobalMembers.pv(rootPos, rootDepth, alpha, beta));
				  System.out.print("\n");
				  System.out.print(SyncCout.IO_UNLOCK);
			  }
		  }
    
		  if (!Threads.stop)
		  {
			  completedDepth = rootDepth;
		  }
    
		  if (rootMoves[0].pv[0] != lastBestMove)
		  {
			 lastBestMove = rootMoves[0].pv[0];
			 lastBestMoveDepth = rootDepth;
		  }
    
		  // Have we found a "mate in x"?
		  if (GlobalMembers.Limits.mate != 0 && bestValue.getValue() >= Value.VALUE_MATE_IN_MAX_PLY.getValue() && Value.VALUE_MATE - bestValue.getValue() <= 2 * GlobalMembers.Limits.mate.getValue() != 0)
		  {
			  Threads.stop = true;
		  }
    
		  if (mainThread == null)
		  {
			  continue;
		  }
    
		  // If skill level is enabled and time is up, pick a sub-optimal best move
		  if (skill.enabled() && skill.time_to_pick(rootDepth))
		  {
			  skill.pick_best(multiPV);
		  }
    
		  // Do we have time for the next iteration? Can we stop searching now?
		  if (GlobalMembers.Limits.use_time_management() && !Threads.stop && !Threads.stopOnPonderhit)
		  {
				  final int[] F = {failedLow, bestValue.getValue() - mainThread - >previousScore};
    
				  int improvingFactor = Math.max(246, Math.min(832, 306 + 119 * F[0] - 6 * F[1]));
    
				  // If the bestMove is stable over several iterations, reduce time accordingly
				  timeReduction = 1.0;
				  for (int i : {3, 4, 5})
				  {
					  if (lastBestMoveDepth * i < completedDepth.getValue() != 0)
					  {
						 timeReduction *= 1.25;
					  }
				  }
    
				  // Use part of the gained time from a previous stable move for the current move
				  double bestMoveInstability = 1.0 + mainThread.bestMoveChanges;
				  bestMoveInstability *= Math.pow(mainThread.previousTimeReduction, 0.528) / timeReduction;
    
				  // Stop the search if we have only one legal move, or if available time elapsed
				  if (rootMoves.size() == 1 || Time.elapsed() > Time.optimum() * bestMoveInstability * improvingFactor / 581)
				  {
					  // If we are allowed to ponder do not stop the search now but
					  // keep pondering until the GUI sends "ponderhit" or "stop".
					  if (Threads.ponder)
					  {
						  Threads.stopOnPonderhit = true;
					  }
					  else
					  {
						  Threads.stop = true;
					  }
				  }
		  }
	  }
    
	  if (mainThread == null)
	  {
		  return;
	  }
    
	  mainThread.previousTimeReduction = timeReduction;
    
	  // If skill level is enabled, swap best PV line with the sub-optimal one
	  if (skill.enabled())
	  {
		  std::swap(rootMoves[0], *std::find(rootMoves.begin(), rootMoves.end(), skill.best.getValue() != 0 ? skill.best : skill.pick_best(multiPV)));
	  }
	}
}