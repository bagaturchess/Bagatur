package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

// class TBTables creates and keeps ownership of the TBTable objects, one for
// each TB file found. It supports a fast, hash based, table lookup. Populated
// at init time, accessed at probe time.
public class TBTables
{


	private static final int Size = 1 << 12; // 4K table, indexed by key's 12 lsb
	private static final int Overflow = 1; // Number of elements allowed to map to the last bucket

	private std::tuple<Key, TBTable<TBType.WDL>, TBTable<TBType.DTZ>>[] hashTable = tangible.Arrays.initializeWithDefaulttupleInstances(Size + Overflow);

	private LinkedList<TBTable<TBType.WDL>> wdlTable = new LinkedList<TBTable<TBType.WDL.getValue()>>();
	private LinkedList<TBTable<TBType.DTZ>> dtzTable = new LinkedList<TBTable<TBType.DTZ.getValue()>>();

	private void insert(Key key, TBTable<TBType.WDL> wdl, TBTable<TBType.DTZ> dtz)
	{
		uint32_t homeBucket = (uint32_t)key & (Size - 1);
		std::tuple<Key, TBTable<TBType.WDL>, TBTable<TBType.DTZ>> entry = std::make_tuple(key, wdl, dtz);

		// Ensure last element is empty to avoid overflow when looking up
		for (uint32_t bucket = homeBucket; bucket < Size + Overflow - 1; ++bucket)
		{
			Key otherKey = std::get<TBType.KEY.getValue()>(hashTable[bucket]);
			if (otherKey == key || !std::get<TBType.WDL.getValue()>(hashTable[bucket]))
			{
				hashTable[bucket] = entry;
				return;
			}

			// Robin Hood hashing: If we've probed for longer than this element,
			// insert here and search for a new spot for the other element instead.
			uint32_t otherHomeBucket = (uint32_t)otherKey & (Size - 1);
			if (otherHomeBucket > homeBucket)
			{
				swap(entry, hashTable[bucket]);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: key = otherKey;
				key.copyFrom(otherKey);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: homeBucket = otherHomeBucket;
				homeBucket.copyFrom(otherHomeBucket);
			}
		}
		std::cerr << "TB hash table size too low!" << std::endl;
		System.exit(1);
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<TBType Type>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Type>
	public final <Type> TBTable<Type> get(Key key)
	{
		for (const std::tuple<Key, TBTable<TBType.WDL.getValue()>, TBTable<TBType.DTZ.getValue()>> entry = hashTable[(uint32_t)key & (Size - 1)]; ; ++entry)
		{
			if (std::get<TBType.KEY.getValue()>(entry) == key || !std::get<Type>(entry))
			{
				return std::get<Type>(entry);
			}
		}
	}

	public final void clear()
	{
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
		memset(hashTable, 0, sizeof(hashTable));
		wdlTable.clear();
		dtzTable.clear();
	}
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: size_t size() const
	public final size_t size()
	{
		return wdlTable.size();
	}

	// If the corresponding file exists two new objects TBTable<WDL> and TBTable<DTZ>
	// are created and added to the lists and hash table. Called at init time.
	public final void add(ArrayList<PieceType> pieces)
	{

		String code;

		for (PieceType pt : pieces)
		{
			code += GlobalMembers.PieceToChar.charAt(pt);
		}

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to the standard string 'insert' method in Java if it's used as an rvalue:
		TBFile file = new TBFile(code.insert(code.indexOf('K', 1), "v") + ".rtbw"); // KRK -> KRvK

		if (!file.is_open()) // Only WDL file is checked
		{
			return;
		}

		file.close();

		GlobalMembers.MaxCardinality = Math.max((int)pieces.size(), GlobalMembers.MaxCardinality);

		wdlTable.emplace_back(code);
		dtzTable.emplace_back(wdlTable.getLast());

		// Insert into the hash keys for both colors: KRvK with KR white and black
		insert(wdlTable.getLast().key, wdlTable.getLast(), dtzTable.getLast());
		insert(wdlTable.getLast().key2, wdlTable.getLast(), dtzTable.getLast());
	}
}