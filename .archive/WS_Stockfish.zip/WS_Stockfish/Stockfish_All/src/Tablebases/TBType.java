package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

public enum TBType
{
	KEY,
	WDL,
	DTZ;

	public static final int SIZE = java.lang.Integer.SIZE;

	public int getValue()
	{
		return this.ordinal();
	}

	public static TBType forValue(int value)
	{
		return values()[value];
	}
} // Used as template parameter