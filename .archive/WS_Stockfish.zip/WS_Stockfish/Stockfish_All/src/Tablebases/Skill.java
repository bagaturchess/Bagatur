package Tablebases;
import java.util.*;

  // Skill structure is used to implement strength limit
  public class Skill
  {
	public Skill(int l)
	{
		this.level = l;
	}
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean enabled() const
	public final boolean enabled()
	{
		return level < 20;
	}
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean time_to_pick(Depth depth) const
	public final boolean time_to_pick(Depth depth)
	{
		return depth / Depth.ONE_PLY == 1 + level.getValue() != 0;
	}

	// When playing with strength handicap, choose best move among a set of RootMoves
	// using a statistical rule dependent on 'level'. Idea by Heinz van Saanen.

//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	PRNG pick_best_rng(now() UnnamedParameter);

	public final Move pick_best(int multiPV)
	{

  //C++ TO JAVA CONVERTER TODO TASK: The typedef 'RootMoves' was defined in multiple preprocessor conditionals and cannot be replaced in-line:
	  final RootMoves rootMoves = Threads.main().rootMoves;
//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
//	  static PRNG rng(now()); // PRNG sequence should be non-deterministic

	  // RootMoves are already sorted by score in descending order
	  Value topScore = rootMoves[0].score;
	  int delta = Math.min(topScore - rootMoves[multiPV - 1].score, Value.PawnValueMg);
	  int weakness = 120 - 2 * level;
	  int maxScore = -Value.VALUE_INFINITE.getValue();

	  // Choose best move. For each move score we add two terms, both dependent on
	  // weakness. One is deterministic and bigger for weaker levels, and one is
	  // random. Then we choose the move with the resulting highest score.
	  for (int i = 0; i < multiPV; ++i)
	  {
		  // This is our magic formula
		  int push = (weakness * (int)(topScore - rootMoves[i].score) + delta * (pick_best_rng.<Integer>rand() % weakness)) / 128;

		  if (rootMoves[i].score + push >= maxScore)
		  {
			  maxScore = rootMoves[i].score + push;
			  best = rootMoves[i].pv[0];
		  }
	  }

	  return best;
	}

	public int level;
	public Move best = Move.MOVE_NONE;
  }