package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

// Each table has a set of flags: all of them refer to DTZ tables, the last one to WDL tables
public enum TBFlag
{
	STM(1),
	Mapped(2),
	WinPlies(4),
	LossPlies(8),
	Wide(16),
	SingleValue(128);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, TBFlag> mappings;
	private static java.util.HashMap<Integer, TBFlag> getMappings()
	{
		if (mappings == null)
		{
			synchronized (TBFlag.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, TBFlag>();
				}
			}
		}
		return mappings;
	}

	private TBFlag(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static TBFlag forValue(int value)
	{
		return getMappings().get(value);
	}
}