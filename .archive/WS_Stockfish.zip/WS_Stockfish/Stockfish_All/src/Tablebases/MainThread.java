package Tablebases;
import java.util.*;

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template <NodeType NT>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template <typename NT>



/// MainThread::search() is called by the main thread when the program receives
/// the UCI 'go' command. It searches from the root position and outputs the "bestmove".

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: void MainThread::search()


/// Thread::search() is the main iterative deepening loop. It calls search()
/// repeatedly with increasing depth until the allocated thinking time has been
/// consumed, the user stops the search, or the maximum search depth is reached.

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: void Thread::search()

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: void MainThread::check_time()


/// UCI::pv() formats PV information according to the UCI protocol. UCI requires
/// that all (if any) unsearched PV lines are sent using a previous search score.

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: String UCI::pv(const Position& pos, Depth depth, Value alpha, Value beta)


/// RootMove::extract_ponder_from_tt() is called in case we have no ponder move
/// before exiting the search, for instance, in case we stop the search during a
/// fail high at root. We try hard to have a ponder move to return to the GUI,
/// otherwise in case of 'ponder on' we have nothing to think on.

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: boolean RootMove::extract_ponder_from_tt(Position& pos)

//C++ TO JAVA CONVERTER TODO TASK: The typedef 'RootMoves' was defined in multiple preprocessor conditionals and cannot be replaced in-line:
//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: void Tablebases::rank_root_moves(Position& pos, Search::RootMoves& rootMoves)


public class MainThread
{
	public void search()
	{
    
	  if (GlobalMembers.Limits.perft != 0)
	  {
		  nodes = GlobalMembers.<true>perft(rootPos, GlobalMembers.Limits.perft * Depth.ONE_PLY.getValue());
		  System.out.print(SyncCout.IO_LOCK);
		  System.out.print("\nNodes searched: ");
		  System.out.print(nodes);
		  System.out.print("\n");
		  System.out.print("\n");
		  System.out.print(SyncCout.IO_UNLOCK);
		  return;
	  }
    
	  Color us = rootPos.side_to_move();
	  Time.init(GlobalMembers.Limits, us, rootPos.game_ply());
	  TT.new_search();
    
	  if (rootMoves.empty())
	  {
		  rootMoves.emplace_back(Move.MOVE_NONE);
		  System.out.print(SyncCout.IO_LOCK);
		  System.out.print("info depth 0 score ");
		  System.out.print(UCI.value(rootPos.checkers() ? -Value.VALUE_MATE : Value.VALUE_DRAW));
		  System.out.print("\n");
		  System.out.print(SyncCout.IO_UNLOCK);
	  }
	  else
	  {
		  for (Thread th : Threads)
		  {
			  if (th != this)
			  {
				  th.start_searching();
			  }
		  }
    
		  Thread.search(); // Let's start searching!
	  }
    
	  // When we reach the maximum depth, we can arrive here without a raise of
	  // Threads.stop. However, if we are pondering or in an infinite search,
	  // the UCI protocol states that we shouldn't print the best move before the
	  // GUI sends a "stop" or "ponderhit" command. We therefore simply wait here
	  // until the GUI sends one of those commands (which also raises Threads.stop).
	  Threads.stopOnPonderhit = true;
    
	  while (!Threads.stop && (Threads.ponder || GlobalMembers.Limits.infinite != 0))
	  {
	  } // Busy wait for a stop or a ponder reset
    
	  // Stop the threads if not already stopped (also raise the stop if
	  // "ponderhit" just reset Threads.ponder).
	  Threads.stop = true;
    
	  // Wait until all threads have finished
	  for (Thread th : Threads)
	  {
		  if (th != this)
		  {
			  th.wait_for_search_finished();
		  }
	  }
    
	  // When playing in 'nodes as time' mode, subtract the searched nodes from
	  // the available ones before exiting.
	  if (GlobalMembers.Limits.npmsec != null)
	  {
		  Time.availableNodes += GlobalMembers.Limits.inc[us.getValue()] - Threads.nodes_searched();
	  }
    
	  // Check if there are threads with a better score than main thread
	  Thread bestThread = this;
	  if (Options["MultiPV"] == 1 && GlobalMembers.Limits.depth == 0 && new Skill(Options["Skill Level"]).enabled() == null && rootMoves[0].pv[0] != Move.MOVE_NONE)
	  {
		  TreeMap<Move, Integer> votes = new TreeMap<Move, Integer>();
		  Value minScore = this.rootMoves[0].score;
    
		  // Find out minimum score and reset votes for moves which can be voted
		  for (Thread th : Threads)
		  {
			  minScore = Math.min(minScore, th.rootMoves.get(0).score);
			  votes.put(th.rootMoves.get(0).pv.get(0).getValue(), 0);
		  }
    
		  // Vote according to score and depth
		  for (Thread th : Threads)
		  {
			  votes.put(th.rootMoves.get(0).pv.get(0).getValue(), votes.put(th.rootMoves.get(0).pv.get(0).getValue()) + (int)(th.rootMoves.get(0).score - minScore) + th.completedDepth.getValue());
		  }
    
		  // Select best thread
		  int bestVote = votes.get(this.rootMoves[0].pv[0]);
		  for (Thread th : Threads)
		  {
			  if (votes.get(th.rootMoves.get(0).pv.get(0).getValue()) > bestVote)
			  {
				  bestVote = votes.get(th.rootMoves.get(0).pv.get(0).getValue());
				  bestThread = th;
			  }
		  }
	  }
    
	  previousScore = bestThread.rootMoves.get(0).score;
    
	  // Send again PV info if we have a new best thread
	  if (bestThread != this)
	  {
		  System.out.print(SyncCout.IO_LOCK);
		  System.out.print(UCI.GlobalMembers.pv(bestThread.rootPos, bestThread.completedDepth, -Value.VALUE_INFINITE, Value.VALUE_INFINITE));
		  System.out.print("\n");
		  System.out.print(SyncCout.IO_UNLOCK);
	  }
    
	  System.out.print(SyncCout.IO_LOCK);
	  System.out.print("bestmove ");
	  System.out.print(UCI.move(bestThread.rootMoves.get(0).pv.get(0), rootPos.is_chess960()));
    
	  if (bestThread.rootMoves.get(0).pv.size() > 1 || bestThread.rootMoves.get(0).extract_ponder_from_tt(rootPos))
	  {
		  System.out.print(" ponder ");
		  System.out.print(UCI.move(bestThread.rootMoves.get(0).pv.get(1), rootPos.is_chess960()));
	  }
    
	  System.out.print("\n");
	  System.out.print(SyncCout.IO_UNLOCK);
	}
	public void check_time()
	{
    
	  if (--callsCnt > 0)
	  {
		  return;
	  }
    
	  // When using nodes, ensure checking rate is not lower than 0.1% of nodes
	  callsCnt = GlobalMembers.Limits.nodes != 0 ? Math.min(1024, (int)(GlobalMembers.Limits.nodes / 1024)) : 1024;
    
	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//  static std::chrono::milliseconds::rep lastInfoTime = now();
    
	  std::chrono.milliseconds.rep elapsed = Time.elapsed();
	  std::chrono.milliseconds.rep tick = GlobalMembers.Limits.startTime + elapsed;
    
	  if (tick - check_time_lastInfoTime >= 1000 != null)
	  {
		  check_time_lastInfoTime = tick;
		  dbg_print();
	  }
    
	  // We should not stop pondering until told so by the GUI
	  if (Threads.ponder)
	  {
		  return;
	  }
    
	  if ((GlobalMembers.Limits.use_time_management() && elapsed > Time.maximum() - 10) || (GlobalMembers.Limits.movetime && elapsed >= GlobalMembers.Limits.movetime) || (GlobalMembers.Limits.nodes && Threads.nodes_searched() >= (long)GlobalMembers.Limits.nodes))
	  {
		  Threads.stop = true;
	  }
	}
}