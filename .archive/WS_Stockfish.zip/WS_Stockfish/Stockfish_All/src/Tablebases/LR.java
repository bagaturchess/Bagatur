package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'static_assert':
//static_assert(sizeof(SparseEntry) == 6, "SparseEntry must be 6 bytes");


public class LR
{
	public enum Side
	{
		Left,
		Right;

		public static final int SIZE = java.lang.Integer.SIZE;

		public int getValue()
		{
			return this.ordinal();
		}

		public static Side forValue(int value)
		{
			return values()[value];
		}
	}

	public uint8_t[] lr = tangible.Arrays.initializeWithDefaultuint8_tInstances(3); // The first 12 bits is the left-hand symbol, the second 12
				   // bits is the right-hand symbol. If symbol has length 1,
				   // then the left-hand symbol is the stored value.
//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Side S>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename S>
	public final <S> uint16_t get()
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		return S == Side.Left ? ((lr[1] & 0xF) << 8) | lr[0] : S == Side.Right ? (lr[2] << 4) | (lr[1] >> 4) : (assert_Renamed(false), Sym(-1));
	}
}