package Tablebases;
import java.util.*;

//C++ TO JAVA CONVERTER TODO TASK: The following package should be saved to a separate file:

//C++ TO JAVA CONVERTER TODO TASK: The following package should be saved to a separate file:


//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to C++ namespace aliases:
//namespace TB = Tablebases;


  // Different node types, used as a template parameter
  public enum NodeType
  {
	  NonPV,
	  PV;

	  public static final int SIZE = java.lang.Integer.SIZE;

	  public int getValue()
	  {
		  return this.ordinal();
	  }

	  public static NodeType forValue(int value)
	  {
		  return values()[value];
	  }
  }