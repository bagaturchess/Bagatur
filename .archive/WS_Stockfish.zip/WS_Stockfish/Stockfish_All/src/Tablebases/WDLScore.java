package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (c) 2013 Ronald de Man
  Copyright (C) 2016-2018 Marco Costalba, Lucas Braesch

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/



/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (c) 2013 Ronald de Man
  Copyright (C) 2016-2018 Marco Costalba, Lucas Braesch

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/





public enum WDLScore
{
	WDLLoss(-2), // Loss
	WDLBlessedLoss(-1), // Loss, but draw under 50-move rule
	WDLDraw(0), // Draw
	WDLCursedWin(1), // Win, but draw under 50-move rule
	WDLWin(2), // Win

	WDLScoreNone(-1000);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, WDLScore> mappings;
	private static java.util.HashMap<Integer, WDLScore> getMappings()
	{
		if (mappings == null)
		{
			synchronized (WDLScore.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, WDLScore>();
				}
			}
		}
		return mappings;
	}

	private WDLScore(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static WDLScore forValue(int value)
	{
		return getMappings().get(value);
	}
}