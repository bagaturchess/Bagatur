import java.util.*;

package Tablebases;

public class GlobalMembers
{
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
//	extern int MaxCardinality;

	/// Tablebases::init() is called at startup and after every change to
	/// "SyzygyPath" UCI option to (re)create the various tables. It is not thread
	/// safe, nor it needs to be.

	public static void init(String paths)
	{

		GlobalMembers.TBTables.clear();
		MaxCardinality = 0;
		TBFile.Paths = paths;

		if (paths.length() == 0 || paths.equals("<empty>"))
		{
			return;
		}

		// MapB1H1H7[] encodes a square below a1-h8 diagonal to 0..27
		int code = 0;
		for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
		{
			if (GlobalMembers.off_A1H8(s) < 0)
			{
				GlobalMembers.MapB1H1H7[s.getValue()] = code++;
			}
		}

		// MapA1D1D4[] encodes a square in the a1-d1-d4 triangle to 0..9
		ArrayList<Square> diagonal = new ArrayList<Square>();
		code = 0;
		for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_D4.getValue(); ++s)
		{
			if (GlobalMembers.off_A1H8(s) < 0 && GlobalMembers.file_of(s) <= File.FILE_D.getValue())
			{
				GlobalMembers.MapA1D1D4[s.getValue()] = code++;
			}

			else if (!GlobalMembers.off_A1H8(s) && GlobalMembers.file_of(s) <= File.FILE_D.getValue())
			{
				diagonal.add(s);
			}
		}

		// Diagonal squares are encoded as last ones
		for (Square s : diagonal)
		{
			GlobalMembers.MapA1D1D4[s.getValue()] = code++;
		}

		// MapKK[] encodes all the 461 possible legal positions of two kings where
		// the first is in the a1-d1-d4 triangle. If the first king is on the a1-d4
		// diagonal, the other one shall not to be above the a1-h8 diagonal.
		ArrayList<tangible.Pair<Integer, Square>> bothOnDiagonal = new ArrayList<tangible.Pair<Integer, Square>>();
		code = 0;
		for (int idx = 0; idx < 10; idx++)
		{
			for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_D4.getValue(); ++s1)
			{
				if (GlobalMembers.MapA1D1D4[s1.getValue()] == idx && (idx != 0 || s1 == Square.SQ_B1)) // SQ_B1 is mapped to 0
				{
					for (Square s2 = Square.SQ_A1; s2.getValue() <= Square.SQ_H8.getValue(); ++s2)
					{
						if (((PseudoAttacks[PieceType.KING.getValue()][s1.getValue()] | s1) & s2) != 0)
						{
							continue; // Illegal position
						}

						else if (!GlobalMembers.off_A1H8(s1) && GlobalMembers.off_A1H8(s2) > 0)
						{
							continue; // First on diagonal, second above
						}

						else if (!GlobalMembers.off_A1H8(s1) && !GlobalMembers.off_A1H8(s2))
						{
							bothOnDiagonal.emplace_back(idx, s2);
						}

						else
						{
							GlobalMembers.MapKK[idx][s2.getValue()] = code++;
						}
					}
				}
			}
		}

		// Legal positions with both kings on diagonal are encoded as last ones
		for (tangible.Pair<Integer, Square> p : bothOnDiagonal)
		{
			GlobalMembers.MapKK[p.first][p.second] = code++;
		}

		// Binomial[] stores the Binomial Coefficents using Pascal rule. There
		// are Binomial[k][n] ways to choose k elements from a set of n elements.
		GlobalMembers.Binomial[0][0] = 1;

		for (int n = 1; n < 64; n++) // Squares
		{
			for (int k = 0; k < 6 && k <= n; ++k) // Pieces
			{
				GlobalMembers.Binomial[k][n] = (k > 0 ? GlobalMembers.Binomial[k - 1][n - 1] : 0) + (k < n ? GlobalMembers.Binomial[k][n - 1] : 0);
			}
		}

		// MapPawns[s] encodes squares a2-h7 to 0..47. This is the number of possible
		// available squares when the leading one is in 's'. Moreover the pawn with
		// highest MapPawns[] is the leading pawn, the one nearest the edge and,
		// among pawns with same file, the one with lowest rank.
		int availableSquares = 47; // Available squares when lead pawn is in a2

		// Init the tables for the encoding of leading pawns group: with 7-men TB we
		// can have up to 5 leading pawns (KPPPPPK).
		for (int leadPawnsCnt = 1; leadPawnsCnt <= 5; ++leadPawnsCnt)
		{
			for (File f = File.FILE_A; f.getValue() <= File.FILE_D.getValue(); ++f)
			{
				// Restart the index at every file because TB table is splitted
				// by file, so we can reuse the same index for different files.
				int idx = 0;

				// Sum all possible combinations for a given file, starting with
				// the leading pawn on rank 2 and increasing the rank.
				for (Rank r = Rank.RANK_2; r.getValue() <= Rank.RANK_7.getValue(); ++r)
				{
					Square sq = GlobalMembers.make_square(f, r);

					// Compute MapPawns[] at first pass.
					// If sq is the leading pawn square, any other pawn cannot be
					// below or more toward the edge of sq. There are 47 available
					// squares when sq = a2 and reduced by 2 for any rank increase
					// due to mirroring: sq == a3 -> no a2, h2, so MapPawns[a3] = 45
					if (leadPawnsCnt == 1)
					{
						GlobalMembers.MapPawns[sq.getValue()] = availableSquares--;
						GlobalMembers.MapPawns[sq.getValue() ^ 7] = availableSquares--; // Horizontal flip
					}
					GlobalMembers.LeadPawnIdx[leadPawnsCnt][sq.getValue()] = idx;
					idx += GlobalMembers.Binomial[leadPawnsCnt - 1][GlobalMembers.MapPawns[sq.getValue()]];
				}
				// After a file is traversed, store the cumulated per-file index
				GlobalMembers.LeadPawnsSize[leadPawnsCnt][f.getValue()] = idx;
			}
		}

		// Add entries in TB tables if the corresponding ".rtbw" file exsists
		for (PieceType p1 = PieceType.PAWN; p1.getValue() < PieceType.KING.getValue(); ++p1)
		{
			GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, PieceType.KING)));

			for (PieceType p2 = PieceType.PAWN; p2.getValue() <= p1.getValue(); ++p2)
			{
				GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, PieceType.KING)));
				GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, PieceType.KING, p2)));

				for (PieceType p3 = PieceType.PAWN; p3.getValue() < PieceType.KING.getValue(); ++p3)
				{
					GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, PieceType.KING, p3)));
				}

				for (PieceType p3 = PieceType.PAWN; p3.getValue() <= p2.getValue(); ++p3)
				{
					GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, p3, PieceType.KING)));

					for (PieceType p4 = PieceType.PAWN; p4.getValue() <= p3.getValue(); ++p4)
					{
						GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, p3, p4, PieceType.KING)));

						for (PieceType p5 = PieceType.PAWN; p5.getValue() <= p4.getValue(); ++p5)
						{
							GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, p3, p4, p5, PieceType.KING)));
						}

						for (PieceType p5 = PieceType.PAWN; p5.getValue() < PieceType.KING.getValue(); ++p5)
						{
							GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, p3, p4, PieceType.KING, p5)));
						}
					}

					for (PieceType p4 = PieceType.PAWN; p4.getValue() < PieceType.KING.getValue(); ++p4)
					{
						GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, p3, PieceType.KING, p4)));

						for (PieceType p5 = PieceType.PAWN; p5.getValue() <= p4.getValue(); ++p5)
						{
							GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, p3, PieceType.KING, p4, p5)));
						}
					}
				}

				for (PieceType p3 = PieceType.PAWN; p3.getValue() <= p1.getValue(); ++p3)
				{
					for (PieceType p4 = PieceType.PAWN; p4.getValue() <= (p1 == p3 ? p2 : p3); ++p4)
					{
						GlobalMembers.TBTables.add(new ArrayList<PieceType>(Arrays.asList(PieceType.KING, p1, p2, PieceType.KING, p3, p4)));
					}
				}
			}
		}

		System.out.print(SyncCout.IO_LOCK);
		System.out.print("info string Found ");
		System.out.print(GlobalMembers.TBTables.size());
		System.out.print(" tablebases");
		System.out.print("\n");
		System.out.print(SyncCout.IO_UNLOCK);
	}

	// Probe the WDL table for a particular position.
	// If *result != FAIL, the probe was successful.
	// The return value is from the point of view of the side to move:
	// -2 : loss
	// -1 : loss, but draw under 50-move rule
	//  0 : draw
	//  1 : win, but draw under 50-move rule
	//  2 : win

	public static WDLScore probe_wdl(Position pos, ProbeState result)
	{

		result = ProbeState.OK;
		return GlobalMembers.<false>search(pos, result);
	}

	// Probe the DTZ table for a particular position.
	// If *result != FAIL, the probe was successful.
	// The return value is from the point of view of the side to move:
	//         n < -100 : loss, but draw under 50-move rule
	// -100 <= n < -1   : loss in n ply (assuming 50-move counter == 0)
	//        -1        : loss, the side to move is mated
	//         0        : draw
	//     1 < n <= 100 : win in n ply (assuming 50-move counter == 0)
	//   100 < n        : win, but draw under 50-move rule
	//
	// The return value n can be off by 1: a return value -n can mean a loss
	// in n+1 ply and a return value +n can mean a win in n+1 ply. This
	// cannot happen for tables with positions exactly on the "edge" of
	// the 50-move rule.
	//
	// This implies that if dtz > 0 is returned, the position is certainly
	// a win if dtz + 50-move-counter <= 99. Care must be taken that the engine
	// picks moves that preserve dtz + 50-move-counter <= 99.
	//
	// If n = 100 immediately after a capture or pawn move, then the position
	// is also certainly a win, and during the whole phase until the next
	// capture or pawn move, the inequality to be preserved is
	// dtz + 50-movecounter <= 100.
	//
	// In short, if a move is available resulting in dtz + 50-move-counter <= 99,
	// then do not accept moves leading to dtz + 50-move-counter == 100.

	public static int probe_dtz(Position pos, ProbeState result)
	{

		result = ProbeState.OK;
		WDLScore wdl = GlobalMembers.<true>search(pos, result);

		if (result == ProbeState.FAIL || wdl == WDLScore.WDLDraw) // DTZ tables don't store draws
		{
			return 0;
		}

		// DTZ stores a 'don't care' value in this case, or even a plain wrong
		// one as in case the best move is a losing ep, so it cannot be probed.
		if (result == ProbeState.ZEROING_BEST_MOVE)
		{
			return GlobalMembers.dtz_before_zeroing(wdl);
		}

		int dtz = GlobalMembers.<TBType.DTZ.getValue()>probe_table(pos, result, wdl);

		if (result == ProbeState.FAIL)
		{
			return 0;
		}

		if (result != ProbeState.CHANGE_STM)
		{
			return (dtz + 100 * (wdl == WDLScore.WDLBlessedLoss || wdl == WDLScore.WDLCursedWin)) * GlobalMembers.sign_of(wdl);
		}

		// DTZ stores results for the other side, so we need to do a 1-ply search and
		// find the winning move that minimizes DTZ.
		StateInfo st = new StateInfo();
		int minDTZ = 0xFFFF;

		for (Move move : new MoveList<GenType.LEGAL.getValue()>(pos))
		{
			boolean zeroing = pos.capture(move) || GlobalMembers.type_of(pos.moved_piece(move)) == PieceType.PAWN;

			pos.do_move(move, st);

			// For zeroing moves we want the dtz of the move _before_ doing it,
			// otherwise we will get the dtz of the next move sequence. Search the
			// position after the move to get the score sign (because even in a
			// winning position we could make a losing capture or going for a draw).
			dtz = zeroing ? -GlobalMembers.dtz_before_zeroing(GlobalMembers.<false>search(pos, result)) : -probe_dtz(pos, result);

			// If the move mates, force minDTZ to 1
			if (dtz == 1 && pos.checkers() != null && new MoveList<GenType.LEGAL.getValue()>(pos).size() == 0 != null)
			{
				minDTZ = 1;
			}

			// Convert result from 1-ply search. Zeroing moves are already accounted
			// by dtz_before_zeroing() that returns the DTZ of the previous move.
			if (!zeroing)
			{
				dtz += GlobalMembers.sign_of(dtz);
			}

			// Skip the draws and if we are winning only pick positive dtz
			if (dtz < minDTZ && GlobalMembers.sign_of(dtz) == GlobalMembers.sign_of(wdl))
			{
				minDTZ = dtz;
			}

			pos.undo_move(move);

			if (result == ProbeState.FAIL)
			{
				return 0;
			}
		}

		// When there are no legal moves, the position is mate: we return -1
		return minDTZ == 0xFFFF ? -1 : minDTZ;
	}

	// Use the DTZ tables to rank root moves.
	//
	// A return value false indicates that not all probes were successful.

	public static boolean root_probe(Position pos, ArrayList<RootMove> rootMoves)
	{

		ProbeState result;
		StateInfo st = new StateInfo();

		// Obtain 50-move counter for the root position
		int cnt50 = pos.rule50_count();

		// Check whether a position was repeated since the last zeroing move.
		boolean rep = pos.has_repeated();

		int dtz;
		int bound = Options["Syzygy50MoveRule"] ? 900 : 1;

		// Probe and rank each move
		for (RootMove m : rootMoves)
		{
			pos.do_move(m.pv[0], st);

			// Calculate dtz for the current move counting from the root position
			if (pos.rule50_count() == 0)
			{
				// In case of a zeroing move, dtz is one of -101/-1/0/1/101
				WDLScore wdl = -probe_wdl(pos, result);
				dtz = GlobalMembers.dtz_before_zeroing(wdl);
			}
			else
			{
				// Otherwise, take dtz for the new position and correct by 1 ply
				dtz = -probe_dtz(pos, result);
				dtz = dtz > 0 ? dtz + 1 : dtz < 0 ? dtz - 1 : dtz;
			}

			// Make sure that a mating move is assigned a dtz value of 1
			if (pos.checkers() != null && dtz == 2 && new MoveList<GenType.LEGAL.getValue()>(pos).size() == 0 != null)
			{
				dtz = 1;
			}

			pos.undo_move(m.pv[0]);

			if (result == ProbeState.FAIL)
			{
				return false;
			}

			// Better moves are ranked higher. Certain wins are ranked equally.
			// Losing moves are ranked equally unless a 50-move draw is in sight.
			int r = dtz > 0 ? (dtz + cnt50 <= 99 && !rep ? 1000 : 1000 - (dtz + cnt50)) : dtz < 0 ? (-dtz * 2 + cnt50 < 100 ? -1000 : -1000 + (-dtz + cnt50)) : 0;
			m.tbRank = r;

			// Determine the score to be displayed for this move. Assign at least
			// 1 cp to cursed wins and let it grow to 49 cp as the positions gets
			// closer to a real win.
			m.tbScore = r >= bound ? Value.VALUE_MATE - GlobalMembers.MAX_PLY - 1 : r > 0 ? Value((Math.max(3, r - 800) * Value.PawnValueEg.getValue()) / 200) : r == 0 ? Value.VALUE_DRAW : r > (-bound) != 0 ? Value((Math.min(-3, r + 800) * Value.PawnValueEg.getValue()) / 200) : -Value.VALUE_MATE + GlobalMembers.MAX_PLY + 1;
		}

		return true;
	}

	// Use the WDL tables to rank root moves.
	// This is a fallback for the case that some or all DTZ tables are missing.
	//
	// A return value false indicates that not all probes were successful.

	public static boolean root_probe_wdl(Position pos, ArrayList<RootMove> rootMoves)
	{

		final int[] WDL_to_rank = {-1000, -899, 0, 899, 1000};

		ProbeState result;
		StateInfo st = new StateInfo();

		boolean rule50 = Options["Syzygy50MoveRule"];

		// Probe and rank each move
		for (RootMove m : rootMoves)
		{
			pos.do_move(m.pv[0], st);

			WDLScore wdl = -probe_wdl(pos, result);

			pos.undo_move(m.pv[0]);

			if (result == ProbeState.FAIL)
			{
				return false;
			}

			m.tbRank = WDL_to_rank[wdl.getValue() + 2];

			if (!rule50)
			{
				wdl = wdl.getValue() > WDLScore.WDLDraw.getValue() ? WDLScore.WDLWin : wdl.getValue() < WDLScore.WDLDraw.getValue() ? WDLScore.WDLLoss : WDLScore.WDLDraw;
			}
			m.tbScore = GlobalMembers.WDL_to_value[wdl.getValue() + 2];
		}

		return true;
	}

//	void rank_root_moves(Position pos, ClassicVector<RootMove> rootMoves);Tangible Method Implementation Not FoundTablebases-rank_root_moves

	private std::ostream leftShift(std::ostream os, WDLScore v)
	{

		os << (v == WDLScore.WDLLoss ? "Loss" : v == WDLScore.WDLBlessedLoss ? "Blessed loss" : v == WDLScore.WDLDraw ? "Draw" : v == WDLScore.WDLCursedWin ? "Cursed win" : v == WDLScore.WDLWin ? "Win" : "None");

		return os;
	}

	private std::ostream leftShift(std::ostream os, ProbeState v)
	{

		os << (v == ProbeState.FAIL ? "Failed" : v == ProbeState.OK ? "Success" : v == ProbeState.CHANGE_STM ? "Probed opponent side" : v == ProbeState.ZEROING_BEST_MOVE ? "Best move zeroes DTZ" : "None");

		return os;
	}


  public static int Cardinality;
  public static boolean RootInTB;
  public static boolean UseRule50;
  public static Depth ProbeDepth;
}