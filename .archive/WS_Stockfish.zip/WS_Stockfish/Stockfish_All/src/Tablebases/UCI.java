package Tablebases;
import java.util.*;

public class UCI
{
	public String pv(Position pos, Depth depth, Value alpha, Value beta)
	{
    
	  std::stringstream ss = new std::stringstream();
	  std::chrono.milliseconds.rep elapsed = Time.elapsed() + 1;
	//C++ TO JAVA CONVERTER TODO TASK: The typedef 'RootMoves' was defined in multiple preprocessor conditionals and cannot be replaced in-line:
	  final RootMoves rootMoves = pos.this_thread().rootMoves;
	  int pvIdx = pos.this_thread().pvIdx;
	  int multiPV = Math.min((int)Options["MultiPV"], rootMoves.size());
	  long nodesSearched = Threads.nodes_searched();
	  long tbHits = Threads.tb_hits() + (TB.RootInTB ? rootMoves.size() : 0);
    
	  for (int i = 0; i < multiPV; ++i)
	  {
		  boolean updated = (i <= pvIdx && rootMoves[i].score != -Value.VALUE_INFINITE);
    
		  if (depth == Depth.ONE_PLY && !updated)
		  {
			  continue;
		  }
    
		  Depth d = updated ? depth : depth - Depth.ONE_PLY;
		  Value v = updated ? rootMoves[i].score : rootMoves[i].previousScore;
    
		  boolean tb = TB.RootInTB && Math.abs(v) < Value.VALUE_MATE.getValue() - MAX_PLY;
		  v = tb ? rootMoves[i].tbScore : v;
    
		  if (ss.rdbuf().in_avail()) // Not at first line
		  {
			  ss << "\n";
		  }
    
		  ss << "info" << " depth " << d.getValue() / Depth.ONE_PLY.getValue() << " seldepth " << rootMoves[i].selDepth << " multipv " << i + 1 << " score " << UCI.value(v);
    
		  if (!tb && i == pvIdx)
		  {
			  ss << (v.getValue() >= beta.getValue() ? " lowerbound" : v.getValue() <= alpha.getValue() ? " upperbound" : "");
		  }
    
		  ss << " nodes " << nodesSearched << " nps " << nodesSearched * 1000 / elapsed;
    
		  if (elapsed > 1000) // Earlier makes little sense
		  {
			  ss << " hashfull " << TT.hashfull();
		  }
    
		  ss << " tbhits " << tbHits << " time " << elapsed << " pv";
    
		  for (Move m : rootMoves[i].pv)
		  {
			  ss << " " << UCI.move(m, pos.is_chess960());
		  }
	  }
    
	  return ss.str();
	}
}