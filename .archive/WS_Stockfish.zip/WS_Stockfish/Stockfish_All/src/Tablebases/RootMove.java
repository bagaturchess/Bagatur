package Tablebases;
import java.util.*;

public class RootMove
{
	public boolean extract_ponder_from_tt(Position pos)
	{
    
		StateInfo st = new StateInfo();
		boolean ttHit;
    
		assert UCI.GlobalMembers.pv.size() == 1;
    
		if (!UCI.GlobalMembers.pv[0])
		{
			return false;
		}
    
		pos.do_move(UCI.GlobalMembers.pv[0], st);
		TTEntry tte = TT.probe(pos.key(), ttHit);
    
		if (ttHit)
		{
			Move m = tte.move(); // Local copy to be SMP safe
			if (new MoveList<GenType.LEGAL.getValue()>(pos).contains(m) != null)
			{
				UCI.GlobalMembers.pv.push_back(m);
			}
		}
    
		pos.undo_move(UCI.GlobalMembers.pv[0]);
		return UCI.GlobalMembers.pv.size() > 1;
	}
}