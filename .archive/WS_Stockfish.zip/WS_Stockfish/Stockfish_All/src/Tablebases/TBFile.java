package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'static_assert':
//static_assert(sizeof(LR) == 3, "LR tree entry must be 3 bytes");

// Tablebases data layout is structured as following:
//
//  TBFile:   memory maps/unmaps the physical .rtbw and .rtbz files
//  TBTable:  one object for each file with corresponding indexing information
//  TBTables: has ownership of TBTable objects, keeping a list and a hash

// class TBFile memory maps/unmaps the single .rtbw and .rtbz files. Files are
// memory mapped for best performance. Files are mapped at first access: at init
// time only existence of the file is checked.
public class TBFile extends std::ifstream
{

	private String fname;

	// Look for and open the file among the Paths directories where the .rtbw
	// and .rtbz files can be found. Multiple directories are separated by ";"
	// on Windows and by ":" on Unix-based operating systems.
	//
	// Example:
	// C:\tb\wdl345;C:\tb\wdl6;D:\tb\dtz345;D:\tb\dtz6
	public static String Paths;

	public TBFile(String f)
	{

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if ! _WIN32
		final char SepChar = ':';
///#else
		final char SepChar = ';';
///#endif
		std::stringstream ss = new std::stringstream(Paths);
		String path;

		while (getline(ss, path, SepChar))
		{
			fname = path + "/" + f;
			std::ifstream.open(fname);
			if (is_open())
			{
				return;
			}
		}
	}

	// Memory map the file and check it. File should be already open and will be
	// closed after mapping.
	public final uint8_t map(Object[] baseAddress, uint64_t mapping, TBType type)
	{

		assert is_open();

		close(); // Need to re-open to get native file descriptor

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if ! _WIN32
		stat statbuf = new stat();
		int fd = open(fname, O_RDONLY);

		if (fd == -1)
		{
			return baseAddress[0] = null, null;
		}

		fstat(fd, statbuf);
		mapping = statbuf.st_size;
		baseAddress[0] = mmap(null, statbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
		madvise(baseAddress[0], statbuf.st_size, MADV_RANDOM);
		close(fd);

		if (baseAddress[0] == MAP_FAILED)
		{
			std::cerr << "Could not mmap() " << fname << std::endl;
			System.exit(1);
		}
///#else
		HANDLE fd = CreateFile(fname, GENERIC_READ, FILE_SHARE_READ, null, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, null);

		if (fd == INVALID_HANDLE_VALUE)
		{
			return baseAddress[0] = null, null;
		}

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: DWORD size_high;
		int size_high;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: DWORD size_low = GetFileSize(fd, &size_high);
		int size_low = GetFileSize(fd, size_high);
		HANDLE mmap = CreateFileMapping(fd, null, PAGE_READONLY, size_high, size_low, null);
		CloseHandle(fd);

		if (mmap == null)
		{
			std::cerr << "CreateFileMapping() failed" << std::endl;
			System.exit(1);
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: *mapping = (uint64_t)mmap;
		mapping.copyFrom((uint64_t)mmap);
		baseAddress[0] = MapViewOfFile(mmap, FILE_MAP_READ, 0, 0, 0);

		if (!baseAddress[0])
		{
			std::cerr << "MapViewOfFile() failed, name = " << fname << ", error = " << GetLastError() << std::endl;
			System.exit(1);
		}
///#endif
		uint8_t data = (uint8_t)baseAddress[0];

		final uint8_t[][] Magics =
		{
			{0xD7, 0x66, 0x0C, 0xA5},
			{0x71, 0xE8, 0x23, 0x5D}
		};

//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcmp' has no equivalent in Java:
		if (memcmp(data, Magics[type.getValue() == TBType.WDL], 4))
		{
			std::cerr << "Corrupted table in file " << fname << std::endl;
			unmap(baseAddress[0], mapping);
			return baseAddress[0] = null, null;
		}

		return data + 4; // Skip Magics's header
	}

	public static void unmap(Object baseAddress, uint64_t mapping)
	{

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if ! _WIN32
		munmap(baseAddress, mapping);
///#else
		UnmapViewOfFile(baseAddress);
		CloseHandle((HANDLE)mapping);
///#endif
	}
}