package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

// struct PairsData contains low level indexing information to access TB data.
// There are 8, 4 or 2 PairsData records for each TBTable, according to type of
// table and if positions have pawns or not. It is populated at first access.
public class PairsData
{
	public uint8_t flags = new uint8_t(); // Table flags, see enum TBFlag
	public uint8_t maxSymLen = new uint8_t(); // Maximum length in bits of the Huffman symbols
	public uint8_t minSymLen = new uint8_t(); // Minimum length in bits of the Huffman symbols
	public uint32_t blocksNum = new uint32_t(); // Number of blocks in the TB file
	public size_t sizeofBlock = new size_t(); // Block size in bytes
	public size_t span = new size_t(); // About every span values there is a SparseIndex[] entry
	public uint16_t[] lowestSym; // lowestSym[l] is the symbol of length l with the lowest value
	public LR[] btree; // btree[sym] stores the left and right symbols that expand sym
	public uint16_t[] blockLength; // Number of stored positions (minus one) for each block: 1..65536
	public uint32_t blockLengthSize = new uint32_t(); // Size of blockLength[] table: padded so it's bigger than blocksNum
	public SparseEntry[] sparseIndex; // Partial indices into blockLength[]
	public size_t sparseIndexSize = new size_t(); // Size of SparseIndex[] table
	public uint8_t data; // Start of Huffman compressed data
	public ArrayList<uint64_t> base64 = new ArrayList<uint64_t>(); // base64[l - min_sym_len] is the 64bit-padded lowest symbol of length l
	public ArrayList<uint8_t> symlen = new ArrayList<uint8_t>(); // Number of values (-1) represented by a given Huffman symbol: 1..256
	public Piece[] pieces = new Piece[TBPIECES]; // Position pieces: the order of pieces defines the groups
	public uint64_t[] groupIdx = tangible.Arrays.initializeWithDefaultuint64_tInstances(TBPIECES + 1); // Start index used for the encoding of the group's pieces
	public int[] groupLen = new int[TBPIECES + 1]; // Number of pieces in a given group: KRKN -> (3, 1)
	public uint16_t[] map_idx = tangible.Arrays.initializeWithDefaultuint16_tInstances(4); // WDLWin, WDLLoss, WDLCursedWin, WDLBlessedLoss (used in DTZ)
}