package Tablebases;

import Tablebases.*;
import java.util.*;
import java.io.*;

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if ! _WIN32
//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
//#include <fcntl.h>
//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
//#include <unistd.h>
//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
//#include <sys/mman.h>
//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
//#include <sys/stat.h>
///#else
///#define WIN32_LEAN_AND_MEAN
///#define NOMINMAX
///#endif

//C++ TO JAVA CONVERTER NOTE: Enums must be named in Java, so the following enum has been named by the converter:
public enum AnonymousEnum
{
	BigEndian,
	LittleEndian;

	public static final int SIZE = java.lang.Integer.SIZE;

	public int getValue()
	{
		return this.ordinal();
	}

	public static AnonymousEnum forValue(int value)
	{
		return values()[value];
	}
}