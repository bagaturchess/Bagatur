package Bitboards;

/// Magic holds all magic bitboards relevant data for a single square
public class Magic
{
  public uint64_t mask = new uint64_t();
  public uint64_t magic = new uint64_t();
  public uint64_t[] attacks;
  public int shift;

  // Compute the attack's index using the 'magic bitboards' approach
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: uint index(uint64_t occupied) const
  public final int index(uint64_t occupied)
  {

	if (GlobalMembers.HasPext)
	{
		return int((b, m) 0(occupied, mask));
	}

	if (GlobalMembers.Is64Bit)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		return int(((occupied & mask) * magic) >> GlobalMembers.shift);
	}

	int lo = int(occupied) & int(mask);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	int hi = int(occupied >> 32) & int(mask >> 32);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	return (lo * int(magic) ^ hi * int(magic >> 32)) >>> GlobalMembers.shift;
  }
}
/// popcount() counts the number of non-zero bits in a bitboard

//C++ TO JAVA CONVERTER TODO TASK: Unions are not supported in Java:
//union