import java.util.*;

/// In stats table, D=0 means that the template parameter is not used
public enum StatsParams
{
	NOT_USED(0);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, StatsParams> mappings;
	private static java.util.HashMap<Integer, StatsParams> getMappings()
	{
		if (mappings == null)
		{
			synchronized (StatsParams.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, StatsParams>();
				}
			}
		}
		return mappings;
	}

	private StatsParams(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static StatsParams forValue(int value)
	{
		return getMappings().get(value);
	}
}