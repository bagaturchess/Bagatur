import String;

/// A list to keep track of the position states along the setup moves (from the
/// start position to the position just before the search starts). Needed by
/// 'draw by repetition' detection. Use a std::deque because pointers to
/// elements are not invalidated upon list resizing.


/// Position class stores information regarding the board representation as
/// pieces, side to move, hash keys, castling info, etc. Important methods are
/// do_move() and undo_move(), used by the search to update node info when
/// traversing the search tree.
//C++ TO JAVA CONVERTER NOTE: Java has no need of forward class declarations:
//class Thread;

public class Position
{

  /// Position::init() initializes at startup the various arrays used to compute
  /// hash keys.

  public static void init()
  {

	PRNG rng = new PRNG(1070372);

	for (Piece pc : GlobalMembers.Pieces)
	{
		for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
		{
			Zobrist.GlobalMembers.psq[pc.getValue()][s.getValue()] = rng.<Long>rand();
		}
	}

	for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); ++f)
	{
		Zobrist.GlobalMembers.enpassant[f.getValue()] = rng.<Long>rand();
	}

	for (int cr = CastlingRight.NO_CASTLING.getValue(); cr <= CastlingRight.ANY_CASTLING.getValue(); ++cr)
	{
		Zobrist.GlobalMembers.castling[cr] = 0;
		long b = (long)cr;
		while (b != 0)
		{
			tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
			long k = Zobrist.GlobalMembers.castling[1 << GlobalMembers.pop_lsb(tempRef_b)];
			b = tempRef_b.argValue;
			Zobrist.GlobalMembers.castling[cr] ^= k != 0 ? k : rng.<Long>rand();
		}
	}

	Zobrist.GlobalMembers.side = rng.<Long>rand();
	Zobrist.GlobalMembers.noPawns = rng.<Long>rand();

	// Prepare the cuckoo tables
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
	memset(GlobalMembers.cuckoo, 0, (Long.SIZE / Byte.SIZE));
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memset(GlobalMembers.cuckooMove, 0, sizeof(GlobalMembers.cuckooMove));
	int count = 0;
	for (Piece pc : GlobalMembers.Pieces)
	{
		for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_H8.getValue(); ++s1)
		{
			for (Square s2 = Square(s1 + 1); s2.getValue() <= Square.SQ_H8.getValue(); ++s2)
			{
				if ((PseudoAttacks[GlobalMembers.type_of(pc).getValue()][s1.getValue()] & s2) != 0)
				{
					Move move = GlobalMembers.make_move(s1, s2);
					long key = Zobrist.GlobalMembers.psq[pc.getValue()][s1.getValue()] ^ Zobrist.GlobalMembers.psq[pc.getValue()][s2.getValue()] ^ Zobrist.GlobalMembers.side;
					int i = GlobalMembers.H1(key);
					while (true)
					{
						std::swap(GlobalMembers.cuckoo[i], key);
						std::swap(GlobalMembers.cuckooMove[i], move);
						if (move == 0) // Arrived at empty slot ?
						{
							break;
						}
						i = (i == GlobalMembers.H1(key)) ? GlobalMembers.H2(key) : GlobalMembers.H1(key); // Push victim to alternative slot
					}
					count++;
				}
			}
		}
	}
	assert count == 3668;
  }

//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = default':
//  Position() = default;
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
//  Position(const Position&) = delete;
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
//  Position& operator =(const Position&) = delete;

  // FEN string input/output

  /// Position::set() initializes the position object with the given FEN string.
  /// This function is not very robust - make sure that input FENs are correct,
  /// this is assumed to be the responsibility of the GUI.

  public final Position set(String fenStr, boolean isChess960, StateInfo si, Thread th)
  {
  /*
     A FEN string defines a particular position using only the ASCII character set.
  
     A FEN string contains six fields separated by a space. The fields are:
  
     1) Piece placement (from white's perspective). Each rank is described, starting
        with rank 8 and ending with rank 1. Within each rank, the contents of each
        square are described from file A through file H. Following the Standard
        Algebraic Notation (SAN), each piece is identified by a single letter taken
        from the standard English names. White pieces are designated using upper-case
        letters ("PNBRQK") whilst Black uses lowercase ("pnbrqk"). Blank squares are
        noted using digits 1 through 8 (the number of blank squares), and "/"
        separates ranks.
  
     2) Active color. "w" means white moves next, "b" means black.
  
     3) Castling availability. If neither side can castle, this is "-". Otherwise,
        this has one or more letters: "K" (White can castle kingside), "Q" (White
        can castle queenside), "k" (Black can castle kingside), and/or "q" (Black
        can castle queenside).
  
     4) En passant target square (in algebraic notation). If there's no en passant
        target square, this is "-". If a pawn has just made a 2-square move, this
        is the position "behind" the pawn. This is recorded only if there is a pawn
        in position to make an en passant capture, and if there really is a pawn
        that might have advanced two squares.
  
     5) Halfmove clock. This is the number of halfmoves since the last pawn advance
        or capture. This is used to determine if a draw can be claimed under the
        fifty-move rule.
  
     6) Fullmove number. The number of the full move. It starts at 1, and is
        incremented after Black's move.
  */

  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned char col, row, token;
	byte col;
	byte row;
	byte token;
	int idx;
	Square sq = Square.SQ_A8;
	std::istringstream ss = new std::istringstream(fenStr);

//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memset(this, 0, sizeof(Position));
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memset(si, 0, sizeof(StateInfo));
//C++ TO JAVA CONVERTER WARNING: This 'sizeof' ratio was replaced with a direct reference to the array length:
//ORIGINAL LINE: std::fill_n(&pieceList[0][0], sizeof(pieceList) / sizeof(Square), SQ_NONE);
	std::fill_n(pieceList[0][0], pieceList.length, Square.SQ_NONE);
	st = si;

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	ss >> std::noskipws;

	// 1. Piece placement
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	while ((ss >> token) != 0 && !Character.isWhitespace(token))
	{
		if (Character.isDigit(token))
		{
			sq += (token - '0') * Direction.EAST; // Advance the given number of files
		}

		else if (token == (byte)'/')
		{
			sq += 2 * Direction.SOUTH;
		}

		else if ((idx = PieceToChar.find(token)) != -1)
		{
			put_piece(Piece(idx), sq);
			++sq;
		}
	}

	// 2. Active color
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	ss >> token;
	sideToMove = (token == (byte)'w' ? Color.WHITE : Color.BLACK);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	ss >> token;

	// 3. Castling availability. Compatible with 3 standards: Normal FEN standard,
	// Shredder-FEN that uses the letters of the columns on which the rooks began
	// the game instead of KQkq and also X-FEN standard that, in case of Chess960,
	// if an inner rook is associated with the castling right, the castling tag is
	// replaced by the file letter of the involved rook, as for the Shredder-FEN.
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	while ((ss >> token) != 0 && !Character.isWhitespace(token))
	{
		Square rsq;
		Color c = Character.isLowerCase(token) ? Color.BLACK : Color.WHITE;
		Piece rook = GlobalMembers.make_piece(c, PieceType.ROOK);

		token = (char)Character.toUpperCase(token);

		if (token == (byte)'K')
		{
			for (rsq = GlobalMembers.relative_square(c, Square.SQ_H1); piece_on(rsq) != rook; --rsq)
			{
			}
		}

		else if (token == (byte)'Q')
		{
			for (rsq = GlobalMembers.relative_square(c, Square.SQ_A1); piece_on(rsq) != rook; ++rsq)
			{
			}
		}

		else if (token >= (byte)'A' && token <= (byte)'H')
		{
			rsq = GlobalMembers.make_square(File(token - 'A'), GlobalMembers.relative_rank(c, Rank.RANK_1));
		}

		else
		{
			continue;
		}

		set_castling_right(c, rsq);
	}

	// 4. En passant square. Ignore if no pawn capture is possible
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	if (((ss >> col) && (col >= (byte)'a' && col <= (byte)'h')) && ((ss >> row) && (row == (byte)'3' || row == (byte)'6')))
	{
		st.epSquare = GlobalMembers.make_square(File(col - 'a'), Rank(row - '1'));

		if ((attackers_to(st.epSquare) & pieces(sideToMove, PieceType.PAWN)) == 0 || (pieces(~sideToMove, PieceType.PAWN) & (st.epSquare + GlobalMembers.pawn_push(~sideToMove))) == 0)
		{
			st.epSquare = Square.SQ_NONE;
		}
	}
	else
	{
		st.epSquare = Square.SQ_NONE;
	}

	// 5-6. Halfmove clock and fullmove number
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	ss >> std::skipws >> st.rule50 >> gamePly;

	// Convert from fullmove starting from 1 to gamePly starting from 0,
	// handle also common incorrect FEN with fullmove = 0.
	gamePly = Math.max(2 * (gamePly - 1), 0) + (sideToMove == Color.BLACK);

	chess960 = isChess960;
	thisThread = th;
	set_state(st);

	assert pos_is_ok();

	return this;
  }


  /// Position::set() is an overload to initialize the position object with
  /// the given endgame code string like "KBPKN". It is mainly a helper to
  /// get the material key out of an endgame code.

  public final Position set(String code, Color c, StateInfo si)
  {

	assert code.length() > 0 && code.length() < 8;
	assert code.charAt(0) == 'K';

	String[] sides = {code.substring(code.indexOf('K', 1)), code.substring(0, code.indexOf('K', 1))};

	sides[c.getValue()] = sides[c.getValue()].toLowerCase();

	String fenStr = "8/" + sides[0] + (char)(8 - sides[0].length() + '0') + "/8/8/8/8/"
						 + sides[1] + (char)(8 - sides[1].length() + '0') + "/8 w - - 0 10";

	return set(fenStr, false, si, null);
  }


  /// Position::fen() returns a FEN representation of the position. In case of
  /// Chess960 the Shredder-FEN notation is used. This is mainly a debugging function.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: const String fen() const
  public final String fen()
  {

	int emptyCnt;
	std::ostringstream ss = new std::ostringstream();

	for (Rank r = Rank.RANK_8; r.getValue() >= Rank.RANK_1.getValue(); --r)
	{
		for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); ++f)
		{
			for (emptyCnt = 0; f.getValue() <= File.FILE_H.getValue() && empty(GlobalMembers.make_square(f, r)); ++f)
			{
				++emptyCnt;
			}

			if (emptyCnt != 0)
			{
				ss << emptyCnt;
			}

			if (f.getValue() <= File.FILE_H.getValue())
			{
				ss << PieceToChar[piece_on(GlobalMembers.make_square(f, r)).getValue()];
			}
		}

		if (r.getValue() > Rank.RANK_1.getValue())
		{
			ss << '/';
		}
	}

	ss << (sideToMove == Color.WHITE ? " w " : " b ");

	if (can_castle(CastlingRight.WHITE_OO) != 0)
	{
		ss << (chess960 ? (char)('A' + GlobalMembers.file_of(castling_rook_square(Color.WHITE | CastlingSide.KING_SIDE))) : 'K');
	}

	if (can_castle(CastlingRight.WHITE_OOO) != 0)
	{
		ss << (chess960 ? (char)('A' + GlobalMembers.file_of(castling_rook_square(Color.WHITE | CastlingSide.QUEEN_SIDE))) : 'Q');
	}

	if (can_castle(CastlingRight.BLACK_OO) != 0)
	{
		ss << (chess960 ? (char)('a' + GlobalMembers.file_of(castling_rook_square(Color.BLACK | CastlingSide.KING_SIDE))) : 'k');
	}

	if (can_castle(CastlingRight.BLACK_OOO) != 0)
	{
		ss << (chess960 ? (char)('a' + GlobalMembers.file_of(castling_rook_square(Color.BLACK | CastlingSide.QUEEN_SIDE))) : 'q');
	}

	if (can_castle(Color.WHITE) == 0 && can_castle(Color.BLACK) == 0)
	{
		ss << '-';
	}

	ss << (ep_square() == Square.SQ_NONE ? " - " : " " + UCI.square(ep_square()) + " ") << st.rule50 << " " << 1 + (gamePly - (sideToMove == Color.BLACK)) / 2;

	return ss.str();
  }

  // Position representation
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces() const
  public final long pieces()
  {
	return byTypeBB[PieceType.ALL_PIECES.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces(PieceType pt) const
  public final long pieces(PieceType pt)
  {
	return byTypeBB[pt.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces(PieceType pt1, PieceType pt2) const
  public final long pieces(PieceType pt1, PieceType pt2)
  {
	return byTypeBB[pt1.getValue()] | byTypeBB[pt2.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces(Color c) const
  public final long pieces(Color c)
  {
	return byColorBB[c.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces(Color c, PieceType pt) const
  public final long pieces(Color c, PieceType pt)
  {
	return byColorBB[c.getValue()] & byTypeBB[pt.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces(Color c, PieceType pt1, PieceType pt2) const
  public final long pieces(Color c, PieceType pt1, PieceType pt2)
  {
	return byColorBB[c.getValue()] & (byTypeBB[pt1.getValue()] | byTypeBB[pt2.getValue()]);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Piece piece_on(Square s) const
  public final Piece piece_on(Square s)
  {
	return board[s.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square ep_square() const
  public final Square ep_square()
  {
	return st.epSquare;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean empty(Square s) const
  public final boolean empty(Square s)
  {
	return board[s.getValue()] == Piece.NO_PIECE;
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<PieceType Pt> int count(Color c) const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Pt>
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int count(Color c) const
  public final <Pt> int count(Color c)
  {
	return pieceCount[GlobalMembers.make_piece(c, Pt).getValue()];
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<PieceType Pt> int count() const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Pt>
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int count() const
  public final <Pt> int count()
  {
	return pieceCount[GlobalMembers.make_piece(Color.WHITE, Pt).getValue()] + pieceCount[GlobalMembers.make_piece(Color.BLACK, Pt).getValue()];
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<PieceType Pt> const Square* squares(Color c) const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Pt>
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline const Square* squares(Color c) const
//C++ TO JAVA CONVERTER WARNING: Java has no equivalent to methods returning pointers to value types:
  public final <Pt> Square squares(Color c)
  {
	return pieceList[GlobalMembers.make_piece(c, Pt).getValue()];
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<PieceType Pt> Square square(Color c) const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Pt>
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square square(Color c) const
  public final <Pt> Square square(Color c)
  {
	assert pieceCount[GlobalMembers.make_piece(c, Pt).getValue()] == 1;
	return pieceList[GlobalMembers.make_piece(c, Pt).getValue()][0];
  }

  // Castling
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int can_castle(Color c) const
  public final int can_castle(Color c)
  {
	return st.castlingRights & ((CastlingRight.WHITE_OO | CastlingRight.WHITE_OOO) << (2 * c));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int can_castle(CastlingRight cr) const
  public final int can_castle(CastlingRight cr)
  {
	return st.castlingRights & cr.getValue();
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean castling_impeded(CastlingRight cr) const
  public final boolean castling_impeded(CastlingRight cr)
  {
	return (byTypeBB[PieceType.ALL_PIECES.getValue()] & castlingPath[cr.getValue()]) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square castling_rook_square(CastlingRight cr) const
  public final Square castling_rook_square(CastlingRight cr)
  {
	return castlingRookSquare[cr.getValue()];
  }

  // Checking
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong checkers() const
  public final long checkers()
  {
	return st.checkersBB;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong blockers_for_king(Color c) const
  public final long blockers_for_king(Color c)
  {
	return st.blockersForKing[c.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong check_squares(PieceType pt) const
  public final long check_squares(PieceType pt)
  {
	return st.checkSquares[pt.getValue()];
  }

  // Attacks to/from a given square
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong attackers_to(Square s) const
  public final long attackers_to(Square s)
  {
	return attackers_to(s, byTypeBB[PieceType.ALL_PIECES.getValue()]);
  }


  /// Position::attackers_to() computes a bitboard of all pieces which attack a
  /// given square. Slider attacks use the occupied bitboard to indicate occupancy.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong attackers_to(Square s, ulong occupied) const
  public final long attackers_to(Square s, long occupied)
  {

	return (this.<PieceType.PAWN.getValue()>attacks_from(s, Color.BLACK) & pieces(Color.WHITE, PieceType.PAWN)) | (this.<PieceType.PAWN.getValue()>attacks_from(s, Color.WHITE) & pieces(Color.BLACK, PieceType.PAWN)) | (this.<PieceType.KNIGHT.getValue()>attacks_from(s) & pieces(PieceType.KNIGHT)) | (GlobalMembers.< PieceType.ROOK.getValue()>attacks_bb(s, occupied) & pieces(PieceType.ROOK, PieceType.QUEEN)) | (GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s, occupied) & pieces(PieceType.BISHOP, PieceType.QUEEN)) | (this.<PieceType.KING.getValue()>attacks_from(s) & pieces(PieceType.KING));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong attacks_from(PieceType pt, Square s) const
  public final long attacks_from(PieceType pt, Square s)
  {
	return GlobalMembers.attacks_bb(pt, s, byTypeBB[PieceType.ALL_PIECES.getValue()]);
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<PieceType> Bitboard attacks_from(Square s) const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename>
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong attacks_from(Square s) const
  public final <typename> long attacks_from(Square s)
  {
	assert Pt != PieceType.PAWN;
	return Pt == PieceType.BISHOP || Pt == PieceType.ROOK ? GlobalMembers.<Pt>attacks_bb(s, byTypeBB[PieceType.ALL_PIECES.getValue()]) : Pt == PieceType.QUEEN ? this.<PieceType.ROOK.getValue()>attacks_from(s) | this.<PieceType.BISHOP.getValue()>attacks_from(s) : PseudoAttacks[Pt][s.getValue()];
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<PieceType> Bitboard attacks_from(Square s, Color c) const;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline ulong attacks_from<PAWN>(Square s, Color c) const
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
  public final <typename> long attacks_from(Square s, Color c)
  {
	return PawnAttacks[c.getValue()][s.getValue()];
  }


  /// Position::slider_blockers() returns a bitboard of all the pieces (both colors)
  /// that are blocking attacks on the square 's' from 'sliders'. A piece blocks a
  /// slider if removing that piece from the board would result in a position where
  /// square 's' is attacked. For example, a king-attack blocking piece can be either
  /// a pinned or a discovered check piece, according if its color is the opposite
  /// or the same of the color of the slider.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong slider_blockers(ulong sliders, Square s, ulong& pinners) const
  public final long slider_blockers(long sliders, Square s, tangible.RefObject<Long> pinners)
  {

	long blockers = 0;
	pinners.argValue = 0;

	// Snipers are sliders that attack 's' when a piece is removed
	long snipers = ((PseudoAttacks[PieceType.ROOK.getValue()][s.getValue()] & pieces(PieceType.QUEEN, PieceType.ROOK)) | (PseudoAttacks[PieceType.BISHOP.getValue()][s.getValue()] & pieces(PieceType.QUEEN, PieceType.BISHOP))) & sliders;

	while (snipers != 0)
	{
	  tangible.RefObject<Long> tempRef_snipers = new tangible.RefObject<Long>(snipers);
	  Square sniperSq = GlobalMembers.pop_lsb(tempRef_snipers);
	  snipers = tempRef_snipers.argValue;
	  long b = GlobalMembers.between_bb(s, sniperSq) & pieces();

	  if (b != 0 && !GlobalMembers.more_than_one(b))
	  {
		  blockers |= b;
		  if ((b & pieces(GlobalMembers.color_of(piece_on(s)))) != 0)
		  {
			  pinners.argValue |= sniperSq;
		  }
	  }
	}
	return blockers;
  }

  // Properties of moves

  /// Position::legal() tests whether a pseudo-legal move is legal

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean legal(Move m) const
  public final boolean legal(Move m)
  {

	assert GlobalMembers.is_ok(m);

	Color us = sideToMove;
	Square from = GlobalMembers.from_sq(m);

	assert GlobalMembers.color_of(moved_piece(m)) == us;
	assert piece_on(this.<PieceType.KING.getValue()>square(us)) == GlobalMembers.make_piece(us, PieceType.KING);

	// En passant captures are a tricky special case. Because they are rather
	// uncommon, we do it simply by testing whether the king is attacked after
	// the move is made.
	if (GlobalMembers.type_of(m) == MoveType.ENPASSANT)
	{
		Square ksq = this.<PieceType.KING.getValue()>square(us);
		Square to = GlobalMembers.to_sq(m);
		Square capsq = to - GlobalMembers.pawn_push(us);
		long occupied = (long)((pieces() ^ from ^ capsq) | to);

		assert to == ep_square();
		assert moved_piece(m) == GlobalMembers.make_piece(us, PieceType.PAWN);
		assert piece_on(capsq) == GlobalMembers.make_piece(~us, PieceType.PAWN);
		assert piece_on(to) == Piece.NO_PIECE;

		return (GlobalMembers.< PieceType.ROOK.getValue()>attacks_bb(ksq, occupied) & pieces(~us, PieceType.QUEEN, PieceType.ROOK)) == 0 && (GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(ksq, occupied) & pieces(~us, PieceType.QUEEN, PieceType.BISHOP)) == 0;
	}

	// If the moving piece is a king, check whether the destination
	// square is attacked by the opponent. Castling moves are checked
	// for legality during move generation.
	if (GlobalMembers.type_of(piece_on(from)) == PieceType.KING)
	{
		return GlobalMembers.type_of(m) == MoveType.CASTLING || (attackers_to(GlobalMembers.to_sq(m)) & pieces(~us)) == 0;
	}

	// A non-king move is legal if and only if it is not pinned or it
	// is moving along the ray towards or away from the king.
	return (blockers_for_king(us) & from.getValue()) == 0 || GlobalMembers.aligned(from, GlobalMembers.to_sq(m), this.<PieceType.KING.getValue()>square(us));
  }


  /// Position::pseudo_legal() takes a random move and tests whether the move is
  /// pseudo legal. It is used to validate moves from TT that can be corrupted
  /// due to SMP concurrent access or hash position key aliasing.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean pseudo_legal(const Move m) const
  public final boolean pseudo_legal(Move m)
  {

	Color us = sideToMove;
	Square from = GlobalMembers.from_sq(m);
	Square to = GlobalMembers.to_sq(m);
	Piece pc = moved_piece(m);

	// Use a slower but simpler function for uncommon cases
	if (GlobalMembers.type_of(m) != MoveType.NORMAL)
	{
		return new MoveList<GenType.LEGAL.getValue()>(this).contains(m) != null;
	}

	// Is not a promotion, so promotion piece must be empty
	if (GlobalMembers.promotion_type(m) - PieceType.KNIGHT != PieceType.NO_PIECE_TYPE.getValue() != 0)
	{
		return false;
	}

	// If the 'from' square is not occupied by a piece belonging to the side to
	// move, the move is obviously not legal.
	if (pc == Piece.NO_PIECE || GlobalMembers.color_of(pc) != us)
	{
		return false;
	}

	// The destination square cannot be occupied by a friendly piece
	if ((pieces(us) & to.getValue()) != 0)
	{
		return false;
	}

	// Handle the special case of a pawn move
	if (GlobalMembers.type_of(pc) == PieceType.PAWN)
	{
		// We have already handled promotion moves, so destination
		// cannot be on the 8th/1st rank.
		if (GlobalMembers.rank_of(to) == GlobalMembers.relative_rank(us, Rank.RANK_8))
		{
			return false;
		}

		if ((this.<PieceType.PAWN.getValue()>attacks_from(from, us) & pieces(~us) & to.getValue()) == 0 && !((from + GlobalMembers.pawn_push(us) == to) && empty(to)) && !((from + 2 * GlobalMembers.pawn_push(us) == to) && (GlobalMembers.rank_of(from) == GlobalMembers.relative_rank(us, Rank.RANK_2)) && empty(to) && empty(to - GlobalMembers.pawn_push(us))))
		{
			return false;
		}
	}
	else if (!(attacks_from(GlobalMembers.type_of(pc), from) & to.getValue()))
	{
		return false;
	}

	// Evasions generator already takes care to avoid some kind of illegal moves
	// and legal() relies on this. We therefore have to take care that the same
	// kind of moves are filtered out here.
	if (checkers() != 0)
	{
		if (GlobalMembers.type_of(pc) != PieceType.KING)
		{
			// Double check? In this case a king move is required
			if (GlobalMembers.more_than_one(checkers()))
			{
				return false;
			}

			// Our move must be a blocking evasion or a capture of the checking piece
			if (((GlobalMembers.between_bb(GlobalMembers.lsb(checkers()), this.<PieceType.KING.getValue()>square(us)) | checkers()) & to) == 0)
			{
				return false;
			}
		}
		// In case of king moves under check we have to remove king so as to catch
		// invalid moves like b1a1 when opposite queen is on c1.
		else if (attackers_to(to, (long)(pieces() ^ from)) & pieces(~us))
		{
			return false;
		}
	}

	return true;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean capture(Move m) const
  public final boolean capture(Move m)
  {
	assert GlobalMembers.is_ok(m);
	// Castling is encoded as "king captures rook"
	return (!empty(GlobalMembers.to_sq(m)) && GlobalMembers.type_of(m) != MoveType.CASTLING) || GlobalMembers.type_of(m) == MoveType.ENPASSANT;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean capture_or_promotion(Move m) const
  public final boolean capture_or_promotion(Move m)
  {
	assert GlobalMembers.is_ok(m);
	return GlobalMembers.type_of(m) != MoveType.NORMAL ? GlobalMembers.type_of(m) != MoveType.CASTLING :!empty(GlobalMembers.to_sq(m));
  }


  /// Position::gives_check() tests whether a pseudo-legal move gives a check

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean gives_check(Move m) const
  public final boolean gives_check(Move m)
  {

	assert GlobalMembers.is_ok(m);
	assert GlobalMembers.color_of(moved_piece(m)) == sideToMove;

	Square from = GlobalMembers.from_sq(m);
	Square to = GlobalMembers.to_sq(m);

	// Is there a direct check?
	if ((st.checkSquares[GlobalMembers.type_of(piece_on(from)).getValue()] & to.getValue()) != 0)
	{
		return true;
	}

	// Is there a discovered check?
	if ((st.blockersForKing[~sideToMove] & from.getValue()) != 0 && !GlobalMembers.aligned(from, to, this.<PieceType.KING.getValue()>square(~sideToMove)))
	{
		return true;
	}

	switch (GlobalMembers.type_of(m))
	{
	case NORMAL:
		return false;

	case PROMOTION:
		return ((GlobalMembers.attacks_bb(GlobalMembers.promotion_type(m), to, (long)(pieces() ^ from)) & this.<PieceType.KING.getValue()>square(~sideToMove).getValue())) != 0;

	// En passant capture with check? We have already handled the case
	// of direct checks and ordinary discovered check, so the only case we
	// need to handle is the unusual case of a discovered check through
	// the captured pawn.
	case ENPASSANT:
	{
		Square capsq = GlobalMembers.make_square(GlobalMembers.file_of(to), GlobalMembers.rank_of(from));
		long b = (long)((pieces() ^ from ^ capsq) | to);

		return ((GlobalMembers.< PieceType.ROOK.getValue()>attacks_bb(this.<PieceType.KING.getValue()>square(~sideToMove), b) & pieces(sideToMove, PieceType.QUEEN, PieceType.ROOK)) | (GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(this.<PieceType.KING.getValue()>square(~sideToMove), b) & pieces(sideToMove, PieceType.QUEEN, PieceType.BISHOP))) != 0;
	}
	case CASTLING:
	{
		Square kfrom = from;
		Square rfrom = to; // Castling is encoded as 'King captures the rook'
		Square kto = GlobalMembers.relative_square(sideToMove, rfrom.getValue() > kfrom.getValue() ? Square.SQ_G1 : Square.SQ_C1);
		Square rto = GlobalMembers.relative_square(sideToMove, rfrom.getValue() > kfrom.getValue() ? Square.SQ_F1 : Square.SQ_D1);

		return (PseudoAttacks[PieceType.ROOK.getValue()][rto.getValue()] & this.<PieceType.KING.getValue()>square(~sideToMove)) != 0 && (GlobalMembers.<PieceType.ROOK.getValue()>attacks_bb(long)(rto, (pieces() ^ kfrom ^ rfrom) | rto | kto) & this.<PieceType.KING.getValue()>square(~sideToMove)) != 0;
	}
	default:
		assert false;
		return false;
	}
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean advanced_pawn_push(Move m) const
  public final boolean advanced_pawn_push(Move m)
  {
	return GlobalMembers.type_of(moved_piece(m)) == PieceType.PAWN && GlobalMembers.relative_rank(sideToMove, GlobalMembers.from_sq(m)) > Rank.RANK_4.getValue();
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Piece moved_piece(Move m) const
  public final Piece moved_piece(Move m)
  {
	return board[GlobalMembers.from_sq(m).getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Piece captured_piece() const
  public final Piece captured_piece()
  {
	return st.capturedPiece;
  }

  // Piece specific
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean pawn_passed(Color c, Square s) const
  public final boolean pawn_passed(Color c, Square s)
  {
	return (pieces(~c, PieceType.PAWN) & GlobalMembers.passed_pawn_mask(c, s)) == 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean opposite_bishops() const
  public final boolean opposite_bishops()
  {
	return pieceCount[Piece.W_BISHOP.getValue()] == 1 && pieceCount[Piece.B_BISHOP.getValue()] == 1 && GlobalMembers.opposite_colors(this.<PieceType.BISHOP.getValue()>square(Color.WHITE), this.<PieceType.BISHOP.getValue()>square(Color.BLACK));
  }

  // Doing and undoing moves
  public final void do_move(Move m, StateInfo newSt)
  {
	do_move(m, newSt, gives_check(m));
  }


  /// Position::do_move() makes a move, and saves all information necessary
  /// to a StateInfo object. The move is assumed to be legal. Pseudo-legal
  /// moves should be filtered out before this function is called.

  public final void do_move(Move m, StateInfo newSt, boolean givesCheck)
  {

	assert GlobalMembers.is_ok(m);
	assert & newSt != st;

	thisThread.nodes.fetch_add(1, std::memory_order_relaxed);
	long k = st.key ^ Zobrist.GlobalMembers.side;

	// Copy some fields of the old state to our new StateInfo object except the
	// ones which are going to be recalculated from scratch anyway and then switch
	// our state pointer to point to the new (ready to be updated) state.
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
	memcpy(newSt, st, offsetof(StateInfo, key));
	newSt.previous = st;
	st = newSt;

	// Increment ply counters. In particular, rule50 will be reset to zero later on
	// in case of a capture or a pawn move.
	++gamePly;
	++st.rule50;
	++st.pliesFromNull;

	Color us = sideToMove;
	Color them = ~us;
	Square from = GlobalMembers.from_sq(m);
	Square to = GlobalMembers.to_sq(m);
	Piece pc = piece_on(from);
	Piece captured = GlobalMembers.type_of(m) == MoveType.ENPASSANT ? GlobalMembers.make_piece(them, PieceType.PAWN) : piece_on(to);

	assert GlobalMembers.color_of(pc) == us;
	assert captured == Piece.NO_PIECE || GlobalMembers.color_of(captured) == (GlobalMembers.type_of(m) != MoveType.CASTLING ? them : us);
	assert GlobalMembers.type_of(captured) != PieceType.KING;

	if (GlobalMembers.type_of(m) == MoveType.CASTLING)
	{
		assert pc == GlobalMembers.make_piece(us, PieceType.KING);
		assert captured == GlobalMembers.make_piece(us, PieceType.ROOK);

		Square rfrom;
		Square rto;
		tangible.RefObject<Square> tempRef_to = new tangible.RefObject<Square>(to);
		tangible.RefObject<Square> tempRef_rfrom = new tangible.RefObject<Square>(rfrom);
		tangible.RefObject<Square> tempRef_rto = new tangible.RefObject<Square>(rto);
		this.<true>do_castling(us, from, tempRef_to, tempRef_rfrom, tempRef_rto);
		rto = tempRef_rto.argValue;
		rfrom = tempRef_rfrom.argValue;
		to = tempRef_to.argValue;

		k ^= Zobrist.GlobalMembers.psq[captured.getValue()][rfrom.getValue()] ^ Zobrist.GlobalMembers.psq[captured.getValue()][rto.getValue()];
		captured = Piece.NO_PIECE;
	}

	if (captured.getValue() != 0)
	{
		Square capsq = to;

		// If the captured piece is a pawn, update pawn hash key, otherwise
		// update non-pawn material.
		if (GlobalMembers.type_of(captured) == PieceType.PAWN)
		{
			if (GlobalMembers.type_of(m) == MoveType.ENPASSANT)
			{
				capsq -= GlobalMembers.pawn_push(us);

				assert pc == GlobalMembers.make_piece(us, PieceType.PAWN);
				assert to == st.epSquare;
				assert GlobalMembers.relative_rank(us, to) == Rank.RANK_6;
				assert piece_on(to) == Piece.NO_PIECE;
				assert piece_on(capsq) == GlobalMembers.make_piece(them, PieceType.PAWN);

				board[capsq.getValue()] = Piece.NO_PIECE; // Not done by remove_piece()
			}

			st.pawnKey ^= Zobrist.GlobalMembers.psq[captured.getValue()][capsq.getValue()];
		}
		else
		{
			st.nonPawnMaterial[them.getValue()] -= PieceValue[Phase.MG.getValue()][captured.getValue()];
		}

		// Update board and piece lists
		remove_piece(captured, capsq);

		// Update material hash key and prefetch access to materialTable
		k ^= Zobrist.GlobalMembers.psq[captured.getValue()][capsq.getValue()];
		st.materialKey ^= Zobrist.GlobalMembers.psq[captured.getValue()][pieceCount[captured.getValue()]];
		prefetch(thisThread.materialTable[st.materialKey]);

		// Reset rule 50 counter
		st.rule50 = 0;
	}

	// Update hash key
	k ^= Zobrist.GlobalMembers.psq[pc.getValue()][from.getValue()] ^ Zobrist.GlobalMembers.psq[pc.getValue()][to.getValue()];

	// Reset en passant square
	if (st.epSquare != Square.SQ_NONE)
	{
		k ^= Zobrist.GlobalMembers.enpassant[GlobalMembers.file_of(st.epSquare).getValue()];
		st.epSquare = Square.SQ_NONE;
	}

	// Update castling rights if needed
	if (st.castlingRights != 0 && (castlingRightsMask[from.getValue()] | castlingRightsMask[to.getValue()]) != 0)
	{
		int cr = castlingRightsMask[from.getValue()] | castlingRightsMask[to.getValue()];
		k ^= Zobrist.GlobalMembers.castling[st.castlingRights & cr];
		st.castlingRights &= ~cr;
	}

	// Move the piece. The tricky Chess960 castling is handled earlier
	if (GlobalMembers.type_of(m) != MoveType.CASTLING)
	{
		move_piece(pc, from, to);
	}

	// If the moving piece is a pawn do some special extra work
	if (GlobalMembers.type_of(pc) == PieceType.PAWN)
	{
		// Set en-passant square if the moved pawn can be captured
		if ((to.getValue() ^ from.getValue()) == 16 && (this.<PieceType.PAWN.getValue()>attacks_from(to - GlobalMembers.pawn_push(us), us) & pieces(them, PieceType.PAWN)) != 0)
		{
			st.epSquare = to - GlobalMembers.pawn_push(us);
			k ^= Zobrist.GlobalMembers.enpassant[GlobalMembers.file_of(st.epSquare).getValue()];
		}

		else if (GlobalMembers.type_of(m) == MoveType.PROMOTION)
		{
			Piece promotion = GlobalMembers.make_piece(us, GlobalMembers.promotion_type(m));

			assert GlobalMembers.relative_rank(us, to) == Rank.RANK_8;
			assert GlobalMembers.type_of(promotion) >= PieceType.KNIGHT.getValue() && GlobalMembers.type_of(promotion) <= PieceType.QUEEN.getValue();

			remove_piece(pc, to);
			put_piece(promotion, to);

			// Update hash keys
			k ^= Zobrist.GlobalMembers.psq[pc.getValue()][to.getValue()] ^ Zobrist.GlobalMembers.psq[promotion.getValue()][to.getValue()];
			st.pawnKey ^= Zobrist.GlobalMembers.psq[pc.getValue()][to.getValue()];
			st.materialKey ^= Zobrist.GlobalMembers.psq[promotion.getValue()][pieceCount[promotion.getValue()] - 1] ^ Zobrist.GlobalMembers.psq[pc.getValue()][pieceCount[pc.getValue()]];

			// Update material
			st.nonPawnMaterial[us.getValue()] += PieceValue[Phase.MG.getValue()][promotion.getValue()];
		}

		// Update pawn hash key and prefetch access to pawnsTable
		st.pawnKey ^= Zobrist.GlobalMembers.psq[pc.getValue()][from.getValue()] ^ Zobrist.GlobalMembers.psq[pc.getValue()][to.getValue()];
		prefetch2(thisThread.pawnsTable[st.pawnKey]);

		// Reset rule 50 draw counter
		st.rule50 = 0;
	}

	// Set capture piece
	st.capturedPiece = captured;

	// Update the key with the final value
	st.key = k;

	// Calculate checkers bitboard (if move gives check)
	st.checkersBB = givesCheck ? attackers_to(this.<PieceType.KING.getValue()>square(them)) & pieces(us) : 0;

	sideToMove = ~sideToMove;

	// Update king attacks used for fast check detection
	set_check_info(st);

	assert pos_is_ok();
  }


  /// Position::undo_move() unmakes a move. When it returns, the position should
  /// be restored to exactly the same state as before the move was made.

  public final void undo_move(Move m)
  {

	assert GlobalMembers.is_ok(m);

	sideToMove = ~sideToMove;

	Color us = sideToMove;
	Square from = GlobalMembers.from_sq(m);
	Square to = GlobalMembers.to_sq(m);
	Piece pc = piece_on(to);

	assert empty(from) || GlobalMembers.type_of(m) == MoveType.CASTLING;
	assert GlobalMembers.type_of(st.capturedPiece) != PieceType.KING;

	if (GlobalMembers.type_of(m) == MoveType.PROMOTION)
	{
		assert GlobalMembers.relative_rank(us, to) == Rank.RANK_8;
		assert GlobalMembers.type_of(pc) == GlobalMembers.promotion_type(m);
		assert GlobalMembers.type_of(pc) >= PieceType.KNIGHT.getValue() && GlobalMembers.type_of(pc) <= PieceType.QUEEN.getValue();

		remove_piece(pc, to);
		pc = GlobalMembers.make_piece(us, PieceType.PAWN);
		put_piece(pc, to);
	}

	if (GlobalMembers.type_of(m) == MoveType.CASTLING)
	{
		Square rfrom;
		Square rto;
		tangible.RefObject<Square> tempRef_to = new tangible.RefObject<Square>(to);
		tangible.RefObject<Square> tempRef_rfrom = new tangible.RefObject<Square>(rfrom);
		tangible.RefObject<Square> tempRef_rto = new tangible.RefObject<Square>(rto);
		this.<false>do_castling(us, from, tempRef_to, tempRef_rfrom, tempRef_rto);
		rto = tempRef_rto.argValue;
		rfrom = tempRef_rfrom.argValue;
		to = tempRef_to.argValue;
	}
	else
	{
		move_piece(pc, to, from); // Put the piece back at the source square

		if (st.capturedPiece.getValue() != 0)
		{
			Square capsq = to;

			if (GlobalMembers.type_of(m) == MoveType.ENPASSANT)
			{
				capsq -= GlobalMembers.pawn_push(us);

				assert GlobalMembers.type_of(pc) == PieceType.PAWN;
				assert to == st.previous.epSquare;
				assert GlobalMembers.relative_rank(us, to) == Rank.RANK_6;
				assert piece_on(capsq) == Piece.NO_PIECE;
				assert st.capturedPiece == GlobalMembers.make_piece(~us, PieceType.PAWN);
			}

			put_piece(st.capturedPiece, capsq); // Restore the captured piece
		}
	}

	// Finally point our state pointer back to the previous state
	st = st.previous;
	--gamePly;

	assert pos_is_ok();
  }


  /// Position::do(undo)_null_move() is used to do(undo) a "null move": It flips
  /// the side to move without executing any move on the board.

  public final void do_null_move(StateInfo newSt)
  {

	assert!checkers();
	assert & newSt != st;

//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memcpy(newSt, st, sizeof(StateInfo));
	newSt.previous = st;
	st = newSt;

	if (st.epSquare != Square.SQ_NONE)
	{
		st.key ^= Zobrist.GlobalMembers.enpassant[GlobalMembers.file_of(st.epSquare).getValue()];
		st.epSquare = Square.SQ_NONE;
	}

	st.key ^= Zobrist.GlobalMembers.side;
	prefetch(TT.first_entry(st.key));

	++st.rule50;
	st.pliesFromNull = 0;

	sideToMove = ~sideToMove;

	set_check_info(st);

	assert pos_is_ok();
  }

  public final void undo_null_move()
  {

	assert!checkers();

	st = st.previous;
	sideToMove = ~sideToMove;
  }

  // Static Exchange Evaluation

  /// Position::see_ge (Static Exchange Evaluation Greater or Equal) tests if the
  /// SEE value of move is greater or equal to the given threshold. We'll use an
  /// algorithm similar to alpha-beta pruning with a null window.

  public final boolean see_ge(Move m)
  {
	  return see_ge(m, Value.VALUE_ZERO);
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean see_ge(Move m, Value threshold = VALUE_ZERO) const
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
  public final boolean see_ge(Move m, Value threshold)
  {

	assert GlobalMembers.is_ok(m);

	// Only deal with normal moves, assume others pass a simple see
	if (GlobalMembers.type_of(m) != MoveType.NORMAL)
	{
		return Value.VALUE_ZERO.getValue() >= threshold.getValue();
	}

	long stmAttackers;
	Square from = GlobalMembers.from_sq(m);
	Square to = GlobalMembers.to_sq(m);
	PieceType nextVictim = GlobalMembers.type_of(piece_on(from));
	Color us = GlobalMembers.color_of(piece_on(from));
	Color stm = ~us; // First consider opponent's move
	Value balance; // Values of the pieces taken by us minus opponent's ones

	// The opponent may be able to recapture so this is the best result
	// we can hope for.
	balance = PieceValue[Phase.MG.getValue()][piece_on(to).getValue()] - threshold;

	if (balance.getValue() < Value.VALUE_ZERO.getValue())
	{
		return false;
	}

	// Now assume the worst possible result: that the opponent can
	// capture our piece for free.
	balance -= PieceValue[Phase.MG.getValue()][nextVictim.getValue()];

	// If it is enough (like in PxQ) then return immediately. Note that
	// in case nextVictim == KING we always return here, this is ok
	// if the given move is legal.
	if (balance.getValue() >= Value.VALUE_ZERO.getValue())
	{
		return true;
	}

	// Find all attackers to the destination square, with the moving piece
	// removed, but possibly an X-ray attacker added behind it.
	long occupied = (long)(pieces() ^ from ^ to);
	long attackers = attackers_to(to, occupied) & occupied;

	while (true)
	{
		stmAttackers = attackers & pieces(stm);

		// Don't allow pinned pieces to attack (except the king) as long as
		// all pinners are on their original square.
		if ((st.pinners[~stm] & ~occupied) == 0)
		{
			stmAttackers &= ~st.blockersForKing[stm.getValue()];
		}

		// If stm has no more attackers then give up: stm loses
		if (stmAttackers == 0)
		{
			break;
		}

		// Locate and remove the next least valuable attacker, and add to
		// the bitboard 'attackers' the possibly X-ray attackers behind it.
		nextVictim = GlobalMembers.<PieceType.PAWN.getValue()>min_attacker(byTypeBB, to, stmAttackers, occupied, attackers);

		stm = ~stm; // Switch side to move

		// Negamax the balance with alpha = balance, beta = balance+1 and
		// add nextVictim's value.
		//
		//      (balance, balance+1) -> (-balance-1, -balance)
		//
		assert balance.getValue() < Value.VALUE_ZERO.getValue();

		balance = -balance - 1 - PieceValue[Phase.MG.getValue()][nextVictim.getValue()];

		// If balance is still non-negative after giving away nextVictim then we
		// win. The only thing to be careful about it is that we should revert
		// stm if we captured with the king when the opponent still has attackers.
		if (balance.getValue() >= Value.VALUE_ZERO.getValue())
		{
			if (nextVictim == PieceType.KING && (attackers & pieces(stm)) != 0)
			{
				stm = ~stm;
			}
			break;
		}
		assert nextVictim != PieceType.KING;
	}
	return us != stm; // We break the above loop when stm loses
  }

  // Accessing hash keys
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong key() const
  public final long key()
  {
	return st.key;
  }


  /// Position::key_after() computes the new hash key after the given move. Needed
  /// for speculative prefetch. It doesn't recognize special moves like castling,
  /// en-passant and promotions.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong key_after(Move m) const
  public final long key_after(Move m)
  {

	Square from = GlobalMembers.from_sq(m);
	Square to = GlobalMembers.to_sq(m);
	Piece pc = piece_on(from);
	Piece captured = piece_on(to);
	long k = st.key ^ Zobrist.GlobalMembers.side;

	if (captured.getValue() != 0)
	{
		k ^= Zobrist.GlobalMembers.psq[captured.getValue()][to.getValue()];
	}

	return k ^ Zobrist.GlobalMembers.psq[pc.getValue()][to.getValue()] ^ Zobrist.GlobalMembers.psq[pc.getValue()][from.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong material_key() const
  public final long material_key()
  {
	return st.materialKey;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pawn_key() const
  public final long pawn_key()
  {
	return st.pawnKey;
  }

  // Other properties of the position
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Color side_to_move() const
  public final Color side_to_move()
  {
	return sideToMove;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int game_ply() const
  public final int game_ply()
  {
	return gamePly;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean is_chess960() const
  public final boolean is_chess960()
  {
	return chess960;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Thread* this_thread() const
  public final Thread this_thread()
  {
	return thisThread;
  }


  /// Position::is_draw() tests whether the position is drawn by 50-move rule
  /// or by repetition. It does not detect stalemates.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean is_draw(int ply) const
  public final boolean is_draw(int ply)
  {

	if (st.rule50 > 99 && (checkers() == 0 || new MoveList<GenType.LEGAL.getValue()>(this).size() != null))
	{
		return true;
	}

	int end = Math.min(st.rule50, st.pliesFromNull);

	if (end < 4)
	{
	  return false;
	}

	StateInfo stp = st.previous.previous;
	int cnt = 0;

	for (int i = 4; i <= end; i += 2)
	{
		stp = stp.previous.previous;

		// Return a draw score if a position repeats once earlier but strictly
		// after the root, or repeats twice before or at the root.
		if (stp.key == st.key && ++cnt + (ply > i) == 2)
		{
			return true;
		}
	}

	return false;
  }


  /// Position::has_game_cycle() tests if the position has a move which draws by repetition,
  /// or an earlier position has a move that directly reaches the current position.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean has_game_cycle(int ply) const
  public final boolean has_game_cycle(int ply)
  {

	int j;

	int end = Math.min(st.rule50, st.pliesFromNull);

	if (end < 3)
	{
	  return false;
	}

	long originalKey = st.key;
	StateInfo stp = st.previous;

	for (int i = 3; i <= end; i += 2)
	{
		stp = stp.previous.previous;

		long moveKey = originalKey ^ stp.key;
		if ((j = GlobalMembers.H1(moveKey), GlobalMembers.cuckoo[j] == moveKey) || (j = GlobalMembers.H2(moveKey), GlobalMembers.cuckoo[j] == moveKey))
		{
			Move move = GlobalMembers.cuckooMove[j];
			Square s1 = GlobalMembers.from_sq(move);
			Square s2 = GlobalMembers.to_sq(move);

			if ((GlobalMembers.between_bb(s1, s2) & pieces()) == 0)
			{
				// In the cuckoo table, both moves Rc1c5 and Rc5c1 are stored in the same
				// location. We select the legal one by reversing the move variable if necessary.
				if (empty(s1))
				{
					move = GlobalMembers.make_move(s2, s1);
				}

				if (ply > i)
				{
					return true;
				}

				// For repetitions before or at the root, require one more
				StateInfo next_stp = stp;
				for (int k = i + 2; k <= end; k += 2)
				{
					next_stp = next_stp.previous.previous;
					if (next_stp.key == stp.key)
					{
					   return true;
					}
				}
			}
		}
	}
	return false;
  }


  // Position::has_repeated() tests whether there has been at least one repetition
  // of positions since the last capture or pawn move.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean has_repeated() const
  public final boolean has_repeated()
  {

	  StateInfo stc = st;
	  while (true)
	  {
		  int i = 4;
		  int end = Math.min(stc.rule50, stc.pliesFromNull);

		  if (end < i)
		  {
			  return false;
		  }

		  StateInfo stp = stc.previous.previous;

		  do
		  {
			  stp = stp.previous.previous;

			  if (stp.key == stc.key)
			  {
				  return true;
			  }

			  i += 2;
		  } while (i <= end);

		  stc = stc.previous;
	  }
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int rule50_count() const
  public final int rule50_count()
  {
	return st.rule50;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Score psq_score() const
  public final Score psq_score()
  {
	return GlobalMembers.psq;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value non_pawn_material(Color c) const
  public final Value non_pawn_material(Color c)
  {
	return st.nonPawnMaterial[c.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value non_pawn_material() const
  public final Value non_pawn_material()
  {
	return st.nonPawnMaterial[Color.WHITE.getValue()] + st.nonPawnMaterial[Color.BLACK.getValue()];
  }

  // Position consistency check, for debugging

  /// Position::pos_is_ok() performs some consistency checks for the
  /// position object and raises an asserts if something wrong is detected.
  /// This is meant to be helpful when debugging.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean pos_is_ok() const
  public final boolean pos_is_ok()
  {

	final boolean Fast = true; // Quick (default) or full check?

	if ((sideToMove != Color.WHITE && sideToMove != Color.BLACK) || piece_on(this.<PieceType.KING.getValue()>square(Color.WHITE)) != Piece.W_KING || piece_on(this.<PieceType.KING.getValue()>square(Color.BLACK)) != Piece.B_KING || (ep_square() != Square.SQ_NONE && GlobalMembers.relative_rank(sideToMove, ep_square()) != Rank.RANK_6))
	{
		assert 0 && "pos_is_ok: Default";
	}

	if (Fast)
	{
		return true;
	}

	if (pieceCount[Piece.W_KING.getValue()] != 1 || pieceCount[Piece.B_KING.getValue()] != 1 || (attackers_to(this.<PieceType.KING.getValue()>square(~sideToMove)) & pieces(sideToMove)) != 0)
	{
		assert 0 && "pos_is_ok: Kings";
	}

	if ((pieces(PieceType.PAWN) & (GlobalMembers.Rank1BB | GlobalMembers.Rank8BB)) != 0 || pieceCount[Piece.W_PAWN.getValue()] > 8 || pieceCount[Piece.B_PAWN.getValue()] > 8)
	{
		assert 0 && "pos_is_ok: Pawns";
	}

	if ((pieces(Color.WHITE) & pieces(Color.BLACK)) != 0 || (pieces(Color.WHITE) | pieces(Color.BLACK)) != pieces() || GlobalMembers.popcount(pieces(Color.WHITE)) > 16 || GlobalMembers.popcount(pieces(Color.BLACK)) > 16)
	{
		assert 0 && "pos_is_ok: Bitboards";
	}

	for (PieceType p1 = PieceType.PAWN; p1.getValue() <= PieceType.KING.getValue(); ++p1)
	{
		for (PieceType p2 = PieceType.PAWN; p2.getValue() <= PieceType.KING.getValue(); ++p2)
		{
			if (p1 != p2 && (pieces(p1) & pieces(p2)) != 0)
			{
				assert 0 && "pos_is_ok: Bitboards";
			}
		}
	}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: StateInfo si = *st;
	StateInfo si = new StateInfo(st);
	set_state(si);
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcmp' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	if (memcmp(si, st, sizeof(StateInfo)))
	{
		assert 0 && "pos_is_ok: State";
	}

	for (Piece pc : GlobalMembers.Pieces)
	{
		if (pieceCount[pc.getValue()] != GlobalMembers.popcount(pieces(GlobalMembers.color_of(pc), GlobalMembers.type_of(pc))) || pieceCount[pc.getValue()] != std::count(board, board + Square.SQUARE_NB, pc))
		{
			assert 0 && "pos_is_ok: Pieces";
		}

		for (int i = 0; i < pieceCount[pc.getValue()]; ++i)
		{
			if (board[pieceList[pc.getValue()][i].getValue()] != pc || index[pieceList[pc.getValue()][i].getValue()] != i)
			{
				assert 0 && "pos_is_ok: Index";
			}
		}
	}

	for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); ++c)
	{
		for (CastlingSide s = CastlingSide.KING_SIDE; s.getValue() <= CastlingSide.QUEEN_SIDE.getValue(); s = CastlingSide(s + 1))
		{
			if (can_castle(c | s) == 0)
			{
				continue;
			}

			if (piece_on(castlingRookSquare[c.getValue() | s]) != GlobalMembers.make_piece(c, PieceType.ROOK) || castlingRightsMask[castlingRookSquare[c.getValue() | s].getValue()] != (c | s) || (castlingRightsMask[this.<PieceType.KING.getValue()>square(c)] & (c | s)) != (c | s))
			{
				assert 0 && "pos_is_ok: Castling";
			}
		}
	}

	return true;
  }


  /// Position::flip() flips position with the white and black sides reversed. This
  /// is only useful for debugging e.g. for finding evaluation symmetry bugs.

  public final void flip()
  {

	String f;
	String token;
	std::stringstream ss = new std::stringstream(fen());

	for (Rank r = Rank.RANK_8; r.getValue() >= Rank.RANK_1.getValue(); --r) // Piece placement
	{
		getline(ss, token, r.getValue() > Rank.RANK_1.getValue() ? '/' : ' ');
		f = f.insert(0, token + (f.length() == 0 ? " " : "/"));
	}

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	ss >> token; // Active color
	f += (token.equals("w") ? "B " : "W "); // Will be lowercased later

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	ss >> token; // Castling availability
	f += token + " ";

	std::transform(f.iterator(), f.end(), f.iterator(), (char c) ->
	{
		return (char)(Character.isLowerCase(c) ? Character.toUpperCase(c) : Character.toLowerCase(c));
	});

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	ss >> token; // En passant square
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to the standard string 'replace' method in Java if it's used as an rvalue:
	f += (token.equals("-") ? token : token.replace(1, 1, token.charAt(1) == '3' ? "6" : "3"));

	getline(ss, token); // Half and full moves
	f += token;

	set(f, is_chess960(), st, this_thread());

	assert pos_is_ok();
  }

  // Initialization helpers (used while setting up a position)

  /// Position::set_castling_right() is a helper function used to set castling
  /// rights given the corresponding color and the rook starting square.

  private void set_castling_right(Color c, Square rfrom)
  {

	Square kfrom = this.<PieceType.KING.getValue()>square(c);
	CastlingSide cs = kfrom.getValue() < rfrom.getValue() ? CastlingSide.KING_SIDE : CastlingSide.QUEEN_SIDE;
	CastlingRight cr = (c | cs);

	st.castlingRights |= cr;
	castlingRightsMask[kfrom.getValue()] |= cr;
	castlingRightsMask[rfrom.getValue()] |= cr;
	castlingRookSquare[cr.getValue()] = rfrom;

	Square kto = GlobalMembers.relative_square(c, cs == CastlingSide.KING_SIDE ? Square.SQ_G1 : Square.SQ_C1);
	Square rto = GlobalMembers.relative_square(c, cs == CastlingSide.KING_SIDE ? Square.SQ_F1 : Square.SQ_D1);

	for (Square s = Math.min(rfrom, rto); s.getValue() <= Math.max(rfrom, rto); ++s)
	{
		if (s != kfrom && s != rfrom)
		{
			castlingPath[cr.getValue()] |= s;
		}
	}

	for (Square s = Math.min(kfrom, kto); s.getValue() <= Math.max(kfrom, kto); ++s)
	{
		if (s != kfrom && s != rfrom)
		{
			castlingPath[cr.getValue()] |= s;
		}
	}
  }


  /// Position::set_state() computes the hash keys of the position, and other
  /// data that once computed is updated incrementally as moves are made.
  /// The function is only used when a new position is set up, and to verify
  /// the correctness of the StateInfo data when running in debug mode.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: void set_state(StateInfo* si) const
  private void set_state(StateInfo si)
  {

	si.key = si.materialKey = 0;
	si.pawnKey = Zobrist.GlobalMembers.noPawns;
	si.nonPawnMaterial[Color.WHITE.getValue()] = si.nonPawnMaterial[Color.BLACK.getValue()] = Value.VALUE_ZERO;
	si.checkersBB = attackers_to(this.<PieceType.KING.getValue()>square(sideToMove)) & pieces(~sideToMove);

	set_check_info(si);

	for (long b = pieces(); b;)
	{
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
		Square s = GlobalMembers.pop_lsb(tempRef_b);
		b = tempRef_b.argValue;
		Piece pc = piece_on(s);
		si.key ^= Zobrist.GlobalMembers.psq[pc.getValue()][s.getValue()];
	}

	if (si.epSquare != Square.SQ_NONE)
	{
		si.key ^= Zobrist.GlobalMembers.enpassant[GlobalMembers.file_of(si.epSquare).getValue()];
	}

	if (sideToMove == Color.BLACK)
	{
		si.key ^= Zobrist.GlobalMembers.side;
	}

	si.key ^= Zobrist.GlobalMembers.castling[si.castlingRights];

	for (long b = pieces(PieceType.PAWN); b;)
	{
		tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b);
		Square s = GlobalMembers.pop_lsb(tempRef_b2);
		b = tempRef_b2.argValue;
		si.pawnKey ^= Zobrist.GlobalMembers.psq[piece_on(s).getValue()][s.getValue()];
	}

	for (Piece pc : GlobalMembers.Pieces)
	{
		if (GlobalMembers.type_of(pc) != PieceType.PAWN && GlobalMembers.type_of(pc) != PieceType.KING)
		{
			si.nonPawnMaterial[GlobalMembers.color_of(pc).getValue()] += pieceCount[pc.getValue()] * PieceValue[Phase.MG.getValue()][pc.getValue()];
		}

		for (int cnt = 0; cnt < pieceCount[pc.getValue()]; ++cnt)
		{
			si.materialKey ^= Zobrist.GlobalMembers.psq[pc.getValue()][cnt];
		}
	}
  }


  /// Position::set_check_info() sets king attacks to detect if a move gives check

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: void set_check_info(StateInfo* si) const
  private void set_check_info(StateInfo si)
  {

	si.blockersForKing[Color.WHITE.getValue()] = slider_blockers(pieces(Color.BLACK), this.<PieceType.KING.getValue()>square(Color.WHITE), si.pinners[Color.BLACK.getValue()]);
	si.blockersForKing[Color.BLACK.getValue()] = slider_blockers(pieces(Color.WHITE), this.<PieceType.KING.getValue()>square(Color.BLACK), si.pinners[Color.WHITE.getValue()]);

	Square ksq = this.<PieceType.KING.getValue()>square(~sideToMove);

	si.checkSquares[PieceType.PAWN.getValue()] = this.<PieceType.PAWN.getValue()>attacks_from(ksq, ~sideToMove);
	si.checkSquares[PieceType.KNIGHT.getValue()] = this.<PieceType.KNIGHT.getValue()>attacks_from(ksq);
	si.checkSquares[PieceType.BISHOP.getValue()] = this.<PieceType.BISHOP.getValue()>attacks_from(ksq);
	si.checkSquares[PieceType.ROOK.getValue()] = this.<PieceType.ROOK.getValue()>attacks_from(ksq);
	si.checkSquares[PieceType.QUEEN.getValue()] = si.checkSquares[PieceType.BISHOP.getValue()] | si.checkSquares[PieceType.ROOK.getValue()];
	si.checkSquares[PieceType.KING.getValue()] = 0;
  }

  // Other helpers
  private void put_piece(Piece pc, Square s)
  {

	board[s.getValue()] = pc;
	byTypeBB[PieceType.ALL_PIECES.getValue()] |= s;
	byTypeBB[GlobalMembers.type_of(pc).getValue()] |= s;
	byColorBB[GlobalMembers.color_of(pc).getValue()] |= s;
	index[s.getValue()] = pieceCount[pc.getValue()]++;
	pieceList[pc.getValue()][index[s.getValue()]] = s;
	pieceCount[GlobalMembers.make_piece(GlobalMembers.color_of(pc), PieceType.ALL_PIECES).getValue()]++;
	GlobalMembers.psq += PSQT.psq[pc.getValue()][s.getValue()];
  }

  private void remove_piece(Piece pc, Square s)
  {

	// WARNING: This is not a reversible operation. If we remove a piece in
	// do_move() and then replace it in undo_move() we will put it at the end of
	// the list and not in its original place, it means index[] and pieceList[]
	// are not invariant to a do_move() + undo_move() sequence.
	byTypeBB[PieceType.ALL_PIECES.getValue()] ^= s;
	byTypeBB[GlobalMembers.type_of(pc).getValue()] ^= s;
	byColorBB[GlobalMembers.color_of(pc).getValue()] ^= s;
	/* board[s] = NO_PIECE;  Not needed, overwritten by the capturing one */
	Square lastSquare = pieceList[pc.getValue()][--pieceCount[pc.getValue()]];
	index[lastSquare.getValue()] = index[s.getValue()];
	pieceList[pc.getValue()][index[lastSquare.getValue()]] = lastSquare;
	pieceList[pc.getValue()][pieceCount[pc.getValue()]] = Square.SQ_NONE;
	pieceCount[GlobalMembers.make_piece(GlobalMembers.color_of(pc), PieceType.ALL_PIECES).getValue()]--;
	GlobalMembers.psq -= PSQT.psq[pc.getValue()][s.getValue()];
  }

  private void move_piece(Piece pc, Square from, Square to)
  {

	// index[from] is not updated and becomes stale. This works as long as index[]
	// is accessed just by known occupied squares.
	long fromTo = (long)(SquareBB[from.getValue()] ^ SquareBB[to.getValue()]);
	byTypeBB[PieceType.ALL_PIECES.getValue()] ^= fromTo;
	byTypeBB[GlobalMembers.type_of(pc).getValue()] ^= fromTo;
	byColorBB[GlobalMembers.color_of(pc).getValue()] ^= fromTo;
	board[from.getValue()] = Piece.NO_PIECE;
	board[to.getValue()] = pc;
	index[to.getValue()] = index[from.getValue()];
	pieceList[pc.getValue()][index[to.getValue()]] = to;
	GlobalMembers.psq += PSQT.psq[pc.getValue()][to.getValue()] - PSQT.psq[pc.getValue()][from.getValue()];
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<bool Do>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Do>

  /// Position::do_castling() is a helper used to do/undo a castling move. This
  /// is a bit tricky in Chess960 where from/to squares can overlap.
  private <Do> void do_castling(Color us, Square from, tangible.RefObject<Square> to, tangible.RefObject<Square> rfrom, tangible.RefObject<Square> rto)
  {

	boolean kingSide = to.argValue.getValue() > from.getValue();
	rfrom.argValue = to.argValue; // Castling is encoded as "king captures friendly rook"
	rto.argValue = GlobalMembers.relative_square(us, kingSide ? Square.SQ_F1 : Square.SQ_D1);
	to.argValue = GlobalMembers.relative_square(us, kingSide ? Square.SQ_G1 : Square.SQ_C1);

	// Remove both pieces first since squares could overlap in Chess960
	remove_piece(GlobalMembers.make_piece(us, PieceType.KING), Do ? from : to.argValue);
	remove_piece(GlobalMembers.make_piece(us, PieceType.ROOK), Do ? rfrom.argValue : rto.argValue);
	board[Do ? from : to.argValue] = board[Do ? rfrom.argValue : rto.argValue] = Piece.NO_PIECE; // Since remove_piece doesn't do it for us
	put_piece(GlobalMembers.make_piece(us, PieceType.KING), Do ? to.argValue : from);
	put_piece(GlobalMembers.make_piece(us, PieceType.ROOK), Do ? rto.argValue : rfrom.argValue);
  }

  // Data members
  private Piece[] board = new Piece[Square.SQUARE_NB.getValue()];
  private long[] byTypeBB = new long[PieceType.PIECE_TYPE_NB.getValue()];
  private long[] byColorBB = new long[Color.COLOR_NB.getValue()];
  private int[] pieceCount = new int[Piece.PIECE_NB.getValue()];
  private Square[][] pieceList = new Square[Piece.PIECE_NB.getValue()][16];
  private int[] index = new int[Square.SQUARE_NB.getValue()];
  private int[] castlingRightsMask = new int[Square.SQUARE_NB.getValue()];
  private Square[] castlingRookSquare = new Square[CastlingRight.CASTLING_RIGHT_NB.getValue()];
  private long[] castlingPath = new long[CastlingRight.CASTLING_RIGHT_NB.getValue()];
  private int gamePly;
  private Color sideToMove;
  private Score psq;
  private Thread thisThread;
  private StateInfo st;
  private boolean chess960;
}
//C++ TO JAVA CONVERTER TODO TASK: The following package should be saved to a separate file:

//C++ TO JAVA CONVERTER TODO TASK: The following package should be saved to a separate file:




//C++ TO JAVA CONVERTER TODO TASK: The following statement was not recognized, possibly due to an unrecognized macro:
const String PieceToChar(" PNBRQK  pnbrqk");