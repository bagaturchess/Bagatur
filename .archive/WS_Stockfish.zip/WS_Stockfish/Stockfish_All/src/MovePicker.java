import java.util.*;

/// CounterMoveHistory stores counter moves indexed by [piece][to] of the previous
/// move, see chessprogramming.wikispaces.com/Countermove+Heuristic

/// CapturePieceToHistory is addressed by a move's [piece][to][captured piece type]

/// PieceToHistory is like ButterflyHistory but is addressed by a move's [piece][to]

/// ContinuationHistory is the combined history of a given pair of moves, usually
/// the current one given a previous one. The nested history table is based on
/// PieceToHistory instead of ButterflyBoards.


/// MovePicker class is used to pick one pseudo legal move at a time from the
/// current position. The most important method is next_move(), which returns a
/// new pseudo legal move each time it is called, until there are no moves left,
/// when MOVE_NONE is returned. In order to improve the efficiency of the alpha
/// beta algorithm, MovePicker attempts to return the moves which are most likely
/// to get a cut-off first.
public class MovePicker
{

  private enum PickType
  {
	  Next,
	  Best;

	  public static final int SIZE = java.lang.Integer.SIZE;

	  public int getValue()
	  {
		  return this.ordinal();
	  }

	  public static PickType forValue(int value)
	  {
		  return values()[value];
	  }
  }

//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
//  MovePicker(const MovePicker&) = delete;
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
//  MovePicker& operator =(const MovePicker&) = delete;

  /// MovePicker constructor for ProbCut: we generate captures with SEE greater
  /// than or equal to the given threshold.
  public MovePicker(Position p, Move ttm, Value th, Stats<int16_t, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB> cph)
  {
	  this.pos = new Position(p);
	  this.captureHistory = new Stats<int16_t, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB.getValue()>(cph);
	  this.threshold = new Value(th);

	assert!pos.checkers();

	stage = Stages.PROBCUT_TT.getValue();
	ttMove = ttm.getValue() != 0 && pos.pseudo_legal(ttm) && pos.capture(ttm) && pos.see_ge(ttm, threshold) ? ttm : Move.MOVE_NONE;
	stage += (ttMove == Move.MOVE_NONE);
  }


  /// MovePicker constructor for quiescence search
  public MovePicker(Position p, Move ttm, Depth d, ButterflyHistory mh, Stats<int16_t, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB> cph, Stats<int16_t, 29952, Piece.PIECE_NB, Square.SQUARE_NB>[] ch, Square rs)
  {
	  this.pos = new Position(p);
	  this.mainHistory = mh;
	  this.captureHistory = new Stats<int16_t, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB.getValue()>(cph);
	  this.continuationHistory = new Stats<int16_t, 29952, Piece.PIECE_NB, Square.SQUARE_NB.getValue()>(ch);
	  this.recaptureSquare = new Square(rs);
	  this.depth = new Depth(d);

	assert d.getValue() <= Depth.DEPTH_ZERO.getValue();

	stage = pos.checkers() != null ? Stages.EVASION_TT.getValue() : Stages.QSEARCH_TT.getValue();
	ttMove = ttm.getValue() != 0 && pos.pseudo_legal(ttm) && (depth.getValue() > Depth.DEPTH_QS_RECAPTURES.getValue() || GlobalMembers.to_sq(ttm) == recaptureSquare) ? ttm : Move.MOVE_NONE;
	stage += (ttMove == Move.MOVE_NONE);
  }


  /// Constructors of the MovePicker class. As arguments we pass information
  /// to help it to return the (presumably) good moves first, to decide which
  /// moves to return (in the quiescence search, for instance, we only want to
  /// search captures, promotions, and some checks) and how important good move
  /// ordering is at the current node.

  /// MovePicker constructor for the main search
  public MovePicker(Position p, Move ttm, Depth d, ButterflyHistory mh, Stats<int16_t, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB> cph, Stats<int16_t, 29952, Piece.PIECE_NB, Square.SQUARE_NB>[] ch, Move cm, Move killers)
  {
	  this.pos = new Position(p);
	  this.mainHistory = mh;
	  this.captureHistory = new Stats<int16_t, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB.getValue()>(cph);
	  this.continuationHistory = new Stats<int16_t, 29952, Piece.PIECE_NB, Square.SQUARE_NB.getValue()>(ch);
	  refutations[0] = new ExtMove(killers[0], 0);
	  refutations[1] =  new ExtMove(killers[1], 0);
	  refutations[2] =  new ExtMove(cm, 0);
	  this.depth = new Depth(d);

	assert d.getValue() > Depth.DEPTH_ZERO.getValue();

	stage = pos.checkers() != null ? Stages.EVASION_TT.getValue() : Stages.MAIN_TT.getValue();
	ttMove = ttm.getValue() != 0 && pos.pseudo_legal(ttm) ? ttm : Move.MOVE_NONE;
	stage += (ttMove == Move.MOVE_NONE);
  }


  /// MovePicker::next_move() is the most important method of the MovePicker class. It
  /// returns a new pseudo legal move every time it is called until there are no more
  /// moves left, picking the move with the highest score from a list of generated moves.
  public final Move next_move()
  {
	  return next_move(false);
  }
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: Move next_move(boolean skipQuiets = false)
  public final Move next_move(boolean skipQuiets)
  {

//C++ TO JAVA CONVERTER TODO TASK: There are no gotos or labels in Java:
  top:
	switch (stage)
	{

	case MAIN_TT:
	case EVASION_TT:
	case QSEARCH_TT:
	case PROBCUT_TT:
		++stage;
		return ttMove;

	case CAPTURE_INIT:
	case PROBCUT_INIT:
	case QCAPTURE_INIT:
		cur = endBadCaptures = moves;
		endMoves = generate<GenType.CAPTURES.getValue()>(pos, cur);

		this.<GenType.CAPTURES.getValue()>score();
		++stage;
//C++ TO JAVA CONVERTER TODO TASK: There are no gotos or labels in Java:
		goto top;

	case GOOD_CAPTURE:
		if (this.<PickType.Best.getValue()>select(() ->
		{
			//C++ TO JAVA CONVERTER TODO TASK: The following line could not be converted:
			return pos.see_ge(move, Value(-55 * (cur - 1).value / 1024)) ? true : (endBadCaptures++ = move, false);
		}).getValue() != 0)
		{
			return move;
		}

		// Prepare the pointers to loop over the refutations array
		cur = refutations.begin();
		endMoves = refutations.end();

		// If the countermove is the same as a killer, skip it
		if (refutations[0].move == refutations[2].move || refutations[1].move == refutations[2].move)
		{
			--endMoves;
		}

		++stage;
		/* fallthrough */

	case REFUTATION:
		if (this.<PickType.Next.getValue()>select(() ->
		{
			//C++ TO JAVA CONVERTER TODO TASK: The following line could not be converted:
			return move != Move.MOVE_NONE && !pos.capture(move) && pos.pseudo_legal(move);
		}).getValue() != 0)
		{
			return move;
		}
		++stage;
		/* fallthrough */

	case QUIET_INIT:
		cur = endBadCaptures;
		endMoves = generate<GenType.QUIETS.getValue()>(pos, cur);

		this.<GenType.QUIETS.getValue()>score();
		GlobalMembers.partial_insertion_sort(cur, endMoves, -4000 * depth / Depth.ONE_PLY.getValue());
		++stage;
		/* fallthrough */

	case QUIET:
		if (!skipQuiets && this.<PickType.Next.getValue()>select(() ->
		{
			//C++ TO JAVA CONVERTER TODO TASK: The following line could not be converted:
			return move != refutations[0] && move != refutations[1] && move != refutations[2];
		}).getValue() != 0)
		{
			return move;
		}

		// Prepare the pointers to loop over the bad captures
		cur = moves;
		endMoves = endBadCaptures;

		++stage;
		/* fallthrough */

	case BAD_CAPTURE:
		return this.<PickType.Next.getValue()>select(Any);

	case EVASION_INIT:
		cur = moves;
		endMoves = generate<GenType.EVASIONS.getValue()>(pos, cur);

		this.<GenType.EVASIONS.getValue()>score();
		++stage;
		/* fallthrough */

	case EVASION:
		return this.<PickType.Best.getValue()>select(Any);

	case PROBCUT:
		return this.<PickType.Best.getValue()>select(() ->
		{
			return pos.see_ge(move, threshold);
		});

	case QCAPTURE:
		if (this.<PickType.Best.getValue()>select(() ->
		{
			//C++ TO JAVA CONVERTER TODO TASK: The following line could not be converted:
			return depth.getValue() > Depth.DEPTH_QS_RECAPTURES.getValue() || to_sq(move) == recaptureSquare;
		}).getValue() != 0)
		{
			return move;
		}

		// If we did not find any move and we do not try checks, we have finished
		if (depth != Depth.DEPTH_QS_CHECKS)
		{
			return Move.MOVE_NONE;
		}

		++stage;
		/* fallthrough */

	case QCHECK_INIT:
		cur = moves;
		endMoves = generate<GenType.QUIET_CHECKS.getValue()>(pos, cur);

		++stage;
		/* fallthrough */

	case QCHECK:
		return this.<PickType.Next.getValue()>select(Any);
	}

	assert false;
	return Move.MOVE_NONE; // Silence warning
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<PickType T, typename Pred> Move select(Pred);
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T, typename Pred>

  /// MovePicker::select() returns the next move satisfying a predicate function.
  /// It never returns the TT move.
  private <T, Pred> Move select(Pred filter)
  {

	while (cur < endMoves)
	{
		if (T == PickType.Best)
		{
			std::swap(cur, *std::max_element(cur, endMoves));
		}

		move = cur++;

		if (move != ttMove && filter())
		{
			return move;
		}
	}
	return move = Move.MOVE_NONE;
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<GenType> void score();
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename>

  /// MovePicker::score() assigns a numerical value to each move in a list, used
  /// for sorting. Captures are ordered by Most Valuable Victim (MVV), preferring
  /// captures with a good history. Quiets moves are ordered using the histories.
  private <typename> void score()
  {

  //C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'static_assert':
  //  static_assert(Type == CAPTURES || Type == QUIETS || Type == EVASIONS, "Wrong type");

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
	for (auto m : this)
	{
		if (Type == GenType.CAPTURES)
		{
			m.value = PieceValue[Phase.MG.getValue()][pos.piece_on(GlobalMembers.to_sq(new auto(m))).getValue()] + captureHistory[pos.moved_piece(new auto(m)).getValue()][GlobalMembers.to_sq(new auto(m)).getValue()][GlobalMembers.type_of(pos.piece_on(GlobalMembers.to_sq(new auto(m)))).getValue()] / 8;
		}

		else if (Type == GenType.QUIETS)
		{
			m.value = mainHistory[pos.side_to_move().getValue()][GlobalMembers.from_to(new auto(m))] + (continuationHistory[0])[pos.moved_piece(new auto(m)).getValue()][GlobalMembers.to_sq(new auto(m)).getValue()] + (continuationHistory[1])[pos.moved_piece(new auto(m)).getValue()][GlobalMembers.to_sq(new auto(m)).getValue()] + (continuationHistory[3])[pos.moved_piece(new auto(m)).getValue()][GlobalMembers.to_sq(new auto(m)).getValue()];
		}

		else // Type == EVASIONS
		{
			if (pos.capture(new auto(m)))
			{
				m.value = PieceValue[Phase.MG.getValue()][pos.piece_on(GlobalMembers.to_sq(new auto(m))).getValue()] - Value(GlobalMembers.type_of(pos.moved_piece(new auto(m))));
			}
			else
			{
				m.value = mainHistory[pos.side_to_move().getValue()][GlobalMembers.from_to(new auto(m))] + (continuationHistory[0])[pos.moved_piece(new auto(m)).getValue()][GlobalMembers.to_sq(new auto(m)).getValue()] - (1 << 28);
			}
		}
	}
  }

  private ExtMove begin()
  {
	  return cur;
  }
  private ExtMove end()
  {
	  return endMoves;
  }

  private final Position pos;
  private final ButterflyHistory[] mainHistory;
  private final Stats<int16_t, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB>[] captureHistory;
  private final Stats<int16_t, 29952, Piece.PIECE_NB, Square.SQUARE_NB>[] continuationHistory;
  private Move ttMove;
  private ExtMove[] refutations = tangible.Arrays.initializeWithDefaultExtMoveInstances(3);
  private ExtMove cur;
  private ExtMove endMoves;
  private ExtMove endBadCaptures;
  private int stage;
  private Move move;
  private Square recaptureSquare;
  private Value threshold;
  private Depth depth;
  private ExtMove[] moves = tangible.Arrays.initializeWithDefaultExtMoveInstances(MAX_MOVES);
}