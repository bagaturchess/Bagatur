import java.util.*;
import java.io.*;

/// A TranspositionTable consists of a power of 2 number of clusters and each
/// cluster consists of ClusterSize number of TTEntry. Each non-empty entry
/// contains information of exactly one position. The size of a cluster should
/// divide the size of a cache line size, to ensure that clusters never cross
/// cache lines. This ensures best cache performance, as the cacheline is
/// prefetched, as soon as possible.

public class TranspositionTable implements Closeable
{

  private static final int CacheLineSize = 64;
  private static final int ClusterSize = 3;

  private static class Cluster
  {
	public TTEntry[] entry = tangible.Arrays.initializeWithDefaultTTEntryInstances(ClusterSize);
	public String padding = new String(new char[2]); // Align to a divisor of the cache line size
  }

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'static_assert':
//  static_assert(CacheLineSize % sizeof(Cluster) == 0, "Cluster size incorrect");

 public final void close()
 {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'free' has no equivalent in Java:
	 free(mem);
 }
  public final void new_search()
  {
	  generation8 += 4;
  } // Lower 2 bits are used by Bound

  /// TranspositionTable::probe() looks up the current position in the transposition
  /// table. It returns true and a pointer to the TTEntry if the position is found.
  /// Otherwise, it returns false and a pointer to an empty or least valuable TTEntry
  /// to be replaced later. The replace value of an entry is calculated as its depth
  /// minus 8 times its relative age. TTEntry t1 is considered more valuable than
  /// TTEntry t2 if its replace value is greater than that of t2.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: TTEntry* probe(const ulong key, boolean& found) const
  public final TTEntry probe(long key, tangible.RefObject<Boolean> found)
  {

	final TTEntry[] tte = first_entry(key);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	final short key16 = (short)(key >>> 48); // Use the high 16 bits as key inside the cluster

	for (int i = 0; i < ClusterSize; ++i)
	{
		if ((tte[i].key16) == 0 || tte[i].key16 == key16)
		{
			tte[i].genBound8 = (byte)((generation8 | tte[i].bound().getValue())); // Refresh

			return found.argValue = (boolean)tte[i].key16, tte[i];
		}
	}

	// Find an entry to be replaced according to the replacement strategy
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: TTEntry* replace = tte;
	TTEntry[] replace = new TTEntry(tte);
	for (int i = 1; i < ClusterSize; ++i)
	{
		// Due to our packed storage format for generation and its cyclic
		// nature we add 259 (256 is the modulus plus 3 to keep the lowest
		// two bound bits from affecting the result) to calculate the entry
		// age correctly even after generation8 overflows into the next cycle.
		if (replace.depth8 - ((259 + generation8 - replace.genBound8) & 0xFC) * 2 > tte[i].depth8 - ((259 + generation8 - tte[i].genBound8) & 0xFC) * 2)
		{
			replace = tte[i];
		}
	}

	return found.argValue = false, replace;
  }


  /// TranspositionTable::hashfull() returns an approximation of the hashtable
  /// occupation during a search. The hash is x permill full, as per UCI protocol.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int hashfull() const
  public final int hashfull()
  {

	int cnt = 0;
	for (int i = 0; i < 1000 / ClusterSize; i++)
	{
		TTEntry[] tte = table[i].entry[0];
		for (int j = 0; j < ClusterSize; j++)
		{
			if ((tte[j].genBound8 & 0xFC) == generation8)
			{
				cnt++;
			}
		}
	}
	return cnt;
  }


  /// TranspositionTable::resize() sets the size of the transposition table,
  /// measured in megabytes. Transposition table consists of a power of 2 number
  /// of clusters and each cluster consists of ClusterSize number of TTEntry.

  public final void resize(int mbSize)
  {

//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	clusterCount = mbSize * 1024 * 1024 / sizeof(Cluster);

//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'free' has no equivalent in Java:
	free(mem);
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'malloc' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	mem = malloc(clusterCount * sizeof(Cluster) + CacheLineSize - 1);

	if (!mem)
	{
		std::cerr << "Failed to allocate " << mbSize << "MB for transposition table." << std::endl;
		System.exit(1);
	}

	table = (Cluster)((short(mem) + CacheLineSize - 1) & ~(CacheLineSize - 1));
	clear();
  }


  /// TranspositionTable::clear() initializes the entire transposition table to zero,
  //  in a multi-threaded way.

  public final void clear()
  {

	ArrayList<std::thread> threads = new ArrayList<std::thread>();

	for (int idx = 0; idx < Options["Threads"]; idx++)
	{
//C++ TO JAVA CONVERTER TODO TASK: Only lambda expressions having all locals passed by reference can be converted to Java:
//ORIGINAL LINE: threads.emplace_back([this, idx]()
		threads.emplace_back(() ->
		{

			// Thread binding gives faster search on systems with a first-touch policy
			if (Options["Threads"] > 8)
			{
				WinProcGroup.bindThisThread(idx);
			}

			// Each thread will zero its part of the hash table
			final int stride = clusterCount / Options["Threads"];
			final int start = stride * idx;
			final int len = idx != Options["Threads"] (- 1) != 0 ? stride : clusterCount - start;

//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
			memset(table[start], 0, len * sizeof(Cluster));
		});
	}

	for (std  : :thread & th: threads)
	{
		th.join();
	}
  }

  // The 32 lowest order bits of the key are used to get the index of the cluster
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: TTEntry* first_entry(const ulong key) const
  public final TTEntry first_entry(long key)
  {
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return &table[(uint(key) * ulong(clusterCount)) >> 32].entry[0];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	return new TTEntry(table[(int(key) * long(clusterCount)) >>> 32].entry[0]);
  }

//C++ TO JAVA CONVERTER TODO TASK: Java has no concept of a 'friend' class:
//  friend struct TTEntry;

  private int clusterCount;
  private Cluster[] table;
  private Object mem;
  private byte generation8; // Size must be not bigger than TTEntry::genBound8
}