import java.util.*;
import java.io.*;

/// ThreadPool struct handles all the threads-related stuff like init, starting,
/// parking and, most importantly, launching a thread. All the access to threads
/// is done through this class.

public class ThreadPool extends ArrayList<Thread*>
{


  /// ThreadPool::start_thinking() wakes up main thread waiting in idle_loop() and
  /// returns immediately. Main thread will wake up other threads and start the search.

  public final void start_thinking(Position pos, std::unique_ptr<ClassicDeque<StateInfo>> states, Search.LimitsType limits)
  {
	  start_thinking(pos, states, limits, false);
  }
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: void start_thinking(Position& pos, std::unique_ptr<ClassicDeque<StateInfo>>& states, const Search::LimitsType& limits, boolean ponderMode = false)
  public final void start_thinking(Position pos, std::unique_ptr<LinkedList<StateInfo>> states, Search.LimitsType limits, boolean ponderMode)
  {

	main().wait_for_search_finished();

	stopOnPonderhit = stop = false;
	ponder = ponderMode;
	Search.Limits = limits;
	Search.RootMoves rootMoves = new Search.RootMoves();

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
	for (auto m : new MoveList<GenType.LEGAL.getValue()>(pos))
	{
		if (limits.searchmoves.isEmpty() || std::count(limits.searchmoves.iterator(), limits.searchmoves.end(), m))
		{
			rootMoves.emplace_back(m);
		}
	}

	if (!rootMoves.empty())
	{
		Tablebases.rank_root_moves(pos, rootMoves);
	}

	// After ownership transfer 'states' becomes empty, so if we stop the search
	// and call 'go' again without setting a new position states.get() == NULL.
	assert states.get() || setupStates.get();

	if (states.get())
	{
		setupStates = std::move(states); // Ownership transfer, states is now empty
	}

	// We use Position::set() to set root position across threads. But there are
	// some StateInfo fields (previous, pliesFromNull, capturedPiece) that cannot
	// be deduced from a fen string, so set() clears them and to not lose the info
	// we need to backup and later restore setupStates->back(). Note that setupStates
	// is shared by threads but is accessed in read-only mode.
	StateInfo tmp = setupStates.back();

	for (Thread th : this)
	{
		th.nodes = th.tbHits = th.nmpMinPly = 0;
		th.rootDepth = th.completedDepth = Depth.DEPTH_ZERO;
		th.rootMoves = rootMoves;
		th.rootPos.set(pos.fen(), pos.is_chess960(), setupStates.back(), th);
	}

	setupStates.back() = tmp;

	main().start_searching();
  }


  /// ThreadPool::clear() sets threadPool data to initial values.

  public final void clear()
  {

	for (Thread th : this)
	{
		th.clear();
	}

	main().callsCnt = 0;
	main().previousScore = Value.VALUE_INFINITE;
	main().previousTimeReduction = 1.0;
  }


  /// ThreadPool::set() creates/destroys threads to match the requested number.
  /// Created and launched threads will go immediately to sleep in idle_loop.
  /// Upon resizing, threads are recreated to allow for binding if necessary.

  public final void set(int requested)
  {

	if (size() > 0)
	{ // destroy any existing thread(s)
		main().wait_for_search_finished();

		while (size() > 0)
		{
			back(), pop_back() = null;
		}
	}

	if (requested > 0)
	{ // create new thread(s)
		push_back(new MainThread(0));

		while (size() < requested)
		{
			push_back(new Thread(size()));
		}
		clear();
	}

	// Reallocate the hash with the new threadpool size
	TT.resize(Options["Hash"]);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: MainThread* main() const
  public static MainThread Main()
  {
	  return (MainThread)front();
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong nodes_searched() const
  public final long nodes_searched()
  {
	  return accumulate(Thread.nodes);
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong tb_hits() const
  public final long tb_hits()
  {
	  return accumulate(Thread.tbHits);
  }

  public std::atomic_bool stop = new std::atomic_bool();
  public std::atomic_bool ponder = new std::atomic_bool();
  public std::atomic_bool stopOnPonderhit = new std::atomic_bool();

  private std::unique_ptr<LinkedList<StateInfo>> setupStates = new std::unique_ptr<LinkedList<StateInfo>>();

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong accumulate(std::atomic<ulong> Thread::* member) const
  private long accumulate(std::atomic<Long> Thread. member)
  {

	long sum = 0;
	for (Thread th : this)
	{
		sum += (th.member).load(std::memory_order_relaxed);
	}
	return sum;
  }
}