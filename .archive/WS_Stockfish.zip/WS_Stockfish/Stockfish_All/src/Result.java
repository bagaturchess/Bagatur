import java.util.*;

  public enum Result
  {
	INVALID(0),
	UNKNOWN(1),
	DRAW(2),
	WIN(4);

	  public static final int SIZE = java.lang.Integer.SIZE;

	  private int intValue;
	  private static java.util.HashMap<Integer, Result> mappings;
	  private static java.util.HashMap<Integer, Result> getMappings()
	  {
		  if (mappings == null)
		  {
			  synchronized (Result.class)
			  {
				  if (mappings == null)
				  {
					  mappings = new java.util.HashMap<Integer, Result>();
				  }
			  }
		  }
		  return mappings;
	  }

	  private Result(int value)
	  {
		  intValue = value;
		  getMappings().put(value, this);
	  }

	  public int getValue()
	  {
		  return intValue;
	  }

	  public static Result forValue(int value)
	  {
		  return getMappings().get(value);
	  }
  }