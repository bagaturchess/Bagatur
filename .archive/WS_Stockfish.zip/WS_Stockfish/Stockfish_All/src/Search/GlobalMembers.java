package Search;

public class GlobalMembers
{
	/// Threshold used for countermoves based pruning
	public static final int CounterMovePruneThreshold = 0;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
//	extern LimitsType Limits;

	/// Search::init() is called at startup to initialize various lookup tables


	public static void init()
	{

	  for (int imp = 0; imp <= 1; ++imp)
	  {
		  for (int d = 1; d < 64; ++d)
		  {
			  for (int mc = 1; mc < 64; ++mc)
			  {
				  double r = Math.log(d) * Math.log(mc) / 1.95;

				  GlobalMembers.Reductions[NodeType.NonPV.getValue()][imp][d][mc] = (int)Math.round(r);
				  GlobalMembers.Reductions[NodeType.PV.getValue()][imp][d][mc] = Math.max(GlobalMembers.Reductions[NodeType.NonPV.getValue()][imp][d][mc] - 1, 0);

				  // Increase reduction for non-PV nodes when eval is not improving
				  if (imp == 0 && r > 1.0)
				  {
					GlobalMembers.Reductions[NodeType.NonPV.getValue()][imp][d][mc]++;
				  }
			  }
		  }
	  }

	  for (int d = 0; d < 16; ++d)
	  {
		  GlobalMembers.FutilityMoveCounts[0][d] = (int)(2.4 + 0.74 * Math.pow(d, 1.78));
		  GlobalMembers.FutilityMoveCounts[1][d] = (int)(5.0 + 1.00 * Math.pow(d, 2.00));
	  }
	}

	/// Search::clear() resets search state to its initial value


	public static void clear()
	{

	  Threads.main().wait_for_search_finished();

	  Time.availableNodes = 0;
	  TT.clear();
	  Threads.clear();
	  Tablebases.init(Options["SyzygyPath"]); // Free up mapped files
	}


	/// Threshold used for countermoves based pruning
	public static final int CounterMovePruneThreshold = 0;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
//	extern LimitsType Limits;

//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	void init();
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	void clear();





  public static LimitsType Limits = new LimitsType();
}