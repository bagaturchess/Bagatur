package Search;

import String;
import Eval.evaluate;
import Search.*;
import java.util.*;

/// LimitsType struct stores information sent by GUI about available time to
/// search the current move, maximum depth/time, or if we are in analysis mode.

public class LimitsType
{

  public LimitsType()
  { // Init explicitly due to broken value-initialization of non POD in MSVC
	time[Color.WHITE.getValue()] = time[Color.BLACK.getValue()] = inc[Color.WHITE.getValue()] = inc[Color.BLACK.getValue()] = npmsec = movetime = TimePoint(0);
	movestogo = depth = mate = GlobalMembers.perft = infinite = 0;
	nodes = 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean use_time_management() const
  public final boolean use_time_management()
  {
	return (mate | movetime | depth | nodes | GlobalMembers.perft | infinite) == 0;
  }

  public ArrayList<Move> searchmoves = new ArrayList<Move>();
  public std::chrono.milliseconds.rep[] time = tangible.Arrays.initializeWithDefaultrepInstances(Color.COLOR_NB.getValue());
  public std::chrono.milliseconds.rep[] inc = tangible.Arrays.initializeWithDefaultrepInstances(Color.COLOR_NB.getValue());
  public std::chrono.milliseconds.rep npmsec = new std::chrono.milliseconds.rep();
  public std::chrono.milliseconds.rep movetime = new std::chrono.milliseconds.rep();
  public std::chrono.milliseconds.rep startTime = new std::chrono.milliseconds.rep();
  public int movestogo;
  public int depth;
  public int mate;
  public int perft;
  public int infinite;
  public long nodes;
}