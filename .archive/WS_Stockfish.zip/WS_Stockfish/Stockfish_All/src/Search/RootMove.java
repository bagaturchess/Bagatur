package Search;

import String;
import Eval.evaluate;
import Search.*;
import java.util.*;

/// RootMove struct is used for moves at the root of the tree. For each root move
/// we store a score and a PV (really a refutation in the case of moves which
/// fail low). Score is normally set at -VALUE_INFINITE for all non-pv moves.

public class RootMove implements Comparable<RootMove>
{
	public final int compareTo(RootMove otherInstance)
	{
		if (lessThan(otherInstance))
		{
			return -1;
		}
		else if (otherInstance.lessThan(this))
		{
			return 1;
		}

		return 0;
	}


  public RootMove(Move m)
  {
	  this.pv = new ArrayList<Move>(1, m);
  }
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  boolean extract_ponder_from_tt(Position pos);
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean operator ==(const Move& m) const
  public boolean equalsTo(Move m)
  {
	  return UCI.GlobalMembers.pv[0] == m;
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean operator <(const RootMove& m) const
  public boolean lessThan(RootMove m)
  { // Sort in descending order
	return m.score != score ? m.score.getValue() < score.getValue() : m.previousScore.getValue() < previousScore.getValue();
  }

  public Value score = -Value.VALUE_INFINITE;
  public Value previousScore = -Value.VALUE_INFINITE;
  public int selDepth = 0;
  public int tbRank;
  public Value tbScore;
  public ArrayList<Move> pv = new ArrayList<Move>();
}