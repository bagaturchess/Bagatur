import java.util.*;

package WinProcGroup;

public class GlobalMembers
{
	/// Under Windows it is not possible for a process to run on more than one
	/// logical processor group. This usually means to be limited to use max 64
	/// cores. To overcome this, some special platform specific API should be
	/// called to set group affinity for each thread. Original code from Texel by
	/// Peter Österlund.

//  void bindThisThread(size_t idx);Tangible Method Implementation Not FoundWinProcGroup-bindThisThread


	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! _WIN32

	public static void bindThisThread(int UnnamedParameter)
	{
	}

	///#else

	/// best_group() retrieves logical processor information using Windows specific
	/// API and returns the best group id for the thread with index idx. Original
	/// code from Texel by Peter Österlund.

	public static int best_group(int idx)
	{

	  int threads = 0;
	  int nodes = 0;
	  int cores = 0;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: DWORD returnLength = 0;
	  int returnLength = 0;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: DWORD byteOffset = 0;
	  int byteOffset = 0;

	  // Early exit if the needed API is not available at runtime
	  HMODULE k32 = GetModuleHandle("Kernel32.dll");
	  fun1_t fun1 = (fun1_t)(void(*)())GetProcAddress(k32, "GetLogicalProcessorInformationEx");
	  if (fun1 == null)
	  {
		  return -1;
	  }

	  // First call to get returnLength. We expect it to fail due to null buffer
	  if (fun1.invoke(RelationAll, null, returnLength))
	  {
		  return -1;
	  }

	  // Once we know returnLength, allocate the buffer
	  SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX buffer;
	  SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX ptr;
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'malloc' has no equivalent in Java:
	  ptr = buffer = (SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)malloc(returnLength);

	  // Second call, now we expect to succeed
	  if (!fun1.invoke(RelationAll, buffer, returnLength))
	  {
		  buffer = null;
		  return -1;
	  }

	  while (ptr.Size > 0 && byteOffset + ptr.Size <= returnLength)
	  {
		  if (ptr.Relationship == RelationNumaNode)
		  {
			  nodes++;
		  }

		  else if (ptr.Relationship == RelationProcessorCore)
		  {
			  cores++;
			  threads += (ptr.Processor.Flags == LTP_PC_SMT) ? 2 : 1;
		  }

		  byteOffset += ptr.Size;
		  ptr = (SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)(((String)ptr) + ptr.Size);
	  }

	  buffer = null;

	  ArrayList<Integer> groups = new ArrayList<Integer>();

	  // Run as many threads as possible on the same node until core limit is
	  // reached, then move on filling the next node.
	  for (int n = 0; n < nodes; n++)
	  {
		  for (int i = 0; i < cores / nodes; i++)
		  {
			  groups.add(n);
		  }
	  }

	  // In case a core has more than one logical processor (we assume 2) and we
	  // have still threads to allocate, then spread them evenly across available
	  // nodes.
	  for (int t = 0; t < threads - cores; t++)
	  {
		  groups.add(t % nodes);
	  }

	  // If we still have more threads than the total number of logical processors
	  // then return -1 and let the OS to decide what to do.
	  return idx < groups.size() ? groups.get(idx) : -1;
	}


	/// bindThisThread() set the group affinity of the current thread

	public static void bindThisThread(int idx)
	{

	  // Use only local variables to be thread-safe
	  int group = best_group(idx);

	  if (group == -1)
	  {
		  return;
	  }

	  // Early exit if the needed API are not available at runtime
	  HMODULE k32 = GetModuleHandle("Kernel32.dll");
	  fun2_t fun2 = (fun2_t)(void(*)())GetProcAddress(k32, "GetNumaNodeProcessorMaskEx");
	  fun3_t fun3 = (fun3_t)(void(*)())GetProcAddress(k32, "SetThreadGroupAffinity");

	  if (fun2 == null || fun3 == null)
	  {
		  return;
	  }

	  GROUP_AFFINITY affinity = new GROUP_AFFINITY();
	  if (fun2.invoke(group, affinity))
	  {
		  fun3.invoke(GetCurrentThread(), affinity, null);
	  }
	}

	///#endif
}