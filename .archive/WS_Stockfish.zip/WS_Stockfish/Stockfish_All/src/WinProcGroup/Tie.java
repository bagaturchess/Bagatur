package WinProcGroup;
import java.util.*;
import java.io.*;

/// Our fancy logging facility. The trick here is to replace cin.rdbuf() and
/// cout.rdbuf() with two Tie objects that tie cin and cout to a file stream. We
/// can toggle the logging of std::cout and std:cin at runtime whilst preserving
/// usual I/O functionality, all without changing a single line of code!
/// Idea from http://groups.google.com/group/comp.lang.c++/msg/1d941c0f26ea0d81

public class Tie extends streambuf
{ // MSVC requires split streambuf for cin and cout

  public Tie(streambuf b, streambuf l)
  {
	  this.buf = b;
	  this.logBuf = l;
  }

  @Override
  public int sync()
  {
	  return logBuf.pubsync(), buf.pubsync();
  }
  @Override
  public int overflow(int c)
  {
	  return log(buf.sputc((char)c), "<< ");
  }
  @Override
  public int underflow()
  {
	  return buf.sgetc();
  }
  @Override
  public int uflow()
  {
	  return log(buf.sbumpc(), ">> ");
  }

  public streambuf buf;
  public streambuf logBuf;

//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
  private int log_last = '\n';

  public final int log(int c, String prefix)
  {

//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
//	static int last = '\n'; // Single log file

	if (log_last == '\n')
	{
		logBuf.sputn(prefix, 3);
	}

	return log_last = logBuf.sputc((char)c);
  }
}