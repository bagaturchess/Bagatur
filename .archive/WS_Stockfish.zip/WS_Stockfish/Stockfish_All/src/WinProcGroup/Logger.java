package WinProcGroup;
import java.util.*;
import java.io.*;

public class Logger implements Closeable
{

  private Logger()
  {
	  this.in = new Tie(cin.rdbuf(), file.rdbuf());
	  this.out = new Tie(cout.rdbuf(), file.rdbuf());
  }
 public final void close()
 {
	 start("");
 }

  private ofstream file = new ofstream();
  private Tie in = new Tie();
  private Tie out = new Tie();

//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
  private static Logger start_l = new Logger();

  public static void start(String fname)
  {

//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
//	static Logger l;

	if (fname.length() > 0 && !start_l.file.is_open())
	{
		start_l.file.open(fname, ifstream.out);
		cin.rdbuf(start_l.in);
		cout.rdbuf(start_l.out);
	}
	else if (fname.length() == 0 && start_l.file.is_open())
	{
		cout.rdbuf(start_l.out.buf);
		cin.rdbuf(start_l.in.buf);
		start_l.file.close();
	}
  }
}