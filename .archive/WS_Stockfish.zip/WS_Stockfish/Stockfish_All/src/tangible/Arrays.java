package tangible;

//----------------------------------------------------------------------------------------
//	Copyright © 2006 - 2019 Tangible Software Solutions, Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to initialize and delete array elements.
//----------------------------------------------------------------------------------------
public final class Arrays
{
	public static uint8_t[] initializeWithDefaultuint8_tInstances(int length)
	{
		uint8_t[] array = new uint8_t[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new uint8_t();
		}
		return array;
	}

	public static uint64_t[] initializeWithDefaultuint64_tInstances(int length)
	{
		uint64_t[] array = new uint64_t[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new uint64_t();
		}
		return array;
	}

	public static uint16_t[] initializeWithDefaultuint16_tInstances(int length)
	{
		uint16_t[] array = new uint16_t[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new uint16_t();
		}
		return array;
	}

	public static std::tuple[] initializeWithDefaulttupleInstances(int length)
	{
		std::tuple[] array = new std::tuple[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new std::tuple();
		}
		return array;
	}

	public static uint32_t[] initializeWithDefaultuint32_tInstances(int length)
	{
		uint32_t[] array = new uint32_t[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new uint32_t();
		}
		return array;
	}

	public static Magic[] initializeWithDefaultMagicInstances(int length)
	{
		Magic[] array = new Magic[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new Magic();
		}
		return array;
	}

	public static EndgameBase[] initializeWithDefaultEndgameBaseInstances(int length)
	{
		EndgameBase[] array = new EndgameBase[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new EndgameBase();
		}
		return array;
	}

	public static ExtMove[] initializeWithDefaultExtMoveInstances(int length)
	{
		ExtMove[] array = new ExtMove[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new ExtMove();
		}
		return array;
	}

	public static std::chrono.milliseconds.rep[] initializeWithDefaultrepInstances(int length)
	{
		std::chrono.milliseconds.rep[] array = new std::chrono.milliseconds.rep[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new std::chrono.milliseconds.rep();
		}
		return array;
	}

	public static Stack[] initializeWithDefaultStackInstances(int length)
	{
		Stack[] array = new Stack[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new Stack();
		}
		return array;
	}

	public static TTEntry[] initializeWithDefaultTTEntryInstances(int length)
	{
		TTEntry[] array = new TTEntry[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new TTEntry();
		}
		return array;
	}

	public static <T extends java.io.Closeable> void deleteArray(T[] array)
	{
		for (T element : array)
		{
			if (element != null)
				element.close();
		}
	}
}