/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


/// When compiling with provided Makefile (e.g. for Linux and OSX), configuration
/// is done automatically. To get started type 'make help'.
///
/// When Makefile is not used (e.g. with Microsoft Visual Studio) some switches
/// need to be set manually:
///
/// -DNDEBUG      | Disable debugging mode. Always use this for release.
///
/// -DNO_PREFETCH | Disable use of prefetch asm-instruction. You may need this to
///               | run on some very old machines.
///
/// -DUSE_POPCNT  | Add runtime support for use of popcnt asm-instruction. Works
///               | only in 64-bit mode and requires hardware with popcnt support.
///
/// -DUSE_PEXT    | Add runtime support for use of pext asm-instruction. Works
///               | only in 64-bit mode and requires hardware with pext support.


//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if _MSC_VER
// Disable some silly and noisy warning from MSVC compiler
//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#pragma warning(disable: 4127) // Conditional expression is constant
//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#pragma warning(disable: 4146) // Unary minus operator applied to unsigned type
//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#pragma warning(disable: 4800) // Forcing value to bool 'true' or 'false'
///#endif

/// Predefined macros hell:
///
/// __GNUC__           Compiler is gcc, Clang or Intel on Linux
/// __INTEL_COMPILER   Compiler is Intel
/// _MSC_VER           Compiler is MSVC or Intel on Windows
/// _WIN32             Building on Windows (any)
/// _WIN64             Building on Windows 64 bit

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if _WIN64 && _MSC_VER // No Makefile used
///#define IS_64BIT
///#endif

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if USE_POPCNT && (__INTEL_COMPILER || _MSC_VER)
//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
//#include <nmmintrin.h> // Intel and Microsoft header for _mm_popcnt_u64()
///#endif

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if !NO_PREFETCH && (__INTEL_COMPILER || _MSC_VER)
//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
//#include <xmmintrin.h> // Intel and Microsoft header for _mm_prefetch()
///#endif

//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
///#if USE_PEXT
//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
//#include <immintrin.h> // Header for _pext_u64() intrinsic
//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
///#define pext(b, m) _pext_u64(b, m)
///#else
//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
///#define pext(b, m) 0
///#endif

/// A move needs 16 bits to be stored
///
/// bit  0- 5: destination square (from 0 to 63)
/// bit  6-11: origin square (from 0 to 63)
/// bit 12-13: promotion piece type - 2 (from KNIGHT-2 to QUEEN-2)
/// bit 14-15: special move flag: promotion (1), en passant (2), castling (3)
/// NOTE: EN-PASSANT bit is set only when a pawn can be captured
///
/// Special cases are MOVE_NONE and MOVE_NULL. We can sneak these in because in
/// any normal move destination square is always different from origin square
/// while MOVE_NONE and MOVE_NULL have the same origin and destination square.

public enum Move
{
  MOVE_NONE(0),
  MOVE_NULL(65);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Move> mappings;
	private static java.util.HashMap<Integer, Move> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Move.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Move>();
				}
			}
		}
		return mappings;
	}

	private Move(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Move forValue(int value)
	{
		return getMappings().get(value);
	}
}