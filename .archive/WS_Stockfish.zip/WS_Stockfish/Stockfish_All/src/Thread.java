import java.util.*;
import java.io.*;

/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/





/// Thread class keeps together all the thread-related stuff. We use
/// per-thread pawn and material hash tables so that once we get a
/// pointer to an entry its life time is unlimited and we don't have
/// to care about someone changing the entry under our feet.

public class Thread implements Closeable
{

  private Object mutex = new Object();
  private ConditionVariable cv = new ConditionVariable();
  private int idx;
  private boolean exit = false; // Set before starting std::thread
  private boolean searching = true;
  private std::thread stdThread = new std::thread();


  /// Thread constructor launches the thread and waits until it goes to sleep
  /// in idle_loop(). Note that 'searching' and 'exit' should be alredy set.

  public Thread(int n)
  {
	  this.idx = n;
	  this.stdThread = new std::thread(this.idle_loop, this);

	wait_for_search_finished();
  }


  /// Thread destructor wakes up the thread in idle_loop() and waits
  /// for its termination. Thread should be already waiting.

  public void close()
  {

	assert!searching;

	exit = true;
	start_searching();
	stdThread.join();
  }

//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  virtual void search();

  /// Thread::clear() reset histories, usually before a new game

  public final void clear()
  {

	counterMoves.fill(Move.MOVE_NONE);
	mainHistory.fill(0);
	captureHistory.fill(0);

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
	for (auto to : continuationHistory)
	{
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
		for (auto h : to)
		{
			h.fill(0);
		}
	}

	continuationHistory[Piece.NO_PIECE.getValue()][0].fill(Search.GlobalMembers.CounterMovePruneThreshold - 1);
  }


  /// Thread::idle_loop() is where the thread is parked, blocked on the
  /// condition variable, when it has no work to do.

  public final void idle_loop()
  {

	// If OS already scheduled us on a different group than 0 then don't overwrite
	// the choice, eventually we are one of many one-threaded processes running on
	// some Windows NUMA hardware, for instance in fishtest. To make it simple,
	// just check if running threads are below a threshold, in this case all this
	// NUMA machinery is not needed.
	if (Options["Threads"] > 8)
	{
		WinProcGroup.bindThisThread(idx);
	}

	while (true)
	{
		std::unique_lock<Object> lk = new std::unique_lock<Object>(Object);
		searching = false;
		cv.notify_one(); // Wake up anyone waiting for search finished
		cv.wait(lk, () ->
		{
			return searching;
		});

		if (exit)
		{
			return;
		}

		lk.unlock();

		search();
	}
  }


  /// Thread::start_searching() wakes up the thread that will start the search

  public final void start_searching()
  {

	synchronized (Object)
	{
		searching = true;
	}
	cv.notify_one(); // Wake up the thread in idle_loop()
  }


  /// Thread::wait_for_search_finished() blocks on the condition variable
  /// until the thread has finished searching.

  public final void wait_for_search_finished()
  {

	std::unique_lock<Object> lk = new std::unique_lock<Object>(Object);
	cv.wait(lk, () ->
	{
		return !searching;
	});
  }

  public Pawns.Table pawnsTable = new Pawns.Table();
  public Material.Table materialTable = new Material.Table();
  public Endgames endgames = new Endgames();
  public int pvIdx;
  public int pvLast;
  public int selDepth;
  public int nmpMinPly;
  public Color nmpColor;
  public std::atomic<Long> nodes = new std::atomic<Long>();
  public std::atomic<Long> tbHits = new std::atomic<Long>();

  public Position rootPos = new Position();
  public ArrayList<RootMove> rootMoves = new ArrayList<RootMove>();
  public Depth rootDepth;
  public Depth completedDepth;
  public Stats<Move, StatsParams.NOT_USED, Piece.PIECE_NB, Square.SQUARE_NB> counterMoves = new Stats<Move, StatsParams.NOT_USED, Piece.PIECE_NB, Square.SQUARE_NB.getValue()>();
  public ButterflyHistory mainHistory = new ButterflyHistory();
  public Stats<Short, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB> captureHistory = new Stats<Short, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB.getValue()>();
  public Stats<Stats<Short, 29952, Piece.PIECE_NB, Square.SQUARE_NB>, StatsParams.NOT_USED, Piece.PIECE_NB, Square.SQUARE_NB> continuationHistory = new Stats<Stats<Short, 29952, Piece.PIECE_NB, Square.SQUARE_NB.getValue()>, StatsParams.NOT_USED, Piece.PIECE_NB, Square.SQUARE_NB.getValue()>();
  public Score contempt;
}