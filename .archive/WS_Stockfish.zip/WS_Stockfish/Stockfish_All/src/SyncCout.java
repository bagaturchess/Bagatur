import java.util.*;
import java.io.*;

public enum SyncCout
{
	IO_LOCK,
	IO_UNLOCK;

	public static final int SIZE = java.lang.Integer.SIZE;

	public int getValue()
	{
		return this.ordinal();
	}

	public static SyncCout forValue(int value)
	{
		return values()[value];
	}
}