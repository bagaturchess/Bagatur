/// Score enum stores a middlegame and an endgame value in a single integer (enum).
/// The least significant 16 bits are used to store the middlegame value and the
/// upper 16 bits are used to store the endgame value. We have to take care to
/// avoid left-shifting a signed int to avoid undefined behavior.
public enum Score
{
	SCORE_ZERO;

	public static final int SIZE = java.lang.Integer.SIZE;

	public int getValue()
	{
		return this.ordinal();
	}

	public static Score forValue(int value)
	{
		return values()[value];
	}
}
/// Extracting the signed lower and upper 16 bits is not so trivial because
/// according to the standard a simple cast to short is implementation defined
/// and so is a right shift of a signed integer.
//C++ TO JAVA CONVERTER TODO TASK: Unions are not supported in Java:
//union

//C++ TO JAVA CONVERTER TODO TASK: Unions are not supported in Java:
//union