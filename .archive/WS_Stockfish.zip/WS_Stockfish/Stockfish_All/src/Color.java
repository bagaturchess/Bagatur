public enum Color
{
  WHITE(0),
  BLACK(1),
  COLOR_NB(2);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Color> mappings;
	private static java.util.HashMap<Integer, Color> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Color.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Color>();
				}
			}
		}
		return mappings;
	}

	private Color(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Color forValue(int value)
	{
		return getMappings().get(value);
	}
}