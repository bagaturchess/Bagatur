/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/



/// The TimeManagement class computes the optimal time to think depending on
/// the maximum available time, the game move number and other parameters.

public class TimeManagement
{

  /// init() is called at the beginning of the search and calculates the allowed
  /// thinking time out of the time control and current game ply. We support four
  /// different kinds of time controls, passed in 'limits':
  ///
  ///  inc == 0 && movestogo == 0 means: x basetime  [sudden death!]
  ///  inc == 0 && movestogo != 0 means: x moves in y minutes
  ///  inc >  0 && movestogo == 0 means: x basetime + z increment
  ///  inc >  0 && movestogo != 0 means: x moves in y minutes + z increment

  public final void init(Search.LimitsType limits, Color us, int ply)
  {

	std::chrono.milliseconds.rep minThinkingTime = Options["Minimum Thinking Time"];
	std::chrono.milliseconds.rep moveOverhead = Options["Move Overhead"];
	std::chrono.milliseconds.rep slowMover = Options["Slow Mover"];
	std::chrono.milliseconds.rep npmsec = Options["nodestime"];
	std::chrono.milliseconds.rep hypMyTime = new std::chrono.milliseconds.rep();

	// If we have to play in 'nodes as time' mode, then convert from time
	// to nodes, and use resulting values in time management formulas.
	// WARNING: to avoid time losses, the given npmsec (nodes per millisecond)
	// must be much lower than the real engine speed.
	if (npmsec != null)
	{
		if (availableNodes == 0) // Only once at game start
		{
			availableNodes = npmsec * limits.time[us.getValue()]; // Time is in msec
		}

		// Convert from milliseconds to nodes
		limits.time[us.getValue()] = TimePoint(availableNodes);
		limits.inc[us.getValue()] *= npmsec;
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: limits.npmsec = npmsec;
		limits.npmsec.copyFrom(npmsec);
	}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: startTime = limits.startTime;
	startTime.copyFrom(limits.startTime);
	optimumTime = maximumTime = Math.max(limits.time[us.getValue()], minThinkingTime);

	final int maxMTG = limits.movestogo != 0 ? Math.min(limits.movestogo, GlobalMembers.MoveHorizon) : GlobalMembers.MoveHorizon;

	// We calculate optimum time usage for different hypothetical "moves to go" values
	// and choose the minimum of calculated search time values. Usually the greatest
	// hypMTG gives the minimum values.
	for (int hypMTG = 1; hypMTG <= maxMTG; ++hypMTG)
	{
		// Calculate thinking time for hypothetical "moves to go"-value
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: hypMyTime = limits.time[us] + limits.inc[us] * (hypMTG - 1) - moveOverhead * (2 + std::min(hypMTG, 40));
		hypMyTime.copyFrom(limits.time[us.getValue()] + limits.inc[us.getValue()] * (hypMTG - 1) - moveOverhead * (2 + Math.min(hypMTG, 40)));

		hypMyTime = Math.max(hypMyTime, TimePoint(0));

		std::chrono.milliseconds.rep t1 = minThinkingTime + GlobalMembers.<TimeType.OptimumTime.getValue()>remaining(hypMyTime, hypMTG, ply, slowMover);
		std::chrono.milliseconds.rep t2 = minThinkingTime + GlobalMembers.<TimeType.MaxTime.getValue() >remaining(hypMyTime, hypMTG, ply, slowMover);

		optimumTime = Math.min(t1, optimumTime);
		maximumTime = Math.min(t2, maximumTime);
	}

	if (Options["Ponder"])
	{
		optimumTime += optimumTime / 4;
	}
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: std::chrono::milliseconds::rep optimum() const
  public final std::chrono.milliseconds.rep optimum()
  {
	  return new std::chrono.milliseconds.rep(optimumTime);
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: std::chrono::milliseconds::rep maximum() const
  public final std::chrono.milliseconds.rep maximum()
  {
	  return new std::chrono.milliseconds.rep(maximumTime);
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: std::chrono::milliseconds::rep elapsed() const
  public final std::chrono.milliseconds.rep elapsed()
  {
	  return Search.Limits.npmsec ? TimePoint(Threads.nodes_searched()) : GlobalMembers.now() - startTime;
  }

  public long availableNodes; // When in 'nodes as time' mode

  private std::chrono.milliseconds.rep startTime = new std::chrono.milliseconds.rep();
  private std::chrono.milliseconds.rep optimumTime = new std::chrono.milliseconds.rep();
  private std::chrono.milliseconds.rep maximumTime = new std::chrono.milliseconds.rep();
}