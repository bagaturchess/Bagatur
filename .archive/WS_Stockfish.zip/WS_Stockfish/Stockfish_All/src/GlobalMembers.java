import java.util.*;

package <missing>;

public class GlobalMembers
{
	public static int Tablebases.MaxCardinality;


	public static final int TBPIECES = 7; // Max number of supported pieces

	private WDLScore subtract(WDLScore d)
	{
		return WDLScore(-d.getValue());
	}
	private Square exclusiveOrAssignment(Square s, int i)
	{
		return s = Square(s.getValue() ^ i);
	}
	private Square exclusiveOr(Square s, int i)
	{
		return Square(s.getValue() ^ i);
	}

	public static final String PieceToChar = " PNBRQK  pnbrqk";

	public static int[] MapPawns = new int[Square.SQUARE_NB.getValue()];
	public static int[] MapB1H1H7 = new int[Square.SQUARE_NB.getValue()];
	public static int[] MapA1D1D4 = new int[Square.SQUARE_NB.getValue()];
	public static int[][] MapKK = new int[10][Square.SQUARE_NB.getValue()]; // [MapA1D1D4][SQUARE_NB]

	public static int[][] Binomial = new int[6][Square.SQUARE_NB.getValue()]; // [k][n] k elements from a set of n elements
	public static int[][] LeadPawnIdx = new int[6][Square.SQUARE_NB.getValue()]; // [leadPawnsCnt][SQUARE_NB]
	public static int[][] LeadPawnsSize = new int[6][4]; // [leadPawnsCnt][FILE_A..FILE_D]

	// Comparison function to sort leading pawns in ascending MapPawns[] order
	public static boolean pawns_comp(Square i, Square j)
	{
		return MapPawns[i.getValue()] < MapPawns[j.getValue()];
	}
	public static int off_A1H8(Square sq)
	{
		return rank_of(sq).getValue() - file_of(sq).getValue();
	}

	public static final Value[] WDL_to_value = {-Value.VALUE_MATE + MAX_PLY + 1, Value.VALUE_DRAW - 2, Value.VALUE_DRAW, Value.VALUE_DRAW + 2, Value.VALUE_MATE - MAX_PLY - 1};

//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename T, int Half = sizeof(T) / 2, int End = sizeof(T) - 1>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers containing defaults cannot be converted to Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	public static <T, int Half = sizeof(T) / 2, int End = sizeof(T) - 1> void swap_endian(T x)
	{
	//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'static_assert':
	//	static_assert(std::is_unsigned<T>::value, "Argument of swap_endian not unsigned");

		uint8_t tmp = new uint8_t();
		uint8_t[] c = (uint8_t) x;
		for (int i = 0; i < Half; ++i)
		{
			tmp = c[i], c[i] = c[End - i], c[End - i] = tmp;
		}
	}
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline void swap_endian<uint8_t>(uint8_t&)
	public static void swap_endian(uint8_t UnnamedParameter)
	{
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename T, int LE>
	//{
	//	uint32_t i;
	//	char c[4];
	//}
	public static <T, int LE> T number(Object addr)
	{
		 Le = {0x01020304};
		final boolean IsLittleEndian = (Le.c[0] == 4);

		T v = new T();

	//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'alignof':
		if ((uintptr_t)addr & (alignof(T) - 1) != null) // Unaligned pointer (very rare)
		{
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
			memcpy(v, addr, sizeof(T));
		}
		else
		{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: v = *((T*)addr);
			v.copyFrom((T)addr);
		}

		if (LE != IsLittleEndian)
		{
			swap_endian(v);
		}
		return new T(v);
	}

	// DTZ tables don't store valid scores for moves that reset the rule50 counter
	// like captures and pawn moves but we can easily recover the correct dtz of the
	// previous move if we know the position's WDL score.
	public static int dtz_before_zeroing(WDLScore wdl)
	{
		return wdl == WDLWin ? 1 : wdl == WDLCursedWin ? 101 : wdl == WDLBlessedLoss ? -101 : wdl == WDLLoss ? -1 : 0;
	}

	// Return the sign of a number (-1, 0, 1)
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template <typename T>
	public static <T> int sign_of(T val)
	{
		return (T(0) < val) - (val < T(0));
	}

	public static TBTable<TBType.WDL>.TBTable(String code)
	{
		this.TBTable = new <type missing>();

		StateInfo st = new StateInfo();
		Position pos = new Position();

		key = pos.set(code, Color.WHITE, st).material_key();
		pieceCount = pos.<PieceType.ALL_PIECES.getValue()>count();
		hasPawns = pos.pieces(PieceType.PAWN);

		hasUniquePieces = false;
		for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); ++c)
		{
			for (PieceType pt = PieceType.PAWN; pt.getValue() < PieceType.KING.getValue(); ++pt)
			{
				if (popcount(pos.pieces(c, pt)) == 1)
				{
					hasUniquePieces = true;
				}
			}
		}

		// Set the leading color. In case both sides have pawns the leading color
		// is the side with less pawns because this leads to better compression.
		boolean c = (pos.<PieceType.PAWN.getValue()>count(Color.BLACK)) == 0 || ((pos.<PieceType.PAWN.getValue()>count(Color.WHITE)) != 0 && pos.<PieceType.PAWN.getValue()>count(Color.BLACK) >= pos.<PieceType.PAWN.getValue()>count(Color.WHITE));

		pawnCount[0] = pos.<PieceType.PAWN.getValue()>count(c ? Color.WHITE : Color.BLACK);
		pawnCount[1] = pos.<PieceType.PAWN.getValue()>count(c ? Color.BLACK : Color.WHITE);

		key2 = pos.set(code, Color.BLACK, st).material_key();
	}

	public static TBTable<TBType.DTZ>.TBTable(TBTable<TBType.WDL> wdl)
	{
		this.TBTable = new <type missing>();

		// Use the corresponding WDL table to avoid recalculating all from scratch
		key = wdl.key;
		key2 = wdl.key2;
		pieceCount = wdl.pieceCount;
		hasPawns = wdl.hasPawns;
		hasUniquePieces = wdl.hasUniquePieces;
		pawnCount[0] = wdl.pawnCount[0];
		pawnCount[1] = wdl.pawnCount[1];
	}

	public static TBTables TBTables = new TBTables();

	// TB tables are compressed with canonical Huffman code. The compressed data is divided into
	// blocks of size d->sizeofBlock, and each block stores a variable number of symbols.
	// Each symbol represents either a WDL or a (remapped) DTZ value, or a pair of other symbols
	// (recursively). If you keep expanding the symbols in a block, you end up with up to 65536
	// WDL or DTZ values. Each symbol represents up to 256 values and will correspond after
	// Huffman coding to at least 1 bit. So a block of 32 bytes corresponds to at most
	// 32 x 8 x 256 = 65536 values. This maximum is only reached for tables that consist mostly
	// of draws or mostly of wins, but such tables are actually quite common. In principle, the
	// blocks in WDL tables are 64 bytes long (and will be aligned on cache lines). But for
	// mostly-draw or mostly-win tables this can leave many 64-byte blocks only half-filled, so
	// in such cases blocks are 32 bytes long. The blocks of DTZ tables are up to 1024 bytes long.
	// The generator picks the size that leads to the smallest table. The "book" of symbols and
	// Huffman codes is the same for all blocks in the table. A non-symmetric pawnless TB file
	// will have one table for wtm and one for btm, a TB file with pawns will have tables per
	// file a,b,c,d also in this case one set for wtm and one for btm.
	public static int decompress_pairs(PairsData d, uint64_t idx)
	{

		// Special case where all table positions store the same value
		if (d.flags & TBFlag.SingleValue != null)
		{
			return new uint8_t(d.minSymLen);
		}

		// First we need to locate the right block that stores the value at index "idx".
		// Because each block n stores blockLength[n] + 1 values, the index i of the block
		// that contains the value at position idx is:
		//
		//                    for (i = -1, sum = 0; sum <= idx; i++)
		//                        sum += blockLength[i + 1] + 1;
		//
		// This can be slow, so we use SparseIndex[] populated with a set of SparseEntry that
		// point to known indices into blockLength[]. Namely SparseIndex[k] is a SparseEntry
		// that stores the blockLength[] index and the offset within that block of the value
		// with index I(k), where:
		//
		//       I(k) = k * d->span + d->span / 2      (1)

		// First step is to get the 'k' of the I(k) nearest to our idx, using definition (1)
		uint32_t k = idx / d.span;

		// Then we read the corresponding SparseIndex[] entry
		uint32_t block = GlobalMembers.<uint32_t, AnonymousEnum.LittleEndian.getValue()>number(d.sparseIndex[k].block);
		int offset = GlobalMembers.<uint16_t, AnonymousEnum.LittleEndian.getValue()>number(d.sparseIndex[k].offset);

		// Now compute the difference idx - I(k). From definition of k we know that
		//
		//       idx = k * d->span + idx % d->span    (2)
		//
		// So from (1) and (2) we can compute idx - I(K):
		int diff = idx % d.span - d.span / 2;

		// Sum the above to offset to find the offset corresponding to our idx
		offset += diff;

		// Move to previous/next block, until we reach the correct block that contains idx,
		// that is when 0 <= offset <= d->blockLength[block]
		while (offset < 0)
		{
			offset += d.blockLength[--block] + 1;
		}

		while (offset > d.blockLength[block])
		{
			offset -= d.blockLength[block++] + 1;
		}

		// Finally, we find the start address of our block of canonical Huffman symbols
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
		uint32_t * ptr = (uint32_t)(d.data + ((uint64_t)block * d.sizeofBlock));

		// Read the first 64 bits in our block, this is a (truncated) sequence of
		// unknown number of symbols of unknown length but we know the first one
		// is at the beginning of this 64 bits sequence.
		uint64_t buf64 = GlobalMembers.<uint64_t, AnonymousEnum.BigEndian.getValue()>number(ptr);
		ptr += 2;
		int buf64Size = 64;
		uint16_t sym = new uint16_t();

		while (true)
		{
			int len = 0; // This is the symbol length - d->min_sym_len

			// Now get the symbol length. For any symbol s64 of length l right-padded
			// to 64 bits we know that d->base64[l-1] >= s64 >= d->base64[l] so we
			// can find the symbol length iterating through base64[].
			while (buf64 < d.base64.get(len))
			{
				++len;
			}

			// All the symbols of a given length are consecutive integers (numerical
			// sequence property), so we can compute the offset of our symbol of
			// length len, stored at the beginning of buf64.
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			sym = (buf64 - d.base64.get(len)) >> (64 - len - d.minSymLen);

			// Now add the value of the lowest symbol of length len to get our symbol
			sym += GlobalMembers.<uint16_t, AnonymousEnum.LittleEndian.getValue()>number(d.lowestSym[len]);

			// If our offset is within the number of values represented by symbol sym
			// we are done...
			if (offset < d.symlen.get(sym) + 1)
			{
				break;
			}

			// ...otherwise update the offset and continue to iterate
			offset -= d.symlen.get(sym) + 1;
			len += d.minSymLen; // Get the real length
			buf64 <<= len; // Consume the just processed symbol
			buf64Size -= len;

			if (buf64Size <= 32)
			{ // Refill the buffer
				buf64Size += 32;
				buf64 |= (uint64_t)GlobalMembers.<uint32_t, AnonymousEnum.BigEndian.getValue()>number(ptr++) << (64 - buf64Size);
			}
		}

		// Ok, now we have our symbol that expands into d->symlen[sym] + 1 symbols.
		// We binary-search for our value recursively expanding into the left and
		// right child symbols until we reach a leaf node where symlen[sym] + 1 == 1
		// that will store the value we need.
		while (d.symlen.get(sym) != null)
		{

			uint16_t left = d.btree[sym].<LR.Side.Left.getValue()>get();

			// If a symbol contains 36 sub-symbols (d->symlen[sym] + 1 = 36) and
			// expands in a pair (d->symlen[left] = 23, d->symlen[right] = 11), then
			// we know that, for instance the ten-th value (offset = 10) will be on
			// the left side because in Recursive Pairing child symbols are adjacent.
			if (offset < d.symlen.get(left) + 1)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: sym = left;
				sym.copyFrom(left);
			}
			else
			{
				offset -= d.symlen.get(left) + 1;
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: sym = d->btree[sym].get<LR::Right>();
				sym.copyFrom(d.btree[sym].<LR.Side.Right.getValue()>get());
			}
		}

		return d.btree[sym].<LR.Side.Left.getValue()>get();
	}

	public static boolean check_dtz_stm(TBTable<TBType.WDL>*, int UnnamedParameter, File UnnamedParameter2)
	{
		return true;
	}

	public static boolean check_dtz_stm(TBTable<TBType.DTZ> entry, int stm, File f)
	{

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
		auto flags = entry.get(stm, f.getValue()).flags;
		return (flags & TBFlag.STM) == stm || ((entry.key == entry.key2) && !entry.hasPawns);
	}

	// DTZ scores are sorted by frequency of occurrence and then assigned the
	// values 0, 1, 2, ... in order of decreasing frequency. This is done for each
	// of the four WDLScore values. The mapping information necessary to reconstruct
	// the original values is stored in the TB file and read during map[] init.
	public static WDLScore map_score(TBTable<TBType.WDL>*, File UnnamedParameter, int value, WDLScore UnnamedParameter2)
	{
		return WDLScore(value - 2);
	}

	public static int map_score(TBTable<TBType.DTZ> entry, File f, int value, WDLScore wdl)
	{

		final int[] WDLMap = {1, 3, 0, 2, 0};

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
		auto flags = entry.get(0, f.getValue()).flags;

		uint8_t[] map = new uint8_t(entry.map);
		uint16_t[] idx = entry.get(0, f.getValue()).map_idx;
		if (flags & TBFlag.Mapped != null)
		{
			if (flags & TBFlag.Wide != null)
			{
				value = ((uint16_t)map)[idx[WDLMap[wdl.getValue() + 2]] + value];
			}
			else
			{
				value = map[idx[WDLMap[wdl.getValue() + 2]] + value];
			}
		}

		// DTZ tables store distance to zero in number of moves or plies. We
		// want to return plies, so we have convert to plies when needed.
		if ((wdl == WDLWin && !(flags & TBFlag.WinPlies)) || (wdl == WDLLoss && !(flags & TBFlag.LossPlies)) || wdl == WDLCursedWin || wdl == WDLBlessedLoss)
		{
			value *= 2;
		}

		return value + 1;
	}

	// Compute a unique index out of a position and use it to probe the TB file. To
	// encode k pieces of same type and color, first sort the pieces by square in
	// ascending order s1 <= s2 <= ... <= sk then compute the unique index as:
	//
	//      idx = Binomial[1][s1] + Binomial[2][s2] + ... + Binomial[k][sk]
	//
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers containing defaults cannot be converted to Java:
//ORIGINAL LINE: template<typename T, typename Ret = typename T::Ret>
	public static <T, Ret = T.Ret> Ret do_probe_table(Position pos, T entry, WDLScore wdl, ProbeState result)
	{

		Square[] squares = new Square[TBPIECES];
		Piece[] pieces = new Piece[TBPIECES];
		uint64_t idx = new uint64_t();
		int next = 0;
		int size = 0;
		int leadPawnsCnt = 0;
		PairsData d;
		Bitboard b = new Bitboard();
		Bitboard leadPawns = 0;
		File tbFile = File.FILE_A;

		// A given TB entry like KRK has associated two material keys: KRvk and Kvkr.
		// If both sides have the same pieces keys are equal. In this case TB tables
		// only store the 'white to move' case, so if the position to lookup has black
		// to move, we need to switch the color and flip the squares before to lookup.
		boolean symmetricBlackToMove = (entry.key == entry.key2 && pos.side_to_move().getValue() != 0);

		// TB files are calculated for white as stronger side. For instance we have
		// KRvK, not KvKR. A position where stronger side is white will have its
		// material key == entry->key, otherwise we have to switch the color and
		// flip the squares before to lookup.
		boolean blackStronger = (pos.material_key() != entry.key);

		int flipColor = (symmetricBlackToMove || blackStronger) * 8;
		int flipSquares = (symmetricBlackToMove || blackStronger) * 070;
		int stm = (symmetricBlackToMove || blackStronger) ^ pos.side_to_move();

		// For pawns, TB files store 4 separate tables according if leading pawn is on
		// file a, b, c or d after reordering. The leading pawn is the one with maximum
		// MapPawns[] value, that is the one most toward the edges and with lowest rank.
		if (entry.hasPawns)
		{

			// In all the 4 tables, pawns are at the beginning of the piece sequence and
			// their color is the reference one. So we just pick the first one.
			Piece pc = entry.get(0, 0).pieces[0] ^ flipColor;

			assert type_of(pc) == PieceType.PAWN;

			leadPawns = b = pos.pieces(color_of(pc), PieceType.PAWN);
			do
			{
				squares[size++] = pop_lsb(b) ^ flipSquares;
			} while (b != null);

			leadPawnsCnt = size;

			std::swap(squares[0], *std::max_element(squares, squares + leadPawnsCnt, pawns_comp));

			tbFile = file_of(squares[0]);
			if (tbFile.getValue() > File.FILE_D.getValue())
			{
				tbFile = file_of(squares[0] ^ 7); // Horizontal flip: SQ_H1 -> SQ_A1
			}
		}

		// DTZ tables are one-sided, i.e. they store positions only for white to
		// move or only for black to move, so check for side to move to be stm,
		// early exit otherwise.
		if (!check_dtz_stm(entry, stm, tbFile))
		{
			return result = CHANGE_STM, null;
		}

		// Now we are ready to get all the position pieces (but the lead pawns) and
		// directly map them to the correct color and square.
		b = pos.pieces() ^ leadPawns;
		do
		{
			Square s = pop_lsb(b);
			squares[size] = s ^ flipSquares;
			pieces[size++] = Piece(pos.piece_on(s) ^ flipColor);
		} while (b != null);

		assert size >= 2;

		d = entry.get(stm, tbFile);

		// Then we reorder the pieces to have the same sequence as the one stored
		// in pieces[i]: the sequence that ensures the best compression.
		for (int i = leadPawnsCnt; i < size; ++i)
		{
			for (int j = i; j < size; ++j)
			{
				if (d.pieces[i] == pieces[j])
				{
					std::swap(pieces[i], pieces[j]);
					std::swap(squares[i], squares[j]);
					break;
				}
			}
		}

		// Now we map again the squares so that the square of the lead piece is in
		// the triangle A1-D1-D4.
		if (file_of(squares[0]) > File.FILE_D.getValue())
		{
			for (int i = 0; i < size; ++i)
			{
				squares[i] ^= 7; // Horizontal flip: SQ_H1 -> SQ_A1
			}
		}

		// Encode leading pawns starting with the one with minimum MapPawns[] and
		// proceeding in ascending order.
		if (entry.hasPawns)
		{
			idx = LeadPawnIdx[leadPawnsCnt][squares[0].getValue()];

			std::sort(squares + 1, squares + leadPawnsCnt, pawns_comp);

			for (int i = 1; i < leadPawnsCnt; ++i)
			{
				idx += Binomial[i][MapPawns[squares[i].getValue()]];
			}

//C++ TO JAVA CONVERTER TODO TASK: There are no gotos or labels in Java:
			goto encode_remaining; // With pawns we have finished special treatments
		}

		// In positions withouth pawns, we further flip the squares to ensure leading
		// piece is below RANK_5.
		if (rank_of(squares[0]) > Rank.RANK_4.getValue())
		{
			for (int i = 0; i < size; ++i)
			{
				squares[i] ^= 070; // Vertical flip: SQ_A8 -> SQ_A1
			}
		}

		// Look for the first piece of the leading group not on the A1-D4 diagonal
		// and ensure it is mapped below the diagonal.
		for (int i = 0; i < d.groupLen[0]; ++i)
		{
			if (off_A1H8(squares[i]) == 0)
			{
				continue;
			}

			if (off_A1H8(squares[i]) > 0) // A1-H8 diagonal flip: SQ_A3 -> SQ_C3
			{
				for (int j = i; j < size; ++j)
				{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
					squares[j] = Square(((squares[j].getValue() >> 3) | (squares[j].getValue() << 3)) & 63);
				}
			}
			break;
		}

		// Encode the leading group.
		//
		// Suppose we have KRvK. Let's say the pieces are on square numbers wK, wR
		// and bK (each 0...63). The simplest way to map this position to an index
		// is like this:
		//
		//   index = wK * 64 * 64 + wR * 64 + bK;
		//
		// But this way the TB is going to have 64*64*64 = 262144 positions, with
		// lots of positions being equivalent (because they are mirrors of each
		// other) and lots of positions being invalid (two pieces on one square,
		// adjacent kings, etc.).
		// Usually the first step is to take the wK and bK together. There are just
		// 462 ways legal and not-mirrored ways to place the wK and bK on the board.
		// Once we have placed the wK and bK, there are 62 squares left for the wR
		// Mapping its square from 0..63 to available squares 0..61 can be done like:
		//
		//   wR -= (wR > wK) + (wR > bK);
		//
		// In words: if wR "comes later" than wK, we deduct 1, and the same if wR
		// "comes later" than bK. In case of two same pieces like KRRvK we want to
		// place the two Rs "together". If we have 62 squares left, we can place two
		// Rs "together" in 62 * 61 / 2 ways (we divide by 2 because rooks can be
		// swapped and still get the same position.)
		//
		// In case we have at least 3 unique pieces (inlcuded kings) we encode them
		// together.
		if (entry.hasUniquePieces)
		{

			int adjust1 = squares[1].getValue() > squares[0].getValue();
			int adjust2 = (squares[2].getValue() > squares[0].getValue()) + (squares[2].getValue() > squares[1].getValue());

			// First piece is below a1-h8 diagonal. MapA1D1D4[] maps the b1-d1-d3
			// triangle to 0...5. There are 63 squares for second piece and and 62
			// (mapped to 0...61) for the third.
			if (off_A1H8(squares[0]) != 0)
			{
				idx = (MapA1D1D4[squares[0].getValue()] * 63 + (squares[1] - adjust1)) * 62 + squares[2] - adjust2;
			}

			// First piece is on a1-h8 diagonal, second below: map this occurence to
			// 6 to differentiate from the above case, rank_of() maps a1-d4 diagonal
			// to 0...3 and finally MapB1H1H7[] maps the b1-h1-h7 triangle to 0..27.
			else if (off_A1H8(squares[1]))
			{
				idx = (6 * 63 + rank_of(squares[0]) * 28 + MapB1H1H7[squares[1].getValue()]) * 62 + squares[2] - adjust2;
			}

			// First two pieces are on a1-h8 diagonal, third below
			else if (off_A1H8(squares[2]))
			{
				idx = 6 * 63 * 62 + 4 * 28 * 62 + rank_of(squares[0]) * 7 * 28 + (rank_of(squares[1]) - adjust1) * 28 + MapB1H1H7[squares[2].getValue()];
			}

			// All 3 pieces on the diagonal a1-h8
			else
			{
				idx = 6 * 63 * 62 + 4 * 28 * 62 + 4 * 7 * 28 + rank_of(squares[0]) * 7 * 6 + (rank_of(squares[1]) - adjust1) * 6 + (rank_of(squares[2]) - adjust2);
			}
		}
		else
		{
			// We don't have at least 3 unique pieces, like in KRRvKBB, just map
			// the kings.
			idx = MapKK[MapA1D1D4[squares[0].getValue()]][squares[1].getValue()];
		}

//C++ TO JAVA CONVERTER TODO TASK: There are no gotos or labels in Java:
	encode_remaining:
		idx *= d.groupIdx[0];
		Square[] groupSq = squares + d.groupLen[0];

		// Encode remainig pawns then pieces according to square, in ascending order
		boolean remainingPawns = entry.hasPawns && entry.pawnCount[1];

		while (d.groupLen[++next] != 0)
		{
			std::sort(groupSq, groupSq + d.groupLen[next]);
			uint64_t n = 0;

			// Map down a square if "comes later" than a square in the previous
			// groups (similar to what done earlier for leading group pieces).
			for (int i = 0; i < d.groupLen[next]; ++i)
			{
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
			auto f = (Square s) ->
			{
				return groupSq[i].getValue() > s.getValue();
			};
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
				auto adjust = std::count_if(squares, groupSq, f);
				n += Binomial[i + 1][groupSq[i].getValue() - adjust - 8 * remainingPawns];
			}

			remainingPawns = false;
			idx += n * d.groupIdx[next];
			groupSq += d.groupLen[next];
		}

		// Now that we have the index, decompress the pair and get the score
		return map_score(entry, tbFile, decompress_pairs(d, new uint64_t(idx)), wdl);
	}

	// Group together pieces that will be encoded together. The general rule is that
	// a group contains pieces of same type and color. The exception is the leading
	// group that, in case of positions withouth pawns, can be formed by 3 different
	// pieces (default) or by the king pair when there is not a unique piece apart
	// from the kings. When there are pawns, pawns are always first in pieces[].
	//
	// As example KRKN -> KRK + N, KNNK -> KK + NN, KPPKP -> P + PP + K + K
	//
	// The actual grouping depends on the TB generator and can be inferred from the
	// sequence of pieces in piece[] array.
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
	public static <T> void set_groups(T e, PairsData d, int[] order, File f)
	{

		int n = 0;
		int firstLen = e.hasPawns ? 0 : e.hasUniquePieces ? 3 : 2;
		d.groupLen[n] = 1;

		// Number of pieces per group is stored in groupLen[], for instance in KRKN
		// the encoder will default on '111', so groupLen[] will be (3, 1).
		for (int i = 1; i < e.pieceCount; ++i)
		{
			if (--firstLen > 0 || d.pieces[i] == d.pieces[i - 1])
			{
				d.groupLen[n]++;
			}
			else
			{
				d.groupLen[++n] = 1;
			}
		}

		d.groupLen[++n] = 0; // Zero-terminated

		// The sequence in pieces[] defines the groups, but not the order in which
		// they are encoded. If the pieces in a group g can be combined on the board
		// in N(g) different ways, then the position encoding will be of the form:
		//
		//           g1 * N(g2) * N(g3) + g2 * N(g3) + g3
		//
		// This ensures unique encoding for the whole position. The order of the
		// groups is a per-table parameter and could not follow the canonical leading
		// pawns/pieces -> remainig pawns -> remaining pieces. In particular the
		// first group is at order[0] position and the remaining pawns, when present,
		// are at order[1] position.
		boolean pp = e.hasPawns && e.pawnCount[1]; // Pawns on both sides
		int next = pp ? 2 : 1;
		int freeSquares = 64 - d.groupLen[0] - (pp ? d.groupLen[1] : 0);
		uint64_t idx = 1;

		for (int k = 0; next < n || k == order[0] || k == order[1]; ++k)
		{
			if (k == order[0]) // Leading pawns or pieces
			{
				d.groupIdx[0] = idx;
				idx *= e.hasPawns ? LeadPawnsSize[d.groupLen[0]][f.getValue()] : e.hasUniquePieces ? 31332 : 462;
			}
			else if (k == order[1]) // Remaining pawns
			{
				d.groupIdx[1] = idx;
				idx *= Binomial[d.groupLen[1]][48 - d.groupLen[0]];
			}
			else // Remainig pieces
			{
				d.groupIdx[next] = idx;
				idx *= Binomial[d.groupLen[next]][freeSquares];
				freeSquares -= d.groupLen[next++];
			}
		}

		d.groupIdx[n] = idx;
	}

	// In Recursive Pairing each symbol represents a pair of childern symbols. So
	// read d->btree[] symbols data and expand each one in his left and right child
	// symbol until reaching the leafs that represent the symbol value.
	public static uint8_t set_symlen(PairsData d, uint16_t s, ArrayList<Boolean> visited)
	{

		visited.set(s, true); // We can set it now because tree is acyclic
		uint16_t sr = d.btree[s].<LR.Side.Right.getValue()>get();

		if (sr == 0xFFF)
		{
			return 0;
		}

		uint16_t sl = d.btree[s].<LR.Side.Left.getValue()>get();

		if (!visited.get(sl))
		{
			d.symlen.set(sl, set_symlen(d, new uint16_t(sl), visited));
		}

		if (!visited.get(sr))
		{
			d.symlen.set(sr, set_symlen(d, new uint16_t(sr), visited));
		}

		return d.symlen.get(sl) + d.symlen.get(sr) + 1;
	}

//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'data', so pointers on this parameter are left unchanged:
	public static uint8_t set_sizes(PairsData d, uint8_t * data)
	{

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: d->flags = *data++;
		d.flags.copyFrom(data++);

		if (d.flags & TBFlag.SingleValue != null)
		{
			d.blocksNum = d.blockLengthSize = 0;
			d.span = d.sparseIndexSize = 0; // Broken MSVC zero-init
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: d->minSymLen = *data++;
			d.minSymLen.copyFrom(data++); // Here we store the single value
			return new uint8_t(data);
		}

		// groupLen[] is a zero-terminated list of group lengths, the last groupIdx[]
		// element stores the biggest index that is the tb size.
		uint64_t tbSize = d.groupIdx[std::find(d.groupLen, d.groupLen + 7, 0) - d.groupLen];

		d.sizeofBlock = 1 << *data++;
		d.span = 1 << *data++;
		d.sparseIndexSize = (tbSize + d.span - 1) / d.span; // Round up
		T padding = GlobalMembers.<uint8_t, AnonymousEnum.LittleEndian.getValue()>number(data++);
		d.blocksNum = GlobalMembers.<uint32_t, AnonymousEnum.LittleEndian.getValue()>number(data);
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
		data += sizeof(uint32_t);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: d->blockLengthSize = d->blocksNum + padding;
		d.blockLengthSize.copyFrom(d.blocksNum + padding); // Padded to ensure SparseIndex[]
													 // does not point out of range.
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: d->maxSymLen = *data++;
		d.maxSymLen.copyFrom(data++);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: d->minSymLen = *data++;
		d.minSymLen.copyFrom(data++);
		d.lowestSym = (uint16_t)data;
		tangible.VectorHelper.resize(d.base64, d.maxSymLen - d.minSymLen + 1);

		// The canonical code is ordered such that longer symbols (in terms of
		// the number of bits of their Huffman code) have lower numeric value,
		// so that d->lowestSym[i] >= d->lowestSym[i+1] (when read as LittleEndian).
		// Starting from this we compute a base64[] table indexed by symbol length
		// and containing 64 bit values so that d->base64[i] >= d->base64[i+1].
		// See http://www.eecs.harvard.edu/~michaelm/E210/huffman.pdf
		for (int i = d.base64.size() - 2; i >= 0; --i)
		{
			d.base64.set(i, (d.base64.get(i + 1) + GlobalMembers.<uint16_t, AnonymousEnum.LittleEndian.getValue()>number(d.lowestSym[i]) - GlobalMembers.<uint16_t, AnonymousEnum.LittleEndian.getValue()>number(d.lowestSym[i + 1])) / 2);

			assert d.base64.get(i) * 2 >= d.base64.get(i + 1);
		}

		// Now left-shift by an amount so that d->base64[i] gets shifted 1 bit more
		// than d->base64[i+1] and given the above assert condition, we ensure that
		// d->base64[i] >= d->base64[i+1]. Moreover for any symbol s64 of length i
		// and right-padded to 64 bits holds d->base64[i-1] >= s64 >= d->base64[i].
		for (size_t i = 0; i < d.base64.size(); ++i)
		{
			d.base64.get(i) <<= 64 - i - d.minSymLen; // Right-padding to 64 bits
		}

//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
		data += d.base64.size() * sizeof(uint16_t);
		tangible.VectorHelper.resize(d.symlen, GlobalMembers.<uint16_t, AnonymousEnum.LittleEndian.getValue()>number(data));
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
		data += sizeof(uint16_t);
		d.btree = (LR)data;

		// The compression scheme used is "Recursive Pairing", that replaces the most
		// frequent adjacent pair of symbols in the source message by a new symbol,
		// reevaluating the frequencies of all of the symbol pairs with respect to
		// the extended alphabet, and then repeating the process.
		// See http://www.larsson.dogma.net/dcc99.pdf
		ArrayList<Boolean> visited = new ArrayList<Boolean>(d.symlen.size());

		for (uint16_t sym = 0; sym < d.symlen.size(); ++sym)
		{
			if (!visited.get(sym))
			{
				d.symlen.set(sym, set_symlen(d, new uint16_t(sym), visited));
			}
		}

//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
		return data + d.symlen.size() * sizeof(LR) + (d.symlen.size() & 1);
	}

	public static uint8_t set_dtz_map(TBTable<TBType.WDL> UnnamedParameter, uint8_t data, File UnnamedParameter2)
	{
		return data;
	}

//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'data', so pointers on this parameter are left unchanged:
	public static uint8_t set_dtz_map(TBTable<TBType.DTZ> e, uint8_t * data, File maxFile)
	{

		e.map = data;

		for (File f = File.FILE_A; f.getValue() <= maxFile.getValue(); ++f)
		{
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
			auto flags = e.get(0, f.getValue()).flags;
			if (flags & TBFlag.Mapped != null)
			{
				if (flags & TBFlag.Wide != null)
				{
					data += (uintptr_t)data & 1; // Word alignment, we may have a mixed table
					for (int i = 0; i < 4; ++i)
					{ // Sequence like 3,x,x,x,1,x,0,2,x,x
						e.get(0, f.getValue()).map_idx[i] = (uint16_t)((uint16_t)data - (uint16_t)e.map + 1);
						data += 2 * GlobalMembers.<uint16_t, AnonymousEnum.LittleEndian.getValue()>number(data) + 2;
					}
				}
				else
				{
					for (int i = 0; i < 4; ++i)
					{
						e.get(0, f.getValue()).map_idx[i] = (uint16_t)(data - e.map + 1);
						data += *data + 1;
					}
				}
			}
		}

		return data += (uintptr_t)data & 1; // Word alignment
	}

	// Populate entry's PairsData records with data from the just memory mapped file.
	// Called at first access.
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'data', so pointers on this parameter are left unchanged:
	public static <T> void set(T e, uint8_t * data)
	{

		PairsData d;


		assert e.hasPawns == !!(*data & AnonymousEnum2.HasPawns);
		assert (e.key != e.key2) == !!(*data & AnonymousEnum2.Split);

		data++; // First byte stores flags

		final int sides = T.Sides == 2 && (e.key != e.key2) ? 2 : 1;
		final File maxFile = e.hasPawns ? File.FILE_D : File.FILE_A;

		boolean pp = e.hasPawns && e.pawnCount[1]; // Pawns on both sides

		assert!pp || e.pawnCount[0];

		for (File f = File.FILE_A; f.getValue() <= maxFile.getValue(); ++f)
		{

			for (int i = 0; i < sides; i++)
			{
				*e.get(i, f) = new PairsData();
			}

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			int[][] order =
			{
				{data & 0xF, pp ? *(data + 1) & 0xF : 0xF},
				{data >> 4, pp ? *(data + 1) >> 4 : 0xF}
			};
			data += 1 + pp;

			for (int k = 0; k < e.pieceCount; ++k, ++data)
			{
				for (int i = 0; i < sides; i++)
				{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
					e.get(i, f).pieces[k] = Piece(i ? *data >> 4 : *data & 0xF);
				}
			}

			for (int i = 0; i < sides; ++i)
			{
				set_groups(e, e.get(i, f), order[i], f);
			}
		}

		data += (uintptr_t)data & 1; // Word alignment

		for (File f = File.FILE_A; f.getValue() <= maxFile.getValue(); ++f)
		{
			for (int i = 0; i < sides; i++)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: data = set_sizes(e.get(i, f), data);
				data.copyFrom(set_sizes(e.get(i, f), new uint8_t(data)));
			}
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: data = set_dtz_map(e, data, maxFile);
		data.copyFrom(set_dtz_map(e, new uint8_t(data), maxFile));

		for (File f = File.FILE_A; f.getValue() <= maxFile.getValue(); ++f)
		{
			for (int i = 0; i < sides; i++)
			{
				(d = e.get(i, f)).sparseIndex = (SparseEntry)data;
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
				data += d.sparseIndexSize * sizeof(SparseEntry);
			}
		}

		for (File f = File.FILE_A; f.getValue() <= maxFile.getValue(); ++f)
		{
			for (int i = 0; i < sides; i++)
			{
				(d = e.get(i, f)).blockLength = (uint16_t)data;
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
				data += d.blockLengthSize * sizeof(uint16_t);
			}
		}

		for (File f = File.FILE_A; f.getValue() <= maxFile.getValue(); ++f)
		{
			for (int i = 0; i < sides; i++)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: data = (uint8_t*)(((uintptr_t)data + 0x3F) & ~0x3F);
				data.copyFrom((uint8_t)(((uintptr_t)data + 0x3F) & ~0x3F)); // 64 byte alignment
				(d = e.get(i, f)).data = data;
				data += d.blocksNum * d.sizeofBlock;
			}
		}
	}

	// If the TB file corresponding to the given position is already memory mapped
	// then return its base address, otherwise try to memory map and init it. Called
	// at every probe, memory map and init only at first access. Function is thread
	// safe and can be called concurrently.
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<TBType Type>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Type>
	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to templates on variables:
	public static Object mapped_mutex = new Object();

	public static Object mapped(TBTable<Type> e, Position pos)
	{

	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//	static Object mutex;

		// Use 'aquire' to avoid a thread reads 'ready' == true while another is
		// still working, this could happen due to compiler reordering.
		if (e.ready.load(std::memory_order_acquire))
		{
			return e.baseAddress; // Could be nullptr if file does not exsist
		}

		std::unique_lock<Object> lk = new std::unique_lock<Object>(mapped_mutex);

		if (e.ready.load(std::memory_order_relaxed)) // Recheck under lock
		{
			return e.baseAddress;
		}

		// Pieces strings in decreasing order for each color, like ("KPP","KR")
		String fname;
		String w;
		String b;
		for (PieceType pt = PieceType.KING; pt.getValue() >= PieceType.PAWN.getValue(); --pt)
		{
			w += (String)(PieceToChar.charAt(pt), popcount(pos.pieces(Color.WHITE, pt)));
			b += (String)(PieceToChar.charAt(pt), popcount(pos.pieces(Color.BLACK, pt)));
		}

		fname = (e.key == pos.material_key() ? w + 'v' + b : b + 'v' + w) + (Type == TBType.WDL ? ".rtbw" : ".rtbz");

		uint8_t data = new TBFile(fname).map(e.baseAddress, e.mapping, Type);

		if (data != null)
		{
			set(e, data);
		}

		e.ready.store(true, std::memory_order_release);
		return e.baseAddress;
	}

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<TBType Type, typename Ret = typename TBTable<Type>::Ret>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers containing defaults cannot be converted to Java:
//ORIGINAL LINE: template<typename Type, typename Ret = typename TBTable<Type>::Ret>
public static <Type, Ret = TBTable<Type>.Ret> Ret probe_table(Position pos, ProbeState result)
{
	return probe_table(pos, result, WDLDraw);
}
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: Ret probe_table(const Position& pos, ProbeState* result, WDLScore wdl = WDLDraw)
	public static <Type, Ret = TBTable<Type>.Ret> Ret probe_table(Position pos, ProbeState result, WDLScore wdl)
	{

		if (pos.<PieceType.ALL_PIECES.getValue()>count() == 2) // KvK
		{
			return Ret(WDLDraw);
		}

		TBTable<Type> entry = TBTables.<Type>get(pos.material_key());

		if (entry == null || !mapped(entry, pos))
		{
			return result = FAIL, null;
		}

		return do_probe_table(pos, entry, wdl, result);
	}

	// For a position where the side to move has a winning capture it is not necessary
	// to store a winning value so the generator treats such positions as "don't cares"
	// and tries to assign to it a value that improves the compression ratio. Similarly,
	// if the side to move has a drawing capture, then the position is at least drawn.
	// If the position is won, then the TB needs to store a win value. But if the
	// position is drawn, the TB may store a loss value if that is better for compression.
	// All of this means that during probing, the engine must look at captures and probe
	// their results and must probe the position itself. The "best" result of these
	// probes is the correct result for the position.
	// DTZ tables do not store values when a following move is a zeroing winning move
	// (winning capture or winning pawn move). Also DTZ store wrong values for positions
	// where the best move is an ep-move (even if losing). So in all these cases set
	// the state to ZEROING_BEST_MOVE.
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<bool CheckZeroingMoves>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename CheckZeroingMoves>
	public static <CheckZeroingMoves> WDLScore search(Position pos, ProbeState result)
	{

		WDLScore value;
		WDLScore bestValue = WDLLoss;
		StateInfo st = new StateInfo();

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
		auto moveList = new MoveList<GenType.LEGAL.getValue()>(pos);
		size_t totalCount = moveList.size();
		size_t moveCount = 0;

		for (Move move : moveList)
		{
			if (!pos.capture(move) && (!CheckZeroingMoves || type_of(pos.moved_piece(move)) != PieceType.PAWN))
			{
				continue;
			}

			moveCount++;

			pos.do_move(move, st);
			value = -GlobalMembers.<false>search(pos, result);
			pos.undo_move(move);

			if (result == FAIL)
			{
				return WDLDraw;
			}

			if (value.getValue() > bestValue.getValue())
			{
				bestValue = value;

				if (value.getValue() >= WDLWin)
				{
					result = ZEROING_BEST_MOVE; // Winning DTZ-zeroing move
					return value;
				}
			}
		}

		// In case we have already searched all the legal moves we don't have to probe
		// the TB because the stored score could be wrong. For instance TB tables
		// do not contain information on position with ep rights, so in this case
		// the result of probe_wdl_table is wrong. Also in case of only capture
		// moves, for instance here 4K3/4q3/6p1/2k5/6p1/8/8/8 w - - 0 7, we have to
		// return with ZEROING_BEST_MOVE set.
		boolean noMoreMoves = (moveCount != null && moveCount == totalCount);

		if (noMoreMoves)
		{
			value = bestValue;
		}
		else
		{
			value = GlobalMembers.<TBType.WDL.getValue()>probe_table(pos, result);

			if (result == FAIL)
			{
				return WDLDraw;
			}
		}

		// DTZ stores a "don't care" value if bestValue is a win
		if (bestValue.getValue() >= value.getValue())
		{
			return result = (bestValue.getValue() > WDLDraw || noMoreMoves ? ZEROING_BEST_MOVE : OK), bestValue;
		}

		return result = OK, value;
	}


	/*
	  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
	  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
	  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
	  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad
	
	  Stockfish is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	
	  Stockfish is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/





	public static final ArrayList<String> Defaults = new ArrayList<String>(Arrays.asList("setoption name UCI_Chess960 value false", "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 10", "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 11", "4rrk1/pp1n3p/3q2pQ/2p1pb2/2PP4/2P3N1/P2B2PP/4RRK1 b - - 7 19", "rq3rk1/ppp2ppp/1bnpb3/3N2B1/3NP3/7P/PPPQ1PP1/2KR3R w - - 7 14 moves d4e6", "r1bq1r1k/1pp1n1pp/1p1p4/4p2Q/4Pp2/1BNP4/PPP2PPP/3R1RK1 w - - 2 14 moves g2g4", "r3r1k1/2p2ppp/p1p1bn2/8/1q2P3/2NPQN2/PPP3PP/R4RK1 b - - 2 15", "r1bbk1nr/pp3p1p/2n5/1N4p1/2Np1B2/8/PPP2PPP/2KR1B1R w kq - 0 13", "r1bq1rk1/ppp1nppp/4n3/3p3Q/3P4/1BP1B3/PP1N2PP/R4RK1 w - - 1 16", "4r1k1/r1q2ppp/ppp2n2/4P3/5Rb1/1N1BQ3/PPP3PP/R5K1 w - - 1 17", "2rqkb1r/ppp2p2/2npb1p1/1N1Nn2p/2P1PP2/8/PP2B1PP/R1BQK2R b KQ - 0 11", "r1bq1r1k/b1p1npp1/p2p3p/1p6/3PP3/1B2NN2/PP3PPP/R2Q1RK1 w - - 1 16", "3r1rk1/p5pp/bpp1pp2/8/q1PP1P2/b3P3/P2NQRPP/1R2B1K1 b - - 6 22", "r1q2rk1/2p1bppp/2Pp4/p6b/Q1PNp3/4B3/PP1R1PPP/2K4R w - - 2 18", "4k2r/1pb2ppp/1p2p3/1R1p4/3P4/2r1PN2/P4PPP/1R4K1 b - - 3 22", "3q2k1/pb3p1p/4pbp1/2r5/PpN2N2/1P2P2P/5PP1/Q2R2K1 b - - 4 26", "6k1/6p1/6Pp/ppp5/3pn2P/1P3K2/1PP2P2/3N4 b - - 0 1", "3b4/5kp1/1p1p1p1p/pP1PpP1P/P1P1P3/3KN3/8/8 w - - 0 1", "2K5/p7/7P/5pR1/8/5k2/r7/8 w - - 0 1 moves g5g6 f3e3 g6g5 e3f3", "8/6pk/1p6/8/PP3p1p/5P2/4KP1q/3Q4 w - - 0 1", "7k/3p2pp/4q3/8/4Q3/5Kp1/P6b/8 w - - 0 1", "8/2p5/8/2kPKp1p/2p4P/2P5/3P4/8 w - - 0 1", "8/1p3pp1/7p/5P1P/2k3P1/8/2K2P2/8 w - - 0 1", "8/pp2r1k1/2p1p3/3pP2p/1P1P1P1P/P5KR/8/8 w - - 0 1", "8/3p4/p1bk3p/Pp6/1Kp1PpPp/2P2P1P/2P5/5B2 b - - 0 1", "5k2/7R/4P2p/5K2/p1r2P1p/8/8/8 b - - 0 1", "6k1/6p1/P6p/r1N5/5p2/7P/1b3PP1/4R1K1 w - - 0 1", "1r3k2/4q3/2Pp3b/3Bp3/2Q2p2/1p1P2P1/1P2KP2/3N4 w - - 0 1", "6k1/4pp1p/3p2p1/P1pPb3/R7/1r2P1PP/3B1P2/6K1 w - - 0 1", "8/3p3B/5p2/5P2/p7/PP5b/k7/6K1 w - - 0 1", "8/8/8/8/5kp1/P7/8/1K1N4 w - - 0 1", "8/8/8/5N2/8/p7/8/2NK3k w - - 0 1", "8/3k4/8/8/8/4B3/4KB2/2B5 w - - 0 1", "8/8/1P6/5pr1/8/4R3/7k/2K5 w - - 0 1", "8/2p4P/8/kr6/6R1/8/8/1K6 w - - 0 1", "8/8/3P3k/8/1p6/8/1P6/1K3n2 b - - 0 1", "8/R7/2q5/8/6k1/8/1P5p/K6R w - - 0 124", "6k1/3b3r/1p1p4/p1n2p2/1PPNpP1q/P3Q1p1/1R1RB1P1/5K2 b - - 0 1", "r2r1n2/pp2bk2/2p1p2p/3q4/3PN1QP/2P3R1/P4PP1/5RK1 w - - 0 1", "8/8/8/8/8/6k1/6p1/6K1 w - -", "7k/7P/6K1/8/3B4/8/8/8 b - -", "setoption name UCI_Chess960 value true", "bbqnnrkr/pppppppp/8/8/8/8/PPPPPPPP/BBQNNRKR w KQkq - 0 1 moves g2g3 d7d5 d2d4 c8h3 c1g5 e8d6 g5e7 f7f6", "setoption name UCI_Chess960 value false"));


	/// setup_bench() builds a list of UCI commands to be run by bench. There
	/// are five parameters: TT size in MB, number of search threads that
	/// should be used, the limit value spent for each position, a file name
	/// where to look for positions in FEN format and the type of the limit:
	/// depth, perft, nodes and movetime (in millisecs).
	///
	/// bench -> search default positions up to depth 13
	/// bench 64 1 15 -> search default positions up to depth 15 (TT = 64MB)
	/// bench 64 4 5000 current movetime -> search current position with 4 threads for 5 sec
	/// bench 64 1 100000 default nodes -> search default positions for 100K nodes each
	/// bench 16 1 5 default perft -> run a perft 5 on default positions

	public static ArrayList<String> setup_bench(Position current, istream is)
	{

	  ArrayList<String> fens = new ArrayList<String>();
	  ArrayList<String> list = new ArrayList<String>();
	  String go;
	  String token;

	  // Assign default values to missing arguments
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  String ttSize = (is >> token) != 0 ? token : "16";
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  String threads = (is >> token) != 0 ? token : "1";
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  String limit = (is >> token) != 0 ? token : "13";
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  String fenFile = (is >> token) != 0 ? token : "default";
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  String limitType = (is >> token) != 0 ? token : "depth";

	  go = "go " + limitType + " " + limit;

	  if (fenFile.equals("default"))
	  {
		  fens = new ArrayList<String>(Defaults);
	  }

	  else if (fenFile.equals("current"))
	  {
		  fens.add(current.fen());
	  }

	  else
	  {
		  String fen;
		  ifstream file = new ifstream(fenFile);

		  if (!file.is_open())
		  {
			  cerr << "Unable to open file " << fenFile << "\n";
			  System.exit(1);
		  }

		  while (getline(file, fen))
		  {
			  if (fen.length() > 0)
			  {
				  fens.add(fen);
			  }
		  }

		  file.close();
	  }

	  list.emplace_back("ucinewgame");
	  list.emplace_back("setoption name Threads value " + threads);
	  list.emplace_back("setoption name Hash value " + ttSize);

	  for (String fen : fens)
	  {
		  if (fen.indexOf("setoption") != -1)
		  {
			  list.emplace_back(fen);
		  }
		  else
		  {
			  list.emplace_back("position fen " + fen);
			  list.emplace_back(go);
		  }
	  }

	  return new ArrayList<String>(list);
	}

	/*
	  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
	  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
	  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
	  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad
	
	  Stockfish is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	
	  Stockfish is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




	  // There are 24 possible pawn squares: the first 4 files and ranks from 2 to 7
	  public static final int MAX_INDEX = 2 * 24 * 64 * 64; // stm * psq * wksq * bksq = 196608

	  // Each uint32_t stores results of 32 positions, one per bit
	  public static uint32_t[] KPKBitbase = tangible.Arrays.initializeWithDefaultuint32_tInstances(MAX_INDEX / 32);

	  // A KPK bitbase index is an integer in [0, IndexMax] range
	  //
	  // Information is mapped in a way that minimizes the number of iterations:
	  //
	  // bit  0- 5: white king square (from SQ_A1 to SQ_H8)
	  // bit  6-11: black king square (from SQ_A1 to SQ_H8)
	  // bit    12: side to move (WHITE or BLACK)
	  // bit 13-14: white pawn file (from FILE_A to FILE_D)
	  // bit 15-17: white pawn RANK_7 - rank (from RANK_7 - RANK_7 to RANK_7 - RANK_2)
	  public static int index(Color us, Square bksq, Square wksq, Square psq)
	  {
		return (wksq | (bksq.getValue() << 6) | (us.getValue() << 12) | (file_of(psq) << 13) | ((Rank.RANK_7 - rank_of(psq)) << 15)).getValue();
	  }

	  private Result bitwiseOrAssignment(Result r, Result v)
	  {
		  return r = Result(r | v);
	  }


	public static final uint64_t AllSquares = ~Bitboard(0);
	public static final uint64_t DarkSquares = 0xAA55AA55AA55AA55;

	public static final uint64_t FileABB = 0x0101010101010101;
	public static final uint64_t FileBBB = FileABB << 1;
	public static final uint64_t FileCBB = FileABB << 2;
	public static final uint64_t FileDBB = FileABB << 3;
	public static final uint64_t FileEBB = FileABB << 4;
	public static final uint64_t FileFBB = FileABB << 5;
	public static final uint64_t FileGBB = FileABB << 6;
	public static final uint64_t FileHBB = FileABB << 7;

	public static final uint64_t Rank1BB = 0xFF;
	public static final uint64_t Rank2BB = Rank1BB << (8 * 1);
	public static final uint64_t Rank3BB = Rank1BB << (8 * 2);
	public static final uint64_t Rank4BB = Rank1BB << (8 * 3);
	public static final uint64_t Rank5BB = Rank1BB << (8 * 4);
	public static final uint64_t Rank6BB = Rank1BB << (8 * 5);
	public static final uint64_t Rank7BB = Rank1BB << (8 * 6);
	public static final uint64_t Rank8BB = Rank1BB << (8 * 7);

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern int SquareDistance[SQUARE_NB][SQUARE_NB];

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t SquareBB[SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t FileBB[FILE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t RankBB[RANK_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t AdjacentFilesBB[FILE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t ForwardRanksBB[COLOR_NB][RANK_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t BetweenBB[SQUARE_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t LineBB[SQUARE_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t DistanceRingBB[SQUARE_NB][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t ForwardFileBB[COLOR_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t PassedPawnMask[COLOR_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t PawnAttackSpan[COLOR_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t PseudoAttacks[PIECE_TYPE_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern uint64_t PawnAttacks[COLOR_NB][SQUARE_NB];

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Magic RookMagics[SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Magic BishopMagics[SQUARE_NB];


	/// Overloads of bitwise operators between a Bitboard and a Square for testing
	/// whether a given bit is set in a bitboard, and for setting and clearing bits.

	private uint64_t bitwiseAnd(uint64_t b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b & SquareBB[s.getValue()];
	}

	private uint64_t bitwiseOr(uint64_t b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b | SquareBB[s.getValue()];
	}

	private uint64_t exclusiveOr(uint64_t b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b ^ SquareBB[s.getValue()];
	}

	private uint64_t bitwiseOrAssignment(uint64_t b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b |= SquareBB[s.getValue()];
	}

	private uint64_t exclusiveOrAssignment(uint64_t b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b ^= SquareBB[s.getValue()];
	}

	public static boolean more_than_one(uint64_t b)
	{
	  return b & (b - 1) != null;
	}

	/// rank_bb() and file_bb() return a bitboard representing all the squares on
	/// the given file or rank.

	public static uint64_t rank_bb(Rank r)
	{
	  return new uint64_t(RankBB[r.getValue()]);
	}

	public static uint64_t rank_bb(Square s)
	{
	  return new uint64_t(RankBB[rank_of(s).getValue()]);
	}

	public static uint64_t file_bb(File f)
	{
	  return new uint64_t(FileBB[f.getValue()]);
	}

	public static uint64_t file_bb(Square s)
	{
	  return new uint64_t(FileBB[file_of(s).getValue()]);
	}


	/// shift() moves a bitboard one step along direction D (mainly for pawns)

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Direction D>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename D>
	public static <D> uint64_t shift(uint64_t b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return D == Direction.NORTH ? b << 8 : D == Direction.SOUTH ? b >> 8 : D == Direction.EAST ? (b & ~FileHBB) << 1 : D == Direction.WEST ? (b & ~FileABB) >> 1 : D == Direction.NORTH_EAST ? (b & ~FileHBB) << 9 : D == Direction.NORTH_WEST ? (b & ~FileABB) << 7 : D == Direction.SOUTH_EAST ? (b & ~FileHBB) >> 7 : D == Direction.SOUTH_WEST ? (b & ~FileABB) >> 9 : 0;
	}


	/// pawn_attacks_bb() returns the pawn attacks for the given color from the
	/// squares in the given bitboard.

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color C>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename C>
	public static <C> uint64_t pawn_attacks_bb(uint64_t b)
	{
	  return C == Color.WHITE ? GlobalMembers.<Direction.NORTH_WEST.getValue()>shift(b) | GlobalMembers.<Direction.NORTH_EAST.getValue()>shift(b) : GlobalMembers.<Direction.SOUTH_WEST.getValue()>shift(b) | GlobalMembers.<Direction.SOUTH_EAST.getValue()>shift(b);
	}


	/// adjacent_files_bb() returns a bitboard representing all the squares on the
	/// adjacent files of the given one.

	public static uint64_t adjacent_files_bb(File f)
	{
	  return new uint64_t(AdjacentFilesBB[f.getValue()]);
	}


	/// between_bb() returns a bitboard representing all the squares between the two
	/// given ones. For instance, between_bb(SQ_C4, SQ_F7) returns a bitboard with
	/// the bits for square d5 and e6 set. If s1 and s2 are not on the same rank, file
	/// or diagonal, 0 is returned.

	public static uint64_t between_bb(Square s1, Square s2)
	{
	  return new uint64_t(BetweenBB[s1.getValue()][s2.getValue()]);
	}


	/// forward_ranks_bb() returns a bitboard representing the squares on all the ranks
	/// in front of the given one, from the point of view of the given color. For instance,
	/// forward_ranks_bb(BLACK, SQ_D3) will return the 16 squares on ranks 1 and 2.

	public static uint64_t forward_ranks_bb(Color c, Square s)
	{
	  return new uint64_t(ForwardRanksBB[c.getValue()][rank_of(s).getValue()]);
	}


	/// forward_file_bb() returns a bitboard representing all the squares along the line
	/// in front of the given one, from the point of view of the given color:
	///      ForwardFileBB[c][s] = forward_ranks_bb(c, s) & file_bb(s)

	public static uint64_t forward_file_bb(Color c, Square s)
	{
	  return new uint64_t(ForwardFileBB[c.getValue()][s.getValue()]);
	}


	/// pawn_attack_span() returns a bitboard representing all the squares that can be
	/// attacked by a pawn of the given color when it moves along its file, starting
	/// from the given square:
	///      PawnAttackSpan[c][s] = forward_ranks_bb(c, s) & adjacent_files_bb(file_of(s));

	public static uint64_t pawn_attack_span(Color c, Square s)
	{
	  return new uint64_t(PawnAttackSpan[c.getValue()][s.getValue()]);
	}


	/// passed_pawn_mask() returns a bitboard mask which can be used to test if a
	/// pawn of the given color and on the given square is a passed pawn:
	///      PassedPawnMask[c][s] = pawn_attack_span(c, s) | forward_file_bb(c, s)

	public static uint64_t passed_pawn_mask(Color c, Square s)
	{
	  return new uint64_t(PassedPawnMask[c.getValue()][s.getValue()]);
	}


	/// aligned() returns true if the squares s1, s2 and s3 are aligned either on a
	/// straight or on a diagonal line.

	public static boolean aligned(Square s1, Square s2, Square s3)
	{
	  return LineBB[s1.getValue()][s2.getValue()] & s3 != null;
	}


	/// distance() functions return the distance between x and y, defined as the
	/// number of steps for a king in x to reach y. Works with squares, ranks, files.

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
	public static <T> int distance(T x, T y)
	{
		return x < y ? y - x : x - y;
	}
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline int distance<Square>(Square x, Square y)
	public static int distance(Square x, Square y)
	{
		return SquareDistance[x.getValue()][y.getValue()];
	}

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T1, typename T2>
	//<T1, T2> int distance(T2 x, T2 y);Tangible Method Implementation Not Found-distance
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline int distance<File>(Square x, Square y)
	public static int distance(Square x, Square y)
	{
		return distance(file_of(x), file_of(y));
	}
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline int distance<Rank>(Square x, Square y)
	public static int distance(Square x, Square y)
	{
		return distance(rank_of(x), rank_of(y));
	}


	/// attacks_bb() returns a bitboard representing all the squares attacked by a
	/// piece of type Pt (bishop or rook) placed on 's'.

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<PieceType Pt>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Pt>
	public static <Pt> uint64_t attacks_bb(Square s, uint64_t occupied)
	{

	  final Magic m = Pt == PieceType.ROOK ? RookMagics[s.getValue()] : BishopMagics[s.getValue()];
	  return new uint64_t(m.attacks[m.index(new uint64_t(occupied))]);
	}

	public static uint64_t attacks_bb(PieceType pt, Square s, uint64_t occupied)
	{

	  assert pt != PieceType.PAWN;

	  switch (pt)
	  {
	  case BISHOP:
		  return GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s, occupied);
	  case ROOK :
		  return GlobalMembers.< PieceType.ROOK.getValue()>attacks_bb(s, occupied);
	  case QUEEN :
		  return GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s, occupied) | GlobalMembers.<PieceType.ROOK.getValue()>attacks_bb(s, occupied);
	  default :
		  return new uint64_t(PseudoAttacks[pt.getValue()][s.getValue()]);
	  }
	}
	//{
	//	uint64_t bb;
	//	uint16_t u[4];
	//}
	public static int popcount(uint64_t b)
	{

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! USE_POPCNT

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//  extern uint8_t PopCnt16[1 << 16];
	   v = {b};
	  return PopCnt16[v.u[0]] + PopCnt16[v.u[1]] + PopCnt16[v.u[2]] + PopCnt16[v.u[3]];

	///#elif _MSC_VER || __INTEL_COMPILER

	  return (int)_mm_popcnt_u64(b);

	///#else // Assumed gcc or compatible compiler

	  return __builtin_popcountll(b);

	///#endif
	}


	/// lsb() and msb() return the least/most significant bit in a non-zero bitboard

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if __GNUC__ // GCC, Clang, ICC

	public static Square lsb(uint64_t b)
	{
	  assert b;
	  return Square(__builtin_ctzll(b));
	}

	public static Square msb(uint64_t b)
	{
	  assert b;
	  return Square(63 ^ __builtin_clzll(b));
	}

	///#elif _MSC_VER // MSVC

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if _WIN64 // MSVC, WIN64

	public static Square lsb(uint64_t b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;
  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
	  _BitScanForward64(tempRef_idx, new uint64_t(b));
	  idx = tempRef_idx.argValue;
	  return Square.forValue(idx);
	}

	public static Square msb(uint64_t b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;
  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
	  _BitScanReverse64(tempRef_idx, new uint64_t(b));
	  idx = tempRef_idx.argValue;
	  return Square.forValue(idx);
	}

	///#else // MSVC, WIN32

	public static Square lsb(uint64_t b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;

	  if (b & 0xffffffff != null)
	  {
	  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
		  _BitScanForward(tempRef_idx, int32_t(b));
		  idx = tempRef_idx.argValue;
		  return Square(idx);
	  }
	  else
	  {
	  tangible.RefObject<Integer> tempRef_idx2 = new tangible.RefObject<Integer>(idx);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  _BitScanForward(tempRef_idx2, int32_t(b >> 32));
		  idx = tempRef_idx2.argValue;
		  return Square(idx + 32);
	  }
	}

	public static Square msb(uint64_t b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  if ((b >> 32) != 0)
	  {
	  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  _BitScanReverse(tempRef_idx, int32_t(b >> 32));
		  idx = tempRef_idx.argValue;
		  return Square(idx + 32);
	  }
	  else
	  {
	  tangible.RefObject<Integer> tempRef_idx2 = new tangible.RefObject<Integer>(idx);
		  _BitScanReverse(tempRef_idx2, int32_t(b));
		  idx = tempRef_idx2.argValue;
		  return Square(idx);
	  }
	}

	///#endif

	///#else // Compiler is neither GCC nor MSVC compatible

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#error "Compiler not supported."

	///#endif


	/// pop_lsb() finds and clears the least significant bit in a non-zero bitboard

	public static Square pop_lsb(uint64_t b)
	{
	  final Square s = lsb(b);
	  b &= b - 1;
	  return s;
	}


	/// frontmost_sq() and backmost_sq() return the square corresponding to the
	/// most/least advanced bit relative to the given color.

	public static Square frontmost_sq(Color c, uint64_t b)
	{
		return c == Color.WHITE ? msb(new uint64_t(b)) : lsb(new uint64_t(b));
	}
	public static Square backmost_sq(Color c, uint64_t b)
	{
		return c == Color.WHITE ? lsb(new uint64_t(b)) : msb(new uint64_t(b));
	}



	public static uint8_t[] PopCnt16 = tangible.Arrays.initializeWithDefaultuint8_tInstances(1 << 16);
	public static int[][] SquareDistance = new int[Square.SQUARE_NB.getValue()][Square.SQUARE_NB.getValue()];

	public static uint64_t[] SquareBB = tangible.Arrays.initializeWithDefaultuint64_tInstances(Square.SQUARE_NB.getValue());
	public static uint64_t[] FileBB = tangible.Arrays.initializeWithDefaultuint64_tInstances(File.FILE_NB.getValue());
	public static uint64_t[] RankBB = tangible.Arrays.initializeWithDefaultuint64_tInstances(Rank.RANK_NB.getValue());
	public static uint64_t[] AdjacentFilesBB = tangible.Arrays.initializeWithDefaultuint64_tInstances(File.FILE_NB.getValue());
	public static uint64_t[][] ForwardRanksBB = new uint64_t[Color.COLOR_NB.getValue()][Rank.RANK_NB.getValue()];
	public static uint64_t[][] BetweenBB = new uint64_t[Square.SQUARE_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static uint64_t[][] LineBB = new uint64_t[Square.SQUARE_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static uint64_t[][] DistanceRingBB = new uint64_t[Square.SQUARE_NB.getValue()][8];
	public static uint64_t[][] ForwardFileBB = new uint64_t[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static uint64_t[][] PassedPawnMask = new uint64_t[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static uint64_t[][] PawnAttackSpan = new uint64_t[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static uint64_t[][] PseudoAttacks = new uint64_t[PieceType.PIECE_TYPE_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static uint64_t[][] PawnAttacks = new uint64_t[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];

	public static Magic[] RookMagics = tangible.Arrays.initializeWithDefaultMagicInstances(Square.SQUARE_NB.getValue());
	public static Magic[] BishopMagics = tangible.Arrays.initializeWithDefaultMagicInstances(Square.SQUARE_NB.getValue());


	  public static uint64_t[] RookTable = tangible.Arrays.initializeWithDefaultuint64_tInstances(0x19000); // To store rook attacks
	  public static uint64_t[] BishopTable = tangible.Arrays.initializeWithDefaultuint64_tInstances(0x1480); // To store bishop attacks

  // init_magics() computes all rook and bishop attacks at startup. Magic
  // bitboards are used to look up attacks of sliding pieces. As a reference see
  // chessprogramming.wikispaces.com/Magic+Bitboards. In particular, here we
  // use the so called "fancy" approach.


	  public static void init_magics(uint64_t[] table, Magic[] magics, Direction[] directions)
	  {

		// Optimal PRNG seeds to pick the correct magics in the shortest time
		int[][] seeds =
		{
			{8977, 44560, 54343, 38998, 5731, 95205, 104912, 17020},
			{728, 10316, 55013, 32803, 12281, 15100, 16645, 255}
		};

		uint64_t[] occupancy = tangible.Arrays.initializeWithDefaultuint64_tInstances(4096);
		uint64_t[] reference = tangible.Arrays.initializeWithDefaultuint64_tInstances(4096);
		uint64_t edges = new uint64_t();
		uint64_t b = new uint64_t();
		int[] epoch = new int[4096];
		int cnt = 0;
		int size = 0;

		for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
		{
			// Board edges are not considered in the relevant occupancies
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: edges = ((Rank1BB | Rank8BB) & ~rank_bb(s)) | ((FileABB | FileHBB) & ~file_bb(s));
			edges.copyFrom(((Rank1BB | Rank8BB) & ~rank_bb(s)) | ((FileABB | FileHBB) & ~file_bb(s)));

			// Given a square 's', the mask is the bitboard of sliding attacks from
			// 's' computed on an empty board. The index must be big enough to contain
			// all the attacks for each possible subset of the mask and so is 2 power
			// the number of 1s of the mask. Hence we deduce the size of the shift to
			// apply to the 64 or 32 bits word to get the index.
			Magic m = magics[s.getValue()];
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: m.mask = sliding_attack(directions, s, 0) & ~edges;
			m.mask.copyFrom(sliding_attack(directions, s, 0) & ~edges);
			m.shift = (Is64Bit ? 64 : 32) - popcount(new uint64_t(m.mask));

			// Set the offset for the attacks table of the square. We have individual
			// table sizes for each square with "Fancy Magic Bitboards".
			m.attacks = s == Square.SQ_A1 ? table : magics[s.getValue() - 1].attacks + size;

			// Use Carry-Rippler trick to enumerate all subsets of masks[s] and
			// store the corresponding sliding attack bitboard in reference[].
			b = size = 0;
			do
			{
				occupancy[size] = b;
				reference[size] = sliding_attack(directions, s, new uint64_t(b));

				if (HasPext)
				{
					m.attacks[(b, m) 0(b, m.mask)] = reference[size];
				}

				size++;
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = (b - m.mask) & m.mask;
				b.copyFrom((b - m.mask) & m.mask);
			} while (b != null);

			if (HasPext)
			{
				continue;
			}

			PRNG rng = new PRNG(seeds[Is64Bit][rank_of(s).getValue()]);

			// Find a magic for square 's' picking up an (almost) random number
			// until we find the one that passes the verification test.
			for (int i = 0; i < size;)
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				for (m.magic = 0; popcount((m.magic * m.mask) >> 56) < 6;)
				{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: m.magic = rng.sparse_rand<uint64_t>();
					m.magic.copyFrom(rng.<uint64_t>sparse_rand());
				}

				// A good magic must map every possible occupancy to an index that
				// looks up the correct sliding attack in the attacks[s] database.
				// Note that we build up the database for square 's' as a side
				// effect of verifying the magic. Keep track of the attempt count
				// and save it in epoch[], little speed-up trick to avoid resetting
				// m.attacks[] after every failed attempt.
				for (++cnt, i = 0; i < size; ++i)
				{
					int idx = m.index(occupancy[i]);

					if (epoch[idx] < cnt)
					{
						epoch[idx] = cnt;
						m.attacks[idx] = reference[i];
					}
					else if (m.attacks[idx] != reference[i])
					{
						break;
					}
				}
			}
		}
	  }

	  // popcount16() counts the non-zero bits using SWAR-Popcount algorithm

	  public static int popcount16(int u)
	  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		u -= (u >>> 1) & 0x5555;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		u = (int)(((u >>> 2) & 0x3333) + (u & 0x3333));
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		u = ((u >>> 4) + u) & 0x0F0F;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		return (u * 0x0101) >>> 8;
	  }



	  public static uint64_t sliding_attack(Direction[] directions, Square sq, uint64_t occupied)
	  {

		uint64_t attack = 0;

		for (int i = 0; i < 4; ++i)
		{
			for (Square s = sq + directions[i]; is_ok(s) && distance(s, s - directions[i]) == 1; s += directions[i])
			{
				attack |= s;

				if (occupied & s != null)
				{
					break;
				}
			}
		}

		return new uint64_t(attack);
	  }



	  // Table used to drive the king towards the edge of the board
	  // in KX vs K and KQ vs KR endgames.
	  public static final int[] PushToEdges = {100, 90, 80, 70, 70, 80, 90, 100, 90, 70, 60, 50, 50, 60, 70, 90, 80, 60, 40, 30, 30, 40, 60, 80, 70, 50, 30, 20, 20, 30, 50, 70, 70, 50, 30, 20, 20, 30, 50, 70, 80, 60, 40, 30, 30, 40, 60, 80, 90, 70, 60, 50, 50, 60, 70, 90, 100, 90, 80, 70, 70, 80, 90, 100};

	  // Table used to drive the king towards a corner square of the
	  // right color in KBN vs K endgames.
	  public static final int[] PushToCorners = {200, 190, 180, 170, 160, 150, 140, 130, 190, 180, 170, 160, 150, 140, 130, 140, 180, 170, 155, 140, 140, 125, 140, 150, 170, 160, 140, 120, 110, 140, 150, 160, 160, 150, 140, 110, 120, 140, 160, 170, 150, 140, 125, 140, 140, 155, 170, 180, 140, 130, 140, 150, 160, 170, 180, 190, 130, 140, 150, 160, 170, 180, 190, 200};

	  // Tables used to drive a piece towards or away from another piece
	  public static final int[] PushClose = {0, 0, 100, 80, 60, 40, 20, 10};
	  public static final int[] PushAway = {0, 5, 20, 40, 60, 80, 90, 100};

	  // Pawn Rank based scaling factors used in KRPPKRP endgame
	  public static final int[] KRPPKRPScaleFactors = {0, 9, 10, 14, 21, 44, 0, 0};

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! NDEBUG
	  public static boolean verify_material(Position pos, Color c, Value npm, int pawnsCnt)
	  {
		return pos.non_pawn_material(c) == npm && pos.<PieceType.PAWN.getValue()>count(c) == pawnsCnt;
	  }
	///#endif

	  // Map the square as if strongSide is white and strongSide's only pawn
	  // is on the left half of the board.
	  public static Square normalize(Position pos, Color strongSide, Square sq)
	  {

		assert pos.<PieceType.PAWN.getValue()>count(strongSide) == 1;

		if (file_of(pos.<PieceType.PAWN.getValue()>square(strongSide)) >= File.FILE_E.getValue())
		{
			sq = Square(sq ^ 7); // Mirror SQ_H1 -> SQ_A1
		}

		if (strongSide == Color.BLACK)
		{
			sq = ~sq;
		}

		return sq;
	  }



	/// Mate with KX vs K. This function is used to evaluate positions with
	/// king and plenty of material vs a lone king. It simply gives the
	/// attacking side a bonus for driving the defending king towards the edge
	/// of the board, and for keeping the distance between the two kings small.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KXK>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KXK>.operator ()(Position pos)
	{

	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 0);
	  assert!pos.checkers(); // Eval is never called when in check

	  // Stalemate detection with lone king
	  if (pos.side_to_move() == weakSide && new MoveList<GenType.LEGAL.getValue()>(pos).size() == null)
	  {
		  return Value.VALUE_DRAW;
	  }

	  Square winnerKSq = pos.<PieceType.KING.getValue()>square(strongSide);
	  Square loserKSq = pos.<PieceType.KING.getValue()>square(weakSide);

	  Value result = pos.non_pawn_material(strongSide) + pos.<PieceType.PAWN.getValue()>count(strongSide) * Value.PawnValueEg + PushToEdges[loserKSq.getValue()] + PushClose[distance(winnerKSq, loserKSq)];

	  if ((pos.<PieceType.QUEEN.getValue()>count(strongSide)) != 0 || (pos.<PieceType.ROOK.getValue()>count(strongSide)) != 0 || (pos.<PieceType.BISHOP.getValue()>count(strongSide) && pos.<PieceType.KNIGHT.getValue()>count(strongSide)) || ((pos.pieces(strongSide, PieceType.BISHOP) & ~DarkSquares) && (pos.pieces(strongSide, PieceType.BISHOP) & DarkSquares)))
	  {
		  result = Math.min(result + Value.VALUE_KNOWN_WIN, Value.VALUE_MATE_IN_MAX_PLY - 1);
	  }

	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// Mate with KBN vs K. This is similar to KX vs K, but we have to drive the
	/// defending king towards a corner square of the right color.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KBNK>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KBNK>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.KnightValueMg + Value.BishopValueMg, 0);
	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 0);

	  Square winnerKSq = pos.<PieceType.KING.getValue()>square(strongSide);
	  Square loserKSq = pos.<PieceType.KING.getValue()>square(weakSide);
	  Square bishopSq = pos.<PieceType.BISHOP.getValue()>square(strongSide);

	  // kbnk_mate_table() tries to drive toward corners A1 or H8. If we have a
	  // bishop that cannot reach the above squares, we flip the kings in order
	  // to drive the enemy toward corners A8 or H1.
	  if (opposite_colors(bishopSq, Square.SQ_A1))
	  {
		  winnerKSq = ~winnerKSq;
		  loserKSq = ~loserKSq;
	  }

	  Value result = Value.VALUE_KNOWN_WIN + PushClose[distance(winnerKSq, loserKSq)] + PushToCorners[loserKSq.getValue()];

	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// KP vs K. This endgame is evaluated with the help of a bitbase.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KPK>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KPK>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.VALUE_ZERO, 1);
	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 0);

	  // Assume strongSide is white and the pawn is on files A-D
	  Square wksq = normalize(pos, strongSide, pos.<PieceType.KING.getValue()>square(strongSide));
	  Square bksq = normalize(pos, strongSide, pos.<PieceType.KING.getValue()>square(weakSide));
	  Square psq = normalize(pos, strongSide, pos.<PieceType.PAWN.getValue()>square(strongSide));

	  Color us = strongSide == pos.side_to_move() ? Color.WHITE : Color.BLACK;

	  if (!Bitbases.probe(wksq, psq, bksq, us))
	  {
		  return Value.VALUE_DRAW;
	  }

	  Value result = Value.VALUE_KNOWN_WIN + Value.PawnValueEg + Value(rank_of(psq));

	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// KR vs KP. This is a somewhat tricky endgame to evaluate precisely without
	/// a bitbase. The function below returns drawish scores when the pawn is
	/// far advanced with support of the king, while the attacking king is far
	/// away.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KRKP>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KRKP>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.RookValueMg, 0);
	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 1);

	  Square wksq = relative_square(strongSide, pos.<PieceType.KING.getValue()>square(strongSide));
	  Square bksq = relative_square(strongSide, pos.<PieceType.KING.getValue()>square(weakSide));
	  Square rsq = relative_square(strongSide, pos.<PieceType.ROOK.getValue()>square(strongSide));
	  Square psq = relative_square(strongSide, pos.<PieceType.PAWN.getValue()>square(weakSide));

	  Square queeningSq = make_square(file_of(psq), Rank.RANK_1);
	  Value result;

	  // If the stronger side's king is in front of the pawn, it's a win
	  if (forward_file_bb(Color.WHITE, wksq) & psq != null)
	  {
		  result = Value.RookValueEg - distance(wksq, psq);
	  }

	  // If the weaker side's king is too far from the pawn and the rook,
	  // it's a win.
	  else if (distance(bksq, psq) >= 3 + (pos.side_to_move() == weakSide) && distance(bksq, rsq) >= 3)
	  {
		  result = Value.RookValueEg - distance(wksq, psq);
	  }

	  // If the pawn is far advanced and supported by the defending king,
	  // the position is drawish
	  else if (rank_of(bksq) <= Rank.RANK_3.getValue() && distance(bksq, psq) == 1 && rank_of(wksq) >= Rank.RANK_4.getValue() && distance(wksq, psq) > 2 + (pos.side_to_move() == strongSide))
	  {
		  result = Value(80) - 8 * distance(wksq, psq);
	  }

	  else
	  {
		  result = Value(200) - 8 * (distance(wksq, psq + Direction.SOUTH) - distance(bksq, psq + Direction.SOUTH) - distance(psq, queeningSq));
	  }

	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// KR vs KB. This is very simple, and always returns drawish scores. The
	/// score is slightly bigger when the defending king is close to the edge.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KRKB>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KRKB>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.RookValueMg, 0);
	  assert verify_material(pos, weakSide, Value.BishopValueMg, 0);

	  Value result = PushToEdges[pos.<PieceType.KING.getValue().getValue()>square(weakSide)];
	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// KR vs KN. The attacking side has slightly better winning chances than
	/// in KR vs KB, particularly if the king and the knight are far apart.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KRKN>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KRKN>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.RookValueMg, 0);
	  assert verify_material(pos, weakSide, Value.KnightValueMg, 0);

	  Square bksq = pos.<PieceType.KING.getValue()>square(weakSide);
	  Square bnsq = pos.<PieceType.KNIGHT.getValue()>square(weakSide);
	  Value result = PushToEdges[bksq.getValue()] + PushAway[distance(bksq, bnsq)];
	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// KQ vs KP. In general, this is a win for the stronger side, but there are a
	/// few important exceptions. A pawn on 7th rank and on the A,C,F or H files
	/// with a king positioned next to it can be a draw, so in that case, we only
	/// use the distance between the kings.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KQKP>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KQKP>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.QueenValueMg, 0);
	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 1);

	  Square winnerKSq = pos.<PieceType.KING.getValue()>square(strongSide);
	  Square loserKSq = pos.<PieceType.KING.getValue()>square(weakSide);
	  Square pawnSq = pos.<PieceType.PAWN.getValue()>square(weakSide);

	  Value result = PushClose[distance(winnerKSq, loserKSq)];

	  if (relative_rank(weakSide, pawnSq) != Rank.RANK_7 || distance(loserKSq, pawnSq) != 1 || ((FileABB | FileCBB | FileFBB | FileHBB) & pawnSq) == null)
	  {
		  result += Value.QueenValueEg - Value.PawnValueEg;
	  }

	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// KQ vs KR.  This is almost identical to KX vs K:  We give the attacking
	/// king a bonus for having the kings close together, and for forcing the
	/// defending king towards the edge. If we also take care to avoid null move for
	/// the defending side in the search, this is usually sufficient to win KQ vs KR.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KQKR>::operator ()(const Position& pos) const
	public static Value Endgame<EndgameCode.KQKR>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.QueenValueMg, 0);
	  assert verify_material(pos, weakSide, Value.RookValueMg, 0);

	  Square winnerKSq = pos.<PieceType.KING.getValue()>square(strongSide);
	  Square loserKSq = pos.<PieceType.KING.getValue()>square(weakSide);

	  Value result = Value.QueenValueEg - Value.RookValueEg + PushToEdges[loserKSq.getValue()] + PushClose[distance(winnerKSq, loserKSq)];

	  return strongSide == pos.side_to_move() ? result : -result;
	}


	/// Some cases of trivial draws
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value Endgame<KNNK>::operator ()(const Position&) const
	public static Value Endgame<EndgameCode.KNNK>.operator ()(Position UnnamedParameter)
	{
		return Value.VALUE_DRAW;
	}


	/// KB and one or more pawns vs K. It checks for draws with rook pawns and
	/// a bishop of the wrong color. If such a draw is detected, SCALE_FACTOR_DRAW
	/// is returned. If not, the return value is SCALE_FACTOR_NONE, i.e. no scaling
	/// will be used.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KBPsK>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KBPsK>.operator ()(Position pos)
	{

	  assert pos.non_pawn_material(strongSide) == Value.BishopValueMg;
	  assert pos.<PieceType.PAWN.getValue()>count(strongSide) >= 1;

	  // No assertions about the material of weakSide, because we want draws to
	  // be detected even when the weaker side has some pawns.

	  uint64_t pawns = pos.pieces(strongSide, PieceType.PAWN);
	  File pawnsFile = file_of(lsb(new uint64_t(pawns)));

	  // All pawns are on a single rook file?
	  if ((pawnsFile == File.FILE_A || pawnsFile == File.FILE_H) && !(pawns & ~file_bb(pawnsFile)))
	  {
		  Square bishopSq = pos.<PieceType.BISHOP.getValue()>square(strongSide);
		  Square queeningSq = relative_square(strongSide, make_square(pawnsFile, Rank.RANK_8));
		  Square kingSq = pos.<PieceType.KING.getValue()>square(weakSide);

		  if (opposite_colors(queeningSq, bishopSq) && distance(queeningSq, kingSq) <= 1)
		  {
			  return ScaleFactor.SCALE_FACTOR_DRAW;
		  }
	  }

	  // If all the pawns are on the same B or G file, then it's potentially a draw
	  if ((pawnsFile == File.FILE_B || pawnsFile == File.FILE_G) && !(pos.pieces(PieceType.PAWN) & ~file_bb(pawnsFile)) && pos.non_pawn_material(weakSide) == 0 && pos.<PieceType.PAWN.getValue()>count(weakSide) >= 1)
	  {
		  // Get weakSide pawn that is closest to the home rank
		  Square weakPawnSq = backmost_sq(weakSide, pos.pieces(weakSide, PieceType.PAWN));

		  Square strongKingSq = pos.<PieceType.KING.getValue()>square(strongSide);
		  Square weakKingSq = pos.<PieceType.KING.getValue()>square(weakSide);
		  Square bishopSq = pos.<PieceType.BISHOP.getValue()>square(strongSide);

		  // There's potential for a draw if our pawn is blocked on the 7th rank,
		  // the bishop cannot attack it or they only have one pawn left
		  if (relative_rank(strongSide, weakPawnSq) == Rank.RANK_7 && (pos.pieces(strongSide, PieceType.PAWN) & (weakPawnSq + pawn_push(weakSide))) != null && (opposite_colors(bishopSq, weakPawnSq) || pos.<PieceType.PAWN.getValue()>count(strongSide) == 1))
		  {
			  int strongKingDist = distance(weakPawnSq, strongKingSq);
			  int weakKingDist = distance(weakPawnSq, weakKingSq);

			  // It's a draw if the weak king is on its back two ranks, within 2
			  // squares of the blocking pawn and the strong king is not
			  // closer. (I think this rule only fails in practically
			  // unreachable positions such as 5k1K/6p1/6P1/8/8/3B4/8/8 w
			  // and positions where qsearch will immediately correct the
			  // problem such as 8/4k1p1/6P1/1K6/3B4/8/8/8 w)
			  if (relative_rank(strongSide, weakKingSq) >= Rank.RANK_7.getValue() && weakKingDist <= 2 && weakKingDist <= strongKingDist)
			  {
				  return ScaleFactor.SCALE_FACTOR_DRAW;
			  }
		  }
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// KQ vs KR and one or more pawns. It tests for fortress draws with a rook on
	/// the third rank defended by a pawn.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KQKRPs>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KQKRPs>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.QueenValueMg, 0);
	  assert pos.<PieceType.ROOK.getValue()>count(weakSide) == 1;
	  assert pos.<PieceType.PAWN.getValue()>count(weakSide) >= 1;

	  Square kingSq = pos.<PieceType.KING.getValue()>square(weakSide);
	  Square rsq = pos.<PieceType.ROOK.getValue()>square(weakSide);

	  if (relative_rank(weakSide, kingSq) <= Rank.RANK_2.getValue() && relative_rank(weakSide, pos.<PieceType.KING.getValue()>square(strongSide)) >= Rank.RANK_4.getValue() && relative_rank(weakSide, rsq) == Rank.RANK_3 && (pos.pieces(weakSide, PieceType.PAWN) & pos.<PieceType.KING.getValue()>attacks_from(kingSq) & pos.<PieceType.PAWN.getValue()>attacks_from(rsq, strongSide)) != null)
	  {
			  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// KRP vs KR. This function knows a handful of the most important classes of
	/// drawn positions, but is far from perfect. It would probably be a good idea
	/// to add more knowledge in the future.
	///
	/// It would also be nice to rewrite the actual code for this function,
	/// which is mostly copied from Glaurung 1.x, and isn't very pretty.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KRPKR>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KRPKR>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.RookValueMg, 1);
	  assert verify_material(pos, weakSide, Value.RookValueMg, 0);

	  // Assume strongSide is white and the pawn is on files A-D
	  Square wksq = normalize(pos, strongSide, pos.<PieceType.KING.getValue()>square(strongSide));
	  Square bksq = normalize(pos, strongSide, pos.<PieceType.KING.getValue()>square(weakSide));
	  Square wrsq = normalize(pos, strongSide, pos.<PieceType.ROOK.getValue()>square(strongSide));
	  Square wpsq = normalize(pos, strongSide, pos.<PieceType.PAWN.getValue()>square(strongSide));
	  Square brsq = normalize(pos, strongSide, pos.<PieceType.ROOK.getValue()>square(weakSide));

	  File f = file_of(wpsq);
	  Rank r = rank_of(wpsq);
	  Square queeningSq = make_square(f, Rank.RANK_8);
	  int tempo = (pos.side_to_move() == strongSide);

	  // If the pawn is not too far advanced and the defending king defends the
	  // queening square, use the third-rank defence.
	  if (r.getValue() <= Rank.RANK_5.getValue() && distance(bksq, queeningSq) <= 1 && wksq.getValue() <= Square.SQ_H5.getValue() && (rank_of(brsq) == Rank.RANK_6 || (r.getValue() <= Rank.RANK_3.getValue() && rank_of(wrsq) != Rank.RANK_6)))
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  // The defending side saves a draw by checking from behind in case the pawn
	  // has advanced to the 6th rank with the king behind.
	  if (r == Rank.RANK_6 && distance(bksq, queeningSq) <= 1 && rank_of(wksq) + tempo <= Rank.RANK_6.getValue().getValue() != 0 && (rank_of(brsq) == Rank.RANK_1 || (tempo == 0 && GlobalMembers.<File>distance(brsq, wpsq) >= 3)))
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  if (r.getValue() >= Rank.RANK_6.getValue() && bksq == queeningSq && rank_of(brsq) == Rank.RANK_1 && (tempo == 0 || distance(wksq, wpsq) >= 2))
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  // White pawn on a7 and rook on a8 is a draw if black's king is on g7 or h7
	  // and the black rook is behind the pawn.
	  if (wpsq == Square.SQ_A7 && wrsq == Square.SQ_A8 && (bksq == Square.SQ_H7 || bksq == Square.SQ_G7) && file_of(brsq) == File.FILE_A && (rank_of(brsq) <= Rank.RANK_3.getValue() || file_of(wksq) >= File.FILE_D.getValue() || rank_of(wksq) <= Rank.RANK_5.getValue()))
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  // If the defending king blocks the pawn and the attacking king is too far
	  // away, it's a draw.
	  if (r.getValue() <= Rank.RANK_5.getValue() && bksq == wpsq + Direction.NORTH && distance(wksq, wpsq) - tempo >= 2 && distance(wksq, brsq) - tempo >= 2)
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  // Pawn on the 7th rank supported by the rook from behind usually wins if the
	  // attacking king is closer to the queening square than the defending king,
	  // and the defending king cannot gain tempi by threatening the attacking rook.
	  if (r == Rank.RANK_7 && f != File.FILE_A && file_of(wrsq) == f && wrsq != queeningSq && (distance(wksq, queeningSq) < distance(bksq, queeningSq) - 2 + tempo) && (distance(wksq, queeningSq) < distance(bksq, wrsq) + tempo))
	  {
		  return ScaleFactor(ScaleFactor.SCALE_FACTOR_MAX - 2 * distance(wksq, queeningSq));
	  }

	  // Similar to the above, but with the pawn further back
	  if (f != File.FILE_A && file_of(wrsq) == f && wrsq.getValue() < wpsq.getValue() && (distance(wksq, queeningSq) < distance(bksq, queeningSq) - 2 + tempo) && (distance(wksq, wpsq + Direction.NORTH) < distance(bksq, wpsq + Direction.NORTH) - 2 + tempo) && (distance(bksq, wrsq) + tempo >= 3 || (distance(wksq, queeningSq) < distance(bksq, wrsq) + tempo && (distance(wksq, wpsq + Direction.NORTH) < distance(bksq, wrsq) + tempo))))
	  {
		  return ScaleFactor(ScaleFactor.SCALE_FACTOR_MAX - 8 * distance(wpsq, queeningSq) - 2 * distance(wksq, queeningSq));
	  }

	  // If the pawn is not far advanced and the defending king is somewhere in
	  // the pawn's path, it's probably a draw.
	  if (r.getValue() <= Rank.RANK_4.getValue() && bksq.getValue() > wpsq.getValue())
	  {
		  if (file_of(bksq) == file_of(wpsq))
		  {
			  return ScaleFactor(10);
		  }
		  if (GlobalMembers.<File>distance(bksq, wpsq) == 1 && distance(wksq, bksq) > 2)
		  {
			  return ScaleFactor(24 - 2 * distance(wksq, bksq));
		  }
	  }
	  return ScaleFactor.SCALE_FACTOR_NONE;
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KRPKB>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KRPKB>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.RookValueMg, 1);
	  assert verify_material(pos, weakSide, Value.BishopValueMg, 0);

	  // Test for a rook pawn
	  if (pos.pieces(PieceType.PAWN) & (FileABB | FileHBB) != null)
	  {
		  Square ksq = pos.<PieceType.KING.getValue()>square(weakSide);
		  Square bsq = pos.<PieceType.BISHOP.getValue()>square(weakSide);
		  Square psq = pos.<PieceType.PAWN.getValue()>square(strongSide);
		  Rank rk = relative_rank(strongSide, psq);
		  Direction push = pawn_push(strongSide);

		  // If the pawn is on the 5th rank and the pawn (currently) is on
		  // the same color square as the bishop then there is a chance of
		  // a fortress. Depending on the king position give a moderate
		  // reduction or a stronger one if the defending king is near the
		  // corner but not trapped there.
		  if (rk == Rank.RANK_5 && !opposite_colors(bsq, psq))
		  {
			  int d = distance(psq + 3 * push, ksq);

			  if (d <= 2 && !(d == 0 && ksq == pos.<PieceType.KING.getValue()>square(strongSide) + 2 * push))
			  {
				  return ScaleFactor(24);
			  }
			  else
			  {
				  return ScaleFactor(48);
			  }
		  }

		  // When the pawn has moved to the 6th rank we can be fairly sure
		  // it's drawn if the bishop attacks the square in front of the
		  // pawn from a reasonable distance and the defending king is near
		  // the corner
		  if (rk == Rank.RANK_6 && distance(psq + 2 * push, ksq) <= 1 && (PseudoAttacks[PieceType.BISHOP.getValue()][bsq.getValue()] & (psq + push)) != 0 && GlobalMembers.<File>distance(bsq, psq) >= 2)
		  {
			  return ScaleFactor(8);
		  }
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}

	/// KRPP vs KRP. There is just a single rule: if the stronger side has no passed
	/// pawns and the defending king is actively placed, the position is drawish.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KRPPKRP>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KRPPKRP>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.RookValueMg, 2);
	  assert verify_material(pos, weakSide, Value.RookValueMg, 1);

	  Square wpsq1 = pos.<PieceType.PAWN.getValue()>squares(strongSide)[0];
	  Square wpsq2 = pos.<PieceType.PAWN.getValue()>squares(strongSide)[1];
	  Square bksq = pos.<PieceType.KING.getValue()>square(weakSide);

	  // Does the stronger side have a passed pawn?
	  if (pos.pawn_passed(strongSide, wpsq1) || pos.pawn_passed(strongSide, wpsq2))
	  {
		  return ScaleFactor.SCALE_FACTOR_NONE;
	  }

	  Rank r = Math.max(relative_rank(strongSide, wpsq1), relative_rank(strongSide, wpsq2));

	  if (GlobalMembers.<File>distance(bksq, wpsq1) <= 1 && GlobalMembers.<File>distance(bksq, wpsq2) <= 1 && relative_rank(strongSide, bksq) > r.getValue())
	  {
		  assert r.getValue() > Rank.RANK_1.getValue() && r.getValue() < Rank.RANK_7.getValue();
		  return ScaleFactor(KRPPKRPScaleFactors[r.getValue()]);
	  }
	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// K and two or more pawns vs K. There is just a single rule here: If all pawns
	/// are on the same rook file and are blocked by the defending king, it's a draw.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KPsK>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KPsK>.operator ()(Position pos)
	{

	  assert pos.non_pawn_material(strongSide) == Value.VALUE_ZERO;
	  assert pos.<PieceType.PAWN.getValue()>count(strongSide) >= 2;
	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 0);

	  Square ksq = pos.<PieceType.KING.getValue()>square(weakSide);
	  uint64_t pawns = pos.pieces(strongSide, PieceType.PAWN);

	  // If all pawns are ahead of the king, on a single rook file and
	  // the king is within one file of the pawns, it's a draw.
	  if ((pawns & ~forward_ranks_bb(weakSide, ksq)) == null && !((pawns & ~FileABB) && (pawns & ~FileHBB)) && GlobalMembers.<File>distance(ksq, lsb(new uint64_t(pawns))) <= 1)
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// KBP vs KB. There are two rules: if the defending king is somewhere along the
	/// path of the pawn, and the square of the king is not of the same color as the
	/// stronger side's bishop, it's a draw. If the two bishops have opposite color,
	/// it's almost always a draw.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KBPKB>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KBPKB>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.BishopValueMg, 1);
	  assert verify_material(pos, weakSide, Value.BishopValueMg, 0);

	  Square pawnSq = pos.<PieceType.PAWN.getValue()>square(strongSide);
	  Square strongBishopSq = pos.<PieceType.BISHOP.getValue()>square(strongSide);
	  Square weakBishopSq = pos.<PieceType.BISHOP.getValue()>square(weakSide);
	  Square weakKingSq = pos.<PieceType.KING.getValue()>square(weakSide);

	  // Case 1: Defending king blocks the pawn, and cannot be driven away
	  if (file_of(weakKingSq) == file_of(pawnSq) && relative_rank(strongSide, pawnSq) < relative_rank(strongSide, weakKingSq) && (opposite_colors(weakKingSq, strongBishopSq) || relative_rank(strongSide, weakKingSq) <= Rank.RANK_6.getValue()))
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  // Case 2: Opposite colored bishops
	  if (opposite_colors(strongBishopSq, weakBishopSq))
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// KBPP vs KB. It detects a few basic draws with opposite-colored bishops
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KBPPKB>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KBPPKB>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.BishopValueMg, 2);
	  assert verify_material(pos, weakSide, Value.BishopValueMg, 0);

	  Square wbsq = pos.<PieceType.BISHOP.getValue()>square(strongSide);
	  Square bbsq = pos.<PieceType.BISHOP.getValue()>square(weakSide);

	  if (!opposite_colors(wbsq, bbsq))
	  {
		  return ScaleFactor.SCALE_FACTOR_NONE;
	  }

	  Square ksq = pos.<PieceType.KING.getValue()>square(weakSide);
	  Square psq1 = pos.<PieceType.PAWN.getValue()>squares(strongSide)[0];
	  Square psq2 = pos.<PieceType.PAWN.getValue()>squares(strongSide)[1];
	  Rank r1 = rank_of(psq1);
	  Rank r2 = rank_of(psq2);
	  Square blockSq1;
	  Square blockSq2;

	  if (relative_rank(strongSide, psq1) > relative_rank(strongSide, psq2))
	  {
		  blockSq1 = psq1 + pawn_push(strongSide);
		  blockSq2 = make_square(file_of(psq2), rank_of(psq1));
	  }
	  else
	  {
		  blockSq1 = psq2 + pawn_push(strongSide);
		  blockSq2 = make_square(file_of(psq1), rank_of(psq2));
	  }

	  switch (GlobalMembers.<File>distance(psq1, psq2))
	  {
	  case 0:
		// Both pawns are on the same file. It's an easy draw if the defender firmly
		// controls some square in the frontmost pawn's path.
		if (file_of(ksq) == file_of(blockSq1) && relative_rank(strongSide, ksq) >= relative_rank(strongSide, blockSq1) && opposite_colors(ksq, wbsq))
		{
			return ScaleFactor.SCALE_FACTOR_DRAW;
		}
		else
		{
			return ScaleFactor.SCALE_FACTOR_NONE;
		}

	  case 1:
		// Pawns on adjacent files. It's a draw if the defender firmly controls the
		// square in front of the frontmost pawn's path, and the square diagonally
		// behind this square on the file of the other pawn.
		if (ksq == blockSq1 && opposite_colors(ksq, wbsq) && (bbsq == blockSq2 || (pos.<PieceType.BISHOP.getValue()>attacks_from(blockSq2) & pos.pieces(weakSide, PieceType.BISHOP)) != null || distance(r1, r2) >= 2))
		{
			return ScaleFactor.SCALE_FACTOR_DRAW;
		}

		else if (ksq == blockSq2 && opposite_colors(ksq, wbsq) && (bbsq == blockSq1 || (pos.<PieceType.BISHOP.getValue()>attacks_from(blockSq1) & pos.pieces(weakSide, PieceType.BISHOP))))
		{
			return ScaleFactor.SCALE_FACTOR_DRAW;
		}
		else
		{
			return ScaleFactor.SCALE_FACTOR_NONE;
		}

	  default:
		// The pawns are not on the same file or adjacent files. No scaling.
		return ScaleFactor.SCALE_FACTOR_NONE;
	  }
	}


	/// KBP vs KN. There is a single rule: If the defending king is somewhere along
	/// the path of the pawn, and the square of the king is not of the same color as
	/// the stronger side's bishop, it's a draw.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KBPKN>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KBPKN>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.BishopValueMg, 1);
	  assert verify_material(pos, weakSide, Value.KnightValueMg, 0);

	  Square pawnSq = pos.<PieceType.PAWN.getValue()>square(strongSide);
	  Square strongBishopSq = pos.<PieceType.BISHOP.getValue()>square(strongSide);
	  Square weakKingSq = pos.<PieceType.KING.getValue()>square(weakSide);

	  if (file_of(weakKingSq) == file_of(pawnSq) && relative_rank(strongSide, pawnSq) < relative_rank(strongSide, weakKingSq) && (opposite_colors(weakKingSq, strongBishopSq) || relative_rank(strongSide, weakKingSq) <= Rank.RANK_6.getValue()))
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// KNP vs K. There is a single rule: if the pawn is a rook pawn on the 7th rank
	/// and the defending king prevents the pawn from advancing, the position is drawn.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KNPK>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KNPK>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.KnightValueMg, 1);
	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 0);

	  // Assume strongSide is white and the pawn is on files A-D
	  Square pawnSq = normalize(pos, strongSide, pos.<PieceType.PAWN.getValue()>square(strongSide));
	  Square weakKingSq = normalize(pos, strongSide, pos.<PieceType.KING.getValue()>square(weakSide));

	  if (pawnSq == Square.SQ_A7 && distance(Square.SQ_A8, weakKingSq) <= 1)
	  {
		  return ScaleFactor.SCALE_FACTOR_DRAW;
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// KNP vs KB. If knight can block bishop from taking pawn, it's a win.
	/// Otherwise the position is drawn.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KNPKB>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KNPKB>.operator ()(Position pos)
	{

	  Square pawnSq = pos.<PieceType.PAWN.getValue()>square(strongSide);
	  Square bishopSq = pos.<PieceType.BISHOP.getValue()>square(weakSide);
	  Square weakKingSq = pos.<PieceType.KING.getValue()>square(weakSide);

	  // King needs to get close to promoting pawn to prevent knight from blocking.
	  // Rules for this are very tricky, so just approximate.
	  if (forward_file_bb(strongSide, pawnSq) & pos.<PieceType.BISHOP.getValue()>attacks_from(bishopSq) != null)
	  {
		  return ScaleFactor(distance(weakKingSq, pawnSq));
	  }

	  return ScaleFactor.SCALE_FACTOR_NONE;
	}


	/// KP vs KP. This is done by removing the weakest side's pawn and probing the
	/// KP vs K bitbase: If the weakest side has a draw without the pawn, it probably
	/// has at least a draw with the pawn as well. The exception is when the stronger
	/// side's pawn is far advanced and not on a rook file; in this case it is often
	/// possible to win (e.g. 8/4k3/3p4/3P4/6K1/8/8/8 w - - 0 1).
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ScaleFactor Endgame<KPKP>::operator ()(const Position& pos) const
	public static ScaleFactor Endgame<EndgameCode.KPKP>.operator ()(Position pos)
	{

	  assert verify_material(pos, strongSide, Value.VALUE_ZERO, 1);
	  assert verify_material(pos, weakSide, Value.VALUE_ZERO, 1);

	  // Assume strongSide is white and the pawn is on files A-D
	  Square wksq = normalize(pos, strongSide, pos.<PieceType.KING.getValue()>square(strongSide));
	  Square bksq = normalize(pos, strongSide, pos.<PieceType.KING.getValue()>square(weakSide));
	  Square psq = normalize(pos, strongSide, pos.<PieceType.PAWN.getValue()>square(strongSide));

	  Color us = strongSide == pos.side_to_move() ? Color.WHITE : Color.BLACK;

	  // If the pawn has advanced to the fifth rank or further, and is not a
	  // rook pawn, it's too dangerous to assume that it's at least a draw.
	  if (rank_of(psq) >= Rank.RANK_5.getValue() && file_of(psq) != File.FILE_A)
	  {
		  return ScaleFactor.SCALE_FACTOR_NONE;
	  }

	  // Probe the KPK bitbase with the weakest side's pawn removed. If it's a draw,
	  // it's probably at least a draw even with the pawn.
	  return Bitbases.probe(wksq, psq, bksq, us) ? ScaleFactor.SCALE_FACTOR_NONE : ScaleFactor.SCALE_FACTOR_DRAW;
	}



	  public static final uint64_t QueenSide = FileABB | FileBBB | FileCBB | FileDBB;
	  public static final uint64_t CenterFiles = FileCBB | FileDBB | FileEBB | FileFBB;
	  public static final uint64_t KingSide = FileEBB | FileFBB | FileGBB | FileHBB;
	  public static final uint64_t Center = (FileDBB | FileEBB) & (Rank4BB | Rank5BB);

	  public static final uint64_t[] KingFlank = {QueenSide ^ FileDBB, QueenSide, QueenSide, CenterFiles, CenterFiles, KingSide, KingSide, KingSide ^ FileEBB};

	  // Threshold for lazy and space evaluation
	  public static final Value LazyThreshold = 1500;
	  public static final Value SpaceThreshold = 12222;

	  // KingAttackWeights[PieceType] contains king attack weights by piece type
	  public static final int[] KingAttackWeights = {0, 0, 77, 55, 44, 10};

	  // Penalties for enemy's safe checks
	  public static final int QueenSafeCheck = 780;
	  public static final int RookSafeCheck = 880;
	  public static final int BishopSafeCheck = 435;
	  public static final int KnightSafeCheck = 790;

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define S(mg, eg) make_score(mg, eg)

	  // MobilityBonus[PieceType-2][attacked] contains bonuses for middle and end game,
	  // indexed by piece type and number of attacked squares in the mobility area.
	  public static final Score[][] MobilityBonus =
	  {
		  {make_score(-62, -81), make_score(-53, -56), make_score(-12, -30), make_score(-4, -14), make_score(3, 8), make_score(13, 15), make_score(22, 23), make_score(28, 27), make_score(33, 33), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		  {make_score(-48, -59), make_score(-20, -23), make_score(16, -3), make_score(26, 13), make_score(38, 24), make_score(51, 42), make_score(55, 54), make_score(63, 57), make_score(63, 65), make_score(68, 73), make_score(81, 78), make_score(81, 86), make_score(91, 88), make_score(98, 97), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		  {make_score(-58, -76), make_score(-27, -18), make_score(-15, 28), make_score(-10, 55), make_score(-5, 69), make_score(-2, 82), make_score(9, 112), make_score(16, 118), make_score(30, 132), make_score(29, 142), make_score(32, 155), make_score(38, 165), make_score(46, 166), make_score(48, 169), make_score(58, 171), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		  {make_score(-39, -36), make_score(-21, -15), make_score(3, 8), make_score(3, 18), make_score(14, 34), make_score(22, 54), make_score(28, 61), make_score(41, 73), make_score(43, 79), make_score(48, 92), make_score(56, 94), make_score(60, 104), make_score(60, 113), make_score(66, 120), make_score(67, 123), make_score(70, 126), make_score(71, 133), make_score(73, 136), make_score(79, 140), make_score(88, 143), make_score(88, 148), make_score(99, 166), make_score(102, 170), make_score(102, 175), make_score(106, 184), make_score(109, 191), make_score(113, 206), make_score(116, 212), null, null, null, null}
	  };

	  // Outpost[knight/bishop][supported by pawn] contains bonuses for minor
	  // pieces if they occupy or can reach an outpost square, bigger if that
	  // square is supported by a pawn.
	  public static final Score[][] Outpost =
	  {
		  {make_score(22, 6), make_score(36, 12)},
		  {make_score(9, 2), make_score(15, 5)}
	  };

	  // RookOnFile[semiopen/open] contains bonuses for each rook when there is
	  // no (friendly) pawn on the rook file.
	  public static final Score[] RookOnFile = {make_score(18, 7), make_score(44, 20)};

	  // ThreatByMinor/ByRook[attacked PieceType] contains bonuses according to
	  // which piece type attacks which one. Attacks on lesser pieces which are
	  // pawn-defended are not considered.
	  public static final Score[] ThreatByMinor = {make_score(0, 0), make_score(0, 31), make_score(39, 42), make_score(57, 44), make_score(68, 112), make_score(62, 120)};

	  public static final Score[] ThreatByRook = {make_score(0, 0), make_score(0, 24), make_score(38, 71), make_score(38, 61), make_score(0, 38), make_score(51, 38)};

	  // PassedRank[Rank] contains a bonus according to the rank of a passed pawn
	  public static final Score[] PassedRank = {make_score(0, 0), make_score(5, 18), make_score(12, 23), make_score(10, 31), make_score(57, 62), make_score(163, 167), make_score(271, 250)};

	  // PassedFile[File] contains a bonus according to the file of a passed pawn
	  public static final Score[] PassedFile = {make_score(-1, 7), make_score(0, 9), make_score(-9, -8), make_score(-30, -14), make_score(-30, -14), make_score(-9, -8), make_score(0, 9), make_score(-1, 7)};

	  // Assorted bonuses and penalties
	  public static final Score BishopPawns = make_score(3, 8);
	  public static final Score CloseEnemies = make_score(7, 0);
	  public static final Score CorneredBishop = make_score(50, 50);
	  public static final Score Hanging = make_score(62, 34);
	  public static final Score KingProtector = make_score(6, 7);
	  public static final Score KnightOnQueen = make_score(20, 12);
	  public static final Score LongDiagonalBishop = make_score(44, 0);
	  public static final Score MinorBehindPawn = make_score(16, 0);
	  public static final Score Overload = make_score(12, 6);
	  public static final Score PawnlessFlank = make_score(18, 94);
	  public static final Score RestrictedPiece = make_score(7, 6);
	  public static final Score RookOnPawn = make_score(10, 28);
	  public static final Score SliderOnQueen = make_score(49, 21);
	  public static final Score ThreatByKing = make_score(21, 84);
	  public static final Score ThreatByPawnPush = make_score(48, 42);
	  public static final Score ThreatByRank = make_score(14, 3);
	  public static final Score ThreatBySafePawn = make_score(169, 99);
	  public static final Score TrappedRook = make_score(98, 5);
	  public static final Score WeakQueen = make_score(51, 10);
	  public static final Score WeakUnopposedPawn = make_score(14, 20);

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef S

	  // Evaluation class computes and stores attacks tables and other working data
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Tracing T>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>

	public static void Main(int argc, String[] args)
	{

	  System.out.print(engine_info());
	  System.out.print("\n");

	  UCI.init(Options);
	  PSQT.init();
	  Bitboards.init();
	  Position.init();
	  Bitbases.init();
	  Search.init();
	  Pawns.init();
	  Threads.set(Options["Threads"]);
	  Search.clear(); // After threads are up

	  UCI.loop(argc, args);

	  Threads.set(0);
	}







	  // Polynomial material imbalance parameters

	  public static final int[][] QuadraticOurs =
	  {
		  {1438},
		  {40, 38},
		  {32, 255, -62},
		  {0, 104, 4, 0},
		  {-26, -2, 47, 105, -208},
		  {-189, 24, 117, 133, -134, -6}
	  };

	  public static final int[][] QuadraticTheirs =
	  {
		  {0},
		  {36, 0},
		  {9, 63, 0},
		  {59, 65, 42, 0},
		  {46, 39, 24, -24, 0},
		  {97, 100, -42, 137, 268, 0}
	  };

	  // Endgame evaluation and scaling functions are accessed directly and not through
	  // the function maps because they correspond to more than one material hash key.
	  public static Endgame<EndgameCode.KXK>[] EvaluateKXK = {Endgame<EndgameCode.KXK.getValue()>(Color.WHITE), Endgame<EndgameCode.KXK.getValue()>(Color.BLACK)};

	  public static Endgame<EndgameCode.KBPsK>[] ScaleKBPsK = {Endgame<EndgameCode.KBPsK.getValue()>(Color.WHITE), Endgame<EndgameCode.KBPsK.getValue()>(Color.BLACK)};
	  public static Endgame<EndgameCode.KQKRPs>[] ScaleKQKRPs = {Endgame<EndgameCode.KQKRPs.getValue()>(Color.WHITE), Endgame<EndgameCode.KQKRPs.getValue()>(Color.BLACK)};
	  public static Endgame<EndgameCode.KPsK>[] ScaleKPsK = {Endgame<EndgameCode.KPsK.getValue()>(Color.WHITE), Endgame<EndgameCode.KPsK.getValue()>(Color.BLACK)};
	  public static Endgame<EndgameCode.KPKP>[] ScaleKPKP = {Endgame<EndgameCode.KPKP.getValue()>(Color.WHITE), Endgame<EndgameCode.KPKP.getValue()>(Color.BLACK)};

	  // Helper used to detect a given material distribution
	  public static boolean is_KXK(Position pos, Color us)
	  {
		return !more_than_one(pos.pieces(~us)) && pos.non_pawn_material(us) >= Value.RookValueMg.getValue();
	  }

	  public static boolean is_KBPsK(Position pos, Color us)
	  {
		return pos.non_pawn_material(us) == Value.BishopValueMg && pos.<PieceType.BISHOP.getValue()>count(us) == 1 && pos.<PieceType.PAWN.getValue() >count(us) >= 1;
	  }

	  public static boolean is_KQKRPs(Position pos, Color us)
	  {
		return (pos.<PieceType.PAWN.getValue()>count(us)) == 0 && pos.non_pawn_material(us) == Value.QueenValueMg && pos.<PieceType.QUEEN.getValue()>count(us) == 1 && pos.<PieceType.ROOK.getValue()>count(~us) == 1 && pos.<PieceType.PAWN.getValue()>count(~us) >= 1;
	  }

	  /// imbalance() calculates the imbalance by comparing the piece count of each
	  /// piece type for both colors.
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color Us>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>
	  public static <Us> int imbalance(int[][] pieceCount)
	  {

		final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);

		int bonus = 0;

		// Second-degree polynomial material imbalance, by Tord Romstad
		for (int pt1 = PieceType.NO_PIECE_TYPE.getValue(); pt1 <= PieceType.QUEEN.getValue(); ++pt1)
		{
			if (pieceCount[Us][pt1] == 0)
			{
				continue;
			}

			int v = 0;

			for (int pt2 = PieceType.NO_PIECE_TYPE.getValue(); pt2 <= pt1; ++pt2)
			{
				v += QuadraticOurs[pt1][pt2] * pieceCount[Us][pt2] + QuadraticTheirs[pt1][pt2] * pieceCount[Them.getValue()][pt2];
			}

			bonus += pieceCount[Us][pt1] * v;
		}

		return bonus;
	  }

/// engine_info() returns the full name of the current Stockfish version. This
/// will be either "Stockfish <Tag> DD-MM-YY" (where DD-MM-YY is the date when
/// the program was compiled) or "Stockfish <Version>", depending on whether
/// Version is empty.

public static String engine_info()
{
	return engine_info(false);
}


	/*
	  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
	  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
	  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
	  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad
	
	  Stockfish is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	
	  Stockfish is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: const String engine_info(boolean to_uci = false)
	public static String engine_info(boolean to_uci)
	{

	  String months = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec";
	  String month;
	  String day;
	  String year;
	//C++ TO JAVA CONVERTER TODO TASK: There is no direct equivalent in Java to the following C++ macro:
	  stringstream ss = new stringstream(); // From compiler, format is "Sep 21 2008"
	  stringstream date = new stringstream(__DATE__);

	  ss << "Stockfish " << Version << setfill('0');

	  if (Version.length() == 0)
	  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  date >> month >> day >> year;
		  ss << setw(2) << day << setw(2) << (1 + months.indexOf(month) / 4) << year.substring(2);
	  }

	  ss << (Is64Bit ? " 64" : "") << (HasPext ? " BMI2" : (HasPopCnt ? " POPCNT" : "")) << (to_uci ? "\nid author ": " by ") << "T. Romstad, M. Costalba, J. Kiiski, G. Linscott";

	  return ss.str();
	}

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if NO_PREFETCH
	public static void prefetch(Object addr)
	{
	}
	///#endif

	public static void prefetch2(Object addr)
	{

	  prefetch(addr);
	  prefetch((byte)addr + 64);
	}

/// Trampoline helper to avoid moving Logger to misc.h

	public static void start_logger(String fname)
	{
		Logger.start(fname);
	}

	public static void dbg_hit_on(boolean b)
	{
		++hits[0];
		if (b)
		{
			++hits[1];
		}
	}

	public static void dbg_hit_on(boolean c, boolean b)
	{
		if (c)
		{
			dbg_hit_on(b);
		}
	}

	public static void dbg_mean_of(int v)
	{
		++means[0];
		means[1] += v;
	}

	public static void dbg_print()
	{

	  if (hits[0] != 0)
	  {
		  cerr << "Total " << hits[0] << " Hits " << hits[1] << " hit rate (%) " << 100 * hits[1] / hits[0] << "\n";
	  }

	  if (means[0] != 0)
	  {
		  cerr << "Total " << means[0] << " Mean " << (double)means[1] / means[0] << "\n";
	  }
	}


	//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'static_assert':
	//static_assert(sizeof(std::chrono::milliseconds::rep) == sizeof(int64_t), "TimePoint should be 64 bits");

	public static std::chrono.milliseconds.rep now()
	{
	  return std::chrono.<std::chrono.milliseconds>duration_cast (std::chrono.steady_clock.now().time_since_epoch()).count();
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<class Entry, int Size>

/// Used to serialize access to std::cout to avoid multiple threads writing at
/// the same time.

	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static Object operator << _m = new Object();

	private std::ostream leftShift(std::ostream os, SyncCout sc)
	{

	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//  static Object m;

	  if (sc == SyncCout.IO_LOCK)
	  {
		  operator << _m.lock();
	  }

	  if (sc == SyncCout.IO_UNLOCK)
	  {
		  operator << _m.unlock();
	  }

	  return os;
	}





	/// Version number. If Version is left empty, then compile date in the format
	/// DD-MM-YY and show in engine_info.
	public static final String Version = "10";



	/// Debug functions used mainly to collect run-time statistics
	public static long[] hits = new long[2];
	public static long[] means = new long[2];


	/// prefetch() preloads the given address in L1/L2 cache. This is a non-blocking
	/// function that doesn't stall the CPU waiting for data to be loaded from memory,
	/// which can be quite slow.

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! NO_PREFETCH

	public static void prefetch(Object addr)
	{

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if __INTEL_COMPILER
	   // This hack prevents prefetches from being optimized away by
	   // Intel compiler. Both MSVC and gcc seem not be affected by this.
	   __asm__("");
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if __INTEL_COMPILER || _MSC_VER
	  _mm_prefetch((String)addr, _MM_HINT_T0);
	///#else
	  __builtin_prefetch(addr);
	///#endif
	}

	///#endif

	private boolean lessThan(ExtMove f, ExtMove s)
	{
	  return f.value < s.value;
	}

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<GenType>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename>

/// generate<CAPTURES> generates all pseudo-legal captures and queen
/// promotions. Returns a pointer to the end of the move list.
///
/// generate<QUIETS> generates all pseudo-legal non-captures and
/// underpromotions. Returns a pointer to the end of the move list.
///
/// generate<NON_EVASIONS> generates all pseudo-legal captures and
/// non-captures. Returns a pointer to the end of the move list.

	public static <typename> ExtMove generate(Position pos, ExtMove moveList)
	{

	  assert Type == GenType.CAPTURES || Type == GenType.QUIETS || Type == GenType.NON_EVASIONS;
	  assert!pos.checkers();

	  Color us = pos.side_to_move();

	  uint64_t target = Type == GenType.CAPTURES ? pos.pieces(~us) : Type == GenType.QUIETS ?~pos.pieces() : Type == GenType.NON_EVASIONS ?~pos.pieces(us) : 0;

	  return us == Color.WHITE ? GlobalMembers.<Color.WHITE.getValue(), Type>generate_all(pos, moveList, target) : GlobalMembers.<Color.BLACK.getValue(), Type>generate_all(pos, moveList, target);
	}

	/// The MoveList struct is a simple wrapper around generate(). It sometimes comes
	/// in handy to use this class instead of the low level generate() function.
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<GenType T>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	  public static <Us, CastlingSide Cs, boolean Checks, boolean Chess960> ExtMove generate_castling(Position pos, ExtMove * moveList)
	  {

		final CastlingRight Cr = Us | Cs;
		final boolean KingSide = (Cr == CastlingRight.WHITE_OO || Cr == CastlingRight.BLACK_OO);

		if (pos.castling_impeded(Cr) || pos.can_castle(Cr) == 0)
		{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
			return new ExtMove(moveList);
		}

		// After castling, the rook and king final positions are the same in Chess960
		// as they would be in standard chess.
		Square kfrom = pos.<PieceType.KING.getValue()>square(Us);
		Square rfrom = pos.castling_rook_square(Cr);
		Square kto = relative_square(Us, KingSide ? Square.SQ_G1 : Square.SQ_C1);
		uint64_t enemies = pos.pieces(~Us);

		assert!pos.checkers();

		final Direction step = Chess960 ? kto.getValue() > kfrom.getValue() ? Direction.WEST : Direction.EAST : KingSide ? Direction.WEST : Direction.EAST;

		for (Square s = kto; s != kfrom; s += step)
		{
			if (pos.attackers_to(s) & enemies != null)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
				return new ExtMove(moveList);
			}
		}

		// Because we generate only legal castling moves we need to verify that
		// when moving the castling rook we do not discover some hidden checker.
		// For instance an enemy queen in SQ_A1 when castling rook is in SQ_B1.
		if (Chess960 && (GlobalMembers.<PieceType.ROOK.getValue()>attacks_bb(kto, pos.pieces() ^ rfrom) & pos.pieces(~Us, PieceType.ROOK, PieceType.QUEEN)) != null)
		{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
			return new ExtMove(moveList);
		}

		Move m = GlobalMembers.<MoveType.CASTLING.getValue()>make(kfrom, rfrom);

		if (Checks && !pos.gives_check(m))
		{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
			return new ExtMove(moveList);
		}

		*moveList++ = m;
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
		return new ExtMove(moveList);
	  }


	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<GenType Type, Direction D>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename Type, Direction D>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	  public static <Type, Direction D> ExtMove make_promotions(ExtMove * moveList, Square to, Square ksq)
	  {

		if (Type == GenType.CAPTURES || Type == GenType.EVASIONS || Type == GenType.NON_EVASIONS)
		{
			*moveList++ = GlobalMembers.<MoveType.PROMOTION.getValue()>make(to - D, to, PieceType.QUEEN);
		}

		if (Type == GenType.QUIETS || Type == GenType.EVASIONS || Type == GenType.NON_EVASIONS)
		{
			*moveList++ = GlobalMembers.<MoveType.PROMOTION.getValue()>make(to - D, to, PieceType.ROOK);
			*moveList++ = GlobalMembers.<MoveType.PROMOTION.getValue()>make(to - D, to, PieceType.BISHOP);
			*moveList++ = GlobalMembers.<MoveType.PROMOTION.getValue()>make(to - D, to, PieceType.KNIGHT);
		}

		// Knight promotion is the only promotion that can give a direct check
		// that's not already included in the queen promotion.
		if (Type == GenType.QUIET_CHECKS && (PseudoAttacks[PieceType.KNIGHT.getValue()][to.getValue()] & ksq) != 0)
		{
			*moveList++ = GlobalMembers.<MoveType.PROMOTION.getValue()>make(to - D, to, PieceType.KNIGHT);
		}
		else
		{
			ksq; // Silence a warning under MSVC
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
		return new ExtMove(moveList);
	  }


	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color Us, GenType Type>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename Us, GenType Type>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	  public static <Us, GenType Type> ExtMove generate_pawn_moves(Position pos, ExtMove * moveList, uint64_t target)
	  {

		// Compute our parametrized parameters at compile time, named according to
		// the point of view of white side.
		final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
		final uint64_t TRank8BB = (Us == Color.WHITE ? Rank8BB : Rank1BB);
		final uint64_t TRank7BB = (Us == Color.WHITE ? Rank7BB : Rank2BB);
		final uint64_t TRank3BB = (Us == Color.WHITE ? Rank3BB : Rank6BB);
		final Direction Up = (Us == Color.WHITE ? Direction.NORTH : Direction.SOUTH);
		final Direction UpRight = (Us == Color.WHITE ? Direction.NORTH_EAST : Direction.SOUTH_WEST);
		final Direction UpLeft = (Us == Color.WHITE ? Direction.NORTH_WEST : Direction.SOUTH_EAST);

		uint64_t emptySquares = new uint64_t();

		uint64_t pawnsOn7 = pos.pieces(Us, PieceType.PAWN) & TRank7BB;
		uint64_t pawnsNotOn7 = pos.pieces(Us, PieceType.PAWN) & ~TRank7BB;

		uint64_t enemies = (Type == GenType.EVASIONS ? pos.pieces(Them) & target: Type == GenType.CAPTURES ? target : pos.pieces(Them));

		// Single and double pawn pushes, no promotions
		if (Type != GenType.CAPTURES)
		{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: emptySquares = (Type == QUIETS || Type == QUIET_CHECKS ? target : ~pos.pieces());
			emptySquares.copyFrom((Type == GenType.QUIETS || Type == GenType.QUIET_CHECKS ? target :~pos.pieces()));

			uint64_t b1 = GlobalMembers.<Up>shift(new uint64_t(pawnsNotOn7)) & emptySquares;
			uint64_t b2 = GlobalMembers.<Up>shift(b1 & TRank3BB) & emptySquares;

			if (Type == GenType.EVASIONS) // Consider only blocking squares
			{
				b1 &= target;
				b2 &= target;
			}

			if (Type == GenType.QUIET_CHECKS)
			{
				Square ksq = pos.<PieceType.KING.getValue()>square(Them);

				b1 &= pos.<PieceType.PAWN.getValue()>attacks_from(ksq, Them);
				b2 &= pos.<PieceType.PAWN.getValue()>attacks_from(ksq, Them);

				// Add pawn pushes which give discovered check. This is possible only
				// if the pawn is not on the same file as the enemy king, because we
				// don't generate captures. Note that a possible discovery check
				// promotion has been already generated amongst the captures.
				uint64_t dcCandidates = pos.blockers_for_king(Them);
				if (pawnsNotOn7 & dcCandidates != null)
				{
					uint64_t dc1 = GlobalMembers.<Up>shift(pawnsNotOn7 & dcCandidates) & emptySquares & ~file_bb(ksq);
					uint64_t dc2 = GlobalMembers.<Up>shift(dc1 & TRank3BB) & emptySquares;

					b1 |= dc1;
					b2 |= dc2;
				}
			}

			while (b1 != null)
			{
				Square to = pop_lsb(b1);
				*moveList++ = make_move(to - Up, to);
			}

			while (b2 != null)
			{
				Square to = pop_lsb(b2);
				*moveList++ = make_move(to - Up - Up, to);
			}
		}

		// Promotions and underpromotions
		if (pawnsOn7 != null && (Type != GenType.EVASIONS || (target & TRank8BB) != null))
		{
			if (Type == GenType.CAPTURES)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: emptySquares = ~pos.pieces();
				emptySquares.copyFrom(~pos.pieces());
			}

			if (Type == GenType.EVASIONS)
			{
				emptySquares &= target;
			}

			uint64_t b1 = GlobalMembers.<UpRight>shift(new uint64_t(pawnsOn7)) & enemies;
			uint64_t b2 = GlobalMembers.<UpLeft >shift(new uint64_t(pawnsOn7)) & enemies;
			uint64_t b3 = GlobalMembers.<Up >shift(new uint64_t(pawnsOn7)) & emptySquares;

			Square ksq = pos.<PieceType.KING.getValue()>square(Them);

			while (b1 != null)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = make_promotions<Type, UpRight>(moveList, pop_lsb(&b1), ksq);
				moveList.copyFrom(GlobalMembers.<Type, UpRight>make_promotions(new ExtMove(moveList), pop_lsb(b1), ksq));
			}

			while (b2 != null)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = make_promotions<Type, UpLeft >(moveList, pop_lsb(&b2), ksq);
				moveList.copyFrom(GlobalMembers.<Type, UpLeft >make_promotions(new ExtMove(moveList), pop_lsb(b2), ksq));
			}

			while (b3 != null)
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = make_promotions<Type, Up >(moveList, pop_lsb(&b3), ksq);
				moveList.copyFrom(GlobalMembers.<Type, Up >make_promotions(new ExtMove(moveList), pop_lsb(b3), ksq));
			}
		}

		// Standard and en-passant captures
		if (Type == GenType.CAPTURES || Type == GenType.EVASIONS || Type == GenType.NON_EVASIONS)
		{
			uint64_t b1 = GlobalMembers.<UpRight>shift(new uint64_t(pawnsNotOn7)) & enemies;
			uint64_t b2 = GlobalMembers.<UpLeft >shift(new uint64_t(pawnsNotOn7)) & enemies;

			while (b1 != null)
			{
				Square to = pop_lsb(b1);
				*moveList++ = make_move(to - UpRight, to);
			}

			while (b2 != null)
			{
				Square to = pop_lsb(b2);
				*moveList++ = make_move(to - UpLeft, to);
			}

			if (pos.ep_square() != Square.SQ_NONE)
			{
				assert rank_of(pos.ep_square()) == relative_rank(Us, Rank.RANK_6);

				// An en passant capture can be an evasion only if the checking piece
				// is the double pushed pawn and so is in the target. Otherwise this
				// is a discovery check and we are forced to do otherwise.
				if (Type == GenType.EVASIONS && (target & (pos.ep_square() - Up)) == null)
				{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
					return new ExtMove(moveList);
				}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b1 = pawnsNotOn7 & pos.attacks_from<PAWN>(pos.ep_square(), Them);
				b1.copyFrom(pawnsNotOn7 & pos.<PieceType.PAWN.getValue()>attacks_from(pos.ep_square(), Them));

				assert b1;

				while (b1 != null)
				{
					*moveList++ = GlobalMembers.<MoveType.ENPASSANT.getValue()>make(pop_lsb(b1), pos.ep_square());
				}
			}
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
		return new ExtMove(moveList);
	  }


	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<PieceType Pt, bool Checks>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename Pt, boolean Checks>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	  public static <Pt, boolean Checks> ExtMove generate_moves(Position pos, ExtMove * moveList, Color us, uint64_t target)
	  {

		assert Pt != PieceType.KING && Pt != PieceType.PAWN;

//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
		Square * pl = pos.<Pt>squares(us);

		for (Square from = *pl; from != Square.SQ_NONE; from = *++pl)
		{
			if (Checks)
			{
				if ((Pt == PieceType.BISHOP || Pt == PieceType.ROOK || Pt == PieceType.QUEEN) && !(PseudoAttacks[Pt][from.getValue()] & target & pos.check_squares(Pt)))
				{
					continue;
				}

				if (pos.blockers_for_king(~us) & from != null)
				{
					continue;
				}
			}

			uint64_t b = pos.<Pt>attacks_from(from) & target;

			if (Checks)
			{
				b &= pos.check_squares(Pt);
			}

			while (b != null)
			{
				*moveList++ = make_move(from, pop_lsb(b));
			}
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
		return new ExtMove(moveList);
	  }


	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color Us, GenType Type>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<typename Us, GenType Type>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	  public static <Us, GenType Type> ExtMove generate_all(Position pos, ExtMove * moveList, uint64_t target)
	  {

		final boolean Checks = Type == GenType.QUIET_CHECKS;

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = generate_pawn_moves<Us, Type>(pos, moveList, target);
		moveList.copyFrom(GlobalMembers.<Us, Type>generate_pawn_moves(pos, new ExtMove(moveList), new uint64_t(target)));
		moveList.copyFrom(GlobalMembers.<PieceType.KNIGHT.getValue(), Checks>generate_moves(pos, moveList, Us, target));
		moveList.copyFrom(GlobalMembers.<PieceType.BISHOP.getValue(), Checks>generate_moves(pos, moveList, Us, target));
		moveList.copyFrom(GlobalMembers.< PieceType.ROOK.getValue(), Checks>generate_moves(pos, moveList, Us, target));
		moveList.copyFrom(GlobalMembers.< PieceType.QUEEN.getValue(), Checks>generate_moves(pos, moveList, Us, target));

		if (Type != GenType.QUIET_CHECKS && Type != GenType.EVASIONS)
		{
			Square ksq = pos.<PieceType.KING.getValue()>square(Us);
			uint64_t b = pos.<PieceType.KING.getValue()>attacks_from(ksq) & target;
			while (b != null)
			{
				*moveList++ = make_move(ksq, pop_lsb(b));
			}
		}

		if (Type != GenType.CAPTURES && Type != GenType.EVASIONS && pos.can_castle(Us) != 0)
		{
			if (pos.is_chess960())
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = generate_castling<Us, KING_SIDE, Checks, true>(pos, moveList);
				moveList.copyFrom(GlobalMembers.<Us, CastlingSide.KING_SIDE, Checks, true>generate_castling(pos, new ExtMove(moveList)));
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = generate_castling<Us, QUEEN_SIDE, Checks, true>(pos, moveList);
				moveList.copyFrom(GlobalMembers.<Us, CastlingSide.QUEEN_SIDE, Checks, true>generate_castling(pos, new ExtMove(moveList)));
			}
			else
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = generate_castling<Us, KING_SIDE, Checks, false>(pos, moveList);
				moveList.copyFrom(GlobalMembers.<Us, CastlingSide.KING_SIDE, Checks, false>generate_castling(pos, new ExtMove(moveList)));
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: moveList = generate_castling<Us, QUEEN_SIDE, Checks, false>(pos, moveList);
				moveList.copyFrom(GlobalMembers.<Us, CastlingSide.QUEEN_SIDE, Checks, false>generate_castling(pos, new ExtMove(moveList)));
			}
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
		return new ExtMove(moveList);
	  }

/// generate<QUIET_CHECKS> generates all pseudo-legal non-captures and knight
/// underpromotions that give check. Returns a pointer to the end of the move list.


	// Explicit template instantiations
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: ExtMove* generate<QUIET_CHECKS>(const Position& pos, ExtMove* moveList)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	public static ExtMove generate(Position pos, ExtMove * moveList)
	{

	  assert!pos.checkers();

	  Color us = pos.side_to_move();
	  uint64_t dc = pos.blockers_for_king(~us) & pos.pieces(us);

	  while (dc != null)
	  {
		 Square from = pop_lsb(dc);
		 PieceType pt = type_of(pos.piece_on(from));

		 if (pt == PieceType.PAWN)
		 {
			 continue; // Will be generated together with direct checks
		 }

		 uint64_t b = pos.attacks_from(pt, from) & ~pos.pieces();

		 if (pt == PieceType.KING)
		 {
			 b &= ~PseudoAttacks[PieceType.QUEEN.getValue()][pos.<PieceType.KING.getValue().getValue()>square(~us)];
		 }

		 while (b != null)
		 {
			 *moveList++ = make_move(from, pop_lsb(b));
		 }
	  }

	  return us == Color.WHITE ? GlobalMembers.<Color.WHITE.getValue(), GenType.QUIET_CHECKS.getValue()>generate_all(pos, moveList, ~pos.pieces()) : GlobalMembers.<Color.BLACK.getValue(), GenType.QUIET_CHECKS.getValue()>generate_all(pos, moveList, ~pos.pieces());
	}

/// generate<EVASIONS> generates all pseudo-legal check evasions when the side
/// to move is in check. Returns a pointer to the end of the move list.

//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: ExtMove* generate<EVASIONS>(const Position& pos, ExtMove* moveList)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	public static ExtMove generate(Position pos, ExtMove * moveList)
	{

	  assert pos.checkers();

	  Color us = pos.side_to_move();
	  Square ksq = pos.<PieceType.KING.getValue()>square(us);
	  uint64_t sliderAttacks = 0;
	  uint64_t sliders = pos.checkers() & ~pos.pieces(PieceType.KNIGHT, PieceType.PAWN);

	  // Find all the squares attacked by slider checkers. We will remove them from
	  // the king evasions in order to skip known illegal moves, which avoids any
	  // useless legality checks later on.
	  while (sliders != null)
	  {
		  Square checksq = pop_lsb(sliders);
		  sliderAttacks |= LineBB[checksq.getValue()][ksq.getValue()] ^ checksq;
	  }

	  // Generate evasions for king, capture and non capture moves
	  uint64_t b = pos.<PieceType.KING.getValue()>attacks_from(ksq) & ~pos.pieces(us) & ~sliderAttacks;
	  while (b != null)
	  {
		  *moveList++ = make_move(ksq, pop_lsb(b));
	  }

	  if (more_than_one(pos.checkers()))
	  {
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
		  return new ExtMove(moveList); // Double check, only a king move can save the day
	  }

	  // Generate blocking evasions or captures of the checking piece
	  Square checksq = lsb(pos.checkers());
	  uint64_t target = between_bb(checksq, ksq) | checksq;

	  return us == Color.WHITE ? GlobalMembers.<Color.WHITE.getValue(), GenType.EVASIONS.getValue()>generate_all(pos, moveList, target) : GlobalMembers.<Color.BLACK.getValue(), GenType.EVASIONS.getValue()>generate_all(pos, moveList, target);
	}

/// generate<LEGAL> generates all the legal moves in the given position


//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: ExtMove* generate<LEGAL>(const Position& pos, ExtMove* moveList)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'moveList', so pointers on this parameter are left unchanged:
	public static ExtMove generate(Position pos, ExtMove * moveList)
	{

	  Color us = pos.side_to_move();
	  uint64_t pinned = pos.blockers_for_king(us) & pos.pieces(us);
	  Square ksq = pos.<PieceType.KING.getValue()>square(us);
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: ExtMove* cur = moveList;
	  ExtMove * cur = new ExtMove(moveList);

	  moveList.copyFrom(pos.checkers() != null ? GlobalMembers.<GenType.EVASIONS.getValue() >generate(pos, moveList) : GlobalMembers.<GenType.NON_EVASIONS.getValue()>generate(pos, moveList));
	  while (cur != moveList)
	  {
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: if ((pinned || from_sq(*cur) == ksq || type_of(*cur) == ENPASSANT) && !pos.legal(*cur))
		  if ((pinned || from_sq(cur) == ksq || type_of(new ExtMove(cur)) == MoveType.ENPASSANT) && !pos.legal(cur))
		  {
			  *cur = (--moveList).move;
		  }
		  else
		  {
			  ++cur;
		  }
	  }

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return moveList;
	  return new ExtMove(moveList);
	}




	/// ButterflyHistory records how often quiet moves have been successful or
	/// unsuccessful during the current search, and is used for reduction and move
	/// ordering decisions. It uses 2 tables (one for each color) indexed by
	/// the move's from and to squares, see chessprogramming.wikispaces.com/Butterfly+Boards
	public static typedef Stats<int16_t, 10692, Color.COLOR_NB, int(Square.SQUARE_NB) * int(Square.SQUARE_NB)> ButterflyHistory = new typedef();

	  // Helper filter used with select()
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
  public static final auto Any = () ->
  {
	  return true;
  };

	  // partial_insertion_sort() sorts moves in descending order up to and including
	  // a given limit. The order of moves smaller than the limit is left unspecified.
	  public static void partial_insertion_sort(ExtMove begin, ExtMove end, int limit)
	  {

		for (ExtMove * sortedEnd = begin, *p = begin + 1; p < end; ++p)
		{
			if (p.value >= limit)
			{
				ExtMove tmp = *p;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
				ExtMove * q = new ExtMove();
				*p = *++sortedEnd;
				for (q = sortedEnd; q != begin && (q - 1) < tmp; --q)
				{
					*q = *(q - 1);
				}
				*q = tmp;
			}
		}
	  }







	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define V Value
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define S(mg, eg) make_score(mg, eg)

	  // Pawn penalties
	  public static final Score Backward = make_score(9, 24);
	  public static final Score Doubled = make_score(11, 56);
	  public static final Score Isolated = make_score(5, 15);

	  // Connected pawn bonus by opposed, phalanx, #support and rank
	  public static Score[][][][] Connected = new Score[2][2][3][Rank.RANK_NB.getValue()];

	  // Strength of pawn shelter for our king by [distance from edge][rank].
	  // RANK_1 = 0 is used for files where we have no pawn, or pawn is behind our king.
//C++ TO JAVA CONVERTER TODO TASK: The following statement was not recognized, possibly due to an unrecognized macro:
	  constexpr Value ShelterStrength[int(FILE_NB) / 2][RANK_NB] =
	  {
		  {Value(-6), Value(81), Value(93), Value(58), Value(39), Value(18), Value(25)},
		  {Value(-43), Value(61), Value(35), Value(-49), Value(-29), Value(-11), Value(-63)},
		  {Value(-10), Value(75), Value(23), Value(-2), Value(32), Value(3), Value(-45)},
		  {Value(-39), Value(-13), Value(-29), Value(-52), Value(-48), Value(-67), Value(-166)}
	  };

	  // Danger of enemy pawns moving toward our king by [distance from edge][rank].
	  // RANK_1 = 0 is used for files where the enemy has no pawn, or their pawn
	  // is behind our king.
//C++ TO JAVA CONVERTER TODO TASK: The following statement was not recognized, possibly due to an unrecognized macro:
	  constexpr Value UnblockedStorm[int(FILE_NB) / 2][RANK_NB] =
	  {
		  {Value(89), Value(107), Value(123), Value(93), Value(57), Value(45), Value(51)},
		  {Value(44), Value(-18), Value(123), Value(46), Value(39), Value(-7), Value(23)},
		  {Value(4), Value(52), Value(162), Value(37), Value(7), Value(-14), Value(-2)},
		  {Value(-10), Value(-14), Value(90), Value(15), Value(2), Value(-7), Value(-16)}
	  };

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	  ///#undef S
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	  ///#undef V

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color Us>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'e', so pointers on this parameter are left unchanged:
	  public static <Us> Score evaluate(Position pos, Pawns.Entry * e)
	  {

		final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
		final Direction Up = (Us == Color.WHITE ? Direction.NORTH : Direction.SOUTH);

		long b;
		long neighbours;
		long stoppers;
		long doubled;
		long supported;
		long phalanx;
		long lever;
		long leverPush;
		Square s;
		boolean opposed;
		boolean backward;
		Score score = Score.SCORE_ZERO;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
		Square * pl = pos.<PieceType.PAWN.getValue()>squares(Us);

		long ourPawns = pos.pieces(Us, PieceType.PAWN);
		long theirPawns = pos.pieces(Them, PieceType.PAWN);

		e.passedPawns[Us] = e.pawnAttacksSpan[Us] = (long)e.weakUnopposed[Us] = 0;
		e.semiopenFiles[Us] = 0xFF;
		e.kingSquares[Us] = Square.SQ_NONE;
		e.pawnAttacks[Us] = GlobalMembers.<Us>pawn_attacks_bb(ourPawns);
		e.pawnsOnSquares[Us][Color.BLACK.getValue()] = popcount(ourPawns & DarkSquares);
		e.pawnsOnSquares[Us][Color.WHITE.getValue()] = pos.<PieceType.PAWN.getValue()>count(Us) - e.pawnsOnSquares[Us][Color.BLACK.getValue()];

		// Loop through all pawns of the current color and score each pawn
		while ((s = *pl++) != Square.SQ_NONE)
		{
			assert pos.piece_on(s) == make_piece(Us, PieceType.PAWN);

			File f = file_of(s);

			e.semiopenFiles[Us] &= ~(1 << f.getValue());
			e.pawnAttacksSpan[Us] |= pawn_attack_span(Us, s);

			// Flag the pawn
			opposed = (theirPawns & forward_file_bb(Us, s)) != 0;
			stoppers = theirPawns & passed_pawn_mask(Us, s);
			lever = (long)(theirPawns & PawnAttacks[Us][s.getValue()]);
			leverPush = (long)(theirPawns & PawnAttacks[Us][s.getValue() + Up]);
			doubled = (long)(ourPawns & (s - Up));
			neighbours = ourPawns & adjacent_files_bb(f);
			phalanx = neighbours & rank_bb(s);
			supported = neighbours & rank_bb(s - Up);

			// A pawn is backward when it is behind all pawns of the same color
			// on the adjacent files and cannot be safely advanced.
			backward = (ourPawns & pawn_attack_span(Them, s + Up)) == 0 && (stoppers & (leverPush | (s + Up))) != 0;

			// Passed pawns will be properly scored in evaluation because we need
			// full attack info to evaluate them. Include also not passed pawns
			// which could become passed after one or two pawn pushes when are
			// not attacked more times than defended.
			if ((stoppers ^ lever ^ leverPush) == 0 && popcount(supported) >= popcount(lever) - 1 && popcount(phalanx) >= popcount(leverPush))
			{
				e.passedPawns[Us] |= s;
			}

			else if (stoppers == SquareBB[s.getValue() + Up] && relative_rank(Us, s) >= Rank.RANK_5.getValue())
			{
				b = (long)(GlobalMembers.<Up>shift(supported) &)~theirPawns;
				while (b != 0)
				{
				tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
					if (!more_than_one((long)(theirPawns & PawnAttacks[Us][pop_lsb(tempRef_b).getValue()])))
					{
						b = tempRef_b.argValue;
						e.passedPawns[Us] |= s;
					}
					else
					{
						b = tempRef_b.argValue;
					}
				}
			}

			// Score this pawn
			if ((supported | phalanx) != 0)
			{
				score += Connected[opposed][(boolean)phalanx][popcount(supported)][relative_rank(Us, s).getValue()];
			}

			else if (!neighbours)
			{
				score -= Isolated, e.weakUnopposed[Us] += !opposed;
			}

			else if (backward)
			{
				score -= Backward, e.weakUnopposed[Us] += !opposed;
			}

			if (doubled != 0 && supported == 0)
			{
				score -= Doubled;
			}
		}

		return score;
	  }

/// operator<<(Position) returns an ASCII representation of the position


	private std::ostream leftShift(std::ostream os, Position pos)
	{

	  os << "\n +---+---+---+---+---+---+---+---+\n";

	  for (Rank r = Rank.RANK_8; r.getValue() >= Rank.RANK_1.getValue(); --r)
	  {
		  for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); ++f)
		  {
			  os << " | " << PieceToChar[pos.piece_on(make_square(f, r)).getValue()];
		  }

		  os << " |\n +---+---+---+---+---+---+---+---+\n";
	  }

	  os << "\nFen: " << pos.fen() << "\nKey: " << std::hex << std::uppercase << std::setfill('0') << std::setw(16) << pos.key() << std::setfill(' ') << std::dec << "\nCheckers: ";

	  for (long b = pos.checkers(); b;)
	  {
	  tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
		  os << UCI.square(pop_lsb(tempRef_b)) << " ";
		  b = tempRef_b.argValue;
	  }

	  if ((int)Tablebases.MaxCardinality >= popcount(pos.pieces()) && pos.can_castle(CastlingRight.ANY_CASTLING) == 0)
	  {
		  StateInfo st = new StateInfo();
		  Position p = new Position();
		  p.set(pos.fen(), pos.is_chess960(), st, pos.this_thread());
		  Tablebases.ProbeState s1;
		  Tablebases.ProbeState s2;
		  Tablebases.WDLScore wdl = Tablebases.probe_wdl(p, s1);
		  int dtz = Tablebases.probe_dtz(p, s2);
		  os << "\nTablebases WDL: " << std::setw(4) << wdl.getValue() << " (" << s1.getValue() << ")" << "\nTablebases DTZ: " << std::setw(4) << dtz << " (" << s2.getValue() << ")";
	  }

	  return os;
	}

	public static final Piece[] Pieces = {Piece.W_PAWN, Piece.W_KNIGHT, Piece.W_BISHOP, Piece.W_ROOK, Piece.W_QUEEN, Piece.W_KING, Piece.B_PAWN, Piece.B_KNIGHT, Piece.B_BISHOP, Piece.B_ROOK, Piece.B_QUEEN, Piece.B_KING};

	// min_attacker() is a helper function used by see_ge() to locate the least
	// valuable attacker for the side to move, remove the attacker we just found
	// from the bitboards and scan for new X-ray attacks behind it.

//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<int Pt>
	public static <int Pt> PieceType min_attacker(long[] byTypeBB, Square to, long stmAttackers, tangible.RefObject<Long> occupied, tangible.RefObject<Long> attackers)
	{

	  long b = (long)(stmAttackers & byTypeBB[Pt]);
	  if (b == 0)
	  {
		  return min_attacker < Pt + 1>(byTypeBB, to, stmAttackers, occupied.argValue, attackers.argValue);
	  }

	  occupied.argValue ^= lsb(b); // Remove the attacker from occupied

	  // Add any X-ray attack behind the just removed piece. For instance with
	  // rooks in a8 and a7 attacking a1, after removing a7 we add rook in a8.
	  // Note that new added attackers can be of any color.
	  if (Pt == PieceType.PAWN || Pt == PieceType.BISHOP || Pt == PieceType.QUEEN)
	  {
		  attackers.argValue |= GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(to, occupied.argValue) & (byTypeBB[PieceType.BISHOP.getValue()] | byTypeBB[PieceType.QUEEN.getValue()]);
	  }

	  if (Pt == PieceType.ROOK || Pt == PieceType.QUEEN)
	  {
		  attackers.argValue |= GlobalMembers.<PieceType.ROOK.getValue()>attacks_bb(to, occupied.argValue) & (byTypeBB[PieceType.ROOK.getValue()] | byTypeBB[PieceType.QUEEN.getValue()]);
	  }

	  // X-ray may add already processed pieces because byTypeBB[] is constant: in
	  // the rook example, now attackers contains _again_ rook in a7, so remove it.
	  attackers.argValue &= occupied.argValue;
	  return PieceType.forValue(Pt);
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: PieceType min_attacker<KING>(const ulong*, Square, ulong, ulong&, ulong&)
	public static PieceType min_attacker(long UnnamedParameter, Square UnnamedParameter2, long UnnamedParameter3, tangible.RefObject<Long> UnnamedParameter4, tangible.RefObject<Long> UnnamedParameter5)
	{
	  return PieceType.KING; // No need to update bitboards: it is the last cycle
	}



	// Marcel van Kervinck's cuckoo algorithm for fast detection of "upcoming repetition"
	// situations. Description of the algorithm in the following paper:
	// https://marcelk.net/2013-04-06/paper/upcoming-rep-v2.pdf

	// First and second hash functions for indexing the cuckoo tables
	public static int H1(long h)
	{
		return (int)(h & 0x1fff);
	}
	public static int H2(long h)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		return (h >>> 16) & 0x1fff;
	}

	// Cuckoo tables with Zobrist hashes of valid reversible moves, and the moves themselves
	public static long[] cuckoo = new long[8192];
	public static Move[] cuckooMove = new Move[8192];

	/*
	  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
	  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
	  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
	  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad
	
	  Stockfish is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	
	  Stockfish is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	public static Value[][] PieceValue =
	{
		{Value.VALUE_ZERO, Value.PawnValueMg, Value.KnightValueMg, Value.BishopValueMg, Value.RookValueMg, Value.QueenValueMg},
		{Value.VALUE_ZERO, Value.PawnValueEg, Value.KnightValueEg, Value.BishopValueEg, Value.RookValueEg, Value.QueenValueEg}
	};

	  // Sizes and phases of the skip-blocks, used for distributing search depths across the threads
	  public static final int[] SkipSize = {1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4};
	  public static final int[] SkipPhase = {0, 1, 0, 1, 2, 3, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 6, 7};

	  // Razor and futility margins
	  public static final int RazorMargin = 600;
	  public static Value futility_margin(Depth d, boolean improving)
	  {
		return Value((175 - 50 * improving) * d / Depth.ONE_PLY);
	  }

	  // Futility and reductions lookup tables, initialized at startup
	  public static int[][] FutilityMoveCounts = new int[2][16]; // [improving][depth]
	  public static int[][][][] Reductions = new int[2][2][64][64]; // [pv][improving][depth][moveNumber]

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template <bool PvNode> Depth reduction(bool i, Depth d, int mn) {
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template <typename PvNode>
	  public static <PvNode> Depth reduction(boolean i, Depth d, int mn)
	  {
		return Reductions[PvNode][i][Math.min(d / Depth.ONE_PLY, 63)][Math.min(mn, 63)] * Depth.ONE_PLY.getValue();
	  }

	  // History and stats update bonus, based on depth
	  public static int stat_bonus(Depth depth)
	  {
		int d = depth.getValue() / Depth.ONE_PLY.getValue();
		return d > 17 ? 0 : 29 * d * d + 138 * d - 134;
	  }

	  // Add a small random component to draw evaluations to keep search dynamic
	  // and to avoid 3fold-blindness.
	  public static Value value_draw(Depth depth, Thread thisThread)
	  {
		return depth.getValue() < 4 ? Value.VALUE_DRAW : Value.VALUE_DRAW + Value(2 * (thisThread.nodes.load(std::memory_order_relaxed) % 2) - 1);
	  }

  // search<>() is the main search function for both PV and non-PV nodes

	  public static <NT> Value search(Position pos, Stack ss, Value alpha, Value beta, Depth depth, boolean cutNode)
	  {

		final boolean PvNode = NT == NodeType.PV;
		final boolean rootNode = PvNode && ss.ply == 0;

		// Check if we have an upcoming move which draws by repetition, or
		// if the opponent had an alternative move earlier to this position.
		if (pos.rule50_count() >= 3 && alpha.getValue() < Value.VALUE_DRAW.getValue() && !rootNode && pos.has_game_cycle(ss.ply))
		{
			alpha = value_draw(depth, pos.this_thread());
			if (alpha.getValue() >= beta.getValue())
			{
				return alpha;
			}
		}

		// Dive into quiescence search when the depth reaches zero
		if (depth.getValue() < Depth.ONE_PLY.getValue())
		{
			return GlobalMembers.<NT>qsearch(pos, ss, alpha, beta);
		}

		assert - Value.VALUE_INFINITE.getValue() <= alpha.getValue() && alpha.getValue() < beta.getValue() && beta.getValue() <= Value.VALUE_INFINITE.getValue();
		assert PvNode || (alpha == beta - 1);
		assert Depth.DEPTH_ZERO.getValue() < depth.getValue() && depth.getValue() < Depth.DEPTH_MAX.getValue();
		assert!(PvNode && cutNode);
		assert depth / Depth.ONE_PLY * Depth.ONE_PLY == depth;

		Move[] pv = new Move[MAX_PLY + 1];
		Move[] capturesSearched = new Move[32];
		Move[] quietsSearched = new Move[64];
		StateInfo st = new StateInfo();
		TTEntry tte;
		long posKey;
		Move ttMove;
		Move move;
		Move excludedMove;
		Move bestMove;
		Depth extension;
		Depth newDepth;
		Value bestValue;
		Value value;
		Value ttValue;
		Value eval;
		Value maxValue;
		Value pureStaticEval;
		boolean ttHit;
		boolean inCheck;
		boolean givesCheck;
		boolean improving;
		boolean captureOrPromotion;
		boolean doFullDepthSearch;
		boolean moveCountPruning;
		boolean skipQuiets;
		boolean ttCapture;
		boolean pvExact;
		Piece movedPiece;
		int moveCount;
		int captureCount;
		int quietCount;

		// Step 1. Initialize node
		Thread thisThread = pos.this_thread();
		inCheck = pos.checkers() != 0;
		Color us = pos.side_to_move();
		moveCount = captureCount = quietCount = ss.moveCount = 0;
		bestValue = -Value.VALUE_INFINITE;
		maxValue = Value.VALUE_INFINITE;

		// Check for the available remaining time
		if (thisThread == Threads.main())
		{
			((MainThread)thisThread).check_time();
		}

		// Used to send selDepth info to GUI (selDepth counts from 1, ply from 0)
		if (PvNode && thisThread.selDepth < ss.ply + 1)
		{
			thisThread.selDepth = ss.ply + 1;
		}

		if (!rootNode)
		{
			// Step 2. Check for aborted search and immediate draw
			if (Threads.stop.load(std::memory_order_relaxed) || pos.is_draw(ss.ply) || ss.ply >= MAX_PLY)
			{
				return (ss.ply >= MAX_PLY && !inCheck) ? evaluate(pos) : value_draw(depth, pos.this_thread());
			}

			// Step 3. Mate distance pruning. Even if we mate at the next move our score
			// would be at best mate_in(ss->ply+1), but if alpha is already bigger because
			// a shorter mate was found upward in the tree then there is no need to search
			// because we will never beat the current alpha. Same logic but with reversed
			// signs applies also in the opposite condition of being mated instead of giving
			// mate. In this case return a fail-high score.
			alpha = Math.max(mated_in(ss.ply), alpha);
			beta = Math.min(mate_in(ss.ply + 1), beta);
			if (alpha.getValue() >= beta.getValue())
			{
				return alpha;
			}
		}

		assert 0 <= ss.ply && ss.ply < MAX_PLY;

		(ss + 1).ply = ss.ply + 1;
		ss.currentMove = (ss + 1).excludedMove = bestMove = Move.MOVE_NONE;
		ss.continuationHistory = thisThread.continuationHistory[Piece.NO_PIECE.getValue()][0];
		(ss + 2).killers[0] = (ss + 2).killers[1] = Move.MOVE_NONE;
		Square prevSq = to_sq((ss - 1).currentMove);

		// Initialize statScore to zero for the grandchildren of the current position.
		// So statScore is shared between all grandchildren and only the first grandchild
		// starts with statScore = 0. Later grandchildren start with the last calculated
		// statScore of the previous grandchild. This influences the reduction rules in
		// LMR which are based on the statScore of parent position.
		(ss + 2).statScore = 0;

		// Step 4. Transposition table lookup. We don't want the score of a partial
		// search to overwrite a previous full search TT value, so we use a different
		// position key in case of an excluded move.
		excludedMove = ss.excludedMove;
		posKey = (long)(pos.key() ^ Key(excludedMove.getValue() << 16)); // Isn't a very good hash
		tte = TT.probe(posKey, ttHit);
		ttValue = ttHit ? value_from_tt(tte.value(), ss.ply) : Value.VALUE_NONE;
		ttMove = rootNode ? thisThread.rootMoves.get(thisThread.pvIdx).pv.get(0) : ttHit ? tte.move() : Move.MOVE_NONE;

		// At non-PV nodes we check for an early TT cutoff
		if (!PvNode && ttHit && tte.depth() >= depth.getValue() && ttValue != Value.VALUE_NONE && (ttValue.getValue() >= beta.getValue() ? (tte.bound() & Bound.BOUND_LOWER) : (tte.bound() & Bound.BOUND_UPPER)).getValue() != 0)
		{
			// If ttMove is quiet, update move sorting heuristics on TT hit
			if (ttMove.getValue() != 0)
			{
				if (ttValue.getValue() >= beta.getValue())
				{
					if (!pos.capture_or_promotion(ttMove))
					{
						update_quiet_stats(pos, ss, ttMove, null, 0, stat_bonus(depth));
					}

					// Extra penalty for a quiet TT move in previous ply when it gets refuted
					if ((ss - 1).moveCount == 1 && pos.captured_piece().getValue() == 0)
					{
						update_continuation_histories(ss - 1, pos.piece_on(prevSq), prevSq, -stat_bonus(depth + Depth.ONE_PLY));
					}
				}
				// Penalty for a quiet ttMove that fails low
				else if (!pos.capture_or_promotion(ttMove))
				{
					int penalty = -stat_bonus(depth);
					thisThread.mainHistory[us.getValue()][from_to(ttMove)] << penalty;
					update_continuation_histories(ss, pos.moved_piece(ttMove), to_sq(ttMove), penalty);
				}
			}
			return ttValue;
		}

		// Step 5. Tablebases probe
		if (!rootNode && TB.Cardinality)
		{
			int piecesCount = pos.<PieceType.ALL_PIECES.getValue()>count();

			if (piecesCount <= TB.Cardinality && (piecesCount < TB.Cardinality || depth.getValue() >= TB.ProbeDepth) && pos.rule50_count() == 0 && !pos.can_castle(CastlingRight.ANY_CASTLING))
			{
				TB.ProbeState err = new TB.ProbeState();
				TB.WDLScore wdl = Tablebases.probe_wdl(pos, err);

				// Force check of time on the next occasion
				if (thisThread == Threads.main())
				{
					((MainThread)thisThread).callsCnt = 0;
				}

				if (err != TB.ProbeState.FAIL)
				{
					thisThread.tbHits.fetch_add(1, std::memory_order_relaxed);

					int drawScore = TB.UseRule50 ? 1 : 0;

					value = wdl < (-drawScore) != 0 ? -Value.VALUE_MATE + MAX_PLY + ss.ply + 1 : wdl > drawScore ? Value.VALUE_MATE - MAX_PLY - ss.ply - 1 : Value.VALUE_DRAW + 2 * wdl * drawScore;

					Bound b = wdl < (-drawScore) != 0 ? Bound.BOUND_UPPER : wdl > drawScore ? Bound.BOUND_LOWER : Bound.BOUND_EXACT;

					if (b == Bound.BOUND_EXACT || (b == Bound.BOUND_LOWER ? value.getValue() >= beta.getValue() : value.getValue() <= alpha.getValue()))
					{
						tte.save(posKey, value_to_tt(value, ss.ply), b, Math.min(Depth.DEPTH_MAX - Depth.ONE_PLY, depth + 6 * Depth.ONE_PLY), Move.MOVE_NONE, Value.VALUE_NONE);

						return value;
					}

					if (PvNode)
					{
						if (b == Bound.BOUND_LOWER)
						{
							bestValue = value, alpha = Math.max(alpha, bestValue);
						}
						else
						{
							maxValue = value;
						}
					}
				}
			}
		}

		// Step 6. Static evaluation of the position
		if (inCheck)
		{
			ss.staticEval = eval = pureStaticEval = Value.VALUE_NONE;
			improving = false;
//C++ TO JAVA CONVERTER TODO TASK: There are no gotos or labels in Java:
			goto moves_loop; // Skip early pruning when in check
		}
		else if (ttHit)
		{
			// Never assume anything on values stored in TT
			ss.staticEval = eval = pureStaticEval = tte.eval();
			if (eval == Value.VALUE_NONE)
			{
				ss.staticEval = eval = pureStaticEval = evaluate(pos);
			}

			// Can ttValue be used as a better position evaluation?
			if (ttValue != Value.VALUE_NONE && (tte.bound() & (ttValue.getValue() > eval.getValue() ? Bound.BOUND_LOWER : Bound.BOUND_UPPER)).getValue() != 0)
			{
				eval = ttValue;
			}
		}
		else
		{
			if ((ss - 1).currentMove != Move.MOVE_NULL)
			{
				int p = (ss - 1).statScore;
				int bonus = p > 0 ? (-p - 2500) / 512 : p < 0 ? (-p + 2500) / 512 : 0;

				pureStaticEval = evaluate(pos);
				ss.staticEval = eval = pureStaticEval + bonus;
			}
			else
			{
				ss.staticEval = eval = pureStaticEval = -(ss - 1).staticEval + 2 * Eval.GlobalMembers.Tempo;
			}

			tte.save(posKey, Value.VALUE_NONE, Bound.BOUND_NONE, Depth.DEPTH_NONE, Move.MOVE_NONE, pureStaticEval);
		}

		// Step 7. Razoring (~2 Elo)
		if (depth.getValue() < 2 * Depth.ONE_PLY && eval.getValue() <= alpha.getValue() - RazorMargin)
		{
			return GlobalMembers.<NT>qsearch(pos, ss, alpha, beta);
		}

		improving = ss.staticEval.getValue() >= (ss - 2).staticEval.getValue() || (ss - 2).staticEval == Value.VALUE_NONE;

		// Step 8. Futility pruning: child node (~30 Elo)
		if (!rootNode && depth.getValue() < 7 * Depth.ONE_PLY && eval - futility_margin(depth, improving) >= beta.getValue().getValue() != 0 && eval.getValue() < Value.VALUE_KNOWN_WIN.getValue()) // Do not return unproven wins
		{
			return eval;
		}

		// Step 9. Null move search with verification search (~40 Elo)
		if (!PvNode && (ss - 1).currentMove != Move.MOVE_NULL && (ss - 1).statScore < 23200 && eval.getValue() >= beta.getValue() && pureStaticEval.getValue() >= beta.getValue() - 36 * depth / Depth.ONE_PLY + 225 && excludedMove.getValue() == 0 && pos.non_pawn_material(us).getValue() != 0 && (ss.ply >= thisThread.nmpMinPly || us != thisThread.nmpColor))
		{
			assert eval - beta.getValue() >= 0;

			// Null move dynamic reduction based on depth and value
			Depth R = ((823 + 67 * depth / Depth.ONE_PLY) / 256 + Math.min((int)(eval - beta) / 200, 3)) * Depth.ONE_PLY;

			ss.currentMove = Move.MOVE_NULL;
			ss.continuationHistory = thisThread.continuationHistory[Piece.NO_PIECE.getValue()][0];

			pos.do_null_move(st);

			Value nullValue = -GlobalMembers.<NodeType.NonPV.getValue()>search(pos, ss + 1, -beta, -beta + 1, depth - R, !cutNode);

			pos.undo_null_move();

			if (nullValue.getValue() >= beta.getValue())
			{
				// Do not return unproven mate scores
				if (nullValue.getValue() >= Value.VALUE_MATE_IN_MAX_PLY.getValue())
				{
					nullValue = beta;
				}

				if (thisThread.nmpMinPly != 0 || (Math.abs(beta) < Value.VALUE_KNOWN_WIN.getValue() && depth.getValue() < 12 * Depth.ONE_PLY))
				{
					return nullValue;
				}

				assert!thisThread.nmpMinPly; // Recursive verification is not allowed

				// Do verification search at high depths, with null move pruning disabled
				// for us, until ply exceeds nmpMinPly.
				thisThread.nmpMinPly = ss.ply + 3 * (depth - R) / 4;
				thisThread.nmpColor = us;

				Value v = GlobalMembers.<NodeType.NonPV.getValue()>search(pos, ss, beta - 1, beta, depth - R, false);

				thisThread.nmpMinPly = 0;

				if (v.getValue() >= beta.getValue())
				{
					return nullValue;
				}
			}
		}

		// Step 10. ProbCut (~10 Elo)
		// If we have a good enough capture and a reduced search returns a value
		// much above beta, we can (almost) safely prune the previous move.
		if (!PvNode && depth.getValue() >= 5 * Depth.ONE_PLY && Math.abs(beta) < Value.VALUE_MATE_IN_MAX_PLY.getValue())
		{
			Value rbeta = Math.min(beta + 216 - 48 * improving, Value.VALUE_INFINITE);
			MovePicker mp = new MovePicker(pos, ttMove, rbeta - ss.staticEval, thisThread.captureHistory);
			int probCutCount = 0;

			while ((move = mp.next_move()) != Move.MOVE_NONE && probCutCount < 3)
			{
				if (move != excludedMove && pos.legal(move))
				{
					probCutCount++;

					ss.currentMove = move;
					ss.continuationHistory = thisThread.continuationHistory[pos.moved_piece(move).getValue()][to_sq(move).getValue()];

					assert depth.getValue() >= 5 * Depth.ONE_PLY;

					pos.do_move(move, st);

					// Perform a preliminary qsearch to verify that the move holds
					value = -GlobalMembers.<NodeType.NonPV.getValue()>qsearch(pos, ss + 1, -rbeta, -rbeta + 1);

					// If the qsearch held perform the regular search
					if (value.getValue() >= rbeta.getValue())
					{
						value = -GlobalMembers.<NodeType.NonPV.getValue()>search(pos, ss + 1, -rbeta, -rbeta + 1, depth - 4 * Depth.ONE_PLY, !cutNode);
					}

					pos.undo_move(move);

					if (value.getValue() >= rbeta.getValue())
					{
						return value;
					}
				}
			}
		}

		// Step 11. Internal iterative deepening (~2 Elo)
		if (depth.getValue() >= 8 * Depth.ONE_PLY && ttMove.getValue() == 0)
		{
			GlobalMembers.<NT>search(pos, ss, alpha, beta, depth - 7 * Depth.ONE_PLY, cutNode);

			tte = TT.probe(posKey, ttHit);
			ttValue = ttHit ? value_from_tt(tte.value(), ss.ply) : Value.VALUE_NONE;
			ttMove = ttHit ? tte.move() : Move.MOVE_NONE;
		}

//C++ TO JAVA CONVERTER TODO TASK: There are no gotos or labels in Java:
	moves_loop: // When in check, search starts from here

//C++ TO JAVA CONVERTER TODO TASK: The following line could not be converted:
	const Stats<Short, 29952, PIECE_NB, SQUARE_NB>* contHist[] = {(ss - 1).continuationHistory, (ss - 2).continuationHistory, null, (ss - 4).continuationHistory};
		Move countermove = thisThread.counterMoves[pos.piece_on(prevSq).getValue()][prevSq.getValue()];

		MovePicker mp = new MovePicker(pos, ttMove, depth, thisThread.mainHistory, thisThread.captureHistory, contHist, countermove, ss.killers);
		value = bestValue; // Workaround a bogus 'uninitialized' warning under gcc

		skipQuiets = false;
		ttCapture = ttMove.getValue() != 0 && pos.capture_or_promotion(ttMove);
		pvExact = PvNode && ttHit && tte.bound() == Bound.BOUND_EXACT;

		// Step 12. Loop through all pseudo-legal moves until no moves remain
		// or a beta cutoff occurs.
		while ((move = mp.next_move(skipQuiets)) != Move.MOVE_NONE)
		{
		  assert is_ok(move);

		  if (move == excludedMove)
		  {
			  continue;
		  }

		  // At root obey the "searchmoves" option and skip moves not listed in Root
		  // Move List. As a consequence any illegal move is also skipped. In MultiPV
		  // mode we also skip PV moves which have been already searched and those
		  // of lower "TB rank" if we are in a TB root position.
		  if (rootNode && !std::count(thisThread.rootMoves.iterator() + thisThread.pvIdx, thisThread.rootMoves.iterator() + thisThread.pvLast, move))
		  {
			  continue;
		  }

		  ss.moveCount = ++moveCount;

		  if (rootNode && thisThread == Threads.main() && Time.elapsed() > 3000)
		  {
			  System.out.print(SyncCout.IO_LOCK);
			  System.out.print("info depth ");
			  System.out.print(depth / Depth.ONE_PLY);
			  System.out.print(" currmove ");
			  System.out.print(UCI.move(move, pos.is_chess960()));
			  System.out.print(" currmovenumber ");
			  System.out.print(moveCount + thisThread.pvIdx);
			  System.out.print("\n");
			  System.out.print(SyncCout.IO_UNLOCK);
		  }
		  if (PvNode)
		  {
			  (ss + 1).pv = null;
		  }

		  extension = Depth.DEPTH_ZERO;
		  captureOrPromotion = pos.capture_or_promotion(move);
		  movedPiece = pos.moved_piece(move);
		  givesCheck = gives_check(pos, move);

		  moveCountPruning = depth.getValue() < 16 * Depth.ONE_PLY && moveCount >= FutilityMoveCounts[improving][depth.getValue() / Depth.ONE_PLY];

		  // Step 13. Extensions (~70 Elo)

		  // Singular extension search (~60 Elo). If all moves but one fail low on a
		  // search of (alpha-s, beta-s), and just one fails high on (alpha, beta),
		  // then that move is singular and should be extended. To verify this we do
		  // a reduced search on all the other moves but the ttMove and if the
		  // result is lower than ttValue minus a margin then we will extend the ttMove.
		  if (depth.getValue() >= 8 * Depth.ONE_PLY && move == ttMove && !rootNode && excludedMove.getValue() == 0 && ttValue != Value.VALUE_NONE && (tte.bound() & Bound.BOUND_LOWER).getValue() != 0 && tte.depth() >= depth.getValue() - 3 * Depth.ONE_PLY && pos.legal(move))
		  {
			  Value rBeta = Math.max(ttValue - 2 * depth / Depth.ONE_PLY, -Value.VALUE_MATE);
			  ss.excludedMove = move;
			  value = GlobalMembers.<NodeType.NonPV.getValue()>search(pos, ss, rBeta - 1, rBeta, depth / 2, cutNode);
			  ss.excludedMove = Move.MOVE_NONE;

			  if (value.getValue() < rBeta.getValue())
			  {
				  extension = Depth.ONE_PLY;
			  }
		  }
		  else if (givesCheck && pos.see_ge(move))
		  {
			  extension = Depth.ONE_PLY;
		  }

		  // Extension if castling
		  else if (type_of(move) == MoveType.CASTLING)
		  {
			  extension = Depth.ONE_PLY;
		  }

		  // Calculate new depth for this move
		  newDepth = depth - Depth.ONE_PLY + extension;

		  // Step 14. Pruning at shallow depth (~170 Elo)
		  if (!rootNode && pos.non_pawn_material(us).getValue() != 0 && bestValue.getValue() > Value.VALUE_MATED_IN_MAX_PLY.getValue())
		  {
			  if (!captureOrPromotion && !givesCheck && (!pos.advanced_pawn_push(move) || pos.non_pawn_material() >= Value(5000)))
			  {
				  // Move count based pruning (~30 Elo)
				  if (moveCountPruning)
				  {
					  skipQuiets = true;
					  continue;
				  }

				  // Reduced depth of the next LMR search
				  int lmrDepth = Math.max(newDepth - GlobalMembers.<PvNode>reduction(improving, depth, moveCount), Depth.DEPTH_ZERO) / Depth.ONE_PLY.getValue();

				  // Countermoves based pruning (~20 Elo)
				  if (lmrDepth < 3 + ((ss - 1).statScore > 0) && (contHist[0])[movedPiece.getValue()][to_sq(move).getValue()] < GlobalMembers.CounterMovePruneThreshold && (contHist[1])[movedPiece.getValue()][to_sq(move).getValue()] < GlobalMembers.CounterMovePruneThreshold)
				  {
					  continue;
				  }

				  // Futility pruning: parent node (~2 Elo)
				  if (lmrDepth < 7 && !inCheck && ss.staticEval + 256 + 200 * lmrDepth <= alpha.getValue().getValue() != 0)
				  {
					  continue;
				  }

				  // Prune moves with negative SEE (~10 Elo)
				  if (!pos.see_ge(move, Value(-29 * lmrDepth * lmrDepth)))
				  {
					  continue;
				  }
			  }
			  else if (!extension && !pos.see_ge(move, -Value.PawnValueEg * (depth / Depth.ONE_PLY)))
			  {
					  continue;
			  }
		  }

		  // Speculative prefetch as early as possible
		  prefetch(TT.first_entry(pos.key_after(move)));

		  // Check for legality just before making the move
		  if (!rootNode && !pos.legal(move))
		  {
//C++ TO JAVA CONVERTER TODO TASK: The following line could not be converted:
		  ss.moveCount = --moveCount;
			  continue;
		  }

		  // Update the current move (this must be done after singular extension search)
		  ss.currentMove = move;
		  ss.continuationHistory = thisThread.continuationHistory[movedPiece.getValue()][to_sq(move).getValue()];

		  // Step 15. Make the move
		  pos.do_move(move, st, givesCheck);

		  // Step 16. Reduced depth search (LMR). If the move fails high it will be
		  // re-searched at full depth.
		  if (depth.getValue() >= 3 * Depth.ONE_PLY && moveCount > 1 && (!captureOrPromotion || moveCountPruning))
		  {
			  Depth r = GlobalMembers.<PvNode>reduction(improving, depth, moveCount);

			  // Decrease reduction if opponent's move count is high (~10 Elo)
			  if ((ss - 1).moveCount > 15)
			  {
				  r -= Depth.ONE_PLY;
			  }

			  if (!captureOrPromotion)
			  {
				  // Decrease reduction for exact PV nodes (~0 Elo)
				  if (pvExact)
				  {
					  r -= Depth.ONE_PLY;
				  }

				  // Increase reduction if ttMove is a capture (~0 Elo)
				  if (ttCapture)
				  {
					  r += Depth.ONE_PLY;
				  }

				  // Increase reduction for cut nodes (~5 Elo)
				  if (cutNode)
				  {
					  r += 2 * Depth.ONE_PLY;
				  }

				  // Decrease reduction for moves that escape a capture. Filter out
				  // castling moves, because they are coded as "king captures rook" and
				  // hence break make_move(). (~5 Elo)
				  else if (type_of(move) == MoveType.NORMAL && !pos.see_ge(make_move(to_sq(move), from_sq(move))))
				  {
					  r -= 2 * Depth.ONE_PLY;
				  }

				  ss.statScore = thisThread.mainHistory[us.getValue()][from_to(move)] + (contHist[0])[movedPiece.getValue()][to_sq(move).getValue()] + (contHist[1])[movedPiece.getValue()][to_sq(move).getValue()] + (contHist[3])[movedPiece.getValue()][to_sq(move).getValue()] - 4000;

				  // Decrease/increase reduction by comparing opponent's stat score (~10 Elo)
				  if (ss.statScore >= 0 && (ss - 1).statScore < 0)
				  {
					  r -= Depth.ONE_PLY;
				  }

				  else if ((ss - 1).statScore >= 0 && ss.statScore < 0)
				  {
					  r += Depth.ONE_PLY;
				  }

				  // Decrease/increase reduction for moves with a good/bad history (~30 Elo)
				  r -= ss.statScore / 20000 * Depth.ONE_PLY;
			  }

			  Depth d = Math.max(newDepth - Math.max(r, Depth.DEPTH_ZERO), Depth.ONE_PLY);

			  value = -GlobalMembers.<NodeType.NonPV.getValue()>search(pos, ss + 1, -(alpha + 1), -alpha, d, true);

			  doFullDepthSearch = (value.getValue() > alpha.getValue() && d != newDepth);
		  }
		  else
		  {
			  doFullDepthSearch = !PvNode || moveCount > 1;
		  }

		  // Step 17. Full depth search when LMR is skipped or fails high
		  if (doFullDepthSearch)
		  {
			  value = -GlobalMembers.<NodeType.NonPV.getValue()>search(pos, ss + 1, -(alpha + 1), -alpha, newDepth, !cutNode);
		  }

		  // For PV nodes only, do a full PV search on the first move or after a fail
		  // high (in the latter case search only if value < beta), otherwise let the
		  // parent node fail low with value <= alpha and try another move.
		  if (PvNode && (moveCount == 1 || (value.getValue() > alpha.getValue() && (rootNode || value.getValue() < beta.getValue()))))
		  {
			  (ss + 1).pv = UCI.GlobalMembers.pv;
			  (ss + 1).pv[0] = Move.MOVE_NONE;

			  value = -GlobalMembers.<NodeType.PV.getValue()>search(pos, ss + 1, -beta, -alpha, newDepth, false);
		  }

		  // Step 18. Undo move
		  pos.undo_move(move);

		  assert value.getValue() > -Value.VALUE_INFINITE && value.getValue() < Value.VALUE_INFINITE.getValue();

		  // Step 19. Check for a new best move
		  // Finished searching the move. If a stop occurred, the return value of
		  // the search cannot be trusted, and we return immediately without
		  // updating best move, PV and TT.
		  if (Threads.stop.load(std::memory_order_relaxed))
		  {
			  return Value.VALUE_ZERO;
		  }

		  if (rootNode)
		  {
			  RootMove rm = *std::find(thisThread.rootMoves.iterator(), thisThread.rootMoves.end(), move);

			  // PV move or new best move?
			  if (moveCount == 1 || value.getValue() > alpha.getValue())
			  {
				  rm.score = value;
				  rm.selDepth = thisThread.selDepth;
				  tangible.VectorHelper.resize(rm.pv, 1);

				  assert (ss + 1).pv;

				  for (Move * m = (ss + 1).pv; m != Move.MOVE_NONE; ++m)
				  {
					  rm.pv.add(m);
				  }

				  // We record how often the best move has been changed in each
				  // iteration. This information is used for time management: When
				  // the best move changes frequently, we allocate some more time.
				  if (moveCount > 1 && thisThread == Threads.main())
				  {
					  ++((MainThread)thisThread).bestMoveChanges;
				  }
			  }
			  else
			  {
				  // All other moves but the PV are set to the lowest value: this
				  // is not a problem when sorting because the sort is stable and the
				  // move position in the list is preserved - just the PV is pushed up.
				  rm.score = -Value.VALUE_INFINITE;
			  }
		  }

		  if (value.getValue() > bestValue.getValue())
		  {
			  bestValue = value;

			  if (value.getValue() > alpha.getValue())
			  {
				  bestMove = move;

				  if (PvNode && !rootNode) // Update pv even in fail-high case
				  {
					  update_pv(ss.pv, move, (ss + 1).pv);
				  }

				  if (PvNode && value.getValue() < beta.getValue()) // Update alpha! Always alpha < beta
				  {
					  alpha = value;
				  }
				  else
				  {
					  assert value.getValue() >= beta.getValue(); // Fail high
					  ss.statScore = 0;
					  break;
				  }
			  }
		  }

		  if (move != bestMove)
		  {
			  if (captureOrPromotion && captureCount < 32)
			  {
				  capturesSearched[captureCount++] = move;
			  }

			  else if (!captureOrPromotion && quietCount < 64)
			  {
				  quietsSearched[quietCount++] = move;
			  }
		  }
		}

		// The following condition would detect a stop only after move loop has been
		// completed. But in this case bestValue is valid because we have fully
		// searched our subtree, and we can anyhow save the result in TT.
		/*
		   if (Threads.stop)
		    return VALUE_DRAW;
		*/

		// Step 20. Check for mate and stalemate
		// All legal moves have been searched and if there are no legal moves, it
		// must be a mate or a stalemate. If we are in a singular extension search then
		// return a fail low score.

		assert moveCount || !inCheck || excludedMove || !new MoveList<GenType.LEGAL.getValue()>(pos).size();

		if (moveCount == 0)
		{
			bestValue = excludedMove.getValue() != 0 ? alpha : inCheck ? mated_in(ss.ply) : Value.VALUE_DRAW;
		}
		else if (bestMove)
		{
			// Quiet best move: update move sorting heuristics
			if (!pos.capture_or_promotion(bestMove))
			{
				update_quiet_stats(pos, ss, bestMove, quietsSearched, quietCount, stat_bonus(depth + (bestValue.getValue() > beta.getValue() + Value.PawnValueMg ? Depth.ONE_PLY : Depth.DEPTH_ZERO)));
			}

			update_capture_stats(pos, bestMove, capturesSearched, captureCount, stat_bonus(depth + Depth.ONE_PLY));

			// Extra penalty for a quiet TT move in previous ply when it gets refuted
			if ((ss - 1).moveCount == 1 && pos.captured_piece().getValue() == 0)
			{
				update_continuation_histories(ss - 1, pos.piece_on(prevSq), prevSq, -stat_bonus(depth + Depth.ONE_PLY));
			}
		}
		// Bonus for prior countermove that caused the fail low
		else if ((depth.getValue() >= 3 * Depth.ONE_PLY || PvNode) && !pos.captured_piece() && is_ok((ss - 1).currentMove))
		{
			update_continuation_histories(ss - 1, pos.piece_on(prevSq), prevSq, stat_bonus(depth));
		}

		if (PvNode)
		{
			bestValue = Math.min(bestValue, maxValue);
		}

		if (excludedMove.getValue() == 0)
		{
			tte.save(posKey, value_to_tt(bestValue, ss.ply), bestValue.getValue() >= beta.getValue() ? Bound.BOUND_LOWER : PvNode && bestMove.getValue() != 0 ? Bound.BOUND_EXACT : Bound.BOUND_UPPER, depth, bestMove, pureStaticEval);
		}

		assert bestValue.getValue() > -Value.VALUE_INFINITE && bestValue.getValue() < Value.VALUE_INFINITE.getValue();

		return bestValue;
	  }

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template <NodeType NT>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template <typename NT>

  // qsearch() is the quiescence search function, which is called by the main
  // search function with depth zero, or recursively with depth less than ONE_PLY.
  public static <NT> Value qsearch(Position pos, Stack ss, Value alpha, Value beta)
  {
	  return qsearch(pos, ss, alpha, beta, Depth.DEPTH_ZERO);
  }
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: Value qsearch(Position& pos, Stack* ss, Value alpha, Value beta, Depth depth = DEPTH_ZERO)
	  public static <NT> Value qsearch(Position pos, Stack ss, Value alpha, Value beta, Depth depth)
	  {

		final boolean PvNode = NT == NodeType.PV;

		assert alpha.getValue() >= -Value.VALUE_INFINITE && alpha.getValue() < beta.getValue() && beta.getValue() <= Value.VALUE_INFINITE.getValue();
		assert PvNode || (alpha == beta - 1);
		assert depth.getValue() <= Depth.DEPTH_ZERO.getValue();
		assert depth / Depth.ONE_PLY * Depth.ONE_PLY == depth;

		Move[] pv = new Move[MAX_PLY + 1];
		StateInfo st = new StateInfo();
		TTEntry tte;
		long posKey;
		Move ttMove;
		Move move;
		Move bestMove;
		Depth ttDepth;
		Value bestValue;
		Value value;
		Value ttValue;
		Value futilityValue;
		Value futilityBase;
		Value oldAlpha;
		boolean ttHit;
		boolean inCheck;
		boolean givesCheck;
		boolean evasionPrunable;
		int moveCount;

		if (PvNode)
		{
			oldAlpha = alpha; // To flag BOUND_EXACT when eval above alpha and no available moves
			(ss + 1).pv = UCI.GlobalMembers.pv;
			ss.pv[0] = Move.MOVE_NONE;
		}

		Thread thisThread = pos.this_thread();
		(ss + 1).ply = ss.ply + 1;
		ss.currentMove = bestMove = Move.MOVE_NONE;
		ss.continuationHistory = thisThread.continuationHistory[Piece.NO_PIECE.getValue()][0];
		inCheck = pos.checkers() != 0;
		moveCount = 0;

		// Check for an immediate draw or maximum ply reached
		if (pos.is_draw(ss.ply) || ss.ply >= MAX_PLY)
		{
			return (ss.ply >= MAX_PLY && !inCheck) ? evaluate(pos) : Value.VALUE_DRAW;
		}

		assert 0 <= ss.ply && ss.ply < MAX_PLY;

		// Decide whether or not to include checks: this fixes also the type of
		// TT entry depth that we are going to use. Note that in qsearch we use
		// only two types of depth in TT: DEPTH_QS_CHECKS or DEPTH_QS_NO_CHECKS.
		ttDepth = inCheck || depth.getValue() >= Depth.DEPTH_QS_CHECKS.getValue() ? Depth.DEPTH_QS_CHECKS : Depth.DEPTH_QS_NO_CHECKS;
		// Transposition table lookup
		posKey = pos.key();
		tte = TT.probe(posKey, ttHit);
		ttValue = ttHit ? value_from_tt(tte.value(), ss.ply) : Value.VALUE_NONE;
		ttMove = ttHit ? tte.move() : Move.MOVE_NONE;

		if (!PvNode && ttHit && tte.depth() >= ttDepth.getValue() && ttValue != Value.VALUE_NONE && (ttValue.getValue() >= beta.getValue() ? (tte.bound() & Bound.BOUND_LOWER) : (tte.bound() & Bound.BOUND_UPPER)).getValue() != 0)
		{
			return ttValue;
		}

		// Evaluate the position statically
		if (inCheck)
		{
			ss.staticEval = Value.VALUE_NONE;
			bestValue = futilityBase = -Value.VALUE_INFINITE;
		}
		else
		{
			if (ttHit)
			{
				// Never assume anything on values stored in TT
				if ((ss.staticEval = bestValue = tte.eval()) == Value.VALUE_NONE)
				{
					ss.staticEval = bestValue = evaluate(pos);
				}

				// Can ttValue be used as a better position evaluation?
				if (ttValue != Value.VALUE_NONE && (tte.bound() & (ttValue.getValue() > bestValue.getValue() ? Bound.BOUND_LOWER : Bound.BOUND_UPPER)).getValue() != 0)
				{
					bestValue = ttValue;
				}
			}
			else
			{
				ss.staticEval = bestValue = (ss - 1).currentMove != Move.MOVE_NULL ? evaluate(pos) : -(ss - 1).staticEval + 2 * Eval.GlobalMembers.Tempo;
			}

			// Stand pat. Return immediately if static value is at least beta
			if (bestValue.getValue() >= beta.getValue())
			{
				if (!ttHit)
				{
					tte.save(posKey, value_to_tt(bestValue, ss.ply), Bound.BOUND_LOWER, Depth.DEPTH_NONE, Move.MOVE_NONE, ss.staticEval);
				}

				return bestValue;
			}

			if (PvNode && bestValue.getValue() > alpha.getValue())
			{
				alpha = bestValue;
			}

			futilityBase = bestValue + 128;
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line could not be converted:
	const Stats<Short, 29952, PIECE_NB, SQUARE_NB>* contHist[] = {(ss - 1).continuationHistory, (ss - 2).continuationHistory, null, (ss - 4).continuationHistory};

		// Initialize a MovePicker object for the current position, and prepare
		// to search the moves. Because the depth is <= 0 here, only captures,
		// queen promotions and checks (only if depth >= DEPTH_QS_CHECKS) will
		// be generated.
		MovePicker mp = new MovePicker(pos, ttMove, depth, thisThread.mainHistory, thisThread.captureHistory, contHist, to_sq((ss - 1).currentMove));

		// Loop through the moves until no moves remain or a beta cutoff occurs
		while ((move = mp.next_move()) != Move.MOVE_NONE)
		{
		  assert is_ok(move);

		  givesCheck = gives_check(pos, move);

		  moveCount++;

		  // Futility pruning
		  if (!inCheck && !givesCheck && futilityBase.getValue() > -Value.VALUE_KNOWN_WIN && !pos.advanced_pawn_push(move))
		  {
			  assert type_of(move) != MoveType.ENPASSANT; // Due to !pos.advanced_pawn_push

			  futilityValue = futilityBase + PieceValue[Phase.EG.getValue()][pos.piece_on(to_sq(move)).getValue()];

			  if (futilityValue.getValue() <= alpha.getValue())
			  {
				  bestValue = Math.max(bestValue, futilityValue);
				  continue;
			  }

			  if (futilityBase.getValue() <= alpha.getValue() && !pos.see_ge(move, Value.VALUE_ZERO + 1))
			  {
				  bestValue = Math.max(bestValue, futilityBase);
				  continue;
			  }
		  }

		  // Detect non-capture evasions that are candidates to be pruned
		  evasionPrunable = inCheck && (depth != Depth.DEPTH_ZERO || moveCount > 2) && bestValue.getValue() > Value.VALUE_MATED_IN_MAX_PLY.getValue() && !pos.capture(move);

		  // Don't search moves with negative SEE values
		  if ((!inCheck || evasionPrunable) && !pos.see_ge(move))
		  {
			  continue;
		  }

		  // Speculative prefetch as early as possible
		  prefetch(TT.first_entry(pos.key_after(move)));

		  // Check for legality just before making the move
		  if (!pos.legal(move))
		  {
			  moveCount--;
			  continue;
		  }

		  ss.currentMove = move;
		  ss.continuationHistory = thisThread.continuationHistory[pos.moved_piece(move).getValue()][to_sq(move).getValue()];

		  // Make and search the move
		  pos.do_move(move, st, givesCheck);
		  value = -GlobalMembers.<NT>qsearch(pos, ss + 1, -beta, -alpha, depth - Depth.ONE_PLY);
		  pos.undo_move(move);

		  assert value.getValue() > -Value.VALUE_INFINITE && value.getValue() < Value.VALUE_INFINITE.getValue();

		  // Check for a new best move
		  if (value.getValue() > bestValue.getValue())
		  {
			  bestValue = value;

			  if (value.getValue() > alpha.getValue())
			  {
				  bestMove = move;

				  if (PvNode) // Update pv even in fail-high case
				  {
					  update_pv(ss.pv, move, (ss + 1).pv);
				  }

				  if (PvNode && value.getValue() < beta.getValue()) // Update alpha here!
				  {
					  alpha = value;
				  }
				  else
				  {
					  break; // Fail high
				  }
			  }
		  }
		}

		// All legal moves have been searched. A special case: If we're in check
		// and no legal moves were found, it is checkmate.
		if (inCheck && bestValue == -Value.VALUE_INFINITE)
		{
			return mated_in(ss.ply); // Plies to mate from the root
		}

		tte.save(posKey, value_to_tt(bestValue, ss.ply), bestValue.getValue() >= beta.getValue() ? Bound.BOUND_LOWER : PvNode && bestValue.getValue() > oldAlpha.getValue() ? Bound.BOUND_EXACT : Bound.BOUND_UPPER, ttDepth, bestMove, ss.staticEval);

		assert bestValue.getValue() > -Value.VALUE_INFINITE && bestValue.getValue() < Value.VALUE_INFINITE.getValue();

		return bestValue;
	  }

  // value_to_tt() adjusts a mate score from "plies to mate from the root" to
  // "plies to mate from the current position". Non-mate scores are unchanged.
  // The function is called before storing a value in the transposition table.


	  public static Value value_to_tt(Value v, int ply)
	  {

		assert v != Value.VALUE_NONE;

		return v.getValue() >= Value.VALUE_MATE_IN_MAX_PLY.getValue() ? v + ply : v.getValue() <= Value.VALUE_MATED_IN_MAX_PLY.getValue() ? v - ply : v;
	  }

  // value_from_tt() is the inverse of value_to_tt(): It adjusts a mate score
  // from the transposition table (which refers to the plies to mate/be mated
  // from current position) to "plies to mate/be mated from the root".


	  public static Value value_from_tt(Value v, int ply)
	  {

		return v == Value.VALUE_NONE ? Value.VALUE_NONE : v.getValue() >= Value.VALUE_MATE_IN_MAX_PLY.getValue() ? v - ply : v.getValue() <= Value.VALUE_MATED_IN_MAX_PLY.getValue() ? v + ply : v;
	  }

  // update_pv() adds current move and appends child pv[]


//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'pv', so pointers on this parameter are left unchanged:
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'childPv', so pointers on this parameter are left unchanged:
	  public static void update_pv(Move * pv, Move move, Move * childPv)
	  {

		for (*UCI.GlobalMembers.pv++ = move; childPv && childPv != Move.MOVE_NONE;)
		{
			*UCI.GlobalMembers.pv++ = *childPv++;
		}
		*UCI.GlobalMembers.pv = Move.MOVE_NONE;
	  }

  // update_continuation_histories() updates histories of the move pairs formed
  // by moves at ply -1, -2, and -4 with current move.


	  public static void update_continuation_histories(Stack ss, Piece pc, Square to, int bonus)
	  {

		for (int i : {1, 2, 4})
		{
			if (is_ok((ss - i).currentMove))
			{
				(ss - i).continuationHistory[pc.getValue()][to.getValue()] << bonus;
			}
		}
	  }

  // update_quiet_stats() updates move sorting heuristics when a new quiet best move is found


	  public static void update_quiet_stats(Position pos, Stack ss, Move move, Move[] quiets, int quietsCnt, int bonus)
	  {

		if (ss.killers[0] != move)
		{
			ss.killers[1] = ss.killers[0];
			ss.killers[0] = move;
		}

		Color us = pos.side_to_move();
		Thread thisThread = pos.this_thread();
		thisThread.mainHistory[us.getValue()][from_to(move)] << bonus;
		update_continuation_histories(ss, pos.moved_piece(move), to_sq(move), bonus);

		if (is_ok((ss - 1).currentMove))
		{
			Square prevSq = to_sq((ss - 1).currentMove);
			thisThread.counterMoves[pos.piece_on(prevSq).getValue()][prevSq.getValue()] = move;
		}

		// Decrease all the other played quiet moves
		for (int i = 0; i < quietsCnt; ++i)
		{
			thisThread.mainHistory[us.getValue()][from_to(quiets[i])] << -bonus;
			update_continuation_histories(ss, pos.moved_piece(quiets[i]), to_sq(quiets[i]), -bonus);
		}
	  }

  // update_capture_stats() updates move sorting heuristics when a new capture best move is found


	  public static void update_capture_stats(Position pos, Move move, Move[] captures, int captureCnt, int bonus)
	  {

		  Stats<Short, 10692, Piece.PIECE_NB, Square.SQUARE_NB, PieceType.PIECE_TYPE_NB> captureHistory = pos.this_thread().captureHistory;
		  Piece moved_piece = pos.moved_piece(move);
		  PieceType captured = type_of(pos.piece_on(to_sq(move)));

		  if (pos.capture_or_promotion(move))
		  {
			  captureHistory[moved_piece.getValue()][to_sq(move).getValue()][captured.getValue()] << bonus;
		  }

		  // Decrease all the other played capture moves
		  for (int i = 0; i < captureCnt; ++i)
		  {
			  moved_piece = pos.moved_piece(captures[i]);
			  captured = type_of(pos.piece_on(to_sq(captures[i])));
			  captureHistory[moved_piece.getValue()][to_sq(captures[i]).getValue()][captured.getValue()] << -bonus;
		  }
	  }

	  public static boolean gives_check(Position pos, Move move)
	  {
		Color us = pos.side_to_move();
		return (type_of(move) == MoveType.NORMAL && (pos.blockers_for_king(~us) & pos.pieces(us)) == 0 ? pos.check_squares(type_of(pos.moved_piece(move))) & to_sq(move).getValue() : pos.gives_check(move)) != 0;
	  }

	  // perft() is our utility to verify move generation. All the leaf nodes up
	  // to the given depth are generated and counted, and the sum is returned.
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<bool Root>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Root>
	  public static <Root> long perft(Position pos, Depth depth)
	  {

		StateInfo st = new StateInfo();
		long cnt;
		long nodes = 0;
		final boolean leaf = (depth == 2 * Depth.ONE_PLY);

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
		for (auto m : new MoveList<GenType.LEGAL.getValue()>(pos))
		{
			if (Root && depth.getValue() <= Depth.ONE_PLY.getValue())
			{
				cnt = 1, nodes++;
			}
			else
			{
				pos.do_move(new auto(m), st);
				cnt = leaf ? new MoveList<GenType.LEGAL.getValue()>(pos).size() : GlobalMembers.<false>perft(pos, depth - Depth.ONE_PLY);
				nodes += cnt;
				pos.undo_move(new auto(m));
			}
			if (Root)
			{
				System.out.print(SyncCout.IO_LOCK);
				System.out.print(UCI.move(m, pos.is_chess960()));
				System.out.print(": ");
				System.out.print(cnt);
				System.out.print("\n");
				System.out.print(SyncCout.IO_UNLOCK);
			}
		}
		return nodes;
	  }




	/// MainThread::check_time() is used to print debug info and, more importantly,
	/// to detect when we are out of available time and thus stop the search.

	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static std::chrono.milliseconds.rep check_time_lastInfoTime = now();

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ThreadPool Threads;



	public static ThreadPool Threads = new ThreadPool(); // Global object


//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern TimeManagement Time;



	public static TimeManagement Time = new TimeManagement(); // Our global time management object

	  public static final int MoveHorizon = 50; // Plan time management at most this many moves ahead
	  public static final double MaxRatio = 7.3; // When in trouble, we can step over reserved time with this ratio
	  public static final double StealRatio = 0.34; // However we must not steal time from remaining moves over this ratio


	  // move_importance() is a skew-logistic function based on naive statistical
	  // analysis of "how many games are still undecided after n half-moves". Game
	  // is considered "undecided" as long as neither side has >275cp advantage.
	  // Data was extracted from the CCRL game database with some simple filtering criteria.

	  public static double move_importance(int ply)
	  {

		final double XScale = 6.85;
		final double XShift = 64.5;
		final double Skew = 0.171;

		return Math.pow((1 + Math.exp((ply - XShift) / XScale)), -Skew) + DBL_MIN; // Ensure non-zero
	  }

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<TimeType T>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
	  public static <T> std::chrono.milliseconds.rep remaining(std::chrono.milliseconds.rep myTime, int movesToGo, int ply, std::chrono.milliseconds.rep slowMover)
	  {

		final double TMaxRatio = (T == TimeType.OptimumTime ? 1.0 : MaxRatio);
		final double TStealRatio = (T == TimeType.OptimumTime ? 0.0 : StealRatio);

		double moveImportance = (move_importance(ply) * slowMover) / 100.0;
		double otherMovesImportance = 0.0;

		for (int i = 1; i < movesToGo; ++i)
		{
			otherMovesImportance += move_importance(ply + 2 * i);
		}

		double ratio1 = (TMaxRatio * moveImportance) / (TMaxRatio * moveImportance + otherMovesImportance);
		double ratio2 = (moveImportance + TStealRatio * otherMovesImportance) / (moveImportance + otherMovesImportance);

		return std::chrono.milliseconds.rep(myTime * Math.min(ratio1, ratio2)); // Intel C++ asks for an explicit cast
	  }



//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern TranspositionTable TT;



	public static TranspositionTable TT = new TranspositionTable(); // Our global transposition table



//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ClassicMap<String, Option, CaseInsensitiveLess> Options;




//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
	//ClassicVector<String> setup_bench(Position UnnamedParameter, istream UnnamedParameter2);


	  // FEN string of the initial position, normal chess
	  public static String StartFEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";


	  // position() is called when engine receives the "position" UCI command.
	  // The function sets up the position described in the given FEN string ("fen")
	  // or the starting position ("startpos") and then makes the moves given in the
	  // following move list ("moves").

	  public static void position(Position pos, istringstream is, tangible.RefObject<std::unique_ptr<LinkedList<StateInfo>>> states)
	  {

		Move m;
		String token;
		String fen;

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		is >> token;

		if (token.equals("startpos"))
		{
			fen = StartFEN;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			is >> token; // Consume "moves" token if any
		}
		else if (token.equals("fen"))
		{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			while ((is >> token) != 0 && !token.equals("moves"))
			{
				fen += token + " ";
			}
		}
		else
		{
			return;
		}

		states.argValue = StateListPtr(new LinkedList<StateInfo>(1)); // Drop old and create a new one
		pos.set(fen, Options["UCI_Chess960"], states.argValue.back(), Threads.main());

		// Parse move list (if any)
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		while ((is >> token) != 0 && (m = UCI.GlobalMembers.to_move(pos, token)) != Move.MOVE_NONE)
		{
			states.argValue.emplace_back();
			pos.do_move(m, states.argValue.back());
		}
	  }


	  // setoption() is called when engine receives the "setoption" UCI command. The
	  // function updates the UCI option ("name") to the given value ("value").

	  public static void setoption(istringstream is)
	  {

		String token;
		String name;
		String value;

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		is >> token; // Consume "name" token

		// Read option name (can contain spaces)
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		while ((is >> token) != 0 && !token.equals("value"))
		{
			name += (name.length() == 0 ? "" : " ") + token;
		}

		// Read option value (can contain spaces)
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		while ((is >> token) != 0)
		{
			UCI.GlobalMembers.value += (UCI.GlobalMembers.value.empty() ? "" : " ") + token;
		}

		if (Options.count(name))
		{
			Options[name] = UCI.GlobalMembers.value;
		}
		else
		{
			System.out.print(SyncCout.IO_LOCK);
			System.out.print("No such option: ");
			System.out.print(name);
			System.out.print("\n");
			System.out.print(SyncCout.IO_UNLOCK);
		}
	  }


	  // go() is called when engine receives the "go" UCI command. The function sets
	  // the thinking time and other parameters from the input string, then starts
	  // the search.

	  public static void go(Position pos, istringstream is, std::unique_ptr<LinkedList<StateInfo>> states)
	  {

		Search.LimitsType limits = new Search.LimitsType();
		String token;
		boolean ponderMode = false;

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: limits.startTime = now();
		limits.startTime.copyFrom(now()); // As early as possible!

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		while ((is >> token) != 0)
		{
			if (token.equals("searchmoves"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				while ((is >> token) != 0)
				{
					limits.searchmoves.add(UCI.GlobalMembers.to_move(pos, token));
				}
			}

			else if (token.equals("wtime"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.time[Color.WHITE.getValue()];
			}
			else if (token.equals("btime"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.time[Color.BLACK.getValue()];
			}
			else if (token.equals("winc"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.inc[Color.WHITE.getValue()];
			}
			else if (token.equals("binc"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.inc[Color.BLACK.getValue()];
			}
			else if (token.equals("movestogo"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.movestogo;
			}
			else if (token.equals("depth"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.depth;
			}
			else if (token.equals("nodes"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.nodes;
			}
			else if (token.equals("movetime"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.movetime;
			}
			else if (token.equals("mate"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.mate;
			}
			else if (token.equals("perft"))
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				is >> limits.perft;
			}
			else if (token.equals("infinite"))
			{
				limits.infinite = 1;
			}
			else if (token.equals("ponder"))
			{
				ponderMode = true;
			}
		}

		Threads.start_thinking(pos, states, limits, ponderMode);
	  }


	  // bench() is called when engine receives the "bench" command. Firstly
	  // a list of UCI commands is setup according to bench parameters, then
	  // it is run one by one printing a summary at the end.

	  public static void bench(Position pos, istream args, std::unique_ptr<LinkedList<StateInfo>> states)
	  {

		String token;
		long num;
		long nodes = 0;
		long cnt = 1;

		ArrayList<String> list = setup_bench(pos, args);
	num = count_if(list.iterator(), list.end(), (String s) ->
	{
		return s.indexOf("go ") == 0;
	});

		std::chrono.milliseconds.rep elapsed = now();

		for (String cmd : list)
		{
			istringstream is = new istringstream(cmd);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			is >> skipws >> token;

			if (token.equals("go"))
			{
				cerr << "\nPosition: " << cnt++ << '/' << num << "\n";
				go(pos, is, states);
				Threads.main().wait_for_search_finished();
				nodes += Threads.nodes_searched();
			}
			else if (token.equals("setoption"))
			{
				setoption(is);
			}
			else if (token.equals("position"))
			{
			tangible.RefObject<std::unique_ptr<ClassicDeque<StateInfo>>> tempRef_states = new tangible.RefObject<std::unique_ptr<ClassicDeque<StateInfo>>>(states);
				position(pos, is, tempRef_states);
				states = tempRef_states.argValue;
			}
			else if (token.equals("ucinewgame"))
			{
				Search.clear();
			}
		}

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: elapsed = now() - elapsed + 1;
		elapsed.copyFrom(now() - elapsed + 1); // Ensure positivity to avoid a 'divide by zero'

		dbg_print(); // Just before exiting

		cerr << "\n===========================" << "\nTotal time (ms) : " << elapsed << "\nNodes searched  : " << nodes << "\nNodes/second    : " << 1000 * nodes / elapsed << "\n";
	  }



	public static TreeMap<String, Option, CaseInsensitiveLess> Options = new TreeMap<String, Option, CaseInsensitiveLess>(); // Global object

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define _ReturnAddress() (__builtin_return_address(0))
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define _ReadWriteBarrier() __sync_synchronize()

	 public static __INTRIN_INLINE void __yield()
	 {
		 __asm__ __volatile__ = new __asm__("yield");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __break(unsigned int value)
	 public static __INTRIN_INLINE void __break(int value)
	 {
		 __asm__ __volatile__ = new __asm__("bkpt %0": : "M" (value));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short _byteswap_ushort(unsigned short value)
	 public static __INTRIN_INLINE short _byteswap_ushort(short value)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (value >>> 8) || (value << 8);
	 }

	 public static __INTRIN_INLINE int _CountLeadingZeros(int Mask)
	 {
		 return Mask != 0 ? __builtin_clz(Mask) : 32;
	 }

	 public static __INTRIN_INLINE int _CountTrailingZeros(int Mask)
	 {
		 return Mask != 0 ? __builtin_ctz(Mask) : 32;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _BitScanForward(unsigned long * const Index, const unsigned long Mask)
	 public static __INTRIN_INLINE byte _BitScanForward(final int Index, int Mask)
	 {
		 Index = __builtin_ctz(Mask);
		 return (byte)(Mask != 0 ? 1 : 0);
	 }

	 public static __INTRIN_INLINE char _InterlockedCompareExchange8(final String Destination, char Exchange, char Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination, Comperand, Exchange);
	 }

	 public static __INTRIN_INLINE short _InterlockedCompareExchange16(final short Destination, short Exchange, short Comperand)
	 {
		 short a;
		 short b;

		 __asm__ __volatile__ = new __asm__("0:\n\t" + "ldr %1, [%2]\n\t" + "cmp %1, %4\n\t" + "bne 1f\n\t" + "swp %0, %3, [%2]\n\t" + "cmp %0, %1\n\t" + "swpne %3, %0, [%2]\n\t" + "bne 0b\n\t" + "1:" : "=&r" (a), "=&r" (b) : "r" (Destination), "r" (Exchange), "r" (Comperand) : "cc", "memory");

		 return a;
	 }

	 public static __INTRIN_INLINE short _InterlockedExchangeAdd16(final short Addend, short Value)
	 {
		 short a;
		 short b;
		 short c;

		 __asm__ __volatile__ = new __asm__("0:\n\t" + "ldr %0, [%3]\n\t" + "add %1, %0, %4\n\t" + "swp %2, %1, [%3]\n\t" + "cmp %0, %2\n\t" + "swpne %1, %2, [%3]\n\t" + "bne 0b" : "=&r" (a), "=&r" (b), "=&r" (c) : "r" (Value), "r" (Addend) : "cc", "memory");

		 return a;
	 }

	 public static __INTRIN_INLINE int _InterlockedCompareExchange(final int dest, int exch, int comp)
	 {
		 int a;
		 int b;

		 __asm__ __volatile__ = new __asm__("0:\n\t" + "ldr %1, [%2]\n\t" + "cmp %1, %4\n\t" + "bne 1f\n\t" + "swp %0, %3, [%2]\n\t" + "cmp %0, %1\n\t" + "swpne %3, %0, [%2]\n\t" + "bne 0b\n\t" + "1:" : "=&r" (a), "=&r" (b) : "r" (dest), "r" (exch), "r" (comp) : "cc", "memory");

		 return a;
	 }

	 public static __INTRIN_INLINE long _InterlockedCompareExchange64(final long dest, long exch, long comp)
	 {
		 //
		 // FIXME
		 //
		 long result;
		 result = dest;
		 if (dest == comp)
		 {
			 dest = exch;
		 }
		 return result;
	 }

	 public static __INTRIN_INLINE Object _InterlockedCompareExchangePointer(final Object * Destination, final Object Exchange, final Object Comperand)
	 {
		 return (Object)_InterlockedCompareExchange((volatile int * const)Destination, (int)Exchange, (int)Comperand);
	 }


	 public static __INTRIN_INLINE int _InterlockedExchangeAdd(final int dest, int add)
	 {
		 int a;
		 int b;
		 int c;

		 __asm__ __volatile__ = new __asm__("0:\n\t" + "ldr %0, [%3]\n\t" + "add %1, %0, %4\n\t" + "swp %2, %1, [%3]\n\t" + "cmp %0, %2\n\t" + "swpne %1, %2, [%3]\n\t" + "bne 0b" : "=&r" (a), "=&r" (b), "=&r" (c) : "r" (dest), "r" (add) : "cc", "memory");

		 return a;
	 }

	 public static __INTRIN_INLINE int _InterlockedExchange(final int dest, int exch)
	 {
		 int a;

		 __asm__ __volatile__ = new __asm__("swp %0, %2, [%1]" : "=&r" (a) : "r" (dest), "r" (exch));

		 return a;
	 }


	 public static __INTRIN_INLINE Object _InterlockedExchangePointer(final Object * Target, final Object Value)
	 {
		 return (Object)_InterlockedExchange((volatile int * const)Target, (int)Value);
	 }



	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _BitScanReverse(unsigned long * const Index, const unsigned long Mask)
	 public static __INTRIN_INLINE byte _BitScanReverse(final int Index, int Mask)
	 {
		 Index = 31 - __builtin_clz(Mask);
		 return (byte)(Mask != 0 ? 1 : 0);
	 }

	 public static __INTRIN_INLINE char _InterlockedAnd8(final String value, char mask)
	 {
		 char x;
		 char y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange8(value, x & mask, x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE short _InterlockedAnd16(final short value, short mask)
	 {
		 short x;
		 short y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange16(value, (short)(x & mask), x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE int _InterlockedAnd(final int value, int mask)
	 {
		 int x;
		 int y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange(value, x & mask, x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE char _InterlockedOr8(final String value, char mask)
	 {
		 char x;
		 char y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange8(value, x | mask, x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE short _InterlockedOr16(final short value, short mask)
	 {
		 short x;
		 short y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange16(value, (short)(x | mask), x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE int _InterlockedOr(final int value, int mask)
	 {
		 int x;
		 int y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange(value, x | mask, x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE char _InterlockedXor8(final String value, char mask)
	 {
		 char x;
		 char y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange8(value, x ^ mask, x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE short _InterlockedXor16(final short value, short mask)
	 {
		 short x;
		 short y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange16(value, (short)(x ^ mask), x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE int _InterlockedXor(final int value, int mask)
	 {
		 int x;
		 int y;

		 y = value;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange(value, x ^ mask, x);
		 } while (y != x);

		 return y;
	 }

	 public static __INTRIN_INLINE int _InterlockedDecrement(final int lpAddend)
	 {
		 return _InterlockedExchangeAdd(lpAddend, -1) - 1;
	 }

	 public static __INTRIN_INLINE int _InterlockedIncrement(final int lpAddend)
	 {
		 return _InterlockedExchangeAdd(lpAddend, 1) + 1;
	 }

	 public static __INTRIN_INLINE int _InterlockedDecrement16(final short lpAddend)
	 {
		 return _InterlockedExchangeAdd16(lpAddend, -1) - 1;
	 }

	 public static __INTRIN_INLINE int _InterlockedIncrement16(final short lpAddend)
	 {
		 return _InterlockedExchangeAdd16(lpAddend, 1) + 1;
	 }

//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'Addend', so pointers on this parameter are left unchanged:
	 public static __INTRIN_INLINE int _InterlockedAddLargeStatistic(final long * Addend, int Value)
	 {
		 *Addend += Value;
		 return Value;
	 }

	 public static __INTRIN_INLINE void _disable()
	 {
		 __asm__ __volatile__ = new __asm__("cpsid i    @ __cli" : : : "memory", "cc");
	 }

	 public static __INTRIN_INLINE void _enable()
	 {
		 __asm__ __volatile__ = new __asm__("cpsie i    @ __sti" : : : "memory", "cc");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _interlockedbittestandset(volatile long * a, const long b)
	 public static __INTRIN_INLINE byte _interlockedbittestandset(tangible.RefObject<Integer> a, int b)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		 return (byte)((_InterlockedOr(a.argValue, 1 << b) >> b) & 1);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _interlockedbittestandreset(volatile long * a, const long b)
	 public static __INTRIN_INLINE byte _interlockedbittestandreset(tangible.RefObject<Integer> a, int b)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		 return (byte)((_InterlockedAnd(a.argValue, ~(1 << b)) >> b) & 1);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if ! __MSVCRT__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned int _rotl(const unsigned int value, int shift)
	 public static __INTRIN_INLINE int _rotl(int value, int shift)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (((value) << ((int)(shift))) | ((value) >>> (32 - (int)(shift))));
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define _clz(a) ({ ULONG __value, __arg = (a); asm ("clz\t%0, %1": "=r" (__value): "r" (__arg)); __value; })

	 /* EOF */

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__) > 40100

	 public static __inline__ char _InterlockedCompareExchange8(final String Destination, char Exchange, char Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination, Comperand, Exchange);
	 }

	 public static __inline__ short _InterlockedCompareExchange16(final short Destination, short Exchange, short Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination, Comperand, Exchange);
	 }

	 public static __inline__ int _InterlockedCompareExchange(final int Destination, int Exchange, int Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination, Comperand, Exchange);
	 }

	 public static __inline__ long _InterlockedCompareExchange64(final long Destination, long Exchange, long Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination, Comperand, Exchange);
	 }

	 public static __inline__ Object _InterlockedCompareExchangePointer(final Object * Destination, final Object Exchange, final Object Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination, Comperand, Exchange);
	 }

	 public static __inline__ int _InterlockedExchange(final int Target, int Value)
	 {
		 /* NOTE: __sync_lock_test_and_set would be an acquire barrier, so we force a full barrier */
		 __sync_synchronize();
		 return __sync_lock_test_and_set(Target, Value);
	 }

	 public static __inline__ Object _InterlockedExchangePointer(final Object * Target, final Object Value)
	 {
		 /* NOTE: ditto */
		 __sync_synchronize();
		 return __sync_lock_test_and_set(Target, Value);
	 }

	 public static __inline__ int _InterlockedExchangeAdd(final int Addend, int Value)
	 {
		 return __sync_fetch_and_add(Addend, Value);
	 }

	 public static __inline__ char _InterlockedAnd8(final String value, char mask)
	 {
		 return __sync_fetch_and_and(value, mask);
	 }

	 public static __inline__ short _InterlockedAnd16(final short value, short mask)
	 {
		 return __sync_fetch_and_and(value, mask);
	 }

	 public static __inline__ int _InterlockedAnd(final int value, int mask)
	 {
		 return __sync_fetch_and_and(value, mask);
	 }

	 public static __inline__ char _InterlockedOr8(final String value, char mask)
	 {
		 return __sync_fetch_and_or(value, mask);
	 }

	 public static __inline__ short _InterlockedOr16(final short value, short mask)
	 {
		 return __sync_fetch_and_or(value, mask);
	 }

	 public static __inline__ int _InterlockedOr(final int value, int mask)
	 {
		 return __sync_fetch_and_or(value, mask);
	 }

	 public static __inline__ char _InterlockedXor8(final String value, char mask)
	 {
		 return __sync_fetch_and_xor(value, mask);
	 }

	 public static __inline__ short _InterlockedXor16(final short value, short mask)
	 {
		 return __sync_fetch_and_xor(value, mask);
	 }

	 public static __inline__ int _InterlockedXor(final int value, int mask)
	 {
		 return __sync_fetch_and_xor(value, mask);
	 }

	 ///#else

	 public static __inline__ char _InterlockedCompareExchange8(final String Destination, char Exchange, char Comperand)
	 {
			 volatile int retval __asm__("r8") = 0;
		 __asm__ __volatile__ = new __asm__("sync\n" + "1: lbarx   %0,0,%1\n" : "=r" (retval) : "r" (Destination));
			 __asm__ __volatile__ = new __asm__("   cmpw    %3,%1\n" + "   bne-    2f\n" + "   stbcx.  %2,0,%0\n" + "   bne-    1b\n" + "2: isync" : : "r" (Destination), "r" (Comperand), "r" (Exchange), "r" (retval));
		 return retval;
	 }

	 public static __inline__ short _InterlockedCompareExchange16(final short Destination, short Exchange, short Comperand)
	 {
			 volatile int retval __asm__("r8") = 0;
		 __asm__ __volatile__ = new __asm__("sync\n" + "1: lharx   %0,0,%1\n" : "=&r" (retval) : "r" (Destination));
			 __asm__ __volatile__ = new __asm__("   cmpw    %3,%1\n" + "   bne-    2f\n" + "   sthcx.  %2,0,%0\n" + "   bne-    1b\n" + "2: isync" : : "r" (Destination), "r" (Comperand), "r" (Exchange), "r" (retval));
		 return retval;
	 }

	 public static __inline__ int _InterlockedCompareExchange(final int Destination, int Exchange, int Comperand)
	 {
			 volatile int retval __asm__("r8") = 0;
		 __asm__ __volatile__ = new __asm__("sync\n" + "1: lwarx   %0,0,%1\n" : "=&r" (retval) : "r" (Destination));
			 __asm__ __volatile__ = new __asm__("   cmpw    %3,%1\n" + "   bne-    2f\n" + "   stwcx.  %2,0,%0\n" + "   bne-    1b\n" + "2: isync" : : "r" (Destination), "r" (Comperand), "r" (Exchange), "r" (retval));
		 return retval;
	 }

	 public static __inline__ long _InterlockedCompareExchange64(final long Target, long Exchange, long Comperand)
	 {
		 long capture = Target;
		 if (Target == Comperand)
		 {
			 Target = Exchange;
		 }
		 return capture;
	 }

	 public static __inline__ Object _InterlockedCompareExchangePointer(final Object * Destination, final Object Exchange, final Object Comperand)
	 {
		 return (Object)_InterlockedCompareExchange((int)Destination, (int) Exchange, (int) Comperand);
	 }

	 public static __inline__ int _InterlockedExchange(final int Target, int Value)
	 {
		 int retval __asm__("r8");
		 __asm__ __volatile__ = new __asm__("sync\n" + "1: lwarx   8,0,3\n" + "   stwcx.  4,0,3\n" + "   bne-    1b\n" + "   mr      3,8\n" : "=b" (retval) : "b" (Target), "b" (Value) : "cr0", "memory");
		 return retval;
	 }

	 public static __inline__ Object _InterlockedExchangePointer(final Object * Target, final Object Value)
	 {
		 return (Object)_InterlockedExchange((int)Target, (int)Value);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	 ///#define PPC_MakeInterlockedFunction(type,name,op,proto) PPC_QUAL type name proto { long addend, y; do { addend = *value; y = _InterlockedCompareExchange(value, addend op modify, addend); } while(y != addend); return y; }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _interlockedbittestandreset(volatile long * const a, const long b)
	 public static __inline__ byte _interlockedbittestandreset(final int a, int b)
	 {
		 int x;
		 int y;
		 int mask = ~(1 << b);

		 do
		 {
			 x = a;
			 y = _InterlockedCompareExchange(a, x & mask, x);
		 } while (y != x);

		 return (y & ~mask) != 0;
	 }

	 public static __inline__ int _InterlockedExchangeAdd(final int value, int modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend + modify, addend);
		 } while (y != addend);
		 return y;
	 }
	 public static __inline__ char _InterlockedAnd8(final String value, char modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend & modify, addend);
		 } while (y != addend);
		 return y;
	 }
	 public static __inline__ short _InterlockedAnd16(final short value, short modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend & modify, addend);
		 } while (y != addend);
		 return (short)y;
	 }
	 public static __inline__ int _InterlockedAnd(final int value, int modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend & modify, addend);
		 } while (y != addend);
		 return y;
	 }
	 public static __inline__ char _InterlockedOr8(final String value, char modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend | modify, addend);
		 } while (y != addend);
		 return y;
	 }
	 public static __inline__ short _InterlockedOr16(final short value, short modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend | modify, addend);
		 } while (y != addend);
		 return (short)y;
	 }
	 public static __inline__ int _InterlockedOr(final int value, int modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend | modify, addend);
		 } while (y != addend);
		 return y;
	 }
	 public static __inline__ char _InterlockedXor8(final String value, char modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend ^ modify, addend);
		 } while (y != addend);
		 return y;
	 }
	 public static __inline__ short _InterlockedXor16(final short value, short modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend ^ modify, addend);
		 } while (y != addend);
		 return (short)y;
	 }
	 public static __inline__ int _InterlockedXor(final int value, int modify)
	 {
		 int addend;
		 int y;
		 do
		 {
			 addend = value;
			 y = _InterlockedCompareExchange(value, addend ^ modify, addend);
		 } while (y != addend);
		 return y;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _interlockedbittestandset(volatile long * const a, const long b)
	 public static __inline__ byte _interlockedbittestandset(final int a, int b)
	 {
		 int x;
		 int y;
		 int mask = 1 << b;

		 do
		 {
					 x = a;
			 y = _InterlockedCompareExchange(a, x | mask, x);
		 } while (y != x);

		 return (y & ~mask) != 0;
	 }
	 ///#endif

	 public static __inline__ int _InterlockedDecrement(final int lpAddend)
	 {
		 return _InterlockedExchangeAdd(lpAddend, -1) - 1;
	 }

	 public static __inline__ int _InterlockedIncrement(final int lpAddend)
	 {
		 return _InterlockedExchangeAdd(lpAddend, 1) + 1;
	 }

	 /*** String operations ***/
	 /* NOTE: we don't set a memory clobber in the __stosX functions because Visual C++ doesn't */
	 /* Note that the PPC store multiple operations may raise an exception in LE
	  * mode */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __stosb(unsigned char * Dest, const unsigned char Data, unsigned long Count)
	 public static __inline__ void __stosb(tangible.RefObject<Byte> Dest, byte Data, int Count)
	 {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
		 memset(Dest.argValue, Data, Count);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __stosw(unsigned short * Dest, const unsigned short Data, unsigned long Count)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'Dest', so pointers on this parameter are left unchanged:
	 public static __inline__ void __stosw(short * Dest, short Data, int Count)
	 {
		 while ((Count--) != 0)
		 {
		 *Dest++ = Data;
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __stosd(unsigned long * Dest, const unsigned long Data, unsigned long Count)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'Dest', so pointers on this parameter are left unchanged:
	 public static __inline__ void __stosd(int * Dest, int Data, int Count)
	 {
		 while ((Count--) != 0)
		 {
		 *Dest++ = Data;
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __movsb(unsigned char * Destination, const unsigned char * Source, unsigned long Count)
	 public static __inline__ void __movsb(tangible.RefObject<Byte> Destination, byte Source, int Count)
	 {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
		 memcpy(Destination.argValue, Source, Count);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __movsw(unsigned short * Destination, const unsigned short * Source, unsigned long Count)
	 public static __inline__ void __movsw(tangible.RefObject<Short> Destination, short Source, int Count)
	 {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
		 memcpy(Destination.argValue, Source, Count * (Short.SIZE / Byte.SIZE));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __movsd(unsigned long * Destination, const unsigned long * Source, unsigned long Count)
	 public static __inline__ void __movsd(tangible.RefObject<Integer> Destination, int Source, int Count)
	 {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
		 memcpy(Destination.argValue, Source, Count * (Integer.SIZE / Byte.SIZE));
	 }


	 /*** FS segment addressing ***/
	 /* On PowerPC, r13 points to TLS data, including the TEB at 0(r13) from what I
	  * can tell */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __writefsbyte(const unsigned long Offset, const unsigned char Data)
	 public static __inline__ void __writefsbyte(int Offset, byte Data)
	 {
		 String addr;
		 __asm__("\tadd %0,13,%1\n\tstb %2,0(%0)" : "=r" (addr) : "r" (Offset), "r" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __writefsword(const unsigned long Offset, const unsigned short Data)
	 public static __inline__ void __writefsword(int Offset, short Data)
	 {
		 String addr;
		 __asm__("\tadd %0,13,%1\n\tsth %2,0(%0)" : "=r" (addr) : "r" (Offset), "r" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __writefsdword(const unsigned long Offset, const unsigned long Data)
	 public static __inline__ void __writefsdword(int Offset, int Data)
	 {
		 String addr;
		 __asm__("\tadd %0,13,%1\n\tstw %2,0(%0)" : "=r" (addr) : "r" (Offset), "r" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char __readfsbyte(const unsigned long Offset)
	 public static __inline__ byte __readfsbyte(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short result;
		 short result;
		 __asm__("\tadd 7,13,%1\n" + "\tlbz %0,0(7)\n" : "=r" (result) : "r" (Offset) : "r7");
		 return (byte)result;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned short __readfsword(const unsigned long Offset)
	 public static __inline__ short __readfsword(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short result;
		 short result;
		 __asm__("\tadd 7,13,%1\n" + "\tlhz %0,0(7)\n" : "=r" (result) : "r" (Offset) : "r7");
		 return result;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long __readfsdword(const unsigned long Offset)
	 public static __inline__ int __readfsdword(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long result;
		 int result;
		 __asm__("\tadd 7,13,%1\n" + "\tlwz %0,0(7)\n" : "=r" (result) : "r" (Offset) : "r7");
		 return result;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __incfsbyte(const unsigned long Offset)
	 public static __inline__ void __incfsbyte(int Offset)
	 {
		 __writefsbyte(Offset, (byte)(__readfsbyte(Offset) + 1));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __incfsword(const unsigned long Offset)
	 public static __inline__ void __incfsword(int Offset)
	 {
		 __writefsword(Offset, (short)(__readfsword(Offset) + 1));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __incfsdword(const unsigned long Offset)
	 public static __inline__ void __incfsdword(int Offset)
	 {
		 __writefsdword(Offset, __readfsdword(Offset) + 1);
	 }

	 /* NOTE: the bizarre implementation of __addfsxxx mimics the broken Visual C++ behavior */
	 /* PPC Note: Not sure about the bizarre behavior.  We'll try to emulate it later */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __addfsbyte(const unsigned long Offset, const unsigned char Data)
	 public static __inline__ void __addfsbyte(int Offset, byte Data)
	 {
		 __writefsbyte(Offset, (byte)(__readfsbyte(Offset) + Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __addfsword(const unsigned long Offset, const unsigned short Data)
	 public static __inline__ void __addfsword(int Offset, short Data)
	 {
		 __writefsword(Offset, (short)(__readfsword(Offset) + Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __addfsdword(const unsigned long Offset, const unsigned int Data)
	 public static __inline__ void __addfsdword(int Offset, int Data)
	 {
		 __writefsdword(Offset, __readfsdword(Offset) + Data);
	 }


	 /*** Bit manipulation ***/
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _BitScanForward(unsigned long * const Index, const unsigned long Mask)
	 public static __inline__ byte _BitScanForward(final int Index, int Mask)
	 {
		 if (Mask == 0)
		 {
			 return 0;
		 }
		 else
		 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long mask = Mask;
		 int mask = Mask;
		 mask &= -mask;
		 Index = ((mask & 0xffff0000) != 0 ? 16 : 0) + ((mask & 0xff00ff00) != 0 ? 8 : 0) + ((mask & 0xf0f0f0f0) != 0 ? 4 : 0) + ((mask & 0xcccccccc) != 0 ? 2 : 0) + ((mask & 0xaaaaaaaa) != 0 ? 1 : 0);
		 return 1;
		 }
	 }

	 /* Thanks http://www.jjj.de/bitwizardry/files/bithigh.h */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _BitScanReverse(unsigned long * const Index, const unsigned long Mask)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'Index', so pointers on this parameter are left unchanged:
	 public static __inline__ byte _BitScanReverse(final int * Index, int Mask)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long check = 16, checkmask;
		 int check = 16;
		 int checkmask;
		 if (Mask == 0)
		 {
			 return 0;
		 }
		 else
		 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long mask = Mask;
		 int mask = Mask;
		 *Index = 0;
		 while (check != 0)
		 {
			 checkmask = ((1 << check) - 1) << check;
			 if ((mask & checkmask) != 0)
			 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			 mask >>>= check;
			 *Index += check;
			 }
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			 check >>>= 1;
		 }
		 return 1;
		 }
	 }

	 /* NOTE: again, the bizarre implementation follows Visual C++ */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _bittest(const long * const a, const long b)
	 public static __inline__ byte _bittest(final int a, int b)
	 {
		 return (a & (1 << b)) != 0;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _bittestandcomplement(long * const a, const long b)
	 public static __inline__ byte _bittestandcomplement(final int a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char ret = ((*a) & (1<<b)) != 0;
		 byte ret = (a & (1 << b)) != 0;
		 a ^= (1 << b);
		 return ret;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _bittestandreset(long * const a, const long b)
	 public static __inline__ byte _bittestandreset(final int a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char ret = ((*a) & (1<<b)) != 0;
		 byte ret = (a & (1 << b)) != 0;
		 a &= ~(1 << b);
		 return ret;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _bittestandset(long * const a, const long b)
	 public static __inline__ byte _bittestandset(final int a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char ret = ((*a) & (1<<b)) != 0;
		 byte ret = (a & (1 << b)) != 0;
		 a |= (1 << b);
		 return ret;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _rotl8(const unsigned char value, const unsigned char shift)
	 public static __inline__ byte _rotl8(byte value, byte shift)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (byte)((value << shift) | (value >>> (8 - shift)));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned short _rotl16(const unsigned short value, const unsigned char shift)
	 public static __inline__ short _rotl16(short value, byte shift)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (short)((value << shift) | (value >>> (16 - shift)));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char _rotr8(const unsigned char value, const unsigned char shift)
	 public static __inline__ byte _rotr8(byte value, byte shift)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (byte)((value >>> shift) | (value << (8 - shift)));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned short _rotr16(const unsigned short value, const unsigned char shift)
	 public static __inline__ short _rotr16(short value, byte shift)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (short)((value >>> shift) | (value << (16 - shift)));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long long __ll_lshift(const unsigned long long Mask, int Bit)
	 public static __inline__ long __ll_lshift(long Mask, int Bit)
	 {
		 return (long)(Mask << Bit);
	 }

	 public static __inline__ long __ll_rshift(long Mask, int Bit)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		 return Mask >> Bit;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long long __ull_rshift(const unsigned long long Mask, int Bit)
	 public static __inline__ long __ull_rshift(long Mask, int Bit)
	 {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (long)(Mask >>> Bit);
	 }


	 /*** 64-bit math ***/
	 public static __inline__ long __emul(int a, int b)
	 {
		 return a * b;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long long __emulu(const unsigned int a, const unsigned int b)
	 public static __inline__ long __emulu(int a, int b)
	 {
		 return a * b;
	 }


	 /*** Port I/O ***/
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned char __inbyte(const unsigned long Port)
	 public static __inline__ byte __inbyte(int Port)
	 {
		 int ret;
		 __asm__("mfmsr 5\n\t" + "andi. 6,5,0xffef\n\t" + "mtmsr 6\n\t" + "isync\n\t" + "sync\n\t" + "lbz   %0,0(%1)\n\t" + "mtmsr 5\n\t" : "=r" (ret) : "b" (Port));
		 return (byte)ret;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned short __inword(const unsigned long Port)
	 public static __inline__ short __inword(int Port)
	 {
		 int ret;
		 __asm__("mfmsr 5\n\t" + "andi. 6,5,0xffef\n\t" + "mtmsr 6\n\t" + "isync\n\t" + "sync\n\t" + "lhz   %0,0(%1)\n\t" + "mtmsr 5\n\t" : "=r" (ret) : "b" (Port));
		 return (short)ret;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long __indword(const unsigned long Port)
	 public static __inline__ int __indword(int Port)
	 {
		 int ret;
		 __asm__("mfmsr 5\n\t" + "andi. 6,5,0xffef\n\t" + "mtmsr 6\n\t" + "isync\n\t" + "sync\n\t" + "lwz   %0,0(%1)\n\t" + "mtmsr 5\n\t" : "=r" (ret) : "b" (Port));
		 return ret;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __inbytestring(unsigned long Port, unsigned char * Buffer, unsigned long Count)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'Buffer', so pointers on this parameter are left unchanged:
	 public static __inline__ void __inbytestring(int Port, byte * Buffer, int Count)
	 {
		 while ((Count--) != 0)
		 {
		 *Buffer++ = __inbyte(Port);
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __inwordstring(unsigned long Port, unsigned short * Buffer, unsigned long Count)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'Buffer', so pointers on this parameter are left unchanged:
	 public static __inline__ void __inwordstring(int Port, short * Buffer, int Count)
	 {
		 while ((Count--) != 0)
		 {
		 *Buffer++ = __inword(Port);
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __indwordstring(unsigned long Port, unsigned long * Buffer, unsigned long Count)
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'Buffer', so pointers on this parameter are left unchanged:
	 public static __inline__ void __indwordstring(int Port, int * Buffer, int Count)
	 {
		 while ((Count--) != 0)
		 {
		 *Buffer++ = __indword(Port);
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __outbyte(unsigned long const Port, const unsigned char Data)
	 public static __inline__ void __outbyte(int Port, byte Data)
	 {
		 __asm__("mfmsr 5\n\t" + "andi. 6,5,0xffef\n\t" + "mtmsr 6\n\t" + "sync\n\t" + "eieio\n\t" + "stb   %1,0(%0)\n\t" + "dcbst 0,%1\n\t" + "mtmsr 5\n\t" + "sync\n\t" + "eieio\n\t" : : "b" (Port), "r" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __outword(unsigned long const Port, const unsigned short Data)
	 public static __inline__ void __outword(int Port, short Data)
	 {
		 __asm__("mfmsr 5\n\t" + "andi. 6,5,0xffef\n\t" + "mtmsr 6\n\t" + "sync\n\t" + "eieio\n\t" + "sth   %1,0(%0)\n\t" + "dcbst 0,%1\n\t" + "mtmsr 5\n\t" + "sync\n\t" + "eieio\n\t" : : "b" (Port), "b" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __outdword(unsigned long const Port, const unsigned long Data)
	 public static __inline__ void __outdword(int Port, int Data)
	 {
		 __asm__("mfmsr 5\n\t" + "andi. 6,5,0xffef\n\t" + "mtmsr 6\n\t" + "sync\n\t" + "eieio\n\t" + "stw   %1,0(%0)\n\t" + "dcbst 0,%1\n\t" + "mtmsr 5\n\t" + "sync\n\t" + "eieio\n\t" : : "b" (Port), "b" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __outbytestring(unsigned long const Port, const unsigned char * const Buffer, const unsigned long Count)
	 public static __inline__ void __outbytestring(int Port, final byte Buffer, int Count)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long count = Count;
		 int count = Count;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned char *buffer = Buffer;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
		 byte * buffer = Buffer;
		 while ((count--) != 0)
		 {
		 __outbyte(Port, buffer++);
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __outwordstring(unsigned long const Port, const unsigned short * const Buffer, const unsigned long Count)
	 public static __inline__ void __outwordstring(int Port, final short Buffer, int Count)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long count = Count;
		 int count = Count;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned short *buffer = Buffer;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
		 short * buffer = Buffer;
		 while ((count--) != 0)
		 {
		 __outword(Port, buffer++);
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __outdwordstring(unsigned long const Port, const unsigned long * const Buffer, const unsigned long Count)
	 public static __inline__ void __outdwordstring(int Port, final int Buffer, int Count)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long count = Count;
		 int count = Count;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long *buffer = Buffer;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
		 int * buffer = Buffer;
		 while ((count--) != 0)
		 {
		 __outdword(Port, buffer++);
		 }
	 }


	 /*** System information ***/
	 public static __inline__ void __cpuid(int[] CPUInfo, int InfoType)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long lo32;
		 int lo32;
		 __asm__("mfpvr" : "=b" (lo32));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long long __rdtsc(void)
	 public static __inline__ long __rdtsc()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long lo32;
		 int lo32;
		 __asm__("mfdec %0" : "=b" (lo32));
		 return -lo32;
	 }


	 /*** Interrupts ***/
	 /* Finally decided to do this by enabling single step trap */
	 public static __inline__ void __debugbreak()
	 {

	 }

	 public static __inline__ void __int2c()
	 {
		 /* Not sure yet */
	 }

	 public static __inline__ void _disable()
	 {
		 __asm__ __volatile__ = new __asm__("mfmsr 0\n\t" + "li    8,0x7fff\n\t" + "and   0,8,0\n\t" + "mtmsr 0\n\t");
	 }

	 public static __inline__ void _enable()
	 {
		 __asm__ __volatile__ = new __asm__("mfmsr 8\n\t" + "ori   8,8,0x8000\n\t" + "mtmsr 8\n\t");
	 }

	 /*** Protected memory management ***/
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long __readsdr1(void)
	 public static __inline__ int __readsdr1()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__("mfsdr1 %0" : "=b" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __writesdr1(const unsigned long long Data)
	 public static __inline__ void __writesdr1(long Data)
	 {
		 __asm__("mtsdr1 %0" : : "b" (Data));
	 }

	 /*** System operations ***/
	 /* This likely has a different meaning from the X86 equivalent.  We'll keep
	  * the name cause it fits */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ unsigned long long __readmsr()
	 public static __inline__ long __readmsr()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long temp;
		 int temp;
		 __asm__("mfmsr %0" : "=b" (temp));
		 return temp;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern __inline__ void __writemsr(const unsigned long Value)
	 public static __inline__ void __writemsr(int Value)
	 {
		 __asm__("mtmsr %0" : : "b" (Value));
	 }

	 /* We'll make sure of the following:
	  * IO operations have completed
	  * Write operations through cache have completed
	  * We've reloaded anything in the data or instruction cache that might have
	  * changed in real ram.
	  */
	 public static __inline__ void __wbinvd()
	 {
		 __asm__("eieio\n\t" + "dcs\n\t" + "sync\n\t" + "isync\n\t");
	 }

	 public static __inline__ int _InterlockedAddLargeStatistic(final long Addend, int Value)
	 {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if false
	//     __asm__
	//     (
	//         "lock; add %[Value], %[Lo32];"
	//         "jae LABEL%=;"
	//         "lock; adc $0, %[Hi32];"
	//         "LABEL%=:;" :
	//         [Lo32] "=m" (*((volatile long *)(Addend) + 0)), [Hi32] "=m" (*((volatile long *)(Addend) + 1)) :
	//         [Value] "ir" (Value)
	//     );
	 ///#endif
		 return Value;
	 }

	 /*** Miscellaneous ***/
	 /* BUGBUG: only good for use in macros. Cannot be taken the address of */
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define __noop(...) ((void)0)

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define __assume(x) if (!(x)) __builtin_unreachable()

	 /* EOF */

	 /*** memcopy must be memmove ***/
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: Object* __cdecl memmove(Object* dest, const Object* source, int num);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
	// Object memmove(Object dest, Object source, int num);
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE Object* __cdecl memcpy(Object* dest, const Object* source, int num)
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
	 public static __INTRIN_INLINE Object memcpy(Object dest, Object source, int num)
	 {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memmove' has no equivalent in Java:
		 return memmove(dest, source, num);
	 }


	 /*** Stack frame juggling ***/
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define _ReturnAddress() (__builtin_return_address(0))
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define _AddressOfReturnAddress() (&(((void **)(__builtin_frame_address(0)))[1]))
	 /* TODO: __getcallerseflags but how??? */

	 /* Maybe the same for x86? */
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	 ///#define _alloca(s) __builtin_alloca(s)
	 ///#endif

	 /*** Memory barriers ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_ReadWriteBarrier)
	 public static __INTRIN_INLINE void _ReadWriteBarrier()
	 {
		 __asm__ __volatile__ = new __asm__("" : : : "memory");
	 }
	 ///#endif

	 /* GCC only supports full barriers */
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define _ReadBarrier _ReadWriteBarrier
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define _WriteBarrier _ReadWriteBarrier

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_mm_mfence)
	 public static __INTRIN_INLINE void _mm_mfence()
	 {
		 __asm__ __volatile__ = new __asm__("mfence" : : : "memory");
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_mm_lfence)
	 public static __INTRIN_INLINE void _mm_lfence()
	 {
		 _ReadWriteBarrier();
		 __asm__ __volatile__ = new __asm__("lfence");
		 _ReadWriteBarrier();
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_mm_sfence)
	 public static __INTRIN_INLINE void _mm_sfence()
	 {
		 _ReadWriteBarrier();
		 __asm__ __volatile__ = new __asm__("sfence");
		 _ReadWriteBarrier();
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE void __faststorefence()
	 {
		 int local;
		 __asm__ __volatile__ = new __asm__("lock; orl $0, %0;" : : "m"(local));
	 }
	 ///#endif


	 /*** Atomic operations ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__) > 40100

	 public static __INTRIN_INLINE char _InterlockedCompareExchange8(tangible.RefObject<String> Destination, char Exchange, char Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination.argValue, Comperand, Exchange);
	 }

	 public static __INTRIN_INLINE short _InterlockedCompareExchange16(tangible.RefObject<Short> Destination, short Exchange, short Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination.argValue, Comperand, Exchange);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedCompareExchange)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _InterlockedCompareExchange(volatile int * Destination, int Exchange, int Comperand)
	 public static __INTRIN_INLINE int _InterlockedCompareExchange(tangible.RefObject<Integer> Destination, int Exchange, int Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination.argValue, Comperand, Exchange);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedCompareExchangePointer)
	 public static __INTRIN_INLINE Object _InterlockedCompareExchangePointer(Object * Destination, Object Exchange, Object Comperand)
	 {
		 return (Object)__sync_val_compare_and_swap(Destination, Comperand, Exchange);
	 }
	 ///#endif

	 public static __INTRIN_INLINE char _InterlockedExchange8(tangible.RefObject<String> Target, char Value)
	 {
		 /* NOTE: __sync_lock_test_and_set would be an acquire barrier, so we force a full barrier */
		 __sync_synchronize();
		 return __sync_lock_test_and_set(Target.argValue, Value);
	 }

	 public static __INTRIN_INLINE short _InterlockedExchange16(tangible.RefObject<Short> Target, short Value)
	 {
		 /* NOTE: __sync_lock_test_and_set would be an acquire barrier, so we force a full barrier */
		 __sync_synchronize();
		 return __sync_lock_test_and_set(Target.argValue, Value);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchange)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _InterlockedExchange(volatile int * Target, int Value)
	 public static __INTRIN_INLINE int _InterlockedExchange(tangible.RefObject<Integer> Target, int Value)
	 {
		 /* NOTE: __sync_lock_test_and_set would be an acquire barrier, so we force a full barrier */
		 __sync_synchronize();
		 return __sync_lock_test_and_set(Target.argValue, Value);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchangePointer)
	 public static __INTRIN_INLINE Object _InterlockedExchangePointer(Object * Target, Object Value)
	 {
		 /* NOTE: __sync_lock_test_and_set would be an acquire barrier, so we force a full barrier */
		 __sync_synchronize();
		 return (Object)__sync_lock_test_and_set(Target, Value);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE long _InterlockedExchange64(tangible.RefObject<Long> Target, long Value)
	 {
		 /* NOTE: __sync_lock_test_and_set would be an acquire barrier, so we force a full barrier */
		 __sync_synchronize();
		 return __sync_lock_test_and_set(Target.argValue, Value);
	 }
	 ///#endif

	 public static __INTRIN_INLINE char _InterlockedExchangeAdd8(tangible.RefObject<String> Addend, char Value)
	 {
		 return __sync_fetch_and_add(Addend.argValue, Value);
	 }

	 public static __INTRIN_INLINE short _InterlockedExchangeAdd16(tangible.RefObject<Short> Addend, short Value)
	 {
		 return __sync_fetch_and_add(Addend.argValue, Value);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchangeAdd)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _InterlockedExchangeAdd(volatile int * Addend, int Value)
	 public static __INTRIN_INLINE int _InterlockedExchangeAdd(tangible.RefObject<Integer> Addend, int Value)
	 {
		 return __sync_fetch_and_add(Addend.argValue, Value);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE long _InterlockedExchangeAdd64(tangible.RefObject<Long> Addend, long Value)
	 {
		 return __sync_fetch_and_add(Addend.argValue, Value);
	 }
	 ///#endif

	 public static __INTRIN_INLINE char _InterlockedAnd8(tangible.RefObject<String> value, char mask)
	 {
		 return __sync_fetch_and_and(value.argValue, mask);
	 }

	 public static __INTRIN_INLINE short _InterlockedAnd16(tangible.RefObject<Short> value, short mask)
	 {
		 return __sync_fetch_and_and(value.argValue, mask);
	 }

	 public static __INTRIN_INLINE int _InterlockedAnd(tangible.RefObject<Integer> value, int mask)
	 {
		 return __sync_fetch_and_and(value.argValue, mask);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE long _InterlockedAnd64(tangible.RefObject<Long> value, long mask)
	 {
		 return __sync_fetch_and_and(value.argValue, mask);
	 }
	 ///#endif

	 public static __INTRIN_INLINE char _InterlockedOr8(tangible.RefObject<String> value, char mask)
	 {
		 return __sync_fetch_and_or(value.argValue, mask);
	 }

	 public static __INTRIN_INLINE short _InterlockedOr16(tangible.RefObject<Short> value, short mask)
	 {
		 return __sync_fetch_and_or(value.argValue, mask);
	 }

	 public static __INTRIN_INLINE int _InterlockedOr(tangible.RefObject<Integer> value, int mask)
	 {
		 return __sync_fetch_and_or(value.argValue, mask);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE long _InterlockedOr64(tangible.RefObject<Long> value, long mask)
	 {
		 return __sync_fetch_and_or(value.argValue, mask);
	 }
	 ///#endif

	 public static __INTRIN_INLINE char _InterlockedXor8(tangible.RefObject<String> value, char mask)
	 {
		 return __sync_fetch_and_xor(value.argValue, mask);
	 }

	 public static __INTRIN_INLINE short _InterlockedXor16(tangible.RefObject<Short> value, short mask)
	 {
		 return __sync_fetch_and_xor(value.argValue, mask);
	 }

	 public static __INTRIN_INLINE int _InterlockedXor(tangible.RefObject<Integer> value, int mask)
	 {
		 return __sync_fetch_and_xor(value.argValue, mask);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE long _InterlockedXor64(tangible.RefObject<Long> value, long mask)
	 {
		 return __sync_fetch_and_xor(value.argValue, mask);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedDecrement)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _InterlockedDecrement(volatile int * lpAddend)
	 public static __INTRIN_INLINE int _InterlockedDecrement(tangible.RefObject<Integer> lpAddend)
	 {
		 return __sync_sub_and_fetch(lpAddend.argValue, 1);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedIncrement)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _InterlockedIncrement(volatile int * lpAddend)
	 public static __INTRIN_INLINE int _InterlockedIncrement(tangible.RefObject<Integer> lpAddend)
	 {
		 return __sync_add_and_fetch(lpAddend.argValue, 1);
	 }
	 ///#endif

	 public static __INTRIN_INLINE short _InterlockedDecrement16(tangible.RefObject<Short> lpAddend)
	 {
		 return __sync_sub_and_fetch(lpAddend.argValue, 1);
	 }

	 public static __INTRIN_INLINE short _InterlockedIncrement16(tangible.RefObject<Short> lpAddend)
	 {
		 return __sync_add_and_fetch(lpAddend.argValue, 1);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE long _InterlockedDecrement64(tangible.RefObject<Long> lpAddend)
	 {
		 return __sync_sub_and_fetch(lpAddend.argValue, 1);
	 }

	 public static __INTRIN_INLINE long _InterlockedIncrement64(tangible.RefObject<Long> lpAddend)
	 {
		 return __sync_add_and_fetch(lpAddend.argValue, 1);
	 }
	 ///#endif

	 ///#else // (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__) > 40100

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedCompareExchange8)
	 public static __INTRIN_INLINE char _InterlockedCompareExchange8(tangible.RefObject<String> Destination, char Exchange, char Comperand)
	 {
		 char retval = Comperand;
		 __asm__("lock; cmpxchgb %b[Exchange], %[Destination]" : [retval] "+a" (retval) : [Destination.argValue] "m" Destination.argValue, [Exchange] "q" (Exchange) : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedCompareExchange16)
	 public static __INTRIN_INLINE short _InterlockedCompareExchange16(tangible.RefObject<Short> Destination, short Exchange, short Comperand)
	 {
		 short retval = Comperand;
		 __asm__("lock; cmpxchgw %w[Exchange], %[Destination]" : [retval] "+a" (retval) : [Destination.argValue] "m" Destination.argValue, [Exchange] "q" (Exchange): "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedCompareExchange)
	 public static __INTRIN_INLINE int _InterlockedCompareExchange(tangible.RefObject<Integer> Destination, int Exchange, int Comperand)
	 {
		 int retval = Comperand;
		 __asm__("lock; cmpxchgl %k[Exchange], %[Destination]" : [retval] "+a" (retval) : [Destination.argValue] "m" Destination.argValue, [Exchange] "q" (Exchange): "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedCompareExchangePointer)
	 public static __INTRIN_INLINE Object _InterlockedCompareExchangePointer(Object * Destination, Object Exchange, Object Comperand)
	 {
		 Object retval = (Object)Comperand;
		 __asm__("lock; cmpxchgl %k[Exchange], %[Destination]" : [retval] "=a" (retval) : "[retval]" (retval), [Destination] "m" Destination, [Exchange] "q" (Exchange) : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchange8)
	 public static __INTRIN_INLINE char _InterlockedExchange8(tangible.RefObject<String> Target, char Value)
	 {
		 char retval = Value;
		 __asm__("xchgb %[retval], %[Target]" : [retval] "+r" (retval) : [Target.argValue] "m" Target.argValue : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchange16)
	 public static __INTRIN_INLINE short _InterlockedExchange16(tangible.RefObject<Short> Target, short Value)
	 {
		 short retval = Value;
		 __asm__("xchgw %[retval], %[Target]" : [retval] "+r" (retval) : [Target.argValue] "m" Target.argValue : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchange)
	 public static __INTRIN_INLINE int _InterlockedExchange(tangible.RefObject<Integer> Target, int Value)
	 {
		 int retval = Value;
		 __asm__("xchgl %[retval], %[Target]" : [retval] "+r" (retval) : [Target.argValue] "m" Target.argValue : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchangePointer)
	 public static __INTRIN_INLINE Object _InterlockedExchangePointer(Object * Target, Object Value)
	 {
		 Object retval = Value;
		 __asm__("xchgl %[retval], %[Target]" : [retval] "+r" (retval) : [Target] "m" Target : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchangeAdd8)
	 public static __INTRIN_INLINE char _InterlockedExchangeAdd8(tangible.RefObject<String> Addend, char Value)
	 {
		 char retval = Value;
		 __asm__("lock; xaddb %[retval], %[Addend]" : [retval] "+r" (retval) : [Addend.argValue] "m" Addend.argValue : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchangeAdd16)
	 public static __INTRIN_INLINE short _InterlockedExchangeAdd16(tangible.RefObject<Short> Addend, short Value)
	 {
		 short retval = Value;
		 __asm__("lock; xaddw %[retval], %[Addend]" : [retval] "+r" (retval) : [Addend.argValue] "m" Addend.argValue : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedExchangeAdd)
	 public static __INTRIN_INLINE int _InterlockedExchangeAdd(tangible.RefObject<Integer> Addend, int Value)
	 {
		 int retval = Value;
		 __asm__("lock; xaddl %[retval], %[Addend]" : [retval] "+r" (retval) : [Addend.argValue] "m" Addend.argValue : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedAnd8)
	 public static __INTRIN_INLINE char _InterlockedAnd8(tangible.RefObject<String> value, char mask)
	 {
		 char x;
		 char y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange8(value, x & mask, x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedAnd16)
	 public static __INTRIN_INLINE short _InterlockedAnd16(tangible.RefObject<Short> value, short mask)
	 {
		 short x;
		 short y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange16(value, (short)(x & mask), x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedAnd)
	 public static __INTRIN_INLINE int _InterlockedAnd(tangible.RefObject<Integer> value, int mask)
	 {
		 int x;
		 int y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange(value, x & mask, x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedOr8)
	 public static __INTRIN_INLINE char _InterlockedOr8(tangible.RefObject<String> value, char mask)
	 {
		 char x;
		 char y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange8(value, x | mask, x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedOr16)
	 public static __INTRIN_INLINE short _InterlockedOr16(tangible.RefObject<Short> value, short mask)
	 {
		 short x;
		 short y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange16(value, (short)(x | mask), x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedOr)
	 public static __INTRIN_INLINE int _InterlockedOr(tangible.RefObject<Integer> value, int mask)
	 {
		 int x;
		 int y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange(value, x | mask, x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedXor8)
	 public static __INTRIN_INLINE char _InterlockedXor8(tangible.RefObject<String> value, char mask)
	 {
		 char x;
		 char y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange8(value, x ^ mask, x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedXor16)
	 public static __INTRIN_INLINE short _InterlockedXor16(tangible.RefObject<Short> value, short mask)
	 {
		 short x;
		 short y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange16(value, (short)(x ^ mask), x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedXor)
	 public static __INTRIN_INLINE int _InterlockedXor(tangible.RefObject<Integer> value, int mask)
	 {
		 int x;
		 int y;

		 y = value.argValue;

		 do
		 {
			 x = y;
			 y = _InterlockedCompareExchange(value, x ^ mask, x);
		 } while (y != x);

		 return y;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedDecrement)
	 public static __INTRIN_INLINE int _InterlockedDecrement(tangible.RefObject<Integer> lpAddend)
	 {
		 return _InterlockedExchangeAdd(lpAddend, -1) - 1;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedIncrement)
	 public static __INTRIN_INLINE int _InterlockedIncrement(tangible.RefObject<Integer> lpAddend)
	 {
		 return _InterlockedExchangeAdd(lpAddend, 1) + 1;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedDecrement16)
	 public static __INTRIN_INLINE short _InterlockedDecrement16(tangible.RefObject<Short> lpAddend)
	 {
		 return (short)(_InterlockedExchangeAdd16(lpAddend, -1) - 1);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedIncrement16)
	 public static __INTRIN_INLINE short _InterlockedIncrement16(tangible.RefObject<Short> lpAddend)
	 {
		 return (short)(_InterlockedExchangeAdd16(lpAddend, 1) + 1);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	 public static __INTRIN_INLINE long _InterlockedDecrement64(tangible.RefObject<Long> lpAddend)
	 {
		 return _InterlockedExchangeAdd64(lpAddend, -1) - 1;
	 }

	 public static __INTRIN_INLINE long _InterlockedIncrement64(tangible.RefObject<Long> lpAddend)
	 {
		 return _InterlockedExchangeAdd64(lpAddend, 1) + 1;
	 }
	 ///#endif

	 ///#endif // (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__) > 40100

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__) > 40100 && __x86_64__

	 public static __INTRIN_INLINE long _InterlockedCompareExchange64(tangible.RefObject<Long> Destination, long Exchange, long Comperand)
	 {
		 return __sync_val_compare_and_swap(Destination.argValue, Comperand, Exchange);
	 }

	 ///#else // (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__) > 40100 && defined(__x86_64__)

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_InterlockedCompareExchange64)
	 public static __INTRIN_INLINE long _InterlockedCompareExchange64(tangible.RefObject<Long> Destination, long Exchange, long Comperand)
	 {
		 long retval = Comperand;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __asm__( "lock; cmpxchg8b %[Destination]" : [retval] "+A" (retval) : [Destination] "m" (*Destination), "b" ((unsigned long)((Exchange >> 0) & 0xFFFFFFFF)), "c" ((unsigned long)((Exchange >> 32) & 0xFFFFFFFF)) : "memory" );
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		 __asm__("lock; cmpxchg8b %[Destination]" : [retval] "+A" (retval) : [Destination.argValue] "m" Destination.argValue, "b" ((int)((Exchange >> 0) & 0xFFFFFFFF)), "c" ((int)((Exchange >> 32) & 0xFFFFFFFF)) : "memory");

		 return retval;
	 }
	 ///#endif

	 ///#endif // (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__) > 40100 && defined(__x86_64__)

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __i386__
	 public static __INTRIN_INLINE int _InterlockedAddLargeStatistic(tangible.RefObject<Long> Addend, int Value)
	 {
		 __asm__("lock; addl %[Value], %[Lo32];" + "jae LABEL%=;" + "lock; adcl $0, %[Hi32];" + "LABEL%=:;" : [Lo32] "+m" ((volatile int)(Addend.argValue) + 0), [Hi32] "+m" ((volatile int)(Addend.argValue) + 1) : [Value] "ir" (Value) : "memory");

		 return Value;
	 }
	 ///#endif // __i386__

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _interlockedbittestandreset(volatile long * a, long b)
	 public static __INTRIN_INLINE byte _interlockedbittestandreset(tangible.RefObject<Integer> a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;
		 __asm__("lock; btrl %[b], %[a]; setb %b[retval]" : [retval] "=q" (retval), [a.argValue] "+m" a.argValue : [b] "Ir" (b) : "memory");
		 return retval;
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _interlockedbittestandreset64(volatile long long * a, long long b)
	 public static __INTRIN_INLINE byte _interlockedbittestandreset64(tangible.RefObject<Long> a, long b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;
		 __asm__("lock; btrq %[b], %[a]; setb %b[retval]" : [retval] "=r" (retval), [a.argValue] "+m" a.argValue : [b] "Ir" (b) : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_interlockedbittestandset)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _interlockedbittestandset(volatile long * a, long b)
	 public static __INTRIN_INLINE byte _interlockedbittestandset(tangible.RefObject<Integer> a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;
		 __asm__("lock; btsl %[b], %[a]; setc %b[retval]" : [retval] "=q" (retval), [a.argValue] "+m" a.argValue : [b] "Ir" (b) : "memory");
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _interlockedbittestandset64(volatile long long * a, long long b)
	 public static __INTRIN_INLINE byte _interlockedbittestandset64(tangible.RefObject<Long> a, long b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;
		 __asm__("lock; btsq %[b], %[a]; setc %b[retval]" : [retval] "=r" (retval), [a.argValue] "+m" a.argValue : [b] "Ir" (b) : "memory");
		 return retval;
	 }
	 ///#endif

	 /*** String operations ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__stosb)
	 /* NOTE: we don't set a memory clobber in the __stosX functions because Visual C++ doesn't */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __stosb(unsigned char * Dest, unsigned char Data, size_t Count)
	 public static __INTRIN_INLINE void __stosb(tangible.RefObject<Byte> Dest, byte Data, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; stosb" : [Dest.argValue] "=D" (Dest.argValue), [Count] "=c" (Count) : "[Dest]" (Dest.argValue), "a" (Data), "[Count]" (Count));
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __stosw(unsigned short * Dest, unsigned short Data, size_t Count)
	 public static __INTRIN_INLINE void __stosw(tangible.RefObject<Short> Dest, short Data, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; stosw" : [Dest.argValue] "=D" (Dest.argValue), [Count] "=c" (Count) : "[Dest]" (Dest.argValue), "a" (Data), "[Count]" (Count));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __stosd(unsigned long * Dest, unsigned long Data, size_t Count)
	 public static __INTRIN_INLINE void __stosd(tangible.RefObject<Integer> Dest, int Data, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; stosl" : [Dest.argValue] "=D" (Dest.argValue), [Count] "=c" (Count) : "[Dest]" (Dest.argValue), "a" (Data), "[Count]" (Count));
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __stosq(unsigned long long * Dest, unsigned long long Data, size_t Count)
	 public static __INTRIN_INLINE void __stosq(tangible.RefObject<Long> Dest, long Data, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; stosq" : [Dest.argValue] "=D" (Dest.argValue), [Count] "=c" (Count) : "[Dest]" (Dest.argValue), "a" (Data), "[Count]" (Count));
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __movsb(unsigned char * Destination, const unsigned char * Source, size_t Count)
	 public static __INTRIN_INLINE void __movsb(tangible.RefObject<Byte> Destination, byte Source, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; movsb" : [Destination.argValue] "=D" (Destination.argValue), [Source] "=S" (Source), [Count] "=c" (Count) : "[Destination]" (Destination.argValue), "[Source]" (Source), "[Count]" (Count));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __movsw(unsigned short * Destination, const unsigned short * Source, size_t Count)
	 public static __INTRIN_INLINE void __movsw(tangible.RefObject<Short> Destination, short Source, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; movsw" : [Destination.argValue] "=D" (Destination.argValue), [Source] "=S" (Source), [Count] "=c" (Count) : "[Destination]" (Destination.argValue), "[Source]" (Source), "[Count]" (Count));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __movsd(unsigned long * Destination, const unsigned long * Source, size_t Count)
	 public static __INTRIN_INLINE void __movsd(tangible.RefObject<Integer> Destination, int Source, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; movsd" : [Destination.argValue] "=D" (Destination.argValue), [Source] "=S" (Source), [Count] "=c" (Count) : "[Destination]" (Destination.argValue), "[Source]" (Source), "[Count]" (Count));
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __movsq(unsigned long * Destination, const unsigned long * Source, size_t Count)
	 public static __INTRIN_INLINE void __movsq(tangible.RefObject<Integer> Destination, int Source, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; movsq" : [Destination.argValue] "=D" (Destination.argValue), [Source] "=S" (Source), [Count] "=c" (Count) : "[Destination]" (Destination.argValue), "[Source]" (Source), "[Count]" (Count));
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__

	 /*** GS segment addressing ***/

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writegsbyte(unsigned long Offset, unsigned char Data)
	 public static __INTRIN_INLINE void __writegsbyte(int Offset, byte Data)
	 {
		 __asm__ __volatile__ = new __asm__("movb %b[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writegsword(unsigned long Offset, unsigned short Data)
	 public static __INTRIN_INLINE void __writegsword(int Offset, short Data)
	 {
		 __asm__ __volatile__ = new __asm__("movw %w[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writegsdword(unsigned long Offset, unsigned long Data)
	 public static __INTRIN_INLINE void __writegsdword(int Offset, int Data)
	 {
		 __asm__ __volatile__ = new __asm__("movl %k[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writegsqword(unsigned long Offset, unsigned long long Data)
	 public static __INTRIN_INLINE void __writegsqword(int Offset, long Data)
	 {
		 __asm__ __volatile__ = new __asm__("movq %q[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char __readgsbyte(unsigned long Offset)
	 public static __INTRIN_INLINE byte __readgsbyte(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char value;
		 byte value;
		 __asm__ __volatile__ = new __asm__("movb %%gs:%a[Offset], %b[value]" : [value] "=r" (value) : [Offset] "ir" (Offset));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __readgsword(unsigned long Offset)
	 public static __INTRIN_INLINE short __readgsword(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short value;
		 short value;
		 __asm__ __volatile__ = new __asm__("movw %%gs:%a[Offset], %w[value]" : [value] "=r" (value) : [Offset] "ir" (Offset));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __readgsdword(unsigned long Offset)
	 public static __INTRIN_INLINE int __readgsdword(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__ __volatile__ = new __asm__("movl %%gs:%a[Offset], %k[value]" : [value] "=r" (value) : [Offset] "ir" (Offset));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readgsqword(unsigned long Offset)
	 public static __INTRIN_INLINE long __readgsqword(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long value;
		 long value;
		 __asm__ __volatile__ = new __asm__("movq %%gs:%a[Offset], %q[value]" : [value] "=r" (value) : [Offset] "ir" (Offset));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __incgsbyte(unsigned long Offset)
	 public static __INTRIN_INLINE void __incgsbyte(int Offset)
	 {
		 __asm__ __volatile__ = new __asm__("incb %%gs:%a[Offset]" : : [Offset] "ir" (Offset) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __incgsword(unsigned long Offset)
	 public static __INTRIN_INLINE void __incgsword(int Offset)
	 {
		 __asm__ __volatile__ = new __asm__("incw %%gs:%a[Offset]" : : [Offset] "ir" (Offset) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __incgsdword(unsigned long Offset)
	 public static __INTRIN_INLINE void __incgsdword(int Offset)
	 {
		 __asm__ __volatile__ = new __asm__("incl %%gs:%a[Offset]" : : [Offset] "ir" (Offset) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __incgsqword(unsigned long Offset)
	 public static __INTRIN_INLINE void __incgsqword(int Offset)
	 {
		 __asm__ __volatile__ = new __asm__("incq %%gs:%a[Offset]" : : [Offset] "ir" (Offset) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __addgsbyte(unsigned long Offset, unsigned char Data)
	 public static __INTRIN_INLINE void __addgsbyte(int Offset, byte Data)
	 {
		 __asm__ __volatile__ = new __asm__("addb %b[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __addgsword(unsigned long Offset, unsigned short Data)
	 public static __INTRIN_INLINE void __addgsword(int Offset, short Data)
	 {
		 __asm__ __volatile__ = new __asm__("addw %w[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __addgsdword(unsigned long Offset, unsigned int Data)
	 public static __INTRIN_INLINE void __addgsdword(int Offset, int Data)
	 {
		 __asm__ __volatile__ = new __asm__("addl %k[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __addgsqword(unsigned long Offset, unsigned long long Data)
	 public static __INTRIN_INLINE void __addgsqword(int Offset, long Data)
	 {
		 __asm__ __volatile__ = new __asm__("addq %k[Data], %%gs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	 ///#else // defined(__x86_64__)

	 /*** FS segment addressing ***/

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writefsbyte(unsigned long Offset, unsigned char Data)
	 public static __INTRIN_INLINE void __writefsbyte(int Offset, byte Data)
	 {
		 __asm__ __volatile__ = new __asm__("movb %b[Data], %%fs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "iq" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writefsword(unsigned long Offset, unsigned short Data)
	 public static __INTRIN_INLINE void __writefsword(int Offset, short Data)
	 {
		 __asm__ __volatile__ = new __asm__("movw %w[Data], %%fs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writefsdword(unsigned long Offset, unsigned long Data)
	 public static __INTRIN_INLINE void __writefsdword(int Offset, int Data)
	 {
		 __asm__ __volatile__ = new __asm__("movl %k[Data], %%fs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "ir" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__readfsbyte)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char __readfsbyte(unsigned long Offset)
	 public static __INTRIN_INLINE byte __readfsbyte(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char value;
		 byte value;
		 __asm__ __volatile__ = new __asm__("movb %%fs:%a[Offset], %b[value]" : [value] "=q" (value) : [Offset] "ir" (Offset));
		 return value;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__readfsword)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __readfsword(unsigned long Offset)
	 public static __INTRIN_INLINE short __readfsword(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short value;
		 short value;
		 __asm__ __volatile__ = new __asm__("movw %%fs:%a[Offset], %w[value]" : [value] "=r" (value) : [Offset] "ir" (Offset));
		 return value;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__readfsdword)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __readfsdword(unsigned long Offset)
	 public static __INTRIN_INLINE int __readfsdword(int Offset)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__ __volatile__ = new __asm__("movl %%fs:%a[Offset], %k[value]" : [value] "=r" (value) : [Offset] "ir" (Offset));
		 return value;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __incfsbyte(unsigned long Offset)
	 public static __INTRIN_INLINE void __incfsbyte(int Offset)
	 {
		 __asm__ __volatile__ = new __asm__("incb %%fs:%a[Offset]" : : [Offset] "ir" (Offset) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __incfsword(unsigned long Offset)
	 public static __INTRIN_INLINE void __incfsword(int Offset)
	 {
		 __asm__ __volatile__ = new __asm__("incw %%fs:%a[Offset]" : : [Offset] "ir" (Offset) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __incfsdword(unsigned long Offset)
	 public static __INTRIN_INLINE void __incfsdword(int Offset)
	 {
		 __asm__ __volatile__ = new __asm__("incl %%fs:%a[Offset]" : : [Offset] "ir" (Offset) : "memory");
	 }

	 /* NOTE: the bizarre implementation of __addfsxxx mimics the broken Visual C++ behavior */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __addfsbyte(unsigned long Offset, unsigned char Data)
	 public static __INTRIN_INLINE void __addfsbyte(int Offset, byte Data)
	 {
		 if (!__builtin_constant_p(Offset))
		 {
			 __asm__ __volatile__ = new __asm__("addb %b[Offset], %%fs:%a[Offset]" : : [Offset] "r" (Offset) : "memory");
		 }
		 else
		 {
			 __asm__ __volatile__ = new __asm__("addb %b[Data], %%fs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "iq" (Data) : "memory");
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __addfsword(unsigned long Offset, unsigned short Data)
	 public static __INTRIN_INLINE void __addfsword(int Offset, short Data)
	 {
		 if (!__builtin_constant_p(Offset))
		 {
			 __asm__ __volatile__ = new __asm__("addw %w[Offset], %%fs:%a[Offset]" : : [Offset] "r" (Offset) : "memory");
		 }
		 else
		 {
			 __asm__ __volatile__ = new __asm__("addw %w[Data], %%fs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "iq" (Data) : "memory");
		 }
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __addfsdword(unsigned long Offset, unsigned long Data)
	 public static __INTRIN_INLINE void __addfsdword(int Offset, int Data)
	 {
		 if (!__builtin_constant_p(Offset))
		 {
			 __asm__ __volatile__ = new __asm__("addl %k[Offset], %%fs:%a[Offset]" : : [Offset] "r" (Offset) : "memory");
		 }
		 else
		 {
			 __asm__ __volatile__ = new __asm__("addl %k[Data], %%fs:%a[Offset]" : : [Offset] "ir" (Offset), [Data] "iq" (Data) : "memory");
		 }
	 }

	 ///#endif // defined(__x86_64__)


	 /*** Bit manipulation ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_BitScanForward)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _BitScanForward(unsigned long * Index, unsigned long Mask)
	 public static __INTRIN_INLINE byte _BitScanForward(tangible.RefObject<Integer> Index, int Mask)
	 {
		 __asm__("bsfl %[Mask], %[Index]" : [Index.argValue] "=r" Index.argValue : [Mask] "mr" (Mask));
		 return (byte)(Mask != 0 ? 1 : 0);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_BitScanReverse)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _BitScanReverse(unsigned long * Index, unsigned long Mask)
	 public static __INTRIN_INLINE byte _BitScanReverse(tangible.RefObject<Integer> Index, int Mask)
	 {
		 __asm__("bsrl %[Mask], %[Index]" : [Index.argValue] "=r" Index.argValue : [Mask] "mr" (Mask));
		 return (byte)(Mask != 0 ? 1 : 0);
	 }
	 ///#endif

	 /* NOTE: again, the bizarre implementation follows Visual C++ */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittest(const long * a, long b)
	 public static __INTRIN_INLINE byte _bittest(int a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("bt %[b], %[a]; setb %b[retval]" : [retval] "=q" (retval) : [a] "mr" (*(a + (b / 32))), [b] "Ir" (b % 32));
		 }
		 else
		 {
			 __asm__("bt %[b], %[a]; setb %b[retval]" : [retval] "=q" (retval) : [a] "m" a, [b] "r" (b));
		 }

		 return retval;
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _BitScanForward64(unsigned long * Index, unsigned long long Mask)
	 public static __INTRIN_INLINE byte _BitScanForward64(tangible.RefObject<Integer> Index, long Mask)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long Index64;
		 long Index64;
		 __asm__("bsfq %[Mask], %[Index]" : [Index.argValue] "=r" (Index64) : [Mask] "mr" (Mask));
		 Index.argValue = (int)Index64;
		 return (byte)(Mask != 0 ? 1 : 0);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _BitScanReverse64(unsigned long * Index, unsigned long long Mask)
	 public static __INTRIN_INLINE byte _BitScanReverse64(tangible.RefObject<Integer> Index, long Mask)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long Index64;
		 long Index64;
		 __asm__("bsrq %[Mask], %[Index]" : [Index.argValue] "=r" (Index64) : [Mask] "mr" (Mask));
		 Index.argValue = (int)Index64;
		 return (byte)(Mask != 0 ? 1 : 0);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittest64(const long long * a, long long b)
	 public static __INTRIN_INLINE byte _bittest64(long a, long b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("bt %[b], %[a]; setb %b[retval]" : [retval] "=q" (retval) : [a] "mr" (*(a + (b / 64))), [b] "Ir" (b % 64));
		 }
		 else
		 {
			 __asm__("bt %[b], %[a]; setb %b[retval]" : [retval] "=q" (retval) : [a] "m" a, [b] "r" (b));
		 }

		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittestandcomplement(long * a, long b)
	 public static __INTRIN_INLINE byte _bittestandcomplement(tangible.RefObject<Integer> a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("btc %[b], %[a]; setb %b[retval]" : [a.argValue] "+mr" (*(a.argValue + (b / 32))), [retval] "=q" (retval) : [b] "Ir" (b % 32));
		 }
		 else
		 {
			 __asm__("btc %[b], %[a]; setb %b[retval]" : [a.argValue] "+m" a.argValue, [retval] "=q" (retval) : [b] "r" (b));
		 }

		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittestandreset(long * a, long b)
	 public static __INTRIN_INLINE byte _bittestandreset(tangible.RefObject<Integer> a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("btr %[b], %[a]; setb %b[retval]" : [a.argValue] "+mr" (*(a.argValue + (b / 32))), [retval] "=q" (retval) : [b] "Ir" (b % 32));
		 }
		 else
		 {
			 __asm__("btr %[b], %[a]; setb %b[retval]" : [a.argValue] "+m" a.argValue, [retval] "=q" (retval) : [b] "r" (b));
		 }

		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittestandset(long * a, long b)
	 public static __INTRIN_INLINE byte _bittestandset(tangible.RefObject<Integer> a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("bts %[b], %[a]; setb %b[retval]" : [a.argValue] "+mr" (*(a.argValue + (b / 32))), [retval] "=q" (retval) : [b] "Ir" (b % 32));
		 }
		 else
		 {
			 __asm__("bts %[b], %[a]; setb %b[retval]" : [a.argValue] "+m" a.argValue, [retval] "=q" (retval) : [b] "r" (b));
		 }

		 return retval;
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittestandset64(long long * a, long long b)
	 public static __INTRIN_INLINE byte _bittestandset64(tangible.RefObject<Long> a, long b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("btsq %[b], %[a]; setb %b[retval]" : [a.argValue] "+mr" (*(a.argValue + (b / 64))), [retval] "=q" (retval) : [b] "Ir" (b % 64));
		 }
		 else
		 {
			 __asm__("btsq %[b], %[a]; setb %b[retval]" : [a.argValue] "+m" a.argValue, [retval] "=q" (retval) : [b] "r" (b));
		 }

		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittestandreset64(long long * a, long long b)
	 public static __INTRIN_INLINE byte _bittestandreset64(tangible.RefObject<Long> a, long b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("btrq %[b], %[a]; setb %b[retval]" : [a.argValue] "+mr" (*(a.argValue + (b / 64))), [retval] "=q" (retval) : [b] "Ir" (b % 64));
		 }
		 else
		 {
			 __asm__("btrq %[b], %[a]; setb %b[retval]" : [a.argValue] "+m" a.argValue, [retval] "=q" (retval) : [b] "r" (b));
		 }

		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char _bittestandcomplement64(long long * a, long long b)
	 public static __INTRIN_INLINE byte _bittestandcomplement64(tangible.RefObject<Long> a, long b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;

		 if (__builtin_constant_p(b))
		 {
			 __asm__("btcq %[b], %[a]; setb %b[retval]" : [a.argValue] "+mr" (*(a.argValue + (b / 64))), [retval] "=q" (retval) : [b] "Ir" (b % 64));
		 }
		 else
		 {
			 __asm__("btcq %[b], %[a]; setb %b[retval]" : [a.argValue] "+m" a.argValue, [retval] "=q" (retval) : [b] "r" (b));
		 }

		 return retval;
	 }

	 ///#endif // __x86_64__

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotl8)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char __cdecl _rotl8(unsigned char value, unsigned char shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE byte __cdecl _rotl8(byte value, byte shift)
	 public static __INTRIN_INLINE byte _rotl8(byte value, byte shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;
		 __asm__("rolb %b[shift], %b[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotl16)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __cdecl _rotl16(unsigned short value, unsigned char shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ushort __cdecl _rotl16(ushort value, byte shift)
	 public static __INTRIN_INLINE short _rotl16(short value, byte shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short retval;
		 short retval;
		 __asm__("rolw %b[shift], %w[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotl)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned int __cdecl _rotl(unsigned int value, int shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE uint __cdecl _rotl(uint value, int shift)
	 public static __INTRIN_INLINE int _rotl(int value, int shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned int retval;
		 int retval;
		 __asm__("roll %b[shift], %k[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long _rotl64(unsigned long long value, int shift)
	 public static __INTRIN_INLINE long _rotl64(long value, int shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__("rolq %b[shift], %k[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#else // __x86_64__
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotl64)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __cdecl _rotl64(unsigned long long value, int shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ulong __cdecl _rotl64(ulong value, int shift)
	 public static __INTRIN_INLINE long _rotl64(long value, int shift)
	 {
		 /* FIXME: this is probably not optimal */
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (long)((value << shift) | (value >>> (64 - shift)));
	 }
	 ///#endif // !HAS_BUILTIN(_rotl64)
	 ///#endif // __x86_64__

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotr)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned int __cdecl _rotr(unsigned int value, int shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE uint __cdecl _rotr(uint value, int shift)
	 public static __INTRIN_INLINE int _rotr(int value, int shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned int retval;
		 int retval;
		 __asm__("rorl %b[shift], %k[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotr8)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char __cdecl _rotr8(unsigned char value, unsigned char shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE byte __cdecl _rotr8(byte value, byte shift)
	 public static __INTRIN_INLINE byte _rotr8(byte value, byte shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char retval;
		 byte retval;
		 __asm__("rorb %b[shift], %b[retval]" : [retval] "=qm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotr16)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __cdecl _rotr16(unsigned short value, unsigned char shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ushort __cdecl _rotr16(ushort value, byte shift)
	 public static __INTRIN_INLINE short _rotr16(short value, byte shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short retval;
		 short retval;
		 __asm__("rorw %b[shift], %w[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long _rotr64(unsigned long long value, int shift)
	 public static __INTRIN_INLINE long _rotr64(long value, int shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__("rorq %b[shift], %k[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#else // __x86_64__
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_rotr64)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __cdecl _rotr64(unsigned long long value, int shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ulong __cdecl _rotr64(ulong value, int shift)
	 public static __INTRIN_INLINE long _rotr64(long value, int shift)
	 {
		 /* FIXME: this is probably not optimal */
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 return (long)((value >>> shift) | (value << (64 - shift)));
	 }
	 ///#endif // !HAS_BUILTIN(_rotr64)
	 ///#endif // __x86_64__

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_lrotl)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __cdecl _lrotl(unsigned long value, int shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE uint __cdecl _lrotl(uint value, int shift)
	 public static __INTRIN_INLINE int _lrotl(int value, int shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long retval;
		 int retval;
		 __asm__("roll %b[shift], %k[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_lrotr)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __cdecl _lrotr(unsigned long value, int shift)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE uint __cdecl _lrotr(uint value, int shift)
	 public static __INTRIN_INLINE int _lrotr(int value, int shift)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long retval;
		 int retval;
		 __asm__("rorl %b[shift], %k[retval]" : [retval] "=rm" (retval) : "[retval]" (value), [shift] "Nc" (shift));
		 return retval;
	 }
	 ///#endif

	 /*
	     NOTE: in __ll_lshift, __ll_rshift and __ull_rshift we use the "A"
	     constraint (edx:eax) for the Mask argument, because it's the only way GCC
	     can pass 64-bit operands around - passing the two 32 bit parts separately
	     just confuses it. Also we declare Bit as an int and then truncate it to
	     match Visual C++ behavior
	 */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __ll_lshift(unsigned long long Mask, int Bit)
	 public static __INTRIN_INLINE long __ll_lshift(long Mask, int Bit)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval = Mask;
		 long retval = Mask;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __asm__( "shldl %b[Bit], %%eax, %%edx; sall %b[Bit], %%eax" : "+A" (retval) : [Bit] "Nc" ((unsigned char)((unsigned long)Bit) & 0xFF) );
		 __asm__("shldl %b[Bit], %%eax, %%edx; sall %b[Bit], %%eax" : "+A" (retval) : [Bit] "Nc" ((byte)((int)Bit) & 0xFF));

		 return retval;
	 }

	 public static __INTRIN_INLINE long __ll_rshift(long Mask, int Bit)
	 {
		 long retval = Mask;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __asm__( "shrdl %b[Bit], %%edx, %%eax; sarl %b[Bit], %%edx" : "+A" (retval) : [Bit] "Nc" ((unsigned char)((unsigned long)Bit) & 0xFF) );
		 __asm__("shrdl %b[Bit], %%edx, %%eax; sarl %b[Bit], %%edx" : "+A" (retval) : [Bit] "Nc" ((byte)((int)Bit) & 0xFF));

		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __ull_rshift(unsigned long long Mask, int Bit)
	 public static __INTRIN_INLINE long __ull_rshift(long Mask, int Bit)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval = Mask;
		 long retval = Mask;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __asm__( "shrdl %b[Bit], %%edx, %%eax; shrl %b[Bit], %%edx" : "+A" (retval) : [Bit] "Nc" ((unsigned char)((unsigned long)Bit) & 0xFF) );
		 __asm__("shrdl %b[Bit], %%edx, %%eax; shrl %b[Bit], %%edx" : "+A" (retval) : [Bit] "Nc" ((byte)((int)Bit) & 0xFF));

		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __cdecl _byteswap_ushort(unsigned short value)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ushort __cdecl _byteswap_ushort(ushort value)
	 public static __INTRIN_INLINE short _byteswap_ushort(short value)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short retval;
		 short retval;
		 __asm__("rorw $8, %w[retval]" : [retval] "=rm" (retval) : "[retval]" (value));
		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __cdecl _byteswap_ulong(unsigned long value)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE uint __cdecl _byteswap_ulong(uint value)
	 public static __INTRIN_INLINE int _byteswap_ulong(int value)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long retval;
		 int retval;
		 __asm__("bswapl %[retval]" : [retval] "=r" (retval) : "[retval]" (value));
		 return retval;
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long _byteswap_uint64(unsigned long long value)
	 public static __INTRIN_INLINE long _byteswap_uint64(long value)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__("bswapq %[retval]" : [retval] "=r" (retval) : "[retval]" (value));
		 return retval;
	 }
	// {
	// //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	// //ORIGINAL LINE: unsigned long long int64part;
	//	 ulong int64part;
	//	 struct
	//	 {
	// //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	// //ORIGINAL LINE: unsigned long lowpart;
	//		 uint lowpart;
	// //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	// //ORIGINAL LINE: unsigned long hipart;
	//		 uint hipart;
	//	 };
	// }
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ulong __cdecl _byteswap_uint64(ulong value)
	 public static __INTRIN_INLINE long _byteswap_uint64(long value)
	 {
		  retval;
		 retval.int64part = value;
		 __asm__("bswapl %[lowpart]\n" + "bswapl %[hipart]\n" : [lowpart] "=r" (retval.hipart), [hipart] "=r" (retval.lowpart) : "[lowpart]" (retval.lowpart), "[hipart]" (retval.hipart));
		 return retval.int64part;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned int __lzcnt(unsigned int value)
	 public static __INTRIN_INLINE int __lzcnt(int value)
	 {
		 return __builtin_clz(value);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __lzcnt16(unsigned short value)
	 public static __INTRIN_INLINE short __lzcnt16(short value)
	 {
		 return __builtin_clz(value);
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__popcnt)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned int __popcnt(unsigned int value)
	 public static __INTRIN_INLINE int __popcnt(int value)
	 {
		 return __builtin_popcount(value);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__popcnt16)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __popcnt16(unsigned short value)
	 public static __INTRIN_INLINE short __popcnt16(short value)
	 {
		 return __builtin_popcount(value);
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __lzcnt64(unsigned long long value)
	 public static __INTRIN_INLINE long __lzcnt64(long value)
	 {
		 return __builtin_clzll(value);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __popcnt64(unsigned long long value)
	 public static __INTRIN_INLINE long __popcnt64(long value)
	 {
		 return __builtin_popcountll(value);
	 }
	 ///#endif

	 /*** 64-bit math ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__emul)
	 public static __INTRIN_INLINE long __emul(int a, int b)
	 {
		 long retval;
		 __asm__("imull %[b]" : "=A" (retval) : [a] "a" (a), [b] "rm" (b));
		 return retval;
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__emulu)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __emulu(unsigned int a, unsigned int b)
	 public static __INTRIN_INLINE long __emulu(int a, int b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__("mull %[b]" : "=A" (retval) : [a] "a" (a), [b] "rm" (b));
		 return retval;
	 }
	 ///#endif

//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE long __cdecl _abs64(long value)
	 public static __INTRIN_INLINE long _abs64(long value)
	 {
		 return (value >= 0) ? value : -value;
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__

	 public static __INTRIN_INLINE long __mulh(long a, long b)
	 {
		 long retval;
		 __asm__("imulq %[b]" : "=d" (retval) : [a] "a" (a), [b] "rm" (b));
		 return retval;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __umulh(unsigned long long a, unsigned long long b)
	 public static __INTRIN_INLINE long __umulh(long a, long b)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__("mulq %[b]" : "=d" (retval) : [a] "a" (a), [b] "rm" (b));
		 return retval;
	 }

	 ///#endif

	 /*** Port I/O ***/

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned char __inbyte(unsigned short Port)
	 public static __INTRIN_INLINE byte __inbyte(short Port)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char byte;
		 byte byte_Renamed;
		 __asm__ __volatile__ = new __asm__("inb %w[Port], %b[byte]" : [byte] "=a" (byte) : [Port] "Nd" (Port));
		 return byte;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __inword(unsigned short Port)
	 public static __INTRIN_INLINE short __inword(short Port)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned short word;
		 short word;
		 __asm__ __volatile__ = new __asm__("inw %w[Port], %w[word]" : [word] "=a" (word) : [Port] "Nd" (Port));
		 return word;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __indword(unsigned short Port)
	 public static __INTRIN_INLINE int __indword(short Port)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long dword;
		 int dword;
		 __asm__ __volatile__ = new __asm__("inl %w[Port], %k[dword]" : [dword] "=a" (dword) : [Port] "Nd" (Port));
		 return dword;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __inbytestring(unsigned short Port, unsigned char * Buffer, unsigned long Count)
	 public static __INTRIN_INLINE void __inbytestring(short Port, tangible.RefObject<Byte> Buffer, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; insb" : [Buffer.argValue] "=D" (Buffer.argValue), [Count] "=c" (Count) : "d" (Port), "[Buffer]" (Buffer.argValue), "[Count]" (Count) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __inwordstring(unsigned short Port, unsigned short * Buffer, unsigned long Count)
	 public static __INTRIN_INLINE void __inwordstring(short Port, tangible.RefObject<Short> Buffer, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; insw" : [Buffer.argValue] "=D" (Buffer.argValue), [Count] "=c" (Count) : "d" (Port), "[Buffer]" (Buffer.argValue), "[Count]" (Count) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __indwordstring(unsigned short Port, unsigned long * Buffer, unsigned long Count)
	 public static __INTRIN_INLINE void __indwordstring(short Port, tangible.RefObject<Integer> Buffer, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; insl" : [Buffer.argValue] "=D" (Buffer.argValue), [Count] "=c" (Count) : "d" (Port), "[Buffer]" (Buffer.argValue), "[Count]" (Count) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __outbyte(unsigned short Port, unsigned char Data)
	 public static __INTRIN_INLINE void __outbyte(short Port, byte Data)
	 {
		 __asm__ __volatile__ = new __asm__("outb %b[Data], %w[Port]" : : [Port] "Nd" (Port), [Data] "a" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __outword(unsigned short Port, unsigned short Data)
	 public static __INTRIN_INLINE void __outword(short Port, short Data)
	 {
		 __asm__ __volatile__ = new __asm__("outw %w[Data], %w[Port]" : : [Port] "Nd" (Port), [Data] "a" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __outdword(unsigned short Port, unsigned long Data)
	 public static __INTRIN_INLINE void __outdword(short Port, int Data)
	 {
		 __asm__ __volatile__ = new __asm__("outl %k[Data], %w[Port]" : : [Port] "Nd" (Port), [Data] "a" (Data));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __outbytestring(unsigned short Port, unsigned char * Buffer, unsigned long Count)
	 public static __INTRIN_INLINE void __outbytestring(short Port, tangible.RefObject<Byte> Buffer, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; outsb" : : [Port] "d" (Port), [Buffer.argValue] "S" (Buffer.argValue), "c" (Count));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __outwordstring(unsigned short Port, unsigned short * Buffer, unsigned long Count)
	 public static __INTRIN_INLINE void __outwordstring(short Port, tangible.RefObject<Short> Buffer, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; outsw" : : [Port] "d" (Port), [Buffer.argValue] "S" (Buffer.argValue), "c" (Count));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __outdwordstring(unsigned short Port, unsigned long * Buffer, unsigned long Count)
	 public static __INTRIN_INLINE void __outdwordstring(short Port, tangible.RefObject<Integer> Buffer, int Count)
	 {
		 __asm__ __volatile__ = new __asm__("rep; outsl" : : [Port] "d" (Port), [Buffer.argValue] "S" (Buffer.argValue), "c" (Count));
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _inp(unsigned short Port)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _inp(ushort Port)
	 public static __INTRIN_INLINE int _inp(short Port)
	 {
		 return __inbyte(Port);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __cdecl _inpw(unsigned short Port)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ushort __cdecl _inpw(ushort Port)
	 public static __INTRIN_INLINE short _inpw(short Port)
	 {
		 return __inword(Port);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __cdecl _inpd(unsigned short Port)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE uint __cdecl _inpd(ushort Port)
	 public static __INTRIN_INLINE int _inpd(short Port)
	 {
		 return __indword(Port);
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _outp(unsigned short Port, int databyte)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE int __cdecl _outp(ushort Port, int databyte)
	 public static __INTRIN_INLINE int _outp(short Port, int databyte)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __outbyte(Port, (unsigned char)databyte);
		 __outbyte(Port, (byte)databyte);
		 return databyte;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned short __cdecl _outpw(unsigned short Port, unsigned short dataword)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE ushort __cdecl _outpw(ushort Port, ushort dataword)
	 public static __INTRIN_INLINE short _outpw(short Port, short dataword)
	 {
		 __outword(Port, dataword);
		 return dataword;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __cdecl _outpd(unsigned short Port, unsigned long dataword)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE uint __cdecl _outpd(ushort Port, uint dataword)
	 public static __INTRIN_INLINE int _outpd(short Port, int dataword)
	 {
		 __outdword(Port, dataword);
		 return dataword;
	 }


	 /*** System information ***/

	 public static __INTRIN_INLINE void __cpuid(int[] CPUInfo, int InfoType)
	 {
		 __asm__ __volatile__ = new __asm__("cpuid" : "=a" (CPUInfo[0]), "=b" (CPUInfo[1]), "=c" (CPUInfo[2]), "=d" (CPUInfo[3]) : "a" (InfoType));
	 }

	 public static __INTRIN_INLINE void __cpuidex(int[] CPUInfo, int InfoType, int ECXValue)
	 {
		 __asm__ __volatile__ = new __asm__("cpuid" : "=a" (CPUInfo[0]), "=b" (CPUInfo[1]), "=c" (CPUInfo[2]), "=d" (CPUInfo[3]) : "a" (InfoType), "c" (ECXValue));
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__rdtsc)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __rdtsc(void)
	 public static __INTRIN_INLINE long __rdtsc()
	 {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long low, high;
		 long low;
		 long high;
		 __asm__ __volatile__ = new __asm__("rdtsc" : "=a"(low), "=d"(high));
		 return low | (high << 32);
	 ///#else
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__ __volatile__ = new __asm__("rdtsc" : "=A"(retval));
		 return retval;
	 ///#endif
	 }
	 ///#endif // !HAS_BUILTIN(__rdtsc)

	 public static __INTRIN_INLINE void __writeeflags(short Value)
	 {
		 __asm__ __volatile__ = new __asm__("push %0\n popf" : : "rim"(Value));
	 }

	 public static __INTRIN_INLINE short __readeflags()
	 {
		 short retval;
		 __asm__ __volatile__ = new __asm__("pushf\n pop %0" : "=rm"(retval));
		 return retval;
	 }

	 /*** Interrupts ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__debugbreak)
//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE void __cdecl __debugbreak()
	 public static __INTRIN_INLINE void __debugbreak()
	 {
		 __asm__("int $3");
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__ud2)
	 public static __INTRIN_INLINE void __ud2()
	 {
		 __asm__("ud2");
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__int2c)
	 public static __INTRIN_INLINE void __int2c()
	 {
		 __asm__("int $0x2c");
	 }
	 ///#endif

//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE void __cdecl _disable()
	 public static __INTRIN_INLINE void _disable()
	 {
		 __asm__("cli" : : : "memory");
	 }

//C++ TO JAVA CONVERTER NOTE: __cdecl is not available in Java:
//ORIGINAL LINE: __INTRIN_INLINE void __cdecl _enable()
	 public static __INTRIN_INLINE void _enable()
	 {
		 __asm__("sti" : : : "memory");
	 }

	 public static __INTRIN_INLINE void __halt()
	 {
		 __asm__("hlt" : : : "memory");
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__fastfail)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __declspec(noreturn) __INTRIN_INLINE void __fastfail(unsigned int Code)
	//C++ TO JAVA CONVERTER WARNING: Most '__declspec' modifiers cannot be converted to Java:
	 public static __INTRIN_INLINE void __fastfail(int Code)
	 {
		 __asm__("int $0x29" : : "c"(Code) : "memory");
		 __builtin_unreachable();
	 }
	 ///#endif

	 /*** Protected memory management ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr0(unsigned long long Data)
	 public static __INTRIN_INLINE void __writecr0(long Data)
	 {
		 __asm__("mov %[Data], %%cr0" : : [Data] "r" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr3(unsigned long long Data)
	 public static __INTRIN_INLINE void __writecr3(long Data)
	 {
		 __asm__("mov %[Data], %%cr3" : : [Data] "r" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr4(unsigned long long Data)
	 public static __INTRIN_INLINE void __writecr4(long Data)
	 {
		 __asm__("mov %[Data], %%cr4" : : [Data] "r" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr8(unsigned long long Data)
	 public static __INTRIN_INLINE void __writecr8(long Data)
	 {
		 __asm__("mov %[Data], %%cr8" : : [Data] "r" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readcr0(void)
	 public static __INTRIN_INLINE long __readcr0()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long value;
		 long value;
		 __asm__ __volatile__ = new __asm__("mov %%cr0, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readcr2(void)
	 public static __INTRIN_INLINE long __readcr2()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long value;
		 long value;
		 __asm__ __volatile__ = new __asm__("mov %%cr2, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readcr3(void)
	 public static __INTRIN_INLINE long __readcr3()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long value;
		 long value;
		 __asm__ __volatile__ = new __asm__("mov %%cr3, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readcr4(void)
	 public static __INTRIN_INLINE long __readcr4()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long value;
		 long value;
		 __asm__ __volatile__ = new __asm__("mov %%cr4, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readcr8(void)
	 public static __INTRIN_INLINE long __readcr8()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long value;
		 long value;
		 __asm__ __volatile__ = new __asm__("movq %%cr8, %q[value]" : [value] "=r" (value));
		 return value;
	 }

	 ///#else // __x86_64__

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr0(unsigned int Data)
	 public static __INTRIN_INLINE void __writecr0(int Data)
	 {
		 __asm__("mov %[Data], %%cr0" : : [Data] "r" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr3(unsigned int Data)
	 public static __INTRIN_INLINE void __writecr3(int Data)
	 {
		 __asm__("mov %[Data], %%cr3" : : [Data] "r" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr4(unsigned int Data)
	 public static __INTRIN_INLINE void __writecr4(int Data)
	 {
		 __asm__("mov %[Data], %%cr4" : : [Data] "r" (Data) : "memory");
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__writecr8)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writecr8(unsigned int Data)
	 public static __INTRIN_INLINE void __writecr8(int Data)
	 {
		 __asm__("mov %[Data], %%cr8" : : [Data] "r" (Data) : "memory");
	 }
	 ///#endif

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __readcr0(void)
	 public static __INTRIN_INLINE int __readcr0()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__ __volatile__ = new __asm__("mov %%cr0, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __readcr2(void)
	 public static __INTRIN_INLINE int __readcr2()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__ __volatile__ = new __asm__("mov %%cr2, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __readcr3(void)
	 public static __INTRIN_INLINE int __readcr3()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__ __volatile__ = new __asm__("mov %%cr3, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __readcr4(void)
	 public static __INTRIN_INLINE int __readcr4()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__ __volatile__ = new __asm__("mov %%cr4, %[value]" : [value] "=r" (value));
		 return value;
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(__readcr8)
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __readcr8(void)
	 public static __INTRIN_INLINE int __readcr8()
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long value;
		 int value;
		 __asm__ __volatile__ = new __asm__("mov %%cr8, %[value]" : [value] "=r" (value));
		 return value;
	 }
	 ///#endif

	 ///#endif // __x86_64__

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readdr(unsigned int reg)
	 public static __INTRIN_INLINE long __readdr(int reg)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long value;
		 long value;
		 switch (reg)
		 {
			 case 0:
				 __asm__ __volatile__ = new __asm__("movq %%dr0, %q[value]" : [value] "=r" (value));
				 break;
			 case 1:
				 __asm__ __volatile__ = new __asm__("movq %%dr1, %q[value]" : [value] "=r" (value));
				 break;
			 case 2:
				 __asm__ __volatile__ = new __asm__("movq %%dr2, %q[value]" : [value] "=r" (value));
				 break;
			 case 3:
				 __asm__ __volatile__ = new __asm__("movq %%dr3, %q[value]" : [value] "=r" (value));
				 break;
			 case 4:
				 __asm__ __volatile__ = new __asm__("movq %%dr4, %q[value]" : [value] "=r" (value));
				 break;
			 case 5:
				 __asm__ __volatile__ = new __asm__("movq %%dr5, %q[value]" : [value] "=r" (value));
				 break;
			 case 6:
				 __asm__ __volatile__ = new __asm__("movq %%dr6, %q[value]" : [value] "=r" (value));
				 break;
			 case 7:
				 __asm__ __volatile__ = new __asm__("movq %%dr7, %q[value]" : [value] "=r" (value));
				 break;
		 }
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writedr(unsigned reg, unsigned long long value)
	 public static __INTRIN_INLINE void __writedr(int reg, long value)
	 {
		 switch (reg)
		 {
			 case 0:
				 __asm__("movq %q[value], %%dr0" : : [value] "r" (value) : "memory");
				 break;
			 case 1:
				 __asm__("movq %q[value], %%dr1" : : [value] "r" (value) : "memory");
				 break;
			 case 2:
				 __asm__("movq %q[value], %%dr2" : : [value] "r" (value) : "memory");
				 break;
			 case 3:
				 __asm__("movq %q[value], %%dr3" : : [value] "r" (value) : "memory");
				 break;
			 case 4:
				 __asm__("movq %q[value], %%dr4" : : [value] "r" (value) : "memory");
				 break;
			 case 5:
				 __asm__("movq %q[value], %%dr5" : : [value] "r" (value) : "memory");
				 break;
			 case 6:
				 __asm__("movq %q[value], %%dr6" : : [value] "r" (value) : "memory");
				 break;
			 case 7:
				 __asm__("movq %q[value], %%dr7" : : [value] "r" (value) : "memory");
				 break;
		 }
	 }

	 ///#else // __x86_64__

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned int __readdr(unsigned int reg)
	 public static __INTRIN_INLINE int __readdr(int reg)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned int value;
		 int value;
		 switch (reg)
		 {
			 case 0:
				 __asm__ __volatile__ = new __asm__("mov %%dr0, %[value]" : [value] "=r" (value));
				 break;
			 case 1:
				 __asm__ __volatile__ = new __asm__("mov %%dr1, %[value]" : [value] "=r" (value));
				 break;
			 case 2:
				 __asm__ __volatile__ = new __asm__("mov %%dr2, %[value]" : [value] "=r" (value));
				 break;
			 case 3:
				 __asm__ __volatile__ = new __asm__("mov %%dr3, %[value]" : [value] "=r" (value));
				 break;
			 case 4:
				 __asm__ __volatile__ = new __asm__("mov %%dr4, %[value]" : [value] "=r" (value));
				 break;
			 case 5:
				 __asm__ __volatile__ = new __asm__("mov %%dr5, %[value]" : [value] "=r" (value));
				 break;
			 case 6:
				 __asm__ __volatile__ = new __asm__("mov %%dr6, %[value]" : [value] "=r" (value));
				 break;
			 case 7:
				 __asm__ __volatile__ = new __asm__("mov %%dr7, %[value]" : [value] "=r" (value));
				 break;
		 }
		 return value;
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writedr(unsigned reg, unsigned int value)
	 public static __INTRIN_INLINE void __writedr(int reg, int value)
	 {
		 switch (reg)
		 {
			 case 0:
				 __asm__("mov %[value], %%dr0" : : [value] "r" (value) : "memory");
				 break;
			 case 1:
				 __asm__("mov %[value], %%dr1" : : [value] "r" (value) : "memory");
				 break;
			 case 2:
				 __asm__("mov %[value], %%dr2" : : [value] "r" (value) : "memory");
				 break;
			 case 3:
				 __asm__("mov %[value], %%dr3" : : [value] "r" (value) : "memory");
				 break;
			 case 4:
				 __asm__("mov %[value], %%dr4" : : [value] "r" (value) : "memory");
				 break;
			 case 5:
				 __asm__("mov %[value], %%dr5" : : [value] "r" (value) : "memory");
				 break;
			 case 6:
				 __asm__("mov %[value], %%dr6" : : [value] "r" (value) : "memory");
				 break;
			 case 7:
				 __asm__("mov %[value], %%dr7" : : [value] "r" (value) : "memory");
				 break;
		 }
	 }

	 ///#endif // __x86_64__

	 public static __INTRIN_INLINE void __invlpg(Object Address)
	 {
		 __asm__ __volatile__ = new __asm__("invlpg (%[Address])" : : [Address] "b" (Address) : "memory");
	 }


	 /*** System operations ***/

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readmsr(unsigned long reg)
	 public static __INTRIN_INLINE long __readmsr(int reg)
	 {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long low, high;
		 int low;
		 int high;
		 __asm__ __volatile__ = new __asm__("rdmsr" : "=a" (low), "=d" (high) : "c" (reg));
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: return ((unsigned long long)high << 32) | low;
		 return ((long)high << 32) | low;
	 ///#else
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__ __volatile__ = new __asm__("rdmsr" : "=A" (retval) : "c" (reg));
		 return retval;
	 ///#endif
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE void __writemsr(unsigned long Register, unsigned long long Value)
	 public static __INTRIN_INLINE void __writemsr(int Register, long Value)
	 {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __x86_64__
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		 __asm__ __volatile__ = new __asm__("wrmsr" : : "a" (Value), "d" (Value >>> 32), "c" (Register));
	 ///#else
		 __asm__ __volatile__ = new __asm__("wrmsr" : : "A" (Value), "c" (Register));
	 ///#endif
	 }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long long __readpmc(unsigned long counter)
	 public static __INTRIN_INLINE long __readpmc(int counter)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long retval;
		 long retval;
		 __asm__ __volatile__ = new __asm__("rdpmc" : "=A" (retval) : "c" (counter));
		 return retval;
	 }

	 /* NOTE: an immediate value for 'a' will raise an ICE in Visual C++ */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: __INTRIN_INLINE unsigned long __segmentlimit(unsigned long a)
	 public static __INTRIN_INLINE int __segmentlimit(int a)
	 {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long retval;
		 int retval;
		 __asm__ __volatile__ = new __asm__("lsl %[a], %[retval]" : [retval] "=r" (retval) : [a] "rm" (a));
		 return retval;
	 }

	 public static __INTRIN_INLINE void __wbinvd()
	 {
		 __asm__ __volatile__ = new __asm__("wbinvd" : : : "memory");
	 }

	 public static __INTRIN_INLINE void __lidt(Object Source)
	 {
		 __asm__ __volatile__ = new __asm__("lidt %0" : : "m"((short)Source));
	 }

	 public static __INTRIN_INLINE void __sidt(Object Destination)
	 {
		 __asm__ __volatile__ = new __asm__("sidt %0" : : "m"((short)Destination) : "memory");
	 }

	 public static __INTRIN_INLINE void _sgdt(Object Destination)
	 {
		 __asm__ __volatile__ = new __asm__("sgdt %0" : : "m"((short)Destination) : "memory");
	 }

	 /*** Misc operations ***/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if !HAS_BUILTIN(_mm_pause)
	 public static __INTRIN_INLINE void _mm_pause()
	 {
		 __asm__ __volatile__ = new __asm__("pause" : : : "memory");
	 }
	 ///#endif

	 public static __INTRIN_INLINE void __nop()
	 {
		 __asm__ __volatile__ = new __asm__("nop");
	 }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	 ///#if __cplusplus
	 ///#endif


	 /* EOF */

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_POPCNT
	public static final boolean HasPopCnt = true;
	///#else
	public static final boolean HasPopCnt = false;
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_PEXT
	public static final boolean HasPext = true;
	///#else
	public static final boolean HasPext = false;
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if IS_64BIT
	public static final boolean Is64Bit = true;
	///#else
	public static final boolean Is64Bit = false;
	///#endif


	public static final int MAX_MOVES = 256;
	public static final int MAX_PLY = 128;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Value PieceValue[PHASE_NB][PIECE_NB];

	public static Score make_score(int mg, int eg)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: return Score((int)((unsigned int)eg << 16) + mg);
	  return Score((int)((int)eg << 16) + mg);
	}
	//{
	//	ushort u;
	//	short s;
	//}
	public static Value eg_value(Score s)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	   eg = {short(int(s + 0x8000) >>> 16)};
	  return Value(eg.s);
	}
	//{
	//	ushort u;
	//	short s;
	//}
	public static Value mg_value(Score s)
	{
	   mg = {short(int(s))};
	  return Value(mg.s);
	}

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define ENABLE_BASE_OPERATORS_ON(T) constexpr T operator+(T d1, T d2) { return T(int(d1) + int(d2)); } constexpr T operator-(T d1, T d2) { return T(int(d1) - int(d2)); } constexpr T operator-(T d) { return T(-int(d)); } inline T& operator+=(T& d1, T d2) { return d1 = d1 + d2; } inline T& operator-=(T& d1, T d2) { return d1 = d1 - d2; }

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define ENABLE_INCR_OPERATORS_ON(T) inline T& operator++(T& d) { return d = T(int(d) + 1); } inline T& operator--(T& d) { return d = T(int(d) - 1); }

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define ENABLE_FULL_OPERATORS_ON(T) ENABLE_BASE_OPERATORS_ON(T) ENABLE_INCR_OPERATORS_ON(T) constexpr T operator*(int i, T d) { return T(i * int(d)); } constexpr T operator*(T d, int i) { return T(int(d) * i); } constexpr T operator/(T d, int i) { return T(int(d) / i); } constexpr int operator/(T d1, T d2) { return int(d1) / int(d2); } inline T& operator*=(T& d, int i) { return d = T(int(d) * i); } inline T& operator/=(T& d, int i) { return d = T(int(d) / i); }

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator + (Value d1, Value d2)
	{
		return Value(d1.getValue() + d2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator - (Value d1, Value d2)
	{
		return Value(d1.getValue() - d2.getValue());
	}
	private Value subtract(Value d)
	{
		return Value(-d.getValue());
	}
	private Value addAssignment(Value d1, Value d2)
	{
		return d1 = d1 + d2;
	}
	private Value subtractAssignment(Value d1, Value d2)
	{
		return d1 = d1 - d2;
	}
	private Value increment(Value d)
	{
		return d = Value(d.getValue() + 1);
	}
	private Value decrement(Value d)
	{
		return d = Value(d.getValue() - 1);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator * (int i, Value d)
	{
		return Value(i * d.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator * (Value d, int i)
	{
		return Value(d.getValue() * i);
	}
	private Value divide(Value d, int i)
	{
		return Value(d.getValue() / i);
	}
	private int divide(Value d1, Value d2)
	{
		return d1.getValue() / d2.getValue();
	}
	private Value multiplyAssignment(Value d, int i)
	{
		return d = Value(d.getValue() * i);
	}
	private Value divideAssignment(Value d, int i)
	{
		return d = Value(d.getValue() / i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator + (Depth d1, Depth d2)
	{
		return Depth(d1.getValue() + d2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator - (Depth d1, Depth d2)
	{
		return Depth(d1.getValue() - d2.getValue());
	}
	private Depth subtract(Depth d)
	{
		return Depth(-d.getValue());
	}
	private Depth addAssignment(Depth d1, Depth d2)
	{
		return d1 = d1 + d2;
	}
	private Depth subtractAssignment(Depth d1, Depth d2)
	{
		return d1 = d1 - d2;
	}
	private Depth increment(Depth d)
	{
		return d = Depth(d.getValue() + 1);
	}
	private Depth decrement(Depth d)
	{
		return d = Depth(d.getValue() - 1);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator * (int i, Depth d)
	{
		return Depth(i * d.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator * (Depth d, int i)
	{
		return Depth(d.getValue() * i);
	}
	private Depth divide(Depth d, int i)
	{
		return Depth(d.getValue() / i);
	}
	private int divide(Depth d1, Depth d2)
	{
		return d1.getValue() / d2.getValue();
	}
	private Depth multiplyAssignment(Depth d, int i)
	{
		return d = Depth(d.getValue() * i);
	}
	private Depth divideAssignment(Depth d, int i)
	{
		return d = Depth(d.getValue() / i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Direction operator + (Direction d1, Direction d2)
	{
		return Direction(d1.getValue() + d2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Direction operator - (Direction d1, Direction d2)
	{
		return Direction(d1.getValue() - d2.getValue());
	}
	private Direction subtract(Direction d)
	{
		return Direction(-d.getValue());
	}
	private Direction addAssignment(Direction d1, Direction d2)
	{
		return d1 = d1 + d2;
	}
	private Direction subtractAssignment(Direction d1, Direction d2)
	{
		return d1 = d1 - d2;
	}
	private Direction increment(Direction d)
	{
		return d = Direction(d.getValue() + 1);
	}
	private Direction decrement(Direction d)
	{
		return d = Direction(d.getValue() - 1);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Direction operator * (int i, Direction d)
	{
		return Direction(i * d.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Direction operator * (Direction d, int i)
	{
		return Direction(d.getValue() * i);
	}
	private Direction divide(Direction d, int i)
	{
		return Direction(d.getValue() / i);
	}
	private int divide(Direction d1, Direction d2)
	{
		return d1.getValue() / d2.getValue();
	}
	private Direction multiplyAssignment(Direction d, int i)
	{
		return d = Direction(d.getValue() * i);
	}
	private Direction divideAssignment(Direction d, int i)
	{
		return d = Direction(d.getValue() / i);
	}

	private PieceType increment(PieceType d)
	{
		return d = PieceType(d.getValue() + 1);
	}
	private PieceType decrement(PieceType d)
	{
		return d = PieceType(d.getValue() - 1);
	}
	private Piece increment(Piece d)
	{
		return d = Piece(d.getValue() + 1);
	}
	private Piece decrement(Piece d)
	{
		return d = Piece(d.getValue() - 1);
	}
	private Color increment(Color d)
	{
		return d = Color(d.getValue() + 1);
	}
	private Color decrement(Color d)
	{
		return d = Color(d.getValue() - 1);
	}
	private Square increment(Square d)
	{
		return d = Square(d.getValue() + 1);
	}
	private Square decrement(Square d)
	{
		return d = Square(d.getValue() - 1);
	}
	private File increment(File d)
	{
		return d = File(d.getValue() + 1);
	}
	private File decrement(File d)
	{
		return d = File(d.getValue() - 1);
	}
	private Rank increment(Rank d)
	{
		return d = Rank(d.getValue() + 1);
	}
	private Rank decrement(Rank d)
	{
		return d = Rank(d.getValue() - 1);
	}

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Score operator + (Score d1, Score d2)
	{
		return Score(d1.getValue() + d2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Score operator - (Score d1, Score d2)
	{
		return Score(d1.getValue() - d2.getValue());
	}
	private Score subtract(Score d)
	{
		return Score(-d.getValue());
	}
	private Score addAssignment(Score d1, Score d2)
	{
		return d1 = d1 + d2;
	}
	private Score subtractAssignment(Score d1, Score d2)
	{
		return d1 = d1 - d2;
	}

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef ENABLE_FULL_OPERATORS_ON
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef ENABLE_INCR_OPERATORS_ON
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef ENABLE_BASE_OPERATORS_ON

	/// Additional operators to add integers to a Value
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator + (Value v, int i)
	{
		return Value(v.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator - (Value v, int i)
	{
		return Value(v.getValue() - i);
	}
	private Value addAssignment(Value v, int i)
	{
		return v = v + i;
	}
	private Value subtractAssignment(Value v, int i)
	{
		return v = v - i;
	}

	/// Additional operators to add a Direction to a Square
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Square operator + (Square s, Direction d)
	{
		return Square(s.getValue() + d.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Square operator - (Square s, Direction d)
	{
		return Square(s.getValue() - d.getValue());
	}
	private Square addAssignment(Square s, Direction d)
	{
		return s = s + d;
	}
	private Square subtractAssignment(Square s, Direction d)
	{
		return s = s - d;
	}

	/// Only declared but not defined. We don't want to multiply two scores due to
	/// a very high risk of overflow. So user should explicitly convert to integer.
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
	//Score operator *(Score, Score) = delete;

	/// Division of a Score must be handled separately for each term
	private Score divide(Score s, int i)
	{
	  return make_score(mg_value(s).getValue() / i, eg_value(s).getValue() / i);
	}

	/// Multiplication of a Score by an integer. We check for overflow in debug mode.
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Score operator * (Score s, int i)
	{

	  Score result = s.getValue() * i;

	  assert eg_value(result) == (i * eg_value(s).getValue());
	  assert mg_value(result) == (i * mg_value(s).getValue());
	  assert (i == 0) || (result / i) == s;

	  return result;
	}

	private Color onesComplement(Color c)
	{
	  return Color(c ^ Color.BLACK); // Toggle color
	}

	private Square onesComplement(Square s)
	{
	  return Square(s ^ Square.SQ_A8); // Vertical flip SQ_A1 -> SQ_A8
	}

	private File onesComplement(File f)
	{
	  return File(f ^ File.FILE_H); // Horizontal flip FILE_A -> FILE_H
	}

	private Piece onesComplement(Piece pc)
	{
	  return Piece(pc ^ 8); // Swap color of piece B_KNIGHT -> W_KNIGHT
	}

	private CastlingRight bitwiseOr(Color c, CastlingSide s)
	{
	  return CastlingRight(CastlingRight.WHITE_OO.getValue() << ((s == CastlingSide.QUEEN_SIDE) + 2 * c));
	}

	public static Value mate_in(int ply)
	{
	  return Value.VALUE_MATE - ply;
	}

	public static Value mated_in(int ply)
	{
	  return -Value.VALUE_MATE + ply;
	}

	public static Square make_square(File f, Rank r)
	{
	  return Square((r.getValue() << 3) + f);
	}

	public static Piece make_piece(Color c, PieceType pt)
	{
	  return Piece((c.getValue() << 3) + pt);
	}

	public static PieceType type_of(Piece pc)
	{
	  return PieceType(pc & 7);
	}

	public static Color color_of(Piece pc)
	{
	  assert pc != Piece.NO_PIECE;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Color(pc.getValue() >> 3);
	}

	public static boolean is_ok(Square s)
	{
	  return s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	}

	public static File file_of(Square s)
	{
	  return File(s & 7);
	}

	public static Rank rank_of(Square s)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Rank(s.getValue() >> 3);
	}

	public static Square relative_square(Color c, Square s)
	{
	  return Square(s ^ (c * 56));
	}

	public static Rank relative_rank(Color c, Rank r)
	{
	  return Rank(r ^ (c * 7));
	}

	public static Rank relative_rank(Color c, Square s)
	{
	  return relative_rank(c, rank_of(s));
	}

	public static boolean opposite_colors(Square s1, Square s2)
	{
	  int s = s1.getValue() ^ s2.getValue();
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return (((s >> 3) ^ s) & 1) != 0;
	}

	public static Direction pawn_push(Color c)
	{
	  return c == Color.WHITE ? Direction.NORTH : Direction.SOUTH;
	}

	public static Square from_sq(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square((m.getValue() >> 6) & 0x3F);
	}

	public static Square to_sq(Move m)
	{
	  return Square(m & 0x3F);
	}

	public static int from_to(Move m)
	{
	 return (m & 0xFFF).getValue();
	}

	public static MoveType type_of(Move m)
	{
	  return MoveType(m & (3 << 14));
	}

	public static PieceType promotion_type(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return PieceType(((m.getValue() >> 12) & 3) + PieceType.KNIGHT);
	}

	public static Move make_move(Square from, Square to)
	{
	  return Move((from.getValue() << 6) + to);
	}

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<MoveType T>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
public static <T> Move make(Square from, Square to)
{
	return make(from, to, PieceType.KNIGHT);
}
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: constexpr Move make(Square from, Square to, PieceType pt = KNIGHT)
	public static <T> Move make(Square from, Square to, PieceType pt)
	{
	  return Move(T + ((pt - PieceType.KNIGHT) << 12) + (from.getValue() << 6) + to);
	}

	public static boolean is_ok(Move m)
	{
	  return from_sq(m) != to_sq(m); // Catch MOVE_NULL and MOVE_NONE
	}


}