import java.util.*;
import java.io.*;

@FunctionalInterface
interface fun3_t
{
	boolean invoke(HANDLE UnnamedParameter, CONST GROUP_AFFINITY UnnamedParameter2, PGROUP_AFFINITY UnnamedParameter3);
}