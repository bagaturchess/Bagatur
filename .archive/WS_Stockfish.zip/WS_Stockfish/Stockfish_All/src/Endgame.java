import String;
import java.util.*;
import java.io.*;

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<EndgameCode E, typename T = eg_type<E>>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers containing defaults cannot be converted to Java:
//ORIGINAL LINE: template<typename E, typename T = eg_type<E>>
public class Endgame<E, T = eg_type<E>> extends EndgameBase<T>
{

  public Endgame(Color c)
  {
	  this.EndgameBase<T> = c;
  }
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: T operator ()(const Position&) const override;
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  override T operator ()(Position UnnamedParameter);
}