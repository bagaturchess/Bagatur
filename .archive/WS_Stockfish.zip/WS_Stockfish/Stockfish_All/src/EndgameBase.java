import String;
import java.util.*;
import java.io.*;

/// Endgame functions can be of two types depending on whether they return a
/// Value or a ScaleFactor.

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<EndgameCode E> using
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename E>
//C++ TO JAVA CONVERTER TODO TASK: Conditional typedefs are not handled by C++ to Java Converter:
//using eg_type = typename std::conditional<(E < SCALING_FUNCTIONS), Value, ScaleFactor>::type;


/// Base and derived functors for endgame evaluation and scaling functions

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
public abstract class EndgameBase<T> implements Closeable
{

  public EndgameBase(Color c)
  {
	  this.strongSide = new Color(c);
	  this.weakSide = new Color(~c);
  }
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = default':
//  virtual ~EndgameBase() = default;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: virtual T operator ()(const Position&) const = 0;
  public abstract T functorMethod(Position UnnamedParameter);

  public final Color strongSide;
  public Color weakSide;
}