import java.util.*;

  public enum Stages
  {
	MAIN_TT,
	CAPTURE_INIT,
	GOOD_CAPTURE,
	REFUTATION,
	QUIET_INIT,
	QUIET,
	BAD_CAPTURE,
	EVASION_TT,
	EVASION_INIT,
	EVASION,
	PROBCUT_TT,
	PROBCUT_INIT,
	PROBCUT,
	QSEARCH_TT,
	QCAPTURE_INIT,
	QCAPTURE,
	QCHECK_INIT,
	QCHECK;

	  public static final int SIZE = java.lang.Integer.SIZE;

	  public int getValue()
	  {
		  return this.ordinal();
	  }

	  public static Stages forValue(int value)
	  {
		  return values()[value];
	  }
  }