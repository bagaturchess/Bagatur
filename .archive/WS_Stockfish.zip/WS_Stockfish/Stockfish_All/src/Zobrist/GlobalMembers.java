package Zobrist;

public class GlobalMembers
{
  public static long[][] psq = new long[Piece.PIECE_NB.getValue()][Square.SQUARE_NB.getValue()];
  public static long[] enpassant = new long[File.FILE_NB.getValue()];
  public static long[] castling = new long[CastlingRight.CASTLING_RIGHT_NB.getValue()];
  public static long side;
  public static long noPawns;
}