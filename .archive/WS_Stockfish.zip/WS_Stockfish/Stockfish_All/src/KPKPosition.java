import java.util.*;

  public class KPKPosition
  {
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = default':
//	KPKPosition() = default;
	public KPKPosition(int idx)
	{

//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  ksq[Color.WHITE.getValue()] = Square((idx >>> 0) & 0x3F);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  ksq[Color.BLACK.getValue()] = Square((idx >>> 6) & 0x3F);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  us = Color((idx >>> 12) & 0x01);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  psq = GlobalMembers.make_square(File((idx >>> 13) & 0x3), Rank(Rank.RANK_7 - ((idx >>> 15) & 0x7)));

	  // Check if two pieces are on the same square or if a king can be captured
	  if (GlobalMembers.distance(ksq[Color.WHITE.getValue()], ksq[Color.BLACK.getValue()]) <= 1 || ksq[Color.WHITE.getValue()] == psq || ksq[Color.BLACK.getValue()] == psq || (us == Color.WHITE && (PawnAttacks[Color.WHITE.getValue()][psq.getValue()] & ksq[Color.BLACK.getValue()]) != 0))
	  {
		  result = Result.INVALID;
	  }

	  // Immediate win if a pawn can be promoted without getting captured
	  else if (us == Color.WHITE && GlobalMembers.rank_of(psq) == Rank.RANK_7 && ksq[us.getValue()] != psq + Direction.NORTH && (GlobalMembers.distance(ksq[~us], psq + Direction.NORTH) > 1 || (PseudoAttacks[PieceType.KING.getValue()][ksq[us.getValue()].getValue()] & (psq + Direction.NORTH))))
	  {
		  result = Result.WIN;
	  }

	  // Immediate draw if it is a stalemate or a king captures undefended pawn
	  else if (us == Color.BLACK && (!(PseudoAttacks[PieceType.KING.getValue()][ksq[us.getValue()].getValue()] & ~(PseudoAttacks[PieceType.KING.getValue()][ksq[~us].getValue()] | PawnAttacks[~us][psq.getValue()])) || (PseudoAttacks[PieceType.KING.getValue()][ksq[us.getValue()].getValue()] & psq & ~PseudoAttacks[PieceType.KING.getValue()][ksq[~us].getValue()])))
	  {
		  result = Result.DRAW;
	  }

	  // Position will be classified later
	  else
	  {
		  result = Result.UNKNOWN;
	  }
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: operator Result() const
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	operator Result()
	{
		return result;
	}
	public final Result classify(ArrayList<KPKPosition> db)
	{
		return us == Color.WHITE ? this.<Color.WHITE.getValue()>classify(db) : this.<Color.BLACK.getValue()>classify(db);
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<Color Us> Result classify(const std::vector<KPKPosition>& db);
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>
	public final <Us> Result classify(ArrayList<KPKPosition> db)
	{

	  // White to move: If one move leads to a position classified as WIN, the result
	  // of the current position is WIN. If all moves lead to positions classified
	  // as DRAW, the current position is classified as DRAW, otherwise the current
	  // position is classified as UNKNOWN.
	  //
	  // Black to move: If one move leads to a position classified as DRAW, the result
	  // of the current position is DRAW. If all moves lead to positions classified
	  // as WIN, the position is classified as WIN, otherwise the current position is
	  // classified as UNKNOWN.

	  final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
	  final Result Good = (Us == Color.WHITE ? Result.WIN : Result.DRAW);
	  final Result Bad = (Us == Color.WHITE ? Result.DRAW : Result.WIN);

	  Result r = Result.INVALID;
	  uint64_t b = PseudoAttacks[PieceType.KING.getValue()][ksq[Us].getValue()];

	  while (b != null)
	  {
		  r |= Us == Color.WHITE ? db.get(GlobalMembers.index(Them, ksq[Them.getValue()], GlobalMembers.pop_lsb(b), psq)) : db.get(GlobalMembers.index(Them, GlobalMembers.pop_lsb(b), ksq[Them.getValue()], psq));
	  }

	  if (Us == Color.WHITE)
	  {
		  if (GlobalMembers.rank_of(psq) < Rank.RANK_7.getValue()) // Single push
		  {
			  r |= db.get(GlobalMembers.index(Them, ksq[Them.getValue()], ksq[Us], psq + Direction.NORTH));
		  }

		  if (GlobalMembers.rank_of(psq) == Rank.RANK_2 && psq + Direction.NORTH != ksq[Us].getValue() != 0 && psq + Direction.NORTH != ksq[Them.getValue()].getValue() != 0)
		  {
			  r |= db.get(GlobalMembers.index(Them, ksq[Them.getValue()], ksq[Us], psq + Direction.NORTH + Direction.NORTH));
		  }
	  }

	  return result = r & Good.getValue() != 0 ? Good : r & Result.UNKNOWN.getValue() != 0 ? Result.UNKNOWN : Bad;
	}

	public Color us;
	public Square[] ksq = new Square[Color.COLOR_NB.getValue()];
	public Square psq;
	public Result result;
  }