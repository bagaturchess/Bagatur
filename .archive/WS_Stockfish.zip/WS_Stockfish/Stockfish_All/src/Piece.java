public enum Piece
{
  NO_PIECE(0),
  W_PAWN(1),
  W_KNIGHT(2),
  W_BISHOP(3),
  W_ROOK(4),
  W_QUEEN(5),
  W_KING(6),
  B_PAWN(9),
  B_KNIGHT(10),
  B_BISHOP(11),
  B_ROOK(12),
  B_QUEEN(13),
  B_KING(14),
  PIECE_NB(16);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Piece> mappings;
	private static java.util.HashMap<Integer, Piece> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Piece.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Piece>();
				}
			}
		}
		return mappings;
	}

	private Piece(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Piece forValue(int value)
	{
		return getMappings().get(value);
	}
}