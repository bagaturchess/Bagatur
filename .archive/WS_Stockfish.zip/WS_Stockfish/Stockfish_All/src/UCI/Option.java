package UCI;

import java.util.*;

/// Our options container is actually a std::map

/// Option class implements an option as defined by UCI protocol
public class Option
{

  @FunctionalInterface
  private interface OnChange
  {
	  void invoke(Option UnnamedParameter);
  }


//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  Option(OnChange);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  Option(boolean v, OnChange);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  Option(String v, OnChange);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  Option(double v, int minv, int maxv, OnChange);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  Option(String v, String cur, OnChange);

//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  Option operator =(String UnnamedParameter);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  void operator <<(Option UnnamedParameter);
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: operator double() const;
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  operator double();
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: operator String() const;
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  operator String();
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean operator ==(const char*) const;
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  boolean operator ==(String UnnamedParameter);

//C++ TO JAVA CONVERTER TODO TASK: Java has no concept of a 'friend' function:
//ORIGINAL LINE: friend std::ostream& operator <<(std::ostream&, const OptionsMap&);
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  std::ostream operator <<(std::ostream UnnamedParameter, OptionsMap UnnamedParameter2);

  private String defaultValue;
  private String currentValue;
  private String type;
  private int min;
  private int max;
  private int idx;
  private OnChange on_change;
}