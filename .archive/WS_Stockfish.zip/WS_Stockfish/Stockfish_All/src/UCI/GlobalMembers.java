package UCI;

public class GlobalMembers
{
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	void init(ClassicMap<String, Option, CaseInsensitiveLess> UnnamedParameter);

	/// UCI::loop() waits for a command from stdin, parses it and calls the appropriate
	/// function. Also intercepts EOF from stdin to ensure gracefully exiting if the
	/// GUI dies unexpectedly. When called with some command line arguments, e.g. to
	/// run 'bench', once the command is executed the function returns immediately.
	/// In addition to the UCI ones, also some additional debug commands are supported.

	public static void loop(int argc, String[] argv)
	{

	  Position pos = new Position();
	  String token;
	  String cmd;
	  std::unique_ptr<LinkedList<StateInfo>> states = new std::unique_ptr<LinkedList<StateInfo>>(new LinkedList<StateInfo>(1));
	  Thread uiThread = new Thread(0);

	  pos.set(GlobalMembers.StartFEN, false, states.back(), uiThread.get());

	  for (int i = 1; i < argc; ++i)
	  {
		  cmd += new String(argv[i]) + " ";
	  }

	  do
	  {
		  if (argc == 1 && !cmd = new Scanner(System.in).nextLine()) // Block here waiting for input or EOF
		  {
			  cmd = "quit";
		  }

		  istringstream is = new istringstream(cmd);

		  token = ""; // Avoid a stale if getline() returns empty or blank line
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  is >> skipws >> token;

		  // The GUI sends 'ponderhit' to tell us the user has played the expected move.
		  // So 'ponderhit' will be sent if we were told to ponder on the same move the
		  // user has played. We should continue searching but switch from pondering to
		  // normal search. In case Threads.stopOnPonderhit is set we are waiting for
		  // 'ponderhit' to stop the search, for instance if max search depth is reached.
		  if (token.equals("quit") || token.equals("stop") || (token.equals("ponderhit") && Threads.stopOnPonderhit))
		  {
			  Threads.stop = true;
		  }

		  else if (token.equals("ponderhit"))
		  {
			  Threads.ponder = false; // Switch to normal search
		  }

		  else if (token.equals("uci"))
		  {
			  System.out.print(SyncCout.IO_LOCK);
			  System.out.print("id name ");
			  System.out.print(engine_info(true));
			  System.out.print("\n");
			  System.out.print(Options);
			  System.out.print("\nuciok");
			  System.out.print("\n");
			  System.out.print(SyncCout.IO_UNLOCK);
		  }

		  else if (token.equals("setoption"))
		  {
			  GlobalMembers.setoption(is);
		  }
		  else if (token.equals("go"))
		  {
			  GlobalMembers.go(pos, is, states);
		  }
		  else if (token.equals("position"))
		  {
			  tangible.RefObject<std::unique_ptr<ClassicDeque<StateInfo>>> tempRef_states = new tangible.RefObject<std::unique_ptr<ClassicDeque<StateInfo>>>(states);
			  GlobalMembers.position(pos, is, tempRef_states);
			  states = tempRef_states.argValue;
		  }
		  else if (token.equals("ucinewgame"))
		  {
			  Search.clear();
		  }
		  else if (token.equals("isready"))
		  {
			  System.out.print(SyncCout.IO_LOCK);
			  System.out.print("readyok");
			  System.out.print("\n");
			  System.out.print(SyncCout.IO_UNLOCK);
		  }

		  // Additional custom non-UCI commands, mainly for debugging
		  else if (token.equals("flip"))
		  {
			  pos.flip();
		  }
		  else if (token.equals("bench"))
		  {
			  GlobalMembers.bench(pos, is, states);
		  }
		  else if (token.equals("d"))
		  {
			  System.out.print(SyncCout.IO_LOCK);
			  System.out.print(pos);
			  System.out.print("\n");
			  System.out.print(SyncCout.IO_UNLOCK);
		  }
		  else if (token.equals("eval"))
		  {
			  System.out.print(SyncCout.IO_LOCK);
			  System.out.print(Eval.trace(pos));
			  System.out.print("\n");
			  System.out.print(SyncCout.IO_UNLOCK);
		  }
		  else
		  {
			  System.out.print(SyncCout.IO_LOCK);
			  System.out.print("Unknown command: ");
			  System.out.print(cmd);
			  System.out.print("\n");
			  System.out.print(SyncCout.IO_UNLOCK);
		  }

	  } while (!token.equals("quit") && argc == 1); // Command line args are one-shot
	}

	/// UCI::value() converts a Value to a string suitable for use with the UCI
	/// protocol specification:
	///
	/// cp <x>    The score from the engine's point of view in centipawns.
	/// mate <y>  Mate in y moves, not plies. If the engine is getting mated
	///           use negative values for y.


	public static String value(Value v)
	{

	  assert - Value.VALUE_INFINITE.getValue() < v.getValue() && v.getValue() < Value.VALUE_INFINITE.getValue();

	  stringstream ss = new stringstream();

	  if (Math.abs(v) < Value.VALUE_MATE.getValue() - GlobalMembers.MAX_PLY)
	  {
		  ss << "cp " << v.getValue() * 100 / Value.PawnValueEg;
	  }
	  else
	  {
		  ss << "mate " << (v.getValue() > 0 ? Value.VALUE_MATE - v + 1 : -Value.VALUE_MATE - v) / 2;
	  }

	  return ss.str();
	}

	/// UCI::square() converts a Square to a string in algebraic notation (g1, a7, etc.)


	public static String square(Square s)
	{
	  return String{(char)('a' + GlobalMembers.file_of(s)), (char)('1' + GlobalMembers.rank_of(s))};
	}

	/// UCI::move() converts a Move to a string in coordinate notation (g1f3, a7a8q).
	/// The only special case is castling, where we print in the e1g1 notation in
	/// normal chess mode, and in e1h1 notation in chess960 mode. Internally all
	/// castling moves are always encoded as 'king captures rook'.


	public static String move(Move m, boolean chess960)
	{

	  Square from = GlobalMembers.from_sq(m);
	  Square to = GlobalMembers.to_sq(m);

	  if (m == Move.MOVE_NONE)
	  {
		  return "(none)";
	  }

	  if (m == Move.MOVE_NULL)
	  {
		  return "0000";
	  }

	  if (GlobalMembers.type_of(m) == MoveType.CASTLING && !chess960)
	  {
		  to = GlobalMembers.make_square(to.getValue() > from.getValue() ? File.FILE_G : File.FILE_C, GlobalMembers.rank_of(from));
	  }

	  String move = UCI.GlobalMembers.square(from) + UCI.GlobalMembers.square(to);

	  if (GlobalMembers.type_of(m) == MoveType.PROMOTION)
	  {
		  move += " pnbrqk"[GlobalMembers.promotion_type(m).getValue()];
	  }

	  return move;
	}

//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//	String pv(Position pos, Depth depth, Value alpha, Value beta);

	/// UCI::to_move() converts a string representing a move in coordinate notation
	/// (g1f3, a7a8q) to the corresponding legal Move, if any.

	public static Move to_move(Position pos, String str)
	{

	  if (str.length() == 5) // Junior could send promotion piece in uppercase
	  {
		  str = tangible.StringFunctions.changeCharacter(str, 4, (char)Character.toLowerCase(str.charAt(4)));
	  }

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
	  for (auto m : new MoveList<GenType.LEGAL.getValue()>(pos))
	  {
		  if (str.equals(UCI.GlobalMembers.move(new auto(m), pos.is_chess960())))
		  {
			  return new auto(m);
		  }
	  }

	  return Move.MOVE_NONE;
	}


	/// 'On change' actions, triggered by an option's value change
	public static void on_clear_hash(Option UnnamedParameter)
	{
		Search.clear();
	}
	public static void on_hash_size(Option o)
	{
		TT.resize(o);
	}
	public static void on_logger(Option o)
	{
		start_logger(o);
	}
	public static void on_threads(Option o)
	{
		Threads.set(o);
	}
	public static void on_tb_path(Option o)
	{
		Tablebases.init(o);
	}


	/// Our case insensitive less() function as required by UCI protocol
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean CaseInsensitiveLess::operator ()(const String& s1, const String& s2) const
	public static boolean CaseInsensitiveLess.operator ()(String s1, String s2)
	{

	  return std::lexicographical_compare(s1.iterator(), s1.end(), s2.iterator(), s2.end(), (char c1, char c2) ->
	  {
		  return Character.toLowerCase(c1) < Character.toLowerCase(c2);
	  });
	}


	/// init() initializes the UCI options to their hard-coded default values

	public static void init(TreeMap<String, Option, CaseInsensitiveLess> o)
	{

	  // at most 2^32 clusters.
	  final int MaxHashMB = GlobalMembers.Is64Bit ? 131072 : 2048;

	  o.get("Debug Log File") << new Option("", on_logger);
	  o.get("Contempt") << new Option(24, -100, 100);
	  o.get("Analysis Contempt") << new Option("Both var Off var White var Black var Both", "Both");
	  o.get("Threads") << new Option(1, 1, 512, on_threads);
	  o.get("Hash") << new Option(16, 1, MaxHashMB, on_hash_size);
	  o.get("Clear Hash") << new Option(on_clear_hash);
	  o.get("Ponder") << new Option(false);
	  o.get("MultiPV") << new Option(1, 1, 500);
	  o.get("Skill Level") << new Option(20, 0, 20);
	  o.get("Move Overhead") << new Option(30, 0, 5000);
	  o.get("Minimum Thinking Time") << new Option(20, 0, 5000);
	  o.get("Slow Mover") << new Option(84, 10, 1000);
	  o.get("nodestime") << new Option(0, 0, 10000);
	  o.get("UCI_Chess960") << new Option(false);
	  o.get("UCI_AnalyseMode") << new Option(false);
	  o.get("SyzygyPath") << new Option("<empty>", on_tb_path);
	  o.get("SyzygyProbeDepth") << new Option(1, 1, 100);
	  o.get("Syzygy50MoveRule") << new Option(true);
	  o.get("SyzygyProbeLimit") << new Option(7, 0, 7);
	}


	/// operator<<() is used to print all the options default values in chronological
	/// insertion order (the idx field) and in the format defined by the UCI protocol.

	private std::ostream leftShift(std::ostream os, TreeMap<String, Option, CaseInsensitiveLess> om)
	{

	  for (int idx = 0; idx < om.size(); ++idx)
	  {
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java unless the Java 10 inferred typing option is selected:
		  for (auto it : om)
		  {
			  if (it.second.idx == idx)
			  {
				  final Option o = it.second;
				  os << "\noption name " << it.first << " type " << o.type;

				  if (o.type.equals("string") || o.type.equals("check") || o.type.equals("combo"))
				  {
					  os << " default " << o.defaultValue;
				  }

				  if (o.type.equals("spin"))
				  {
					  os << " default " << (int)Float.parseFloat(o.defaultValue) << " min " << o.min << " max " << o.max;
				  }

				  break;
			  }
		  }
	  }

	  return os;
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean Option::operator ==(const char* s) const
	private boolean Option.equalsTo(String s)
	{
	  assert type.equals("combo");
	  return new CaseInsensitiveLess()(currentValue, s) == null && new CaseInsensitiveLess()(s, currentValue) == null;
	}


	/// operator<<() inits options and assigns idx in the correct printing order

	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static int operator << _insert_order = 0;

	private void Option.leftShift(Option o)
	{

	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//	  static int insert_order = 0;

		  this = o;
		  idx = operator << _insert_order++;
	}


	/// operator=() updates currentValue and triggers on_change() action. It's up to
	/// the GUI to check for option's limits, but we could receive the new value from
	/// the user by console window, so let's check the bounds anyway.

//C++ TO JAVA CONVERTER NOTE: This 'copyFrom' method was converted from the original copy assignment operator:
//ORIGINAL LINE: Option& Option::operator =(const String& v)
	public static Option Option.copyFrom(String v)
	{

	  assert!type.empty();

	  if ((!type.equals("button") && v.length() == 0) || (type.equals("check") && !v.equals("true") && !v.equals("false")) || (type.equals("spin") && (Float.parseFloat(v) < min || Float.parseFloat(v) > max)))
	  {
		  return this;
	  }

	  if (!type.equals("button"))
	  {
		  currentValue = v;
	  }

	  if (on_change)
	  {
		  on_change(this);
	  }

	  return this;
	}
}