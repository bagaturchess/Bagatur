package UCI;

import String;
import java.util.*;

/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/




//C++ TO JAVA CONVERTER TODO TASK: The following package should be saved to a separate file:




/// Option class constructors and conversion operators

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: Option::Option(const char* v, OnChange f) : type("string"), min(0), max(0), on_change(f)

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: Option::Option(boolean v, OnChange f) : type("check"), min(0), max(0), on_change(f)

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: Option::Option(OnChange f) : type("button"), min(0), max(0), on_change(f)

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: Option::Option(double v, int minv, int maxv, OnChange f) : type("spin"), min(minv), max(maxv), on_change(f)

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: Option::Option(const char* v, const char* cur, OnChange f) : type("combo"), min(0), max(0), on_change(f)

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: Option::operator double() const
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
Option.operator double()
{
  assert type.equals("check") || type.equals("spin");
  return (type.equals("spin") ? Float.parseFloat(currentValue) : currentValue.equals("true"));
}

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
//ORIGINAL LINE: Option::operator String() const
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
Option.operator String()
{
  assert type.equals("string");
  return currentValue;
}



public class Option
{
	public Option(String v, OnChange f)
	{
		this.type = "string";
		this.min = 0;
		this.max = 0;
		this.on_change = f;
		defaultValue = currentValue = v;
	}
	public Option(boolean v, OnChange f)
	{
		this.type = "check";
		this.min = 0;
		this.max = 0;
		this.on_change = f;
		defaultValue = currentValue = (v ? "true" : "false");
	}
	public Option(OnChange f)
	{
		this.type = "button";
		this.min = 0;
		this.max = 0;
		this.on_change = f;
	}
	public Option(double v, int minv, int maxv, OnChange f)
	{
		this.type = "spin";
		this.min = minv;
		this.max = maxv;
		this.on_change = f;
		defaultValue = currentValue = String.valueOf(v);
	}
	public Option(String v, String cur, OnChange f)
	{
		this.type = "combo";
		this.min = 0;
		this.max = 0;
		this.on_change = f;
		defaultValue = v;
		currentValue = cur;
	}
}