import java.util.*;

/// Stats is a generic N-dimensional array used to store various statistics.
/// The first template parameter T is the base type of the array, the second
/// template parameter D limits the range of updates in [-D, D] when we update
/// values with the << operator, while the last parameters (Size and Sizes)
/// encode the dimensions of the array.
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template <typename T, int D, int Size, int... Sizes>
public class Stats<T, int D, int Size, int... Sizes> extends ArrayList<Stats<T, D, Sizes...>>
{

  public final void fill(T v)
  {

	// For standard-layout 'this' points to first struct member
	assert std::is_standard_layout<GlobalMembers.Stats<T, D, Size, Sizes...>>.value;

//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent to 'reinterpret_cast' in Java:
	StatsEntry<T, D> p = reinterpret_cast<StatsEntry<T, D>>(this);
//C++ TO JAVA CONVERTER WARNING: This 'sizeof' ratio was replaced with a direct reference to the array length:
//ORIGINAL LINE: std::fill(p, p + sizeof(*this) / sizeof(StatsEntry<T, D>), v);
	std::fill(p, p + this.length, v);
  }
}