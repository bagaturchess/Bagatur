import java.util.*;

//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template <typename T, int D, int Size>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: struct Stats<T, D, Size> : public ClassicVector<StatsEntry<T, D>>
public class Stats<T, int D, int Size> extends ArrayList<StatsEntry<T, D>>
{
}