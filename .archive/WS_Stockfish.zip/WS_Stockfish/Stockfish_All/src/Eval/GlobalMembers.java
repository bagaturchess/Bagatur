package Eval;

public class GlobalMembers
{
	public static final Value Tempo = 20; // Must be visible to search

	/// trace() is like evaluate(), but instead of returning a value, it returns
	/// a string (suitable for outputting to stdout) that contains the detailed
	/// descriptions and values of each evaluation term. Useful for debugging.


	public static String trace(Position pos)
	{

//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	  memset(GlobalMembers.scores, 0, sizeof(GlobalMembers.scores));

	  pos.this_thread().contempt = Score.SCORE_ZERO; // Reset any dynamic contempt

	  Value v = new Evaluation<TRACE>(pos).value();

	  v = pos.side_to_move() == Color.WHITE ? v : -v; // Trace scores are from white's point of view

	  std::stringstream ss = new std::stringstream();
	  ss << std::showpoint << std::noshowpos << std::fixed << std::setprecision(2) << "     Term    |    White    |    Black    |    Total   \n" << "             |   MG    EG  |   MG    EG  |   MG    EG \n" << " ------------+-------------+-------------+------------\n" << "    Material | " << Term(MATERIAL) << "   Imbalance | " << Term(IMBALANCE) << "  Initiative | " << Term(INITIATIVE) << "       Pawns | " << Term(PieceType.PAWN) << "     Knights | " << Term(PieceType.KNIGHT) << "     Bishops | " << Term(PieceType.BISHOP) << "       Rooks | " << Term(PieceType.ROOK) << "      Queens | " << Term(PieceType.QUEEN) << "    Mobility | " << Term(MOBILITY) << " King safety | " << Term(PieceType.KING) << "     Threats | " << Term(THREAT) << "      Passed | " << Term(PASSED) << "       Space | " << Term(SPACE) << " ------------+-------------+-------------+------------\n" << "       Total | " << Term(TOTAL);

	  ss << "\nTotal evaluation: " << Trace.GlobalMembers.to_cp(v) << " (white side)\n";

	  return ss.str();
	}

	/// evaluate() is the evaluator for the outer world. It returns a static
	/// evaluation of the position from the point of view of the side to move.


	public static Value evaluate(Position pos)
	{
	  return new Evaluation<NO_TRACE>(pos).value();
	}
}