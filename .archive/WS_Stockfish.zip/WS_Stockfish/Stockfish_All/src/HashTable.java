import java.util.*;
import java.io.*;

// The needed Windows API for processor groups could be missed from old Windows
// versions, so instead of calling them directly (forcing the linker to resolve
// the calls at compile time), try to load them at runtime. To do this we need
// first to define the corresponding function pointers.
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: typedef bool(*fun1_t)(LOGICAL_PROCESSOR_RELATIONSHIP, PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX, PDWORD);
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: typedef bool(*fun2_t)(USHORT, PGROUP_AFFINITY);
///#endif
public class HashTable<Entry, int Size>
{
  public final Entry get(uint64_t key)
  {
	  return new Entry(table.get((uint32_t)key & (Size - 1)));
  }

  private ArrayList<Entry> table = new ArrayList<Entry>(Size);
}