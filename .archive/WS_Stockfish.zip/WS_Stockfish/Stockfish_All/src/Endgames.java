import String;
import java.util.*;
import java.io.*;

/// The Endgames class stores the pointers to endgame evaluation and scaling
/// base objects in two std::map. We use polymorphism to invoke the actual
/// endgame function by calling its virtual operator().

public class Endgames
{

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to C++11 template aliases:
  using Ptr = std::unique_ptr<EndgameBase<T>>;
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to C++11 template aliases:
  using Map = TreeMap<uint64_t, Ptr<T>>;

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
  private <T> Map<T> map()
  {
	return std::get<std::is_same<T, ScaleFactor>.value>(maps);
  }

//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
//ORIGINAL LINE: template<EndgameCode E, typename T = eg_type<E>>
//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers containing defaults cannot be converted to Java:
//ORIGINAL LINE: template<typename E, typename T = eg_type<E>>
  private <E, T = eg_type<E>> void add(String code)
  {

	StateInfo st = new StateInfo();
	this.<T>map()[new Position().set(code, Color.WHITE, st).material_key()] = Ptr<T>(new Endgame<E>(Color.WHITE));
	this.<T>map()[new Position().set(code, Color.BLACK, st).material_key()] = Ptr<T>(new Endgame<E>(Color.BLACK));
  }

  private tangible.Pair<Map<Value>, Map<ScaleFactor>> maps = new tangible.Pair<Map<Value>, Map<ScaleFactor>>();

  public Endgames()
  {

	this.<EndgameCode.KPK.getValue()>add("KPK");
	this.<EndgameCode.KNNK.getValue()>add("KNNK");
	this.<EndgameCode.KBNK.getValue()>add("KBNK");
	this.<EndgameCode.KRKP.getValue()>add("KRKP");
	this.<EndgameCode.KRKB.getValue()>add("KRKB");
	this.<EndgameCode.KRKN.getValue()>add("KRKN");
	this.<EndgameCode.KQKP.getValue()>add("KQKP");
	this.<EndgameCode.KQKR.getValue()>add("KQKR");

	this.<EndgameCode.KNPK.getValue()>add("KNPK");
	this.<EndgameCode.KNPKB.getValue()>add("KNPKB");
	this.<EndgameCode.KRPKR.getValue()>add("KRPKR");
	this.<EndgameCode.KRPKB.getValue()>add("KRPKB");
	this.<EndgameCode.KBPKB.getValue()>add("KBPKB");
	this.<EndgameCode.KBPKN.getValue()>add("KBPKN");
	this.<EndgameCode.KBPPKB.getValue()>add("KBPPKB");
	this.<EndgameCode.KRPPKRP.getValue()>add("KRPPKRP");
  }

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
  public final <T> EndgameBase<T> probe(uint64_t key)
  {
	return this.<T>map().count(key) ? this.<T>map()[key].get() : null;
  }
}