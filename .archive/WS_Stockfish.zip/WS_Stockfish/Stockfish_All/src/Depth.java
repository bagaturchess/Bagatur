public enum Depth
{

  ONE_PLY(1),

  DEPTH_ZERO(0 * ONE_PLY),
  DEPTH_QS_CHECKS(0 * ONE_PLY),
  DEPTH_QS_NO_CHECKS(-1 * ONE_PLY),
  DEPTH_QS_RECAPTURES(-5 * ONE_PLY),

  DEPTH_NONE(-6 * ONE_PLY),
  DEPTH_MAX(MAX_PLY * ONE_PLY);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Depth> mappings;
	private static java.util.HashMap<Integer, Depth> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Depth.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Depth>();
				}
			}
		}
		return mappings;
	}

	private Depth(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Depth forValue(int value)
	{
		return getMappings().get(value);
	}
}