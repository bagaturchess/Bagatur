package glaurung.position;

import glaurung.types.Color;
import glaurung.types.Phase;
import glaurung.types.Piece;
import glaurung.types.Square;

public interface Position {
	
	public static final long[][][] zobMaterial = new long[2][8][16];

	public boolean is_ok();

	public Color side_to_move();

	public int mg_value();

	public long get_material_key();

	public Phase game_phase();

	public long get_pawn_key();

	public long king_attacks(Object king_square);

	public Square king_square(Color white);

	public long pawns(Color white);

	public int knight_count(Color c);

	public Square knight_list(Color c, int i);

	public int bishop_count(Color c);

	public Square bishop_list(Color c, int i);

	public int rook_count(Color c);

	public Square rook_list(Color c, int i);

	public int queen_count(Color c);

	public Square queen_list(Color c, int i);

	public long bishops(Color c);

	public boolean can_castle(Color us);

	public long pieces_of_color(Color us);

	public boolean opposite_colored_bishops();

	public int non_pawn_material(Color black);

	public int pawn_count(Color white);

	public long occupied_squares();

	public long knight_attacks(Square s);

	public boolean square_is_weak(Square s, Color them);

	public long pawn_attacks(Color them, Square s);

	public long queens(Color us);

	public long rooks_and_queens(Color us);

	public long queen_attacks(Square s);

	public boolean is_check();

	public long pinned_pieces(Color them);

	public long rook_attacks(Square s);

	public long bishop_attacks(Square s);

	public long discovered_check_candidates(Color them);

	public long pawns();

	public Piece piece_on(Square s);

	public boolean pawn_is_passed(Color us, Square s);

	public boolean square_is_empty(Square blockSq);

	public int see(Square s, Square b6);
	
	

}
