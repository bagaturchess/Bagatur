package glaurung.position;
import glaurung.types.Move;
import glaurung.types.PieceType;
import glaurung.types.Square;
import glaurung.types.Value;

/// The UndoInfo struct stores information we need to restore a Position
/// object to its previous state when we retract a move.  Whenever a move
/// is made on the board (by calling Position::do_move), an UndoInfo object
/// must be passed as a parameter.  When the move is unmade (by calling
/// Position::undo_move), the same UndoInfo object must be passed again.

public class UndoInfo
{
  public int castleRights;
  public Square epSquare;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long checkersBB;
  public long checkersBB;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long key, pawnKey, materialKey;
  public long key;
  public long pawnKey;
  public long materialKey;
  public int rule50;
  public Move lastMove;
  public PieceType capture;
  public Value mgValue;
  public Value egValue;
}