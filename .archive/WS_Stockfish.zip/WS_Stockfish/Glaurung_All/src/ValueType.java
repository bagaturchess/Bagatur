/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


////
//// Includes
////


/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/



////
//// Includes
////



////
//// Types
////

public enum ValueType
{
  VALUE_TYPE_NONE(0),
  VALUE_TYPE_UPPER(1), // Upper bound
  VALUE_TYPE_LOWER(2), // Lower bound
  VALUE_TYPE_EXACT(3); // Exact score

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, ValueType> mappings;
	private static java.util.HashMap<Integer, ValueType> getMappings()
	{
		if (mappings == null)
		{
			synchronized (ValueType.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, ValueType>();
				}
			}
		}
		return mappings;
	}

	private ValueType(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static ValueType forValue(int value)
	{
		return getMappings().get(value);
	}
}