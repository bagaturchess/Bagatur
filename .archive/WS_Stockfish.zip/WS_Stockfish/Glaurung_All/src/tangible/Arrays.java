package tangible;

//----------------------------------------------------------------------------------------
//	Copyright © 2006 - 2019 Tangible Software Solutions, Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to initialize and delete array elements.
//----------------------------------------------------------------------------------------
public final class Arrays
{
	public static MoveStack[] initializeWithDefaultMoveStackInstances(int length)
	{
		MoveStack[] array = new MoveStack[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new MoveStack();
		}
		return array;
	}

	public static ScalingFunction[] initializeWithDefaultScalingFunctionInstances(int length)
	{
		ScalingFunction[] array = new ScalingFunction[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new ScalingFunction();
		}
		return array;
	}

	public static MaterialInfo[] initializeWithDefaultMaterialInfoInstances(int length)
	{
		MaterialInfo[] array = new MaterialInfo[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new MaterialInfo();
		}
		return array;
	}

	public static PawnInfo[] initializeWithDefaultPawnInfoInstances(int length)
	{
		PawnInfo[] array = new PawnInfo[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new PawnInfo();
		}
		return array;
	}

	public static pthread_t[] initializeWithDefaultpthread_tInstances(int length)
	{
		pthread_t[] array = new pthread_t[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new pthread_t();
		}
		return array;
	}

	public static SearchStack[] initializeWithDefaultSearchStackInstances(int length)
	{
		SearchStack[] array = new SearchStack[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new SearchStack();
		}
		return array;
	}

	public static RootMove[] initializeWithDefaultRootMoveInstances(int length)
	{
		RootMove[] array = new RootMove[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new RootMove();
		}
		return array;
	}

	public static Thread[] initializeWithDefaultThreadInstances(int length)
	{
		Thread[] array = new Thread[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new Thread();
		}
		return array;
	}

	public static HANDLE[] initializeWithDefaultHANDLEInstances(int length)
	{
		HANDLE[] array = new HANDLE[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new HANDLE();
		}
		return array;
	}

	public static TTEntry[] initializeWithDefaultTTEntryInstances(int length)
	{
		TTEntry[] array = new TTEntry[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new TTEntry();
		}
		return array;
	}

	public static <T extends java.io.Closeable> void deleteArray(T[] array)
	{
		for (T element : array)
		{
			if (element != null)
				element.close();
		}
	}
}