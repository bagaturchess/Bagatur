import java.io.*;

/// Abstract base class for all evaluation scaling functions:

public abstract class ScalingFunction implements Closeable
{
  public ScalingFunction(Color c)
  {
	strongerSide = c;
	weakerSide = GlobalMembers.opposite_color(c);
  }

  public void close()
  {
  }

  public abstract ScaleFactor apply(Position pos);

  protected Color strongerSide;
  protected Color weakerSide;
}