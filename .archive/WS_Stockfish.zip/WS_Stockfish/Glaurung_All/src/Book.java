public class Book
{

  // Constructors

  ////
  //// Functions
  ////


  /// Constructor

  public Book()
  {
	bookFile = null;
	bookSize = 0;
  }

  // Open and close book files

  /// Book::open() opens a book file with a given file name.

  public final void open(String fName)
  {
	fileName = fName;
	bookFile = fopen(fileName, "rb");
	if (bookFile != null)
	{
	  if (fseek(bookFile, 0, SEEK_END) == -1)
	  {
		std::cerr << "Failed to open book file " << fileName << std::endl;
		System.exit(1);
	  }
	  bookSize = ftell(bookFile) / 16;
	  if (bookSize == -1)
	  {
		std::cerr << "Failed to open book file " << fileName << std::endl;
		System.exit(1);
	  }
	}
  }


  /// Book::close() closes the currently open book file.

  public final void close()
  {
	if (bookFile != null && fclose(bookFile) == EOF)
	{
	  std::cerr << "Failed to close book file" << std::endl;
	  System.exit(1);
	}
  }

  // Testing if a book is opened

  /// Book::is_open() tests whether a book file has been opened.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean is_open() const
  public final boolean is_open()
  {
	return bookFile != null && bookSize != 0;
  }

  // The file name of the currently active book

  /// Book::file_name() returns the file name of the currently active book,
  /// or the empty string if no book is open.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: const String file_name() const
  public final String file_name()
  {
	return this.is_open()? fileName : "";
  }

  // Get a book move for a given position

  /// Book::get_move() gets a book move for a given position.  Returns
  /// MOVE_NONE if no book move is found.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Move get_move(const Position &pos) const
  public final Move get_move(Position pos)
  {
	if (this.is_open())
	{
	  int bestMove = 0;
	  int bestScore = 0;
	  int move;
	  int score;
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long key = book_key(pos);
	  long key = GlobalMembers.book_key(pos);
	  BookEntry entry = new BookEntry();

	  for (int i = this.find_key(key); i < bookSize; i++)
	  {
		this.read_entry(entry, i);
		if (entry.key != key)
		{
		  break;
		}
		move = entry.move;
		score = entry.count;
		assert score > 0;

		bestScore += score;
		if ((int)(genrand_int32() % bestScore) < score)
		{
		  bestMove = move;
		}
	  }

	  if (bestMove != 0)
	  {
		MoveStack[] moves = tangible.Arrays.initializeWithDefaultMoveStackInstances(256);
		int n;
		int j;
		n = generate_legal_moves(pos, moves);
		for (j = 0; j < n; j++)
		{
		  if ((moves[j].move.getValue() & 07777) == bestMove)
		  {
			return moves[j].move;
		  }
		}
	  }
	}
	return Move.MOVE_NONE;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: int find_key(unsigned long long key) const;

  /// Book::find_key() takes a book key as input, and does a binary search
  /// through the book file for the given key.  The index to the first book
  /// entry with the same key as the input is returned.  When the key is not
  /// found in the book file, bookSize is returned.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int find_key(ulong key) const
  private int find_key(long key)
  {
	int left;
	int right;
	int mid;
	BookEntry entry = new BookEntry();

	// Binary search (finds the leftmost entry)
	left = 0;
	right = bookSize - 1;

	assert left <= right;

	while (left < right)
	{
	  mid = (left + right) / 2;
	  assert mid >= left && mid < right;

	  this.read_entry(entry, mid);

	  if (key <= entry.key)
	  {
		right = mid;
	  }
	  else
	  {
		left = mid + 1;
	  }
	}

	assert left == right;

	this.read_entry(entry, left);

	return (entry.key == key)? left : bookSize;
  }


  /// Book::read_entry() takes a BookEntry reference and an integer index as
  /// input, and looks up the opening book entry at the given index in the book
  /// file.  The book entry is copied to the first input parameter.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: void read_entry(BookEntry& entry, int n) const
  private void read_entry(BookEntry entry, int n)
  {
	assert n >= 0 && n < bookSize;
	assert bookFile != null;

	if (fseek(bookFile, n * 16, SEEK_SET) == -1)
	{
	  std::cerr << "Failed to read book entry at index " << n << std::endl;
	  System.exit(1);
	}

	entry.key = GlobalMembers.read_integer(bookFile, 8);
	entry.move = (short)GlobalMembers.read_integer(bookFile, 2);
	entry.count = (short)GlobalMembers.read_integer(bookFile, 2);
	entry.n = (short)GlobalMembers.read_integer(bookFile, 2);
	entry.sum = (short)GlobalMembers.read_integer(bookFile, 2);
  }

  private String fileName;
  private FILE bookFile;
  private int bookSize;
}
////
//// Local definitions
////


