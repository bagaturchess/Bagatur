  public class Option
  {
	public String name = new String(new char[50]);
	public String defaultValue = new String(new char[300]);
	public String currentValue = new String(new char[300]);
	public OptionType type;
	public int minValue;
	public int maxValue;
	public char[][] comboValues = new char[8][64];
  }