import java.io.*;

// KBB vs KN:
public class KBBKNEvaluationFunction extends EndgameEvaluationFunction
{
  public KBBKNEvaluationFunction(Color c)
  {
	  super(c);
  }

  @Override
  public final Value apply(Position pos)
  {
	assert pos.bishop_count(strongerSide) == 2;
	assert pos.non_pawn_material(strongerSide) == 2 * GlobalMembers.BishopValueMidgame;
	assert pos.knight_count(weakerSide) == 1;
	assert pos.non_pawn_material(weakerSide) == GlobalMembers.KnightValueMidgame;
	assert pos.pawns() == GlobalMembers.EmptyBoardBB;

	Value result = GlobalMembers.BishopValueEndgame;
	Square wksq = pos.king_square(strongerSide);
	Square bksq = pos.king_square(weakerSide);
	Square nsq = pos.knight_list(weakerSide, 0);

	// Bonus for attacking king close to defending king:
	result += GlobalMembers.distance_bonus(GlobalMembers.square_distance(wksq, bksq));

	// Bonus for driving the defending king and knight apart:
	result += Value(GlobalMembers.square_distance(bksq, nsq) * 32);

	// Bonus for restricting the knight's mobility:
	result += Value((8 - GlobalMembers.count_1s_max_15(pos.knight_attacks(nsq))) * 8);

	return (strongerSide == pos.side_to_move())? result : -result;
  }
}