import java.io.*;

// KQ vs KRP:
public class KQKRPScalingFunction extends ScalingFunction
{
  public KQKRPScalingFunction(Color c)
  {
	  super(c);
  }


  /// KQKRPScalingFunction scales endgames where the stronger side has only
  /// king and queen, while the weaker side has at least a rook and a pawn.
  /// It tests for fortress draws with a rook on the third rank defended by
  /// a pawn.

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.QueenValueMidgame;
	assert pos.queen_count(strongerSide) == 1;
	assert pos.pawn_count(strongerSide) == 0;
	assert pos.rook_count(weakerSide) == 1;
	assert pos.pawn_count(weakerSide) >= 1;

	Square kingSq = pos.king_square(weakerSide);
	if (GlobalMembers.pawn_rank(weakerSide, kingSq) <= Rank.RANK_2.getValue() && GlobalMembers.pawn_rank(weakerSide, pos.king_square(strongerSide)) >= Rank.RANK_4.getValue() && (pos.rooks(weakerSide) & GlobalMembers.relative_rank_bb(weakerSide, Rank.RANK_3)) != 0 && (pos.pawns(weakerSide) & GlobalMembers.relative_rank_bb(weakerSide, Rank.RANK_2)) != 0 && (pos.king_attacks(kingSq) & pos.pawns(weakerSide)) != 0)
	{
	  Square rsq = pos.rook_list(weakerSide, 0);
	  if ((pos.pawn_attacks(strongerSide, rsq) & pos.pawns(weakerSide)) != 0)
	  {
		return ScaleFactor(0);
	  }
	}
	return ScaleFactor.SCALE_FACTOR_NONE;
  }
}