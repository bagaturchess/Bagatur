public class Thread
{
  public SplitPoint splitPoint;
  public int activeSplitPoints;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long nodes;
  public long nodes;
  public boolean failHighPly1;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile boolean stop;
  public boolean stop;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile boolean running;
  public boolean running;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile boolean idle;
  public boolean idle;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile boolean workIsWaiting;
  public boolean workIsWaiting;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile boolean printCurrentLine;
  public boolean printCurrentLine;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned char pad[64];
  public byte[] pad = new byte[64];
}