import java.io.*;

/// Subclasses for various concrete endgames:

// KBP vs K:
public class KBPKScalingFunction extends ScalingFunction
{
  public KBPKScalingFunction(Color c)
  {
	  super(c);
  }


  /// KBPKScalingFunction scales endgames where the stronger side has king,
  /// bishop and one or more pawns.  It checks for draws with rook pawns and a
  /// bishop of the wrong color.  If such a draw is detected, ScaleFactor(0) is
  /// returned.  If not, the return value is SCALE_FACTOR_NONE, i.e. no scaling
  /// will be used.

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.BishopValueMidgame;
	assert pos.bishop_count(strongerSide) == 1;
	assert pos.pawn_count(strongerSide) >= 1;

	// No assertions about the material of weakerSide, because we want draws to
	// be detected even when the weaker side has some pawns.

  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long pawns = pos.pawns(strongerSide);
	long pawns = pos.pawns(strongerSide);
	File pawnFile = GlobalMembers.square_file(pos.pawn_list(strongerSide, 0));

	if ((pawnFile == File.FILE_A || pawnFile == File.FILE_H) && (pawns & ~GlobalMembers.file_bb(pawnFile)) == GlobalMembers.EmptyBoardBB)
	{
	  // All pawns are on a single rook file.

	  Square bishopSq = pos.bishop_list(strongerSide, 0);
	  Square queeningSq = GlobalMembers.relative_square(strongerSide, GlobalMembers.make_square(pawnFile, Rank.RANK_8));
	  Square kingSq = pos.king_square(weakerSide);

	  if (GlobalMembers.square_color(queeningSq) != GlobalMembers.square_color(bishopSq) && GlobalMembers.file_distance(GlobalMembers.square_file(kingSq), pawnFile) <= 1)
	  {
		// The bishop has the wrong color, and the defending king is on the
		// file of the pawn(s) or the neighboring file.  Find the rank of the
		// frontmost pawn:

		Rank rank;
		if (strongerSide == Color.WHITE)
		{
		  for (rank = Rank.RANK_7; (GlobalMembers.rank_bb(rank) & pawns) == GlobalMembers.EmptyBoardBB; rank--)
		  {
			  ;
		  }
		  assert rank.getValue() >= Rank.RANK_2.getValue() && rank.getValue() <= Rank.RANK_7.getValue();
		}
		else
		{
		  for (rank = Rank.RANK_2; (GlobalMembers.rank_bb(rank) & pawns) == GlobalMembers.EmptyBoardBB; rank++)
		  {
			  ;
		  }
		  rank = Rank(rank ^ 7); // HACK
		  assert rank.getValue() >= Rank.RANK_2.getValue() && rank.getValue() <= Rank.RANK_7.getValue();
		}
		// If the defending king has distance 1 to the promotion square or
		// is placed somewhere in front of the pawn, it's a draw.
		if (GlobalMembers.square_distance(kingSq, queeningSq) <= 1 || GlobalMembers.pawn_rank(strongerSide, kingSq) >= rank.getValue())
		{
		  return ScaleFactor(0);
		}
	  }
	}
	return ScaleFactor.SCALE_FACTOR_NONE;
  }
}