////
//// Local definitions:
////


  // UCIInputParser is a class for parsing UCI input.  The class is
  // very simple, and basically just consist of a constant input
  // string and a current location in the string.  There are methods
  // for checking if we are at the end of the line, for getting the
  // next token (defined as any whitespace-delimited sequence of
  // characters), and for getting the rest of the line as a single
  // string.

  public class UCIInputParser
  {


	///
	/// Implementation of the UCIInputParser class.
	///

	// Constructor for the UCIInputParser class.  The constructor takes a 
	// text string containing a single UCI command as input.

	public UCIInputParser(String line)
	{
		this.inputLine = line;
	  this.currentIndex = 0;
	  this.length = line.length();
	}


	// UCIInputParser::get_next_token() gets the next token in an UCI
	// command.  A 'token' in an UCI command is simply any
	// whitespace-delimited sequence of characters.

	public final String get_next_token()
	{
	  int i;
	  int j;

	  this.skip_whitespace();
	  for (i = j = this.currentIndex; j < this.length && !isspace(this.inputLine.charAt(j)); j++)
	  {
		  ;
	  }
	  this.currentIndex = j;
	  this.skip_whitespace();

	  String str = this.inputLine.substring(i, j);

	  return str;
	}


	// UCIInputParser::get_rest_of_line() returns the rest of the input
	// line (from the current location) as a single string.

	public final String get_rest_of_line()
	{
	  this.skip_whitespace();
	  return this.inputLine.substring(this.currentIndex, this.currentIndex + this.length);
	}


	// UCIInputParser::at_end_of_line() tests whether we have reached the
	// end of the input string, i.e. if any more input remains to be
	// parsed.

	public final boolean at_end_of_line()
	{
	  return this.currentIndex == this.length;
	}

	private final String inputLine;
	private int length;
	private int currentIndex;


	// UCIInputParser::skip_whitspace() skips any number of whitespace
	// characters from the current location in an input string.

	private void skip_whitespace()
	{
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: while(isspace((int)(unsigned char)this->inputLine[this->currentIndex]))
	  while (isspace((int)(byte)this.inputLine[this.currentIndex]))
	  {
		this.currentIndex++;
	  }
	}

  }
////
//// Local functions
////


