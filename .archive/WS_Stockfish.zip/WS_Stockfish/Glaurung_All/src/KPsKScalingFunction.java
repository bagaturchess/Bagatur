import java.io.*;

// King and pawns vs king:
public class KPsKScalingFunction extends ScalingFunction
{
  public KPsKScalingFunction(Color c)
  {
	  super(c);
  }


  /// KPsKScalingFunction scales endgames with king and two or more pawns
  /// against king.  There is just a single rule here:  If all pawns are on
  /// the same rook file and are blocked by the defending king, it's a draw.

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == Value(0);
	assert pos.pawn_count(strongerSide) >= 2;
	assert pos.non_pawn_material(weakerSide) == Value(0);
	assert pos.pawn_count(weakerSide) == 0;

  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long pawns = pos.pawns(strongerSide);
	long pawns = pos.pawns(strongerSide);

	// Are all pawns on the 'a' file?
	if ((pawns & ~GlobalMembers.FileABB) == GlobalMembers.EmptyBoardBB)
	{
	  // Does the defending king block the pawns?
	  Square ksq = pos.king_square(weakerSide);
	  if (GlobalMembers.square_distance(ksq, GlobalMembers.relative_square(strongerSide, Square.SQ_A8)) <= 1)
	  {
		return ScaleFactor(0);
	  }
	  else if (GlobalMembers.square_file(ksq) == File.FILE_A && (GlobalMembers.in_front_bb(strongerSide, ksq) & pawns) == GlobalMembers.EmptyBoardBB)
	  {
		return ScaleFactor(0);
	  }
	  else
	  {
		return ScaleFactor.SCALE_FACTOR_NONE;
	  }
	}
	// Are all pawns on the 'h' file?
	else if ((pawns & ~GlobalMembers.FileHBB) == GlobalMembers.EmptyBoardBB)
	{
	  // Does the defending king block the pawns?
	  Square ksq = pos.king_square(weakerSide);
	  if (GlobalMembers.square_distance(ksq, GlobalMembers.relative_square(strongerSide, Square.SQ_H8)) <= 1)
	  {
		return ScaleFactor(0);
	  }
	  else if (GlobalMembers.square_file(ksq) == File.FILE_H && (GlobalMembers.in_front_bb(strongerSide, ksq) & pawns) == GlobalMembers.EmptyBoardBB)
	  {
		return ScaleFactor(0);
	  }
	  else
	  {
		return ScaleFactor.SCALE_FACTOR_NONE;
	  }
	}
	else
	{
	  return ScaleFactor.SCALE_FACTOR_NONE;
	}
  }
}