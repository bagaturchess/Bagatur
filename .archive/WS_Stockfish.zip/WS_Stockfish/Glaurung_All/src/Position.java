/// The position data structure.  A position consists of the following data:
///    
///    * For each piece type, a bitboard representing the squares occupied
///      by pieces of that type.
///    * For each color, a bitboard representing the squares occupiecd by
///      pieces of that color.
///    * A bitboard of all occupied squares.
///    * A bitboard of all checking pieces.
///    * A 64-entry array of pieces, indexed by the squares of the board.
///    * The current side to move.
///    * Information about the castling rights for both sides.
///    * The initial files of the kings and both pairs of rooks.  This is
///      used to implement the Chess960 castling rules.
///    * The en passant square (which is SQ_NONE if no en passant capture is
///      possible).
///    * The squares of the kings for both sides.
///    * The last move played.
///    * Hash keys for the position itself, the current pawn structure, and
///      the current material situation.
///    * Hash keys for all previous positions in the game (for detecting
///      repetition draws.
///    * A counter for detecting 50 move rule draws.

public class Position
{

//C++ TO JAVA CONVERTER TODO TASK: Java has no concept of a 'friend' class:
//  friend class MaterialInfo;

  // Constructors

  ////
  //// Functions
  ////

  /// Constructors

  public Position()
  {
  } // Do we really need this one?

  public Position(Position pos)
  {
	this.copy(pos);
  }

  public Position(String fen)
  {
	this.from_fen(fen);
  }

  // Text input/output

  /// Position::from_fen() initializes the position object with the given FEN
  /// string. This function is not very robust - make sure that input FENs are
  /// correct (this is assumed to be the responsibility of the GUI).

  public final void from_fen(String fen)
  {
	File file;
	Rank rank;
	int i;

	this.clear();

	// Board
	rank = Rank.RANK_8;
	file = File.FILE_A;
	for (i = 0; fen.charAt(i) != ' '; i++)
	{
	  if (isdigit(fen.charAt(i)))
	  {
		// Skip the given number of files
		file += (fen.charAt(i) - '1' + 1);
	  }
	  else
	  {
		Square square = GlobalMembers.make_square(file, rank);
		switch (fen.charAt(i))
		{
		case 'K':
			this.put_piece(Piece.WK, square);
			file++;
			break;
		case 'Q':
			this.put_piece(Piece.WQ, square);
			file++;
			break;
		case 'R':
			this.put_piece(Piece.WR, square);
			file++;
			break;
		case 'B':
			this.put_piece(Piece.WB, square);
			file++;
			break;
		case 'N':
			this.put_piece(Piece.WN, square);
			file++;
			break;
		case 'P':
			this.put_piece(Piece.WP, square);
			file++;
			break;
		case 'k':
			this.put_piece(Piece.BK, square);
			file++;
			break;
		case 'q':
			this.put_piece(Piece.BQ, square);
			file++;
			break;
		case 'r':
			this.put_piece(Piece.BR, square);
			file++;
			break;
		case 'b':
			this.put_piece(Piece.BB, square);
			file++;
			break;
		case 'n':
			this.put_piece(Piece.BN, square);
			file++;
			break;
		case 'p':
			this.put_piece(Piece.BP, square);
			file++;
			break;
		case '/':
			file = File.FILE_A;
			rank--;
			break;
		case ' ':
			break;
		default:
		  System.out.print("Error in FEN at character ");
		  System.out.print(i);
		  System.out.print("\n");
		  return;
		}
	  }
	}

	// Side to move
	i++;
	if (fen.charAt(i) == 'w')
	{
	  sideToMove = Color.WHITE;
	}
	else if (fen.charAt(i) == 'b')
	{
	  sideToMove = Color.BLACK;
	}
	else
	{
	  System.out.print("Error in FEN at character ");
	  System.out.print(i);
	  System.out.print("\n");
	  return;
	}

	// Castling rights:
	i++;
	if (fen.charAt(i) != ' ')
	{
	  System.out.print("Error in FEN at character ");
	  System.out.print(i);
	  System.out.print("\n");
	  return;
	}

	i++;
	while (tangible.StringFunctions.strChr("KQkqabcdefghABCDEFGH-", fen.charAt(i)))
	{
	  if (fen.charAt(i) == '-')
	  {
		i++;
		break;
	  }
	  else if (fen.charAt(i) == 'K')
	  {
		  this.allow_oo(Color.WHITE);
	  }
	  else if (fen.charAt(i) == 'Q')
	  {
		  this.allow_ooo(Color.WHITE);
	  }
	  else if (fen.charAt(i) == 'k')
	  {
		  this.allow_oo(Color.BLACK);
	  }
	  else if (fen.charAt(i) == 'q')
	  {
		  this.allow_ooo(Color.BLACK);
	  }
	  else if (fen.charAt(i) >= 'A' && fen.charAt(i) <= 'H')
	  {
		File rookFile;
		File kingFile = File.FILE_NONE;
		for (Square square = Square.SQ_B1; square.getValue() <= Square.SQ_G1.getValue(); square++)
		{
		  if (this.piece_on(square) == Piece.WK)
		  {
			kingFile = GlobalMembers.square_file(square);
		  }
		}
		if (kingFile == File.FILE_NONE)
		{
		  System.out.print("Error in FEN at character ");
		  System.out.print(i);
		  System.out.print("\n");
		  return;
		}
		initialKFile = kingFile;
		rookFile = File(fen.charAt(i) - 'A') + File.FILE_A;
		if (rookFile.getValue() < initialKFile.getValue())
		{
		  this.allow_ooo(Color.WHITE);
		  initialQRFile = rookFile;
		}
		else
		{
		  this.allow_oo(Color.WHITE);
		  initialKRFile = rookFile;
		}
	  }
	  else if (fen.charAt(i) >= 'a' && fen.charAt(i) <= 'h')
	  {
		File rookFile;
		File kingFile = File.FILE_NONE;
		for (Square square = Square.SQ_B8; square.getValue() <= Square.SQ_G8.getValue(); square++)
		{
		  if (this.piece_on(square) == Piece.BK)
		  {
			kingFile = GlobalMembers.square_file(square);
		  }
		}
		if (kingFile == File.FILE_NONE)
		{
		  System.out.print("Error in FEN at character ");
		  System.out.print(i);
		  System.out.print("\n");
		  return;
		}
		initialKFile = kingFile;
		rookFile = File(fen.charAt(i) - 'a') + File.FILE_A;
		if (rookFile.getValue() < initialKFile.getValue())
		{
		  this.allow_ooo(Color.BLACK);
		  initialQRFile = rookFile;
		}
		else
		{
		  this.allow_oo(Color.BLACK);
		  initialKRFile = rookFile;
		}
	  }
	  else
	  {
		System.out.print("Error in FEN at character ");
		System.out.print(i);
		System.out.print("\n");
		return;
	  }
	  i++;
	}

	while (fen.charAt(i) == ' ')
	{
	  i++;
	}

	// En passant square
	if (i < (int)fen.length() - 2)
	{
	  if (fen.charAt(i) >= 'a' && fen.charAt(i) <= 'h' && (fen.charAt(i + 1) == '3' || fen.charAt(i + 1) == '6'))
	  {
		epSquare = square_from_string(fen.substring(i, i + 2));
	  }
	}

	// Various initialisation

	for (Square sq = Square.SQ_A1; sq.getValue() <= Square.SQ_H8.getValue(); sq++)
	{
	  castleRightsMask[sq.getValue()] = CastleRights.ALL_CASTLES.getValue();
	}
	castleRightsMask[GlobalMembers.make_square(initialKFile, Rank.RANK_1).getValue()] ^= (CastleRights.WHITE_OO | CastleRights.WHITE_OOO);
	castleRightsMask[GlobalMembers.make_square(initialKFile, Rank.RANK_8).getValue()] ^= (CastleRights.BLACK_OO | CastleRights.BLACK_OOO);
	castleRightsMask[GlobalMembers.make_square(initialKRFile, Rank.RANK_1).getValue()] ^= CastleRights.WHITE_OO;
	castleRightsMask[GlobalMembers.make_square(initialKRFile, Rank.RANK_8).getValue()] ^= CastleRights.BLACK_OO;
	castleRightsMask[GlobalMembers.make_square(initialQRFile, Rank.RANK_1).getValue()] ^= CastleRights.WHITE_OOO;
	castleRightsMask[GlobalMembers.make_square(initialQRFile, Rank.RANK_8).getValue()] ^= CastleRights.BLACK_OOO;

	this.find_checkers();

	key = this.compute_key();
	pawnKey = this.compute_pawn_key();
	materialKey = this.compute_material_key();
	mgValue = this.compute_mg_value();
	egValue = this.compute_eg_value();
	npMaterial[Color.WHITE.getValue()] = this.compute_non_pawn_material(Color.WHITE);
	npMaterial[Color.BLACK.getValue()] = this.compute_non_pawn_material(Color.BLACK);
  }


  /// Position::to_fen() converts the position object to a FEN string. This is
  /// probably only useful for debugging.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: const String to_fen() const
  public final String to_fen()
  {
	final String pieceLetters = " PNBRQK  pnbrqk";
	String result;
	int skip;

	for (Rank rank = Rank.RANK_8; rank.getValue() >= Rank.RANK_1.getValue(); rank--)
	{
	  skip = 0;
	  for (File file = File.FILE_A; file.getValue() <= File.FILE_H.getValue(); file++)
	  {
		Square square = GlobalMembers.make_square(file, rank);
		if (this.square_is_occupied(square))
		{
		  if (skip > 0)
		  {
			  result += (char)skip + '0';
		  }
		  result += pieceLetters.charAt(this.piece_on(square));
		  skip = 0;
		}
		else
		{
			skip++;
		}
	  }
	  if (skip > 0)
	  {
		  result += (char)skip + '0';
	  }
	  result += (rank.getValue() > Rank.RANK_1.getValue())? '/' : ' ';
	}

	result += (sideToMove == Color.WHITE)? 'w' : 'b';
	result += ' ';
	if (castleRights == CastleRights.NO_CASTLES.getValue())
	{
		result += '-';
	}
	else
	{
	  if (this.can_castle_kingside(Color.WHITE))
	  {
		  result += 'K';
	  }
	  if (this.can_castle_queenside(Color.WHITE))
	  {
		  result += 'Q';
	  }
	  if (this.can_castle_kingside(Color.BLACK))
	  {
		  result += 'k';
	  }
	  if (this.can_castle_queenside(Color.BLACK))
	  {
		  result += 'q';
	  }
	}

	result += ' ';
	if (this.ep_square() == Square.SQ_NONE)
	{
		result += '-';
	}
	else
	{
		result += square_to_string(this.ep_square());
	}

	return result;
  }


  /// Position::print() prints an ASCII representation of the position to
  /// the standard output.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: void print() const
  public final void print()
  {
	String[] pieceStrings = {"| ? ", "| P ", "| N ", "| B ", "| R ", "| Q ", "| K ", "| ? ", "| ? ", "|=P=", "|=N=", "|=B=", "|=R=", "|=Q=", "|=K="};

	for (Rank rank = Rank.RANK_8; rank.getValue() >= Rank.RANK_1.getValue(); rank--)
	{
	  System.out.print("+---+---+---+---+---+---+---+---+\n");
	  for (File file = File.FILE_A; file.getValue() <= File.FILE_H.getValue(); file++)
	  {
		Square sq = GlobalMembers.make_square(file, rank);
		Piece piece = this.piece_on(sq);
		if (piece == Piece.EMPTY)
		{
		  System.out.print(((GlobalMembers.square_color(sq) == Color.WHITE)? "|   " : "| . "));
		}
		else
		{
		  System.out.print(pieceStrings[piece.getValue()]);
		}
	  }
	  System.out.print("|\n");
	}
	System.out.print("+---+---+---+---+---+---+---+---+\n");
	System.out.print(this.to_fen());
	System.out.print("\n");
	System.out.print(key);
	System.out.print("\n");
  }

  // Copying

  /// Position::copy() creates a copy of the input position.

  public final void copy(Position pos)
  {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memcpy(this, pos, sizeof(Position));
  }


  /// Position::flipped_copy() makes a copy of the input position, but with
  /// the white and black sides reversed.  This is only useful for debugging,
  /// especially for finding evaluation symmetry bugs.

  public final void flipped_copy(Position pos)
  {
	assert pos.is_ok();

	this.clear();

	// Board
	for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
	{
	  if (!pos.square_is_empty(s))
	  {
		this.put_piece(Piece(pos.piece_on(s).getValue() ^ 8), GlobalMembers.flip_square(s));
	  }
	}

	// Side to move
	sideToMove = GlobalMembers.opposite_color(pos.side_to_move());

	// Castling rights
	if (pos.can_castle_kingside(Color.WHITE))
	{
		this.allow_oo(Color.BLACK);
	}
	if (pos.can_castle_queenside(Color.WHITE))
	{
		this.allow_ooo(Color.BLACK);
	}
	if (pos.can_castle_kingside(Color.BLACK))
	{
		this.allow_oo(Color.WHITE);
	}
	if (pos.can_castle_queenside(Color.BLACK))
	{
		this.allow_ooo(Color.WHITE);
	}

	initialKFile = pos.initialKFile;
	initialKRFile = pos.initialKRFile;
	initialQRFile = pos.initialQRFile;

	for (Square sq = Square.SQ_A1; sq.getValue() <= Square.SQ_H8.getValue(); sq++)
	{
	  castleRightsMask[sq.getValue()] = CastleRights.ALL_CASTLES.getValue();
	}
	castleRightsMask[GlobalMembers.make_square(initialKFile, Rank.RANK_1).getValue()] ^= (CastleRights.WHITE_OO | CastleRights.WHITE_OOO);
	castleRightsMask[GlobalMembers.make_square(initialKFile, Rank.RANK_8).getValue()] ^= (CastleRights.BLACK_OO | CastleRights.BLACK_OOO);
	castleRightsMask[GlobalMembers.make_square(initialKRFile, Rank.RANK_1).getValue()] ^= CastleRights.WHITE_OO;
	castleRightsMask[GlobalMembers.make_square(initialKRFile, Rank.RANK_8).getValue()] ^= CastleRights.BLACK_OO;
	castleRightsMask[GlobalMembers.make_square(initialQRFile, Rank.RANK_1).getValue()] ^= CastleRights.WHITE_OOO;
	castleRightsMask[GlobalMembers.make_square(initialQRFile, Rank.RANK_8).getValue()] ^= CastleRights.BLACK_OOO;

	// En passant square
	if (pos.epSquare != Square.SQ_NONE)
	{
	  epSquare = GlobalMembers.flip_square(pos.epSquare);
	}

	// Checkers
	this.find_checkers();

	// Hash keys
	key = this.compute_key();
	pawnKey = this.compute_pawn_key();
	materialKey = this.compute_material_key();

	// Incremental scores
	mgValue = this.compute_mg_value();
	egValue = this.compute_eg_value();

	// Material
	npMaterial[Color.WHITE.getValue()] = this.compute_non_pawn_material(Color.WHITE);
	npMaterial[Color.BLACK.getValue()] = this.compute_non_pawn_material(Color.BLACK);

	assert this.is_ok();
  }

  // The piece on a given square

  ////
  //// Inline functions
  ////

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Piece piece_on(Square s) const
  public final Piece piece_on(Square s)
  {
	return board[s.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline PieceType type_of_piece_on(Square s) const
  public final PieceType type_of_piece_on(Square s)
  {
	return GlobalMembers.type_of_piece(this.piece_on(s));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Color color_of_piece_on(Square s) const
  public final Color color_of_piece_on(Square s)
  {
	return GlobalMembers.color_of_piece(this.piece_on(s));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean square_is_empty(Square s) const
  public final boolean square_is_empty(Square s)
  {
	return this.piece_on(s) == Piece.EMPTY;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean square_is_occupied(Square s) const
  public final boolean square_is_occupied(Square s)
  {
	return !this.square_is_empty(s);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value midgame_value_of_piece_on(Square s) const
  public final Value midgame_value_of_piece_on(Square s)
  {
	return GlobalMembers.piece_value_midgame(this.piece_on(s));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value endgame_value_of_piece_on(Square s) const
  public final Value endgame_value_of_piece_on(Square s)
  {
	return GlobalMembers.piece_value_endgame(this.piece_on(s));
  }

  // Side to move
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Color side_to_move() const
  public final Color side_to_move()
  {
	return sideToMove;
  }

  // Bitboard representation of the position
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long empty_squares() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong empty_squares() const
  public final long empty_squares()
  {
	return (long)(~(this.occupied_squares()));
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long occupied_squares() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong occupied_squares() const
  public final long occupied_squares()
  {
	return byTypeBB[0];
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pieces_of_color(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces_of_color(Color c) const
  public final long pieces_of_color(Color c)
  {
	return byColorBB[c.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pieces_of_type(PieceType pt) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces_of_type(PieceType pt) const
  public final long pieces_of_type(PieceType pt)
  {
	return byTypeBB[pt.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pieces_of_color_and_type(Color c, PieceType pt) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pieces_of_color_and_type(Color c, PieceType pt) const
  public final long pieces_of_color_and_type(Color c, PieceType pt)
  {
	return this.pieces_of_color(c) & this.pieces_of_type(pt);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pawns() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pawns() const
  public final long pawns()
  {
	return this.pieces_of_type(PieceType.PAWN);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long knights() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong knights() const
  public final long knights()
  {
	return this.pieces_of_type(PieceType.KNIGHT);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long bishops() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong bishops() const
  public final long bishops()
  {
	return this.pieces_of_type(PieceType.BISHOP);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long rooks() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong rooks() const
  public final long rooks()
  {
	return this.pieces_of_type(PieceType.ROOK);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long queens() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong queens() const
  public final long queens()
  {
	return this.pieces_of_type(PieceType.QUEEN);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long kings() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong kings() const
  public final long kings()
  {
	return this.pieces_of_type(PieceType.KING);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long rooks_and_queens() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong rooks_and_queens() const
  public final long rooks_and_queens()
  {
	return this.rooks() | this.queens();
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long bishops_and_queens() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong bishops_and_queens() const
  public final long bishops_and_queens()
  {
	return this.bishops() | this.queens();
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long sliders() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong sliders() const
  public final long sliders()
  {
	return this.bishops() | this.queens() | this.rooks();
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pawns(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pawns(Color c) const
  public final long pawns(Color c)
  {
	return this.pieces_of_color_and_type(c, PieceType.PAWN);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long knights(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong knights(Color c) const
  public final long knights(Color c)
  {
	return this.pieces_of_color_and_type(c, PieceType.KNIGHT);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long bishops(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong bishops(Color c) const
  public final long bishops(Color c)
  {
	return this.pieces_of_color_and_type(c, PieceType.BISHOP);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long rooks(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong rooks(Color c) const
  public final long rooks(Color c)
  {
	return this.pieces_of_color_and_type(c, PieceType.ROOK);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long queens(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong queens(Color c) const
  public final long queens(Color c)
  {
	return this.pieces_of_color_and_type(c, PieceType.QUEEN);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long kings(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong kings(Color c) const
  public final long kings(Color c)
  {
	return this.pieces_of_color_and_type(c, PieceType.KING);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long rooks_and_queens(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong rooks_and_queens(Color c) const
  public final long rooks_and_queens(Color c)
  {
	return this.rooks_and_queens() & this.pieces_of_color(c);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long bishops_and_queens(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong bishops_and_queens(Color c) const
  public final long bishops_and_queens(Color c)
  {
	return this.bishops_and_queens() & this.pieces_of_color(c);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long sliders_of_color(Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong sliders_of_color(Color c) const
  public final long sliders_of_color(Color c)
  {
	return this.sliders() & this.pieces_of_color(c);
  }

  // Number of pieces of each color and type
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int piece_count(Color c, PieceType pt) const
  public final int piece_count(Color c, PieceType pt)
  {
	return pieceCount[c.getValue()][pt.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int pawn_count(Color c) const
  public final int pawn_count(Color c)
  {
	return this.piece_count(c, PieceType.PAWN);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int knight_count(Color c) const
  public final int knight_count(Color c)
  {
	return this.piece_count(c, PieceType.KNIGHT);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int bishop_count(Color c) const
  public final int bishop_count(Color c)
  {
	return this.piece_count(c, PieceType.BISHOP);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int rook_count(Color c) const
  public final int rook_count(Color c)
  {
	return this.piece_count(c, PieceType.ROOK);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int queen_count(Color c) const
  public final int queen_count(Color c)
  {
	return this.piece_count(c, PieceType.QUEEN);
  }

  // The en passant square:
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square ep_square() const
  public final Square ep_square()
  {
	return epSquare;
  }

  // Current king position for each color
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square king_square(Color c) const
  public final Square king_square(Color c)
  {
	return kingSquare[c.getValue()];
  }

  // Castling rights.
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean can_castle_kingside(Color side) const
  public final boolean can_castle_kingside(Color side)
  {
	return (castleRights & (1 + side.getValue())) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean can_castle_queenside(Color side) const
  public final boolean can_castle_queenside(Color side)
  {
	return (castleRights & (4 + 4 * side.getValue())) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean can_castle(Color side) const
  public final boolean can_castle(Color side)
  {
	return can_castle_kingside(side) || can_castle_queenside(side);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square initial_kr_square(Color c) const
  public final Square initial_kr_square(Color c)
  {
	return GlobalMembers.relative_square(c, GlobalMembers.make_square(initialKRFile, Rank.RANK_1));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square initial_qr_square(Color c) const
  public final Square initial_qr_square(Color c)
  {
	return GlobalMembers.relative_square(c, GlobalMembers.make_square(initialQRFile, Rank.RANK_1));
  }

  // Attack bitboards
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long sliding_attacks(Square s, Direction d) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong sliding_attacks(Square s, Direction d) const;
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  ulong sliding_attacks(Square s, Direction d);
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long ray_attacks(Square s, SignedDirection d) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong ray_attacks(Square s, SignedDirection d) const;
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
//  ulong ray_attacks(Square s, SignedDirection d);
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pawn_attacks(Color c, Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong pawn_attacks(Color c, Square s) const
  public final long pawn_attacks(Color c, Square s)
  {
	return StepAttackBB[GlobalMembers.pawn_of_color(c).getValue()][s.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long white_pawn_attacks(Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong white_pawn_attacks(Square s) const
  public final long white_pawn_attacks(Square s)
  {
	return this.pawn_attacks(Color.WHITE, s);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long black_pawn_attacks(Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong black_pawn_attacks(Square s) const
  public final long black_pawn_attacks(Square s)
  {
	return this.pawn_attacks(Color.BLACK, s);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long knight_attacks(Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong knight_attacks(Square s) const
  public final long knight_attacks(Square s)
  {
	return StepAttackBB[PieceType.KNIGHT.getValue()][s.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long bishop_attacks(Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong bishop_attacks(Square s) const
  public final long bishop_attacks(Square s)
  {
	return GlobalMembers.bishop_attacks_bb(s, this.occupied_squares());
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long rook_attacks(Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong rook_attacks(Square s) const
  public final long rook_attacks(Square s)
  {
	return GlobalMembers.rook_attacks_bb(s, this.occupied_squares());
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long queen_attacks(Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong queen_attacks(Square s) const
  public final long queen_attacks(Square s)
  {
	return this.rook_attacks(s) | this.bishop_attacks(s);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long king_attacks(Square s) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong king_attacks(Square s) const
  public final long king_attacks(Square s)
  {
	return StepAttackBB[PieceType.KING.getValue()][s.getValue()];
  }

  // Bitboards for pinned pieces and discovered check candidates
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long discovered_check_candidates(Color c) const;

  /// Position:discovered_check_candidates() returns a bitboard containing all
  /// pieces for the given side which are candidates for giving a discovered
  /// check.  The code is almost the same as the function for finding pinned
  /// pieces.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong discovered_check_candidates(Color c) const
  public final long discovered_check_candidates(Color c)
  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b1, b2, dc, checkers, sliders;
	long b1;
	long b2;
	long dc;
	long checkers;
	long sliders;
	Square ksq = this.king_square(GlobalMembers.opposite_color(c));
	Square s;

	dc = GlobalMembers.EmptyBoardBB;
	b1 = this.occupied_squares();

	sliders = this.rooks_and_queens(c);
	if ((sliders & RookPseudoAttacks[ksq.getValue()]) != 0)
	{
	  b2 = this.rook_attacks(ksq) & this.pieces_of_color(c);
	  checkers = GlobalMembers.rook_attacks_bb(ksq, b1 ^ b2) & sliders;
	  while (checkers != 0)
	  {
		s = pop_1st_bit(checkers);
		dc |= (GlobalMembers.squares_between(s, ksq) & b2);
	  }
	}

	sliders = this.bishops_and_queens(c);
	if ((sliders & BishopPseudoAttacks[ksq.getValue()]) != 0)
	{
	  b2 = this.bishop_attacks(ksq) & this.pieces_of_color(c);
	  checkers = GlobalMembers.bishop_attacks_bb(ksq, b1 ^ b2) & sliders;
	  while (checkers != 0)
	  {
		s = pop_1st_bit(checkers);
		dc |= (GlobalMembers.squares_between(s, ksq) & b2);
	  }
	}

	return dc;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pinned_pieces(Color c) const;

  /// Position:pinned_pieces() returns a bitboard of all pinned (against the
  /// king) pieces for the given color.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong pinned_pieces(Color c) const
  public final long pinned_pieces(Color c)
  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b1, b2, pinned, pinners, sliders;
	long b1;
	long b2;
	long pinned;
	long pinners;
	long sliders;
	Square ksq = this.king_square(c);
	Square s;
	Color them = GlobalMembers.opposite_color(c);

	pinned = GlobalMembers.EmptyBoardBB;
	b1 = this.occupied_squares();

	sliders = (long)(this.rooks_and_queens(them) &)~this.checkers();
	if ((sliders & RookPseudoAttacks[ksq.getValue()]) != 0)
	{
	  b2 = this.rook_attacks(ksq) & this.pieces_of_color(c);
	  pinners = GlobalMembers.rook_attacks_bb(ksq, b1 ^ b2) & sliders;
	  while (pinners != 0)
	  {
		s = pop_1st_bit(pinners);
		pinned |= (GlobalMembers.squares_between(s, ksq) & b2);
	  }
	}

	sliders = (long)(this.bishops_and_queens(them) &)~this.checkers();
	if ((sliders & BishopPseudoAttacks[ksq.getValue()]) != 0)
	{
	  b2 = this.bishop_attacks(ksq) & this.pieces_of_color(c);
	  pinners = GlobalMembers.bishop_attacks_bb(ksq, b1 ^ b2) & sliders;
	  while (pinners != 0)
	  {
		s = pop_1st_bit(pinners);
		pinned |= (GlobalMembers.squares_between(s, ksq) & b2);
	  }
	}

	return pinned;
  }

  // Checking pieces
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long checkers() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong checkers() const
  public final long checkers()
  {
	return checkersBB;
  }

  // Piece lists:
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square piece_list(Color c, PieceType pt, int index) const
  public final Square piece_list(Color c, PieceType pt, int index)
  {
	return pieceList[c.getValue()][pt.getValue()][index];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square pawn_list(Color c, int index) const
  public final Square pawn_list(Color c, int index)
  {
	return this.piece_list(c, PieceType.PAWN, index);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square knight_list(Color c, int index) const
  public final Square knight_list(Color c, int index)
  {
	return this.piece_list(c, PieceType.KNIGHT, index);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square bishop_list(Color c, int index) const
  public final Square bishop_list(Color c, int index)
  {
	return this.piece_list(c, PieceType.BISHOP, index);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square rook_list(Color c, int index) const
  public final Square rook_list(Color c, int index)
  {
	return this.piece_list(c, PieceType.ROOK, index);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Square queen_list(Color c, int index) const
  public final Square queen_list(Color c, int index)
  {
	return this.piece_list(c, PieceType.QUEEN, index);
  }

  // Attack information for a given square

  /// Position::square_is_attacked() checks whether the given side attacks the
  /// given square.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean square_is_attacked(Square s, Color c) const
  public final boolean square_is_attacked(Square s, Color c)
  {
	return (this.pawn_attacks(GlobalMembers.opposite_color(c), s) & this.pawns(c)) != 0 || (this.knight_attacks(s) & this.knights(c)) != 0 || (this.king_attacks(s) & this.kings(c)) != 0 || (this.rook_attacks(s) & this.rooks_and_queens(c)) != 0 || (this.bishop_attacks(s) & this.bishops_and_queens(c)) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long attacks_to(Square s) const;

  /// Position::attacks_to() computes a bitboard containing all pieces which
  /// attacks a given square. There are two versions of this function: One
  /// which finds attackers of both colors, and one which only finds the
  /// attackers for one side.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong attacks_to(Square s) const
  public final long attacks_to(Square s)
  {
	return (this.black_pawn_attacks(s) & this.pawns(Color.WHITE)) | (this.white_pawn_attacks(s) & this.pawns(Color.BLACK)) | (this.knight_attacks(s) & this.pieces_of_type(PieceType.KNIGHT)) | (this.rook_attacks(s) & this.rooks_and_queens()) | (this.bishop_attacks(s) & this.bishops_and_queens()) | (this.king_attacks(s) & this.pieces_of_type(PieceType.KING));
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long attacks_to(Square s, Color c) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong attacks_to(Square s, Color c) const
  public final long attacks_to(Square s, Color c)
  {
	return this.attacks_to(s) & this.pieces_of_color(c);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean is_check() const
  public final boolean is_check()
  {
	return this.checkers() != GlobalMembers.EmptyBoardBB;
  }


  /// Position::piece_attacks_square() tests whether the piece on square f
  /// attacks square t.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean piece_attacks_square(Square f, Square t) const
  public final boolean piece_attacks_square(Square f, Square t)
  {
	assert square_is_ok(f);
	assert square_is_ok(t);

	switch (this.piece_on(f))
	{
	case WP:
		return this.white_pawn_attacks_square(f, t);
	case BP:
		return this.black_pawn_attacks_square(f, t);
	case WN:
  case BN:
	  return this.knight_attacks_square(f, t);
	case WB:
  case BB:
	  return this.bishop_attacks_square(f, t);
	case WR:
  case BR:
	  return this.rook_attacks_square(f, t);
	case WQ:
  case BQ:
	  return this.queen_attacks_square(f, t);
	case WK:
  case BK:
	  return this.king_attacks_square(f, t);
	default:
		return false;
	}

	return false;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean white_pawn_attacks_square(Square f, Square t) const
  public final boolean white_pawn_attacks_square(Square f, Square t)
  {
	return GlobalMembers.bit_is_set(this.white_pawn_attacks(f), t) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean black_pawn_attacks_square(Square f, Square t) const
  public final boolean black_pawn_attacks_square(Square f, Square t)
  {
	return GlobalMembers.bit_is_set(this.black_pawn_attacks(f), t) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean knight_attacks_square(Square f, Square t) const
  public final boolean knight_attacks_square(Square f, Square t)
  {
	return GlobalMembers.bit_is_set(this.knight_attacks(f), t) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean bishop_attacks_square(Square f, Square t) const
  public final boolean bishop_attacks_square(Square f, Square t)
  {
	return GlobalMembers.bit_is_set(this.bishop_attacks(f), t) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean rook_attacks_square(Square f, Square t) const
  public final boolean rook_attacks_square(Square f, Square t)
  {
	return GlobalMembers.bit_is_set(this.rook_attacks(f), t) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean queen_attacks_square(Square f, Square t) const
  public final boolean queen_attacks_square(Square f, Square t)
  {
	return GlobalMembers.bit_is_set(this.queen_attacks(f), t) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean king_attacks_square(Square f, Square t) const
  public final boolean king_attacks_square(Square f, Square t)
  {
	return GlobalMembers.bit_is_set(this.king_attacks(f), t) != 0;
  }

  // Properties of moves

  /// Position::move_is_legal() tests whether a pseudo-legal move is legal.  
  /// There are two versions of this function:  One which takes only a
  /// move as input, and one which takes a move and a bitboard of pinned
  /// pieces.  The latter function is faster, and should always be preferred
  /// when a pinned piece bitboard has already been computed.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean move_is_legal(Move m) const
  public final boolean move_is_legal(Move m)
  {
	return this.move_is_legal(m, this.pinned_pieces(this.side_to_move()));
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: bool move_is_legal(Move m, unsigned long long pinned) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean move_is_legal(Move m, ulong pinned) const
  public final boolean move_is_legal(Move m, long pinned)
  {
	Color us;
	Color them;
	Square ksq;
	Square from;

	assert this.is_ok();
	assert move_is_ok(m);
	assert pinned == this.pinned_pieces(this.side_to_move());

	// If we're in check, all pseudo-legal moves are legal, because our
	// check evasion generator only generates true legal moves.
	if (this.is_check())
	{
		return true;
	}

	// Castling moves are checked for legality during move generation.
	if (GlobalMembers.move_is_castle(m))
	{
		return true;
	}

	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	from = GlobalMembers.move_from(m);
	ksq = this.king_square(us);

	assert this.color_of_piece_on(from) == us;
	assert this.piece_on(ksq) == GlobalMembers.king_of_color(us);

	// En passant captures are a tricky special case.  Because they are
	// rather uncommon, we do it simply by testing whether the king is attacked
	// after the move is made:
	if (GlobalMembers.move_is_ep(m))
	{
	  Square to = GlobalMembers.move_to(m);
	  Square capsq = GlobalMembers.make_square(GlobalMembers.square_file(to), GlobalMembers.square_rank(from));
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b = this->occupied_squares();
	  long b = this.occupied_squares();

	  assert to == this.ep_square();
	  assert this.piece_on(from) == GlobalMembers.pawn_of_color(us);
	  assert this.piece_on(capsq) == GlobalMembers.pawn_of_color(them);
	  assert this.piece_on(to) == Piece.EMPTY;

	  tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
	  GlobalMembers.clear_bit(tempRef_b, from);
	  b = tempRef_b.argValue;
	  tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b);
	  GlobalMembers.clear_bit(tempRef_b2, capsq);
	  b = tempRef_b2.argValue;
	  tangible.RefObject<Long> tempRef_b3 = new tangible.RefObject<Long>(b);
	  GlobalMembers.set_bit(tempRef_b3, to);
	  b = tempRef_b3.argValue;
	  return ((GlobalMembers.rook_attacks_bb(ksq, b) & this.rooks_and_queens(them)) == 0 && (GlobalMembers.bishop_attacks_bb(ksq, b) & this.bishops_and_queens(them)) == 0);
	}

	// If the moving piece is a king, check whether the destination
	// square is attacked by the opponent.
	if (from == ksq)
	{
		return !(this.square_is_attacked(GlobalMembers.move_to(m), them));
	}

	// A non-king move is legal if and only if it is not pinned or it
	// is moving along the ray towards or away from the king.
	if (GlobalMembers.bit_is_set(pinned, from) == 0)
	{
		return true;
	}
	if (GlobalMembers.direction_between_squares(from, ksq) == GlobalMembers.direction_between_squares(GlobalMembers.move_to(m), ksq))
	{
	  return true;
	}

	return false;
  }


  /// Position::move_is_check() tests whether a pseudo-legal move is a check.
  /// There are two versions of this function:  One which takes only a move as
  /// input, and one which takes a move and a bitboard of discovered check
  /// candidates.  The latter function is faster, and should always be preferred
  /// when a discovered check candidates bitboard has already been computed.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean move_is_check(Move m) const
  public final boolean move_is_check(Move m)
  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long dc = this->discovered_check_candidates(this->side_to_move());
	long dc = this.discovered_check_candidates(this.side_to_move());
	return this.move_is_check(m, dc);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: bool move_is_check(Move m, unsigned long long dcCandidates) const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean move_is_check(Move m, ulong dcCandidates) const
  public final boolean move_is_check(Move m, long dcCandidates)
  {
	Color us;
	Color them;
	Square ksq;
	Square from;
	Square to;

	assert this.is_ok();
	assert move_is_ok(m);
	assert dcCandidates == this.discovered_check_candidates(this.side_to_move());

	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	from = GlobalMembers.move_from(m);
	to = GlobalMembers.move_to(m);
	ksq = this.king_square(them);
	assert this.color_of_piece_on(from) == us;
	assert this.piece_on(ksq) == GlobalMembers.king_of_color(them);

	// Proceed according to the type of the moving piece:
	switch (this.type_of_piece_on(from))
	{
	case PAWN:
	  // Normal check?
	  if (GlobalMembers.bit_is_set(this.pawn_attacks(them, ksq), to) != 0)
	  {
		return true;
	  }
	  // Discovered check?
	  else if (GlobalMembers.bit_is_set(dcCandidates, from) && GlobalMembers.direction_between_squares(from, ksq) != GlobalMembers.direction_between_squares(to, ksq))
	  {
		return true;
	  }
	  // Promotion with check?
	  else if (GlobalMembers.move_promotion(m))
	  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b = this->occupied_squares();
		long b = this.occupied_squares();
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
		GlobalMembers.clear_bit(tempRef_b, from);
		b = tempRef_b.argValue;

		switch (GlobalMembers.move_promotion(m))
		{
		case KNIGHT:
		  return this.knight_attacks_square(to, ksq);
		case BISHOP:
		  return GlobalMembers.bit_is_set(GlobalMembers.bishop_attacks_bb(to, b), ksq) != 0;
		case ROOK:
		  return GlobalMembers.bit_is_set(GlobalMembers.rook_attacks_bb(to, b), ksq) != 0;
		case QUEEN:
		  return GlobalMembers.bit_is_set(GlobalMembers.queen_attacks_bb(to, b), ksq) != 0;
		default:
		  assert false;
		}
	  }
	  // En passant capture with check?  We have already handled the case
	  // of direct checks and ordinary discovered check, the only case we
	  // need to handle is the unusual case of a discovered check through the
	  // captured pawn.
	  else if (GlobalMembers.move_is_ep(m))
	  {
		Square capsq = GlobalMembers.make_square(GlobalMembers.square_file(to), GlobalMembers.square_rank(from));
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b = this->occupied_squares();
		long b = this.occupied_squares();

		tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b);
		GlobalMembers.clear_bit(tempRef_b2, from);
		b = tempRef_b2.argValue;
		tangible.RefObject<Long> tempRef_b3 = new tangible.RefObject<Long>(b);
		GlobalMembers.clear_bit(tempRef_b3, capsq);
		b = tempRef_b3.argValue;
		tangible.RefObject<Long> tempRef_b4 = new tangible.RefObject<Long>(b);
		GlobalMembers.set_bit(tempRef_b4, to);
		b = tempRef_b4.argValue;
		return ((GlobalMembers.rook_attacks_bb(ksq, b) & this.rooks_and_queens(us)) != 0 || (GlobalMembers.bishop_attacks_bb(ksq, b) & this.bishops_and_queens(us)) != 0);
	  }
	  return false;

	case KNIGHT:
	  // Discovered check?
	  if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
	  {
		return true;
	  }
	  // Normal check?
	  else
	  {
		return GlobalMembers.bit_is_set(this.knight_attacks(ksq), to) != 0;
	  }

	case BISHOP:
	  // Discovered check?
	  if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
	  {
		return true;
	  }
	  // Normal check?
	  else
	  {
		return GlobalMembers.bit_is_set(this.bishop_attacks(ksq), to) != 0;
	  }

	case ROOK:
	  // Discovered check?
	  if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
	  {
		return true;
	  }
	  // Normal check?
	  else
	  {
		return GlobalMembers.bit_is_set(this.rook_attacks(ksq), to) != 0;
	  }

	case QUEEN:
	  // Discovered checks are impossible!
	  assert!GlobalMembers.bit_is_set(dcCandidates, from);
	  // Normal check?
	  return GlobalMembers.bit_is_set(this.queen_attacks(ksq), to) != 0;

	case KING:
	  // Discovered check?
	  if (GlobalMembers.bit_is_set(dcCandidates, from) != 0 && GlobalMembers.direction_between_squares(from, ksq) != GlobalMembers.direction_between_squares(to, ksq))
	  {
		return true;
	  }
	  // Castling with check?
	  if (GlobalMembers.move_is_castle(m))
	  {
		Square kfrom;
		Square kto;
		Square rfrom;
		Square rto;
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b = this->occupied_squares();
		long b = this.occupied_squares();

		kfrom = from;
		rfrom = to;
		if (rfrom.getValue() > kfrom.getValue())
		{
		  kto = GlobalMembers.relative_square(us, Square.SQ_G1);
		  rto = GlobalMembers.relative_square(us, Square.SQ_F1);
		}
		else
		{
		  kto = GlobalMembers.relative_square(us, Square.SQ_C1);
		  rto = GlobalMembers.relative_square(us, Square.SQ_D1);
		}

		tangible.RefObject<Long> tempRef_b5 = new tangible.RefObject<Long>(b);
		GlobalMembers.clear_bit(tempRef_b5, kfrom);
		b = tempRef_b5.argValue;
		tangible.RefObject<Long> tempRef_b6 = new tangible.RefObject<Long>(b);
		GlobalMembers.clear_bit(tempRef_b6, rfrom);
		b = tempRef_b6.argValue;
		tangible.RefObject<Long> tempRef_b7 = new tangible.RefObject<Long>(b);
		GlobalMembers.set_bit(tempRef_b7, rto);
		b = tempRef_b7.argValue;
		tangible.RefObject<Long> tempRef_b8 = new tangible.RefObject<Long>(b);
		GlobalMembers.set_bit(tempRef_b8, kto);
		b = tempRef_b8.argValue;

		return GlobalMembers.bit_is_set(GlobalMembers.rook_attacks_bb(rto, b), ksq) != 0;
	  }

	  return false;

	default:
	  assert false;
	  return false;
	}

	assert false;
	return false;
  }


  /// Position::move_is_capture() tests whether a move from the current
  /// position is a capture.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean move_is_capture(Move m) const
  public final boolean move_is_capture(Move m)
  {
	return this.color_of_piece_on(GlobalMembers.move_to(m)) == GlobalMembers.opposite_color(this.side_to_move()) || GlobalMembers.move_is_ep(m);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean move_is_pawn_push_to_7th(Move m) const
  public final boolean move_is_pawn_push_to_7th(Move m)
  {
	Color c = this.side_to_move();
	return this.piece_on(GlobalMembers.move_from(m)) == GlobalMembers.pawn_of_color(c) && GlobalMembers.pawn_rank(c, GlobalMembers.move_to(m)) == Rank.RANK_7;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean move_is_passed_pawn_push(Move m) const
  public final boolean move_is_passed_pawn_push(Move m)
  {
	Color c = this.side_to_move();
	return this.piece_on(GlobalMembers.move_from(m)) == GlobalMembers.pawn_of_color(c) && this.pawn_is_passed(c, GlobalMembers.move_to(m));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean move_was_passed_pawn_push(Move m) const
  public final boolean move_was_passed_pawn_push(Move m)
  {
	Color c = GlobalMembers.opposite_color(this.side_to_move());
	return this.piece_on(GlobalMembers.move_to(m)) == GlobalMembers.pawn_of_color(c) && this.pawn_is_passed(c, GlobalMembers.move_to(m));
  }


  /// Position::move_attacks_square() tests whether a move from the current
  /// position attacks a given square.  Only attacks by the moving piece are
  /// considered; the function does not handle X-ray attacks.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean move_attacks_square(Move m, Square s) const
  public final boolean move_attacks_square(Move m, Square s)
  {
	assert move_is_ok(m);
	assert square_is_ok(s);

	Square f = GlobalMembers.move_from(m);
	Square t = GlobalMembers.move_to(m);

	assert this.square_is_occupied(f);

	switch (this.piece_on(f))
	{
	case WP:
		return this.white_pawn_attacks_square(t, s);
	case BP:
		return this.black_pawn_attacks_square(t, s);
	case WN:
  case BN:
	  return this.knight_attacks_square(t, s);
	case WB:
  case BB:
	  return this.bishop_attacks_square(t, s);
	case WR:
  case BR:
	  return this.rook_attacks_square(t, s);
	case WQ:
  case BQ:
	  return this.queen_attacks_square(t, s);
	case WK:
  case BK:
	  return this.king_attacks_square(t, s);
	default:
		assert false;
	}

	return false;
  }

  // Information about pawns
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean pawn_is_passed(Color c, Square s) const
  public final boolean pawn_is_passed(Color c, Square s)
  {
	return (this.pawns(GlobalMembers.opposite_color(c)) & GlobalMembers.passed_pawn_mask(c, s)) == 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean pawn_is_isolated(Color c, Square s) const
  public final boolean pawn_is_isolated(Color c, Square s)
  {
	return (this.pawns(c) & GlobalMembers.neighboring_files_bb(s)) == 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean pawn_is_doubled(Color c, Square s) const
  public final boolean pawn_is_doubled(Color c, Square s)
  {
	return (this.pawns(c) & GlobalMembers.squares_behind(c, s)) != 0;
  }

  // Open and half-open files
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean file_is_open(File f) const
  public final boolean file_is_open(File f)
  {
	return (this.pawns() & GlobalMembers.file_bb(f)) == 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean file_is_half_open(Color c, File f) const
  public final boolean file_is_half_open(Color c, File f)
  {
	return (this.pawns(c) & GlobalMembers.file_bb(f)) == 0;
  }

  // Weak squares
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean square_is_weak(Square s, Color c) const
  public final boolean square_is_weak(Square s, Color c)
  {
	return (this.pawns(c) & GlobalMembers.outpost_mask(GlobalMembers.opposite_color(c), s)) == 0;
  }

  // Doing and undoing moves

  /// Position::backup() is called when making a move.  All information 
  /// necessary to restore the position when the move is later unmade
  /// is saved to an UndoInfo object.  The function Position::restore
  /// does the reverse operation:  When one does a backup followed by
  /// a restore with the same UndoInfo object, the position is restored
  /// to the state before backup was called.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: void backup(UndoInfo &u) const
  public final void backup(UndoInfo u)
  {
	u.castleRights = castleRights;
	u.epSquare = epSquare;
	u.checkersBB = checkersBB;
	u.key = key;
	u.pawnKey = pawnKey;
	u.materialKey = materialKey;
	u.rule50 = rule50;
	u.lastMove = lastMove;
	u.capture = PieceType.NO_PIECE_TYPE;
	u.mgValue = mgValue;
	u.egValue = egValue;
  }


  /// Position::restore() is called when unmaking a move.  It copies back
  /// the information backed up during a previous call to Position::backup.

  public final void restore(UndoInfo u)
  {
	castleRights = u.castleRights;
	epSquare = u.epSquare;
	checkersBB = u.checkersBB;
	key = u.key;
	pawnKey = u.pawnKey;
	materialKey = u.materialKey;
	rule50 = u.rule50;
	lastMove = u.lastMove;
	mgValue = u.mgValue;
	egValue = u.egValue;
  }


  /// Position::do_move() makes a move, and backs up all information necessary
  /// to undo the move to an UndoInfo object.  The move is assumed to be legal.
  /// Pseudo-legal moves should be filtered out before this function is called.
  /// There are two versions of this function, one which takes only the move and
  /// the UndoInfo as input, and one which takes a third parameter, a bitboard of
  /// discovered check candidates.  The second version is faster, because knowing
  /// the discovered check candidates makes it easier to update the checkersBB
  /// member variable in the position object.

  public final void do_move(Move m, UndoInfo u)
  {
	this.do_move(m, u, this.discovered_check_candidates(this.side_to_move()));
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: void do_move(Move m, UndoInfo &u, unsigned long long dcCandidates);
  public final void do_move(Move m, UndoInfo u, long dcCandidates)
  {
	assert this.is_ok();
	assert move_is_ok(m);

	// Back up the necessary information to our UndoInfo object (except the
	// captured piece, which is taken care of later:
	this.backup(u);

	// Save the current key to the history[] array, in order to be able to
	// detect repetition draws:
	history[gamePly] = key;

	// Increment the 50 moves rule draw counter.  Resetting it to zero in the
	// case of non-reversible moves is taken care of later.
	rule50++;

	if (GlobalMembers.move_is_castle(m))
	{
	  this.do_castle_move(m);
	}
	else if (GlobalMembers.move_promotion(m))
	{
	  this.do_promotion_move(m, u);
	}
	else if (GlobalMembers.move_is_ep(m))
	{
	  this.do_ep_move(m);
	}
	else
	{
	  Color us;
	  Color them;
	  Square from;
	  Square to;
	  PieceType piece;
	  PieceType capture;

	  us = this.side_to_move();
	  them = GlobalMembers.opposite_color(us);

	  from = GlobalMembers.move_from(m);
	  to = GlobalMembers.move_to(m);

	  assert this.color_of_piece_on(from) == us;
	  assert this.color_of_piece_on(to) == them || this.piece_on(to) == Piece.EMPTY;

	  piece = this.type_of_piece_on(from);
	  capture = this.type_of_piece_on(to);

	  if (capture.getValue() != 0)
	  {
		assert capture != PieceType.KING;

		// Remove captured piece:
		GlobalMembers.clear_bit((byColorBB[them.getValue()]), to);
		GlobalMembers.clear_bit((byTypeBB[capture.getValue()]), to);

		// Update hash key:
		key ^= zobrist[them.getValue()][capture.getValue()][to.getValue()];

		// If the captured piece was a pawn, update pawn hash key:
		if (capture == PieceType.PAWN)
		{
		  pawnKey ^= zobrist[them.getValue()][PieceType.PAWN.getValue()][to.getValue()];
		}

		// Update incremental scores:
		mgValue -= this.mg_pst(them, capture, to);
		egValue -= this.eg_pst(them, capture, to);

		// Update material:
		if (capture != PieceType.PAWN)
		{
		  npMaterial[them.getValue()] -= GlobalMembers.piece_value_midgame(capture);
		}

		// Update material hash key:
		materialKey ^= zobMaterial[them.getValue()][capture.getValue()][pieceCount[them.getValue()][capture.getValue()]];

		// Update piece count:
		pieceCount[them.getValue()][capture.getValue()]--;

		// Update piece list:
		pieceList[them.getValue()][capture.getValue()][index[to.getValue()]] = pieceList[them.getValue()][capture.getValue()][pieceCount[them.getValue()][capture.getValue()]];
		index[pieceList[them.getValue()][capture.getValue()][index[to.getValue()]].getValue()] = index[to.getValue()];

		// Remember the captured piece, in order to be able to undo the move
		// correctly:
		u.capture = capture;

		// Reset rule 50 counter:
		rule50 = 0;
	  }

	  // Move the piece:
	  GlobalMembers.clear_bit((byColorBB[us.getValue()]), from);
	  GlobalMembers.clear_bit((byTypeBB[piece.getValue()]), from);
	  GlobalMembers.clear_bit((byTypeBB[0]), from); // HACK: byTypeBB[0] == occupied squares
	  GlobalMembers.set_bit((byColorBB[us.getValue()]), to);
	  GlobalMembers.set_bit((byTypeBB[piece.getValue()]), to);
	  GlobalMembers.set_bit((byTypeBB[0]), to); // HACK: byTypeBB[0] == occupied squares
	  board[to.getValue()] = board[from.getValue()];
	  board[from.getValue()] = Piece.EMPTY;

	  // Update hash key:
	  key ^= zobrist[us.getValue()][piece.getValue()][from.getValue()] ^ zobrist[us.getValue()][piece.getValue()][to.getValue()];

	  // Update incremental scores:
	  mgValue -= this.mg_pst(us, piece, from);
	  mgValue += this.mg_pst(us, piece, to);
	  egValue -= this.eg_pst(us, piece, from);
	  egValue += this.eg_pst(us, piece, to);

	  // If the moving piece was a king, update the king square:
	  if (piece == PieceType.KING)
	  {
		kingSquare[us.getValue()] = to;
	  }

	  // If the move was a double pawn push, set the en passant square.
	  // This code is a bit ugly right now, and should be cleaned up later.
	  // FIXME
	  if (epSquare != Square.SQ_NONE)
	  {
		key ^= zobEp[epSquare.getValue()];
		epSquare = Square.SQ_NONE;
	  }
	  if (piece == PieceType.PAWN)
	  {
		if (Math.abs(to.getValue() - from.getValue()) == 16)
		{
		  if ((us == Color.WHITE && (this.white_pawn_attacks(from + SquareDelta.DELTA_N) & this.pawns(Color.BLACK))) || (us == Color.BLACK && (this.black_pawn_attacks(from + SquareDelta.DELTA_S) & this.pawns(Color.WHITE))))
		  {
			epSquare = Square((from.getValue() + to.getValue()) / 2);
			key ^= zobEp[epSquare.getValue()];
		  }
		}
		// Reset rule 50 draw counter.
		rule50 = 0;
		// Update pawn hash key:
		pawnKey ^= zobrist[us.getValue()][PieceType.PAWN.getValue()][from.getValue()] ^ zobrist[us.getValue()][PieceType.PAWN.getValue()][to.getValue()];
	  }

	  // Update piece lists:
	  pieceList[us.getValue()][piece.getValue()][index[from.getValue()]] = to;
	  index[to.getValue()] = index[from.getValue()];

	  // Update castle rights:
	  key ^= zobCastle[castleRights];
	  castleRights &= castleRightsMask[from.getValue()];
	  castleRights &= castleRightsMask[to.getValue()];
	  key ^= zobCastle[castleRights];

	  // Update checkers bitboard:
	  checkersBB = GlobalMembers.EmptyBoardBB;
	  Square ksq = this.king_square(them);

	  switch (piece)
	  {

	  case PAWN:
		if (GlobalMembers.bit_is_set(this.pawn_attacks(them, ksq), to) != 0)
		{
		  tangible.RefObject<Long> tempRef_checkersBB = new tangible.RefObject<Long>(checkersBB);
		  GlobalMembers.set_bit(tempRef_checkersBB, to);
		  checkersBB = tempRef_checkersBB.argValue;
		}
		if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
		{
		  checkersBB |= ((this.rook_attacks(ksq) & this.rooks_and_queens(us)) | (this.bishop_attacks(ksq) & this.bishops_and_queens(us)));
		}
		break;

	  case KNIGHT:
		if (GlobalMembers.bit_is_set(this.knight_attacks(ksq), to) != 0)
		{
		  tangible.RefObject<Long> tempRef_checkersBB2 = new tangible.RefObject<Long>(checkersBB);
		  GlobalMembers.set_bit(tempRef_checkersBB2, to);
		  checkersBB = tempRef_checkersBB2.argValue;
		}
		if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
		{
		  checkersBB |= ((this.rook_attacks(ksq) & this.rooks_and_queens(us)) | (this.bishop_attacks(ksq) & this.bishops_and_queens(us)));
		}
		break;

	  case BISHOP:
		if (GlobalMembers.bit_is_set(this.bishop_attacks(ksq), to) != 0)
		{
		  tangible.RefObject<Long> tempRef_checkersBB3 = new tangible.RefObject<Long>(checkersBB);
		  GlobalMembers.set_bit(tempRef_checkersBB3, to);
		  checkersBB = tempRef_checkersBB3.argValue;
		}
		if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
		{
		  checkersBB |= (this.rook_attacks(ksq) & this.rooks_and_queens(us));
		}
		break;

	  case ROOK:
		if (GlobalMembers.bit_is_set(this.rook_attacks(ksq), to) != 0)
		{
		  tangible.RefObject<Long> tempRef_checkersBB4 = new tangible.RefObject<Long>(checkersBB);
		  GlobalMembers.set_bit(tempRef_checkersBB4, to);
		  checkersBB = tempRef_checkersBB4.argValue;
		}
		if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
		{
		  checkersBB |= (this.bishop_attacks(ksq) & this.bishops_and_queens(us));
		}
		break;

	  case QUEEN:
		if (GlobalMembers.bit_is_set(this.queen_attacks(ksq), to) != 0)
		{
		  tangible.RefObject<Long> tempRef_checkersBB5 = new tangible.RefObject<Long>(checkersBB);
		  GlobalMembers.set_bit(tempRef_checkersBB5, to);
		  checkersBB = tempRef_checkersBB5.argValue;
		}
		break;

	  case KING:
		if (GlobalMembers.bit_is_set(dcCandidates, from) != 0)
		{
		  checkersBB |= ((this.rook_attacks(ksq) & this.rooks_and_queens(us)) | (this.bishop_attacks(ksq) & this.bishops_and_queens(us)));
		}
		break;

	  default:
		assert false;
		break;
	  }
	}

	// Finish
	key ^= zobSideToMove;
	sideToMove = GlobalMembers.opposite_color(sideToMove);
	gamePly++;

	mgValue += (sideToMove == Color.WHITE)? GlobalMembers.TempoValueMidgame : -GlobalMembers.TempoValueMidgame;
	egValue += (sideToMove == Color.WHITE)? GlobalMembers.TempoValueEndgame : -GlobalMembers.TempoValueEndgame;

	assert this.is_ok();
  }


  /// Position::undo_move() unmakes a move.  When it returns, the position should
  /// be restored to exactly the same state as before the move was made.  It is
  /// important that Position::undo_move is called with the same move and UndoInfo
  /// object as the earlier call to Position::do_move.

  public final void undo_move(Move m, UndoInfo u)
  {
	assert this.is_ok();
	assert move_is_ok(m);

	gamePly--;
	sideToMove = GlobalMembers.opposite_color(sideToMove);

	// Restore information from our UndoInfo object (except the captured piece,
	// which is taken care of later):
	this.restore(u);

	if (GlobalMembers.move_is_castle(m))
	{
	  this.undo_castle_move(m);
	}
	else if (GlobalMembers.move_promotion(m))
	{
	  this.undo_promotion_move(m, u);
	}
	else if (GlobalMembers.move_is_ep(m))
	{
	  this.undo_ep_move(m);
	}
	else
	{
	  Color us;
	  Color them;
	  Square from;
	  Square to;
	  PieceType piece;
	  PieceType capture;

	  us = this.side_to_move();
	  them = GlobalMembers.opposite_color(us);

	  from = GlobalMembers.move_from(m);
	  to = GlobalMembers.move_to(m);

	  assert this.piece_on(from) == Piece.EMPTY;
	  assert color_of_piece_on(to) == us;

	  // Put the piece back at the source square:
	  piece = this.type_of_piece_on(to);
	  GlobalMembers.set_bit((byColorBB[us.getValue()]), from);
	  GlobalMembers.set_bit((byTypeBB[piece.getValue()]), from);
	  GlobalMembers.set_bit((byTypeBB[0]), from); // HACK: byTypeBB[0] == occupied squares
	  board[from.getValue()] = GlobalMembers.piece_of_color_and_type(us, piece);

	  // Clear the destination square
	  GlobalMembers.clear_bit((byColorBB[us.getValue()]), to);
	  GlobalMembers.clear_bit((byTypeBB[piece.getValue()]), to);
	  GlobalMembers.clear_bit((byTypeBB[0]), to); // HACK: byTypeBB[0] == occupied squares

	  // If the moving piece was a king, update the king square:
	  if (piece == PieceType.KING)
	  {
		kingSquare[us.getValue()] = from;
	  }

	  // Update piece list:
	  pieceList[us.getValue()][piece.getValue()][index[to.getValue()]] = from;
	  index[from.getValue()] = index[to.getValue()];

	  capture = u.capture;

	  if (capture.getValue() != 0)
	  {
		assert capture != PieceType.KING;
		// Replace the captured piece:
		GlobalMembers.set_bit((byColorBB[them.getValue()]), to);
		GlobalMembers.set_bit((byTypeBB[capture.getValue()]), to);
		GlobalMembers.set_bit((byTypeBB[0]), to);
		board[to.getValue()] = GlobalMembers.piece_of_color_and_type(them, capture);

		// Update material:
		if (capture != PieceType.PAWN)
		{
		  npMaterial[them.getValue()] += GlobalMembers.piece_value_midgame(capture);
		}

		// Update piece list:
		pieceList[them.getValue()][capture.getValue()][pieceCount[them.getValue()][capture.getValue()]] = to;
		index[to.getValue()] = pieceCount[them.getValue()][capture.getValue()];

		// Update piece count:
		pieceCount[them.getValue()][capture.getValue()]++;
	  }
	  else
	  {
		board[to.getValue()] = Piece.EMPTY;
	  }
	}

	assert this.is_ok();
  }


  /// Position::do_null_move makes() a "null move": It switches the side to move
  /// and updates the hash key without executing any move on the board.

  public final void do_null_move(UndoInfo u)
  {
	assert this.is_ok();
	assert!this.is_check();

	// Back up the information necessary to undo the null move to the supplied
	// UndoInfo object.  In the case of a null move, the only thing we need to
	// remember is the last move made and the en passant square.
	u.lastMove = lastMove;
	u.epSquare = epSquare;

	// Save the current key to the history[] array, in order to be able to
	// detect repetition draws:
	history[gamePly] = key;

	// Update the necessary information.
	sideToMove = GlobalMembers.opposite_color(sideToMove);
	if (epSquare != Square.SQ_NONE)
	{
	  key ^= zobEp[epSquare.getValue()];
	}
	epSquare = Square.SQ_NONE;
	rule50++;
	gamePly++;
	key ^= zobSideToMove;

	mgValue += (sideToMove == Color.WHITE)? GlobalMembers.TempoValueMidgame : -GlobalMembers.TempoValueMidgame;
	egValue += (sideToMove == Color.WHITE)? GlobalMembers.TempoValueEndgame : -GlobalMembers.TempoValueEndgame;

	assert this.is_ok();
  }


  /// Position::undo_null_move() unmakes a "null move".

  public final void undo_null_move(UndoInfo u)
  {
	assert this.is_ok();
	assert!this.is_check();

	// Restore information from the supplied UndoInfo object:
	lastMove = u.lastMove;
	epSquare = u.epSquare;
	if (epSquare != Square.SQ_NONE)
	{
	  key ^= zobEp[epSquare.getValue()];
	}

	// Update the necessary information.
	sideToMove = GlobalMembers.opposite_color(sideToMove);
	rule50--;
	gamePly--;
	key ^= zobSideToMove;

	mgValue += (sideToMove == Color.WHITE)? GlobalMembers.TempoValueMidgame : -GlobalMembers.TempoValueMidgame;
	egValue += (sideToMove == Color.WHITE)? GlobalMembers.TempoValueEndgame : -GlobalMembers.TempoValueEndgame;

	assert this.is_ok();
  }

  // Static exchange evaluation

  /// Position::see() is a static exchange evaluator:  It tries to estimate the
  /// material gain or loss resulting from a move.  There are two versions of
  /// this function: One which takes a move as input, and one which takes a
  /// 'from' and a 'to' square.  The function does not yet understand promotions
  /// or en passant captures.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int see(Square from, Square to) const
  public final int see(Square from, Square to)
  {
	// Approximate material values, with pawn = 1:
	final int[] seeValues = {0, 1, 3, 3, 5, 10, 100, 0, 0, 1, 3, 3, 5, 10, 100, 0, 0, 0};
	Color us;
	Color them;
	Piece piece;
	Piece capture;
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long attackers, occ, b;
	long attackers;
	long occ;
	long b;

	assert square_is_ok(from);
	assert square_is_ok(to);

	// Initialize colors:
	us = this.color_of_piece_on(from);
	them = GlobalMembers.opposite_color(us);

	// Initialize pieces:
	piece = this.piece_on(from);
	capture = this.piece_on(to);

	// Find all attackers to the destination square, with the moving piece
	// removed, but possibly an X-ray attacker added behind it:
	occ = this.occupied_squares();
	tangible.RefObject<Long> tempRef_occ = new tangible.RefObject<Long>(occ);
	GlobalMembers.clear_bit(tempRef_occ, from);
	occ = tempRef_occ.argValue;
	attackers = (GlobalMembers.rook_attacks_bb(to, occ) & this.rooks_and_queens()) | (GlobalMembers.bishop_attacks_bb(to, occ) & this.bishops_and_queens()) | (this.knight_attacks(to) & this.knights()) | (this.king_attacks(to) & this.kings()) | (this.white_pawn_attacks(to) & this.pawns(Color.BLACK)) | (this.black_pawn_attacks(to) & this.pawns(Color.WHITE));
	attackers &= occ;

	// If the opponent has no attackers, we are finished:
	if ((attackers & this.pieces_of_color(them)) == GlobalMembers.EmptyBoardBB)
	{
	  return seeValues[capture.getValue()];
	}

	// The destination square is defended, which makes things rather more
	// difficult to compute.  We proceed by building up a "swap list" containing
	// the material gain or loss at each stop in a sequence of captures to the
	// destianation square, where the sides alternately capture, and always
	// capture with the least valuable piece.  After each capture, we look for
	// new X-ray attacks from behind the capturing piece.
	int lastCapturingPieceValue = seeValues[piece.getValue()];
	int[] swapList = new int[32];
	int n = 1;
	Color c = them;
	PieceType pt;

	swapList[0] = seeValues[capture.getValue()];

	do
	{
	  // Locate the least valuable attacker for the side to move.  The loop
	  // below looks like it is potentially infinite, but it isn't.  We know
	  // that the side to move still has at least one attacker left.
	  for (pt = PieceType.PAWN; !(attackers & this.pieces_of_color_and_type(c, pt)); pt++)
	  {
		assert pt.getValue() < PieceType.KING.getValue();
	  }

	  // Remove the attacker we just found from the 'attackers' bitboard,
	  // and scan for new X-ray attacks behind the attacker:
	  b = attackers & this.pieces_of_color_and_type(c, pt);
	  occ ^= (b & -b);
	  attackers |= (GlobalMembers.rook_attacks_bb(to, occ) & this.rooks_and_queens()) | (GlobalMembers.bishop_attacks_bb(to, occ) & this.bishops_and_queens());
	  attackers &= occ;

	  // Add the new entry to the swap list:
	  assert n < 32;
	  swapList[n] = -swapList[n - 1] + lastCapturingPieceValue;
	  n++;

	  // Remember the value of the capturing piece, and change the side to move
	  // before beginning the next iteration:
	  lastCapturingPieceValue = seeValues[pt.getValue()];
	  c = GlobalMembers.opposite_color(c);

	  // Stop after a king capture:
	  if (pt == PieceType.KING && (attackers & this.pieces_of_color(c)) != 0)
	  {
		assert n < 32;
		swapList[n++] = 100;
		break;
	  }
	} while ((attackers & this.pieces_of_color(c)) != 0);

	// Having built the swap list, we negamax through it to find the best
	// achievable score from the point of view of the side to move:
	while ((--n) != 0)
	{
		swapList[n - 1] = (((-swapList[n]) < (swapList[n - 1]))? (-swapList[n]) : (swapList[n - 1]));
	}

	return swapList[0];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int see(Move m) const
  public final int see(Move m)
  {
	assert move_is_ok(m);
	return this.see(GlobalMembers.move_from(m), GlobalMembers.move_to(m));
  }

  // Accessing hash keys
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long get_key() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong get_key() const
  public final long get_key()
  {
	return key;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long get_pawn_key() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong get_pawn_key() const
  public final long get_pawn_key()
  {
	return pawnKey;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long get_material_key() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong get_material_key() const
  public final long get_material_key()
  {
	return materialKey;
  }

  // Incremental evaluation
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value mg_value() const
  public final Value mg_value()
  {
	return mgValue;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value eg_value() const
  public final Value eg_value()
  {
	return egValue;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value non_pawn_material(Color c) const
  public final Value non_pawn_material(Color c)
  {
	return npMaterial[c.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Phase game_phase() const
  public final Phase game_phase()
  {

	// The purpose of the Value(325) terms below is to make sure the difference
	// between MidgameLimit and EndgameLimit is a power of 2, which should make
	// the division at the end of the function a bit faster.

	final Value MidgameLimit = 2 * GlobalMembers.QueenValueMidgame+2 * GlobalMembers.RookValueMidgame+6 * GlobalMembers.BishopValueMidgame + Value(325);
	final Value EndgameLimit = 4 * GlobalMembers.RookValueMidgame - Value(325);
	Value npm = this.non_pawn_material(Color.WHITE) + this.non_pawn_material(Color.BLACK);

	if (npm.getValue() >= MidgameLimit.getValue())
	{
	  return Phase.PHASE_MIDGAME;
	}
	else if (npm.getValue() <= EndgameLimit.getValue())
	{
	  return Phase.PHASE_ENDGAME;
	}
	else
	{
	  return Phase(((npm - EndgameLimit) * 128) / (MidgameLimit - EndgameLimit));
	}
  }

  // Game termination checks

  /// Position::is_mate() returns true or false depending on whether the
  /// side to move is checkmated.  Note that this function is currently very
  /// slow, and shouldn't be used frequently inside the search.

  public final boolean is_mate()
  {
	if (this.is_check())
	{
	  MovePicker mp = new MovePicker(this, false, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, Depth(0));
	  return mp.get_next_move() == Move.MOVE_NONE;
	}
	else
	{
	  return false;
	}
  }


  /// Position::is_draw() tests whether the position is drawn by material,
  /// repetition, or the 50 moves rule.  It does not detect stalemates, this
  /// must be done by the search.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean is_draw() const
  public final boolean is_draw()
  {
	// Draw by material?
	if (this.pawns() == 0 && this.non_pawn_material(Color.WHITE) + this.non_pawn_material(Color.BLACK) <= GlobalMembers.BishopValueMidgame.getValue().getValue() != 0)
	{
	  return true;
	}

	// Draw by the 50 moves rule?
	if (rule50 > 100 || (rule50 == 100 && !this.is_check()))
	{
	  return true;
	}

	// Draw by repetition?
	for (int i = 2; i < (((gamePly) < (rule50))? (gamePly) : (rule50)); i += 2)
	{
	  if (history[gamePly - i] == key)
	  {
		return true;
	  }
	}

	return false;
  }

  // Check if one side threatens a mate in one

  /// Position::has_mate_threat() tests whether a given color has a mate in one
  /// from the current position.  This function is quite slow, but it doesn't
  /// matter, because it is currently only called from PV nodes, which are rare.

  public final boolean has_mate_threat(Color c)
  {
	UndoInfo u1 = new UndoInfo();
	UndoInfo u2 = new UndoInfo();
	Color stm = this.side_to_move();

	// The following lines are useless and silly, but prevents gcc from
	// emitting a stupid warning stating that u1.lastMove and u1.epSquare might
	// be used uninitialized.
	u1.lastMove = lastMove;
	u1.epSquare = epSquare;

	if (this.is_check())
	{
	  return false;
	}

	// If the input color is not equal to the side to move, do a null move
	if (c != stm)
	{
		this.do_null_move(u1);
	}

	MoveStack[] mlist = tangible.Arrays.initializeWithDefaultMoveStackInstances(120);
	int count;
	boolean result = false;

	// Generate legal moves
	count = generate_legal_moves(this, mlist);

	// Loop through the moves, and see if one of them is mate.
	for (int i = 0; i < count; i++)
	{
	  this.do_move(mlist[i].move, u2);
	  if (this.is_mate())
	  {
		  result = true;
	  }
	  this.undo_move(mlist[i].move, u2);
	}

	// Undo null move, if necessary
	if (c != stm)
	{
		this.undo_null_move(u1);
	}

	return result;
  }

  // Number of plies since the last non-reversible move
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int rule_50_counter() const
  public final int rule_50_counter()
  {
	return rule50;
  }

  // Other properties of the position
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean opposite_colored_bishops() const
  public final boolean opposite_colored_bishops()
  {
	return this.bishop_count(Color.WHITE) == 1 && this.bishop_count(Color.BLACK) == 1 && GlobalMembers.square_color(this.bishop_list(Color.WHITE, 0)) != GlobalMembers.square_color(this.bishop_list(Color.BLACK, 0));
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean has_pawn_on_7th(Color c) const
  public final boolean has_pawn_on_7th(Color c)
  {
	return (this.pawns(c) & GlobalMembers.relative_rank_bb(c, Rank.RANK_7)) != 0;
  }

  // Reset the gamePly variable to 0

  /// Position::reset_game_ply() simply sets gamePly to 0.  It is used from the
  /// UCI interface code, whenever a non-reversible move is made in a
  /// 'position fen <fen> moves m1 m2 ...' command.  This makes it possible
  /// for the program to handle games of arbitrary length, as long as the GUI
  /// handles draws by the 50 move rule correctly.

  public final void reset_game_ply()
  {
	gamePly = 0;
  }

  // Position consistency check, for debugging

  /// Position::is_ok() performs some consitency checks for the position object.
  /// This is meant to be helpful when debugging.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean is_ok() const
  public final boolean is_ok()
  {

	// What features of the position should be verified?
	final boolean debugBitboards = false;
	final boolean debugKingCount = false;
	final boolean debugKingCapture = false;
	final boolean debugCheckerCount = false;
	final boolean debugKey = false;
	final boolean debugMaterialKey = false;
	final boolean debugPawnKey = false;
	final boolean debugIncrementalEval = false;
	final boolean debugNonPawnMaterial = false;
	final boolean debugPieceCounts = false;
	final boolean debugPieceList = false;

	// Side to move OK?
	if (!color_is_ok(this.side_to_move()))
	{
	  return false;
	}

	// Are the king squares in the position correct?
	if (this.piece_on(this.king_square(Color.WHITE)) != Piece.WK)
	{
	  return false;
	}
	if (this.piece_on(this.king_square(Color.BLACK)) != Piece.BK)
	{
	  return false;
	}

	// Castle files OK?
	if (!file_is_ok(initialKRFile))
	{
	  return false;
	}
	if (!file_is_ok(initialQRFile))
	{
	  return false;
	}

	// Do both sides have exactly one king?
	if (debugKingCount)
	{
	  int[] kingCount = {0, 0};
	  for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
	  {
		if (this.type_of_piece_on(s) == PieceType.KING)
		{
		  kingCount[this.color_of_piece_on(s).getValue()]++;
		}
	  }
	  if (kingCount[0] != 1 || kingCount[1] != 1)
	  {
		return false;
	  }
	}

	// Can the side to move capture the opponent's king?
	if (debugKingCapture)
	{
	  Color us = this.side_to_move();
	  Color them = GlobalMembers.opposite_color(us);
	  Square ksq = this.king_square(them);
	  if (this.square_is_attacked(ksq, us))
	  {
		return false;
	  }
	}

	// Is there more than 2 checkers?
	if (debugCheckerCount && GlobalMembers.count_1s(checkersBB) > 2)
	{
	  return false;
	}

	// Bitboards OK?
	if (debugBitboards)
	{
	  // The intersection of the white and black pieces must be empty:
	  if ((this.pieces_of_color(Color.WHITE) & this.pieces_of_color(Color.BLACK)) != GlobalMembers.EmptyBoardBB)
	  {
		return false;
	  }

	  // The union of the white and black pieces must be equal to all
	  // occupied squares:
	  if ((this.pieces_of_color(Color.WHITE) | this.pieces_of_color(Color.BLACK)) != this.occupied_squares())
	  {
		return false;
	  }

	  // Separate piece type bitboards must have empty intersections:
	  for (PieceType p1 = PieceType.PAWN; p1.getValue() <= PieceType.KING.getValue(); p1++)
	  {
		for (PieceType p2 = PieceType.PAWN; p2.getValue() <= PieceType.KING.getValue(); p2++)
		{
		  if (p1 != p2 && (this.pieces_of_type(p1) & this.pieces_of_type(p2)) != 0)
		  {
			return false;
		  }
		}
	  }
	}

	// En passant square OK?
	if (this.ep_square() != Square.SQ_NONE)
	{
	  // The en passant square must be on rank 6, from the point of view of the
	  // side to move.
	  if (GlobalMembers.pawn_rank(this.side_to_move(), this.ep_square()) != Rank.RANK_6)
	  {
		return false;
	  }
	}

	// Hash key OK?
	if (debugKey && key != this.compute_key())
	{
	  return false;
	}

	// Pawn hash key OK?
	if (debugPawnKey && pawnKey != this.compute_pawn_key())
	{
	  return false;
	}

	// Material hash key OK?
	if (debugMaterialKey && materialKey != this.compute_material_key())
	{
	  return false;
	}

	// Incremental eval OK?
	if (debugIncrementalEval)
	{
	  if (mgValue != this.compute_mg_value())
	  {
		return false;
	  }
	  if (egValue != this.compute_eg_value())
	  {
		return false;
	  }
	}

	// Non-pawn material OK?
	if (debugNonPawnMaterial)
	{
	  if (npMaterial[Color.WHITE.getValue()] != compute_non_pawn_material(Color.WHITE))
	  {
		return false;
	  }
	  if (npMaterial[Color.BLACK.getValue()] != compute_non_pawn_material(Color.BLACK))
	  {
		return false;
	  }
	}

	// Piece counts OK?
	if (debugPieceCounts)
	{
	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	  {
		for (PieceType pt = PieceType.PAWN; pt.getValue() <= PieceType.KING.getValue(); pt++)
		{
		  if (pieceCount[c.getValue()][pt.getValue()] != GlobalMembers.count_1s(this.pieces_of_color_and_type(c, pt)))
		  {
			return false;
		  }
		}
	  }
	}

	if (debugPieceList)
	{
	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	  {
		for (PieceType pt = PieceType.PAWN; pt.getValue() <= PieceType.KING.getValue(); pt++)
		{
		  for (int i = 0; i < pieceCount[c.getValue()][pt.getValue()]; i++)
		  {
			if (this.piece_on(this.piece_list(c, pt, i)) != GlobalMembers.piece_of_color_and_type(c, pt))
			{
			  return false;
			}
			if (index[this.piece_list(c, pt, i).getValue()] != i)
			{
			  return false;
			}
		  }
		}
	  }
	}

	return true;
  }

  // Static member functions:

  /// Position::init_zobrist() is a static member function which initializes the
  /// various arrays used to compute hash keys.

  public static void init_zobrist()
  {

	for (int i = 0; i < 2; i++)
	{
	  for (int j = 0; j < 8; j++)
	  {
		for (int k = 0; k < 64; k++)
		{
		  zobrist[i][j][k] = Key(genrand_int64());
		}
	  }
	}

	for (int i = 0; i < 64; i++)
	{
	  zobEp[i] = Key(genrand_int64());
	}

	for (int i = 0; i < 16; i++)
	{
	  zobCastle[i] = genrand_int64();
	}

	zobSideToMove = genrand_int64();

	for (int i = 0; i < 2; i++)
	{
	  for (int j = 0; j < 8; j++)
	  {
		for (int k = 0; k < 16; k++)
		{
		  zobMaterial[i][j][k] = (k > 0)? Key(genrand_int64()) : Key(0L);
		}
	  }
	}

	for (int i = 0; i < 16; i++)
	{
	  zobMaterial[0][PieceType.KING.getValue()][i] = zobMaterial[1][PieceType.KING.getValue()][i] = Key(0);
	}
  }


  /// Position::init_piece_square_tables() initializes the piece square tables.
  /// This is a two-step operation:  First, the white halves of the tables are
  /// copied from the MgPST[][] and EgPST[][] arrays, with a small random number
  /// added to each entry if the "Randomness" UCI parameter is non-zero.
  /// Second, the black halves of the tables are initialized by mirroring
  /// and changing the sign of the corresponding white scores.

  public static void init_piece_square_tables()
  {
	int r = get_option_value_int("Randomness");
	int i;
	for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
	{
	  for (Piece p = Piece.WP; p.getValue() <= Piece.WK.getValue(); p++)
	  {
		i = (r == 0)? 0 : (genrand_int32() % (r * 2) - r);
		MgPieceSquareTable[p.getValue()][s.getValue()] = Value(GlobalMembers.MgPST[p.getValue()][s.getValue()] + i);
		EgPieceSquareTable[p.getValue()][s.getValue()] = Value(GlobalMembers.EgPST[p.getValue()][s.getValue()] + i);
	  }
	}
	for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
	{
	  for (Piece p = Piece.BP; p.getValue() <= Piece.BK.getValue(); p++)
	  {
		MgPieceSquareTable[p.getValue()][s.getValue()] = -MgPieceSquareTable[p.getValue() - 8][GlobalMembers.flip_square(s).getValue()];
		EgPieceSquareTable[p.getValue()][s.getValue()] = -EgPieceSquareTable[p.getValue() - 8][GlobalMembers.flip_square(s).getValue()];
	  }
	}
  }

  // Initialization helper functions (used while setting up a position)

  /// Position::clear() erases the position object to a pristine state, with an
  /// empty board, white to move, and no castling rights.

  private void clear()
  {
	int i;
	int j;

	for (i = 0; i < 64; i++)
	{
	  board[i] = Piece.EMPTY;
	  index[i] = 0;
	}

	for (i = 0; i < 2; i++)
	{
	  byColorBB[i] = GlobalMembers.EmptyBoardBB;
	}

	for (i = 0; i < 7; i++)
	{
	  byTypeBB[i] = GlobalMembers.EmptyBoardBB;
	  pieceCount[0][i] = pieceCount[1][i] = 0;
	  for (j = 0; j < 8; j++)
	  {
		pieceList[0][i][j] = pieceList[1][i][j] = Square.SQ_NONE;
	  }
	}

	checkersBB = GlobalMembers.EmptyBoardBB;

	lastMove = Move.MOVE_NONE;

	sideToMove = Color.WHITE;
	castleRights = CastleRights.NO_CASTLES.getValue();
	initialKFile = File.FILE_E;
	initialKRFile = File.FILE_H;
	initialQRFile = File.FILE_A;
	epSquare = Square.SQ_NONE;
	rule50 = 0;
	gamePly = 0;
  }


  /// Position::put_piece() puts a piece on the given square of the board,
  /// updating the board array, bitboards, and piece counts.

  private void put_piece(Piece p, Square s)
  {
	Color c = GlobalMembers.color_of_piece(p);
	PieceType pt = GlobalMembers.type_of_piece(p);

	board[s.getValue()] = p;
	index[s.getValue()] = pieceCount[c.getValue()][pt.getValue()];
	pieceList[c.getValue()][pt.getValue()][index[s.getValue()]] = s;

	GlobalMembers.set_bit((byTypeBB[pt.getValue()]), s);
	GlobalMembers.set_bit((byColorBB[c.getValue()]), s);
	GlobalMembers.set_bit(byTypeBB[0], s); // HACK: byTypeBB[0] contains all occupied squares.

	pieceCount[c.getValue()][pt.getValue()]++;

	if (pt == PieceType.KING)
	{
	  kingSquare[c.getValue()] = s;
	}
  }


  /// Position::allow_oo() gives the given side the right to castle kingside. 
  /// Used when setting castling rights during parsing of FEN strings.

  private void allow_oo(Color c)
  {
	castleRights |= (1 + c.getValue());
  }


  /// Position::allow_ooo() gives the given side the right to castle queenside.
  /// Used when setting castling rights during parsing of FEN strings.

  private void allow_ooo(Color c)
  {
	castleRights |= (4 + 4 * c.getValue());
  }

  // Helper functions for doing and undoing moves

  /// Position::do_castle_move() is a private method used to make a castling
  /// move.  It is called from the main Position::do_move function.  Note that
  /// castling moves are encoded as "king captures friendly rook" moves, for
  /// instance white short castling in a non-Chess960 game is encoded as e1h1.

  private void do_castle_move(Move m)
  {
	Color us;
	Color them;
	Square kfrom;
	Square kto;
	Square rfrom;
	Square rto;

	assert this.is_ok();
	assert move_is_ok(m);
	assert GlobalMembers.move_is_castle(m);

	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	// Find source squares for king and rook:
	kfrom = GlobalMembers.move_from(m);
	rfrom = GlobalMembers.move_to(m); // HACK: See comment at beginning of function.

	assert this.piece_on(kfrom) == GlobalMembers.king_of_color(us);
	assert this.piece_on(rfrom) == GlobalMembers.rook_of_color(us);

	// Find destination squares for king and rook:
	if (rfrom.getValue() > kfrom.getValue())
	{ // O-O
	  kto = GlobalMembers.relative_square(us, Square.SQ_G1);
	  rto = GlobalMembers.relative_square(us, Square.SQ_F1);
	}
	else
	{ // O-O-O
	  kto = GlobalMembers.relative_square(us, Square.SQ_C1);
	  rto = GlobalMembers.relative_square(us, Square.SQ_D1);
	}

	// Remove pieces from source squares:
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), kfrom);
	GlobalMembers.clear_bit((byTypeBB[PieceType.KING.getValue()]), kfrom);
	GlobalMembers.clear_bit((byTypeBB[0]), kfrom); // HACK: byTypeBB[0] == occupied squares
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), rfrom);
	GlobalMembers.clear_bit((byTypeBB[PieceType.ROOK.getValue()]), rfrom);
	GlobalMembers.clear_bit((byTypeBB[0]), rfrom); // HACK: byTypeBB[0] == occupied squares

	// Put pieces on destination squares:
	GlobalMembers.set_bit((byColorBB[us.getValue()]), kto);
	GlobalMembers.set_bit((byTypeBB[PieceType.KING.getValue()]), kto);
	GlobalMembers.set_bit((byTypeBB[0]), kto); // HACK: byTypeBB[0] == occupied squares
	GlobalMembers.set_bit((byColorBB[us.getValue()]), rto);
	GlobalMembers.set_bit((byTypeBB[PieceType.ROOK.getValue()]), rto);
	GlobalMembers.set_bit((byTypeBB[0]), rto); // HACK: byTypeBB[0] == occupied squares

	// Update board array:
	board[kfrom.getValue()] = board[rfrom.getValue()] = Piece.EMPTY;
	board[kto.getValue()] = GlobalMembers.king_of_color(us);
	board[rto.getValue()] = GlobalMembers.rook_of_color(us);

	// Update king square:
	kingSquare[us.getValue()] = kto;

	// Update piece lists:
	pieceList[us.getValue()][PieceType.KING.getValue()][index[kfrom.getValue()]] = kto;
	pieceList[us.getValue()][PieceType.ROOK.getValue()][index[rfrom.getValue()]] = rto;
	int tmp = index[rfrom.getValue()];
	index[kto.getValue()] = index[kfrom.getValue()];
	index[rto.getValue()] = tmp;

	// Update incremental scores:
	mgValue -= this.mg_pst(us, PieceType.KING, kfrom);
	mgValue += this.mg_pst(us, PieceType.KING, kto);
	egValue -= this.eg_pst(us, PieceType.KING, kfrom);
	egValue += this.eg_pst(us, PieceType.KING, kto);
	mgValue -= this.mg_pst(us, PieceType.ROOK, rfrom);
	mgValue += this.mg_pst(us, PieceType.ROOK, rto);
	egValue -= this.eg_pst(us, PieceType.ROOK, rfrom);
	egValue += this.eg_pst(us, PieceType.ROOK, rto);

	// Update hash key:
	key ^= zobrist[us.getValue()][PieceType.KING.getValue()][kfrom.getValue()] ^ zobrist[us.getValue()][PieceType.KING.getValue()][kto.getValue()];
	key ^= zobrist[us.getValue()][PieceType.ROOK.getValue()][rfrom.getValue()] ^ zobrist[us.getValue()][PieceType.ROOK.getValue()][rto.getValue()];

	// Clear en passant square:
	if (epSquare != Square.SQ_NONE)
	{
	  key ^= zobEp[epSquare.getValue()];
	  epSquare = Square.SQ_NONE;
	}

	// Update castling rights:
	key ^= zobCastle[castleRights];
	castleRights &= castleRightsMask[kfrom.getValue()];
	key ^= zobCastle[castleRights];

	// Reset rule 50 counter:
	rule50 = 0;

	// Update checkers BB:
	checkersBB = attacks_to(this.king_square(them), us);
  }


  /// Position::do_promotion_move() is a private method used to make a promotion 
  /// move.  It is called from the main Position::do_move function.  The 
  /// UndoInfo object, which has been initialized in Position::do_move, is
  /// used to store the captured piece (if any).

  private void do_promotion_move(Move m, UndoInfo u)
  {
	Color us;
	Color them;
	Square from;
	Square to;
	PieceType capture;
	PieceType promotion;

	assert this.is_ok();
	assert move_is_ok(m);
	assert GlobalMembers.move_promotion(m);

	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	from = GlobalMembers.move_from(m);
	to = GlobalMembers.move_to(m);

	assert GlobalMembers.pawn_rank(us, to) == Rank.RANK_8;
	assert this.piece_on(from) == GlobalMembers.pawn_of_color(us);
	assert this.color_of_piece_on(to) == them || this.square_is_empty(to);

	capture = this.type_of_piece_on(to);

	if (capture.getValue() != 0)
	{
	  assert capture != PieceType.KING;

	  // Remove captured piece:
	  GlobalMembers.clear_bit((byColorBB[them.getValue()]), to);
	  GlobalMembers.clear_bit((byTypeBB[capture.getValue()]), to);

	  // Update hash key:
	  key ^= zobrist[them.getValue()][capture.getValue()][to.getValue()];

	  // Update incremental scores:
	  mgValue -= this.mg_pst(them, capture, to);
	  egValue -= this.eg_pst(them, capture, to);

	  // Update material.  Because our move is a promotion, we know that the
	  // captured piece is not a pawn.
	  assert capture != PieceType.PAWN;
	  npMaterial[them.getValue()] -= GlobalMembers.piece_value_midgame(capture);

	  // Update material hash key:
	  materialKey ^= zobMaterial[them.getValue()][capture.getValue()][pieceCount[them.getValue()][capture.getValue()]];

	  // Update piece count:
	  pieceCount[them.getValue()][capture.getValue()]--;

	  // Update piece list:
	  pieceList[them.getValue()][capture.getValue()][index[to.getValue()]] = pieceList[them.getValue()][capture.getValue()][pieceCount[them.getValue()][capture.getValue()]];
	  index[pieceList[them.getValue()][capture.getValue()][index[to.getValue()]].getValue()] = index[to.getValue()];

	  // Remember the captured piece, in order to be able to undo the move
	  // correctly:
	  u.capture = capture;
	}

	// Remove pawn:
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), from);
	GlobalMembers.clear_bit((byTypeBB[PieceType.PAWN.getValue()]), from);
	GlobalMembers.clear_bit((byTypeBB[0]), from); // HACK: byTypeBB[0] == occupied squares
	board[from.getValue()] = Piece.EMPTY;

	// Insert promoted piece:
	promotion = GlobalMembers.move_promotion(m);
	assert promotion.getValue() >= PieceType.KNIGHT.getValue() && promotion.getValue() <= PieceType.QUEEN.getValue();
	GlobalMembers.set_bit((byColorBB[us.getValue()]), to);
	GlobalMembers.set_bit((byTypeBB[promotion.getValue()]), to);
	GlobalMembers.set_bit((byTypeBB[0]), to); // HACK: byTypeBB[0] == occupied squares
	board[to.getValue()] = GlobalMembers.piece_of_color_and_type(us, promotion);

	// Update hash key:
	key ^= zobrist[us.getValue()][PieceType.PAWN.getValue()][from.getValue()] ^ zobrist[us.getValue()][promotion.getValue()][to.getValue()];

	// Update pawn hash key:
	pawnKey ^= zobrist[us.getValue()][PieceType.PAWN.getValue()][from.getValue()];

	// Update material key:
	materialKey ^= zobMaterial[us.getValue()][PieceType.PAWN.getValue()][pieceCount[us.getValue()][PieceType.PAWN.getValue()]];
	materialKey ^= zobMaterial[us.getValue()][promotion.getValue()][pieceCount[us.getValue()][promotion.getValue()] + 1];

	// Update piece counts:
	pieceCount[us.getValue()][PieceType.PAWN.getValue()]--;
	pieceCount[us.getValue()][promotion.getValue()]++;

	// Update piece lists:
	pieceList[us.getValue()][PieceType.PAWN.getValue()][index[from.getValue()]] = pieceList[us.getValue()][PieceType.PAWN.getValue()][pieceCount[us.getValue()][PieceType.PAWN.getValue()]];
	index[pieceList[us.getValue()][PieceType.PAWN.getValue()][index[from.getValue()]].getValue()] = index[from.getValue()];
	pieceList[us.getValue()][promotion.getValue()][pieceCount[us.getValue()][promotion.getValue()] - 1] = to;
	index[to.getValue()] = pieceCount[us.getValue()][promotion.getValue()] - 1;

	// Update incremental scores:
	mgValue -= this.mg_pst(us, PieceType.PAWN, from);
	mgValue += this.mg_pst(us, promotion, to);
	egValue -= this.eg_pst(us, PieceType.PAWN, from);
	egValue += this.eg_pst(us, promotion, to);

	// Update material:
	npMaterial[us.getValue()] += GlobalMembers.piece_value_midgame(promotion);

	// Clear the en passant square:
	if (epSquare != Square.SQ_NONE)
	{
	  key ^= zobEp[epSquare.getValue()];
	  epSquare = Square.SQ_NONE;
	}

	// Update castle rights:
	key ^= zobCastle[castleRights];
	castleRights &= castleRightsMask[to.getValue()];
	key ^= zobCastle[castleRights];

	// Reset rule 50 counter:
	rule50 = 0;

	// Update checkers BB:
	checkersBB = attacks_to(this.king_square(them), us);
  }


  /// Position::do_ep_move() is a private method used to make an en passant
  /// capture.  It is called from the main Position::do_move function.  Because
  /// the captured piece is always a pawn, we don't need to pass an UndoInfo
  /// object in which to store the captured piece.

  private void do_ep_move(Move m)
  {
	Color us;
	Color them;
	Square from;
	Square to;
	Square capsq;

	assert this.is_ok();
	assert move_is_ok(m);
	assert GlobalMembers.move_is_ep(m);

	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	// Find from, to and capture squares:
	from = GlobalMembers.move_from(m);
	to = GlobalMembers.move_to(m);
	capsq = (us == Color.WHITE)? (to - SquareDelta.DELTA_N) : (to - SquareDelta.DELTA_S);

	assert to == epSquare;
	assert GlobalMembers.pawn_rank(us, to) == Rank.RANK_6;
	assert this.piece_on(to) == Piece.EMPTY;
	assert this.piece_on(from) == GlobalMembers.pawn_of_color(us);
	assert this.piece_on(capsq) == GlobalMembers.pawn_of_color(them);

	// Remove captured piece:
	GlobalMembers.clear_bit((byColorBB[them.getValue()]), capsq);
	GlobalMembers.clear_bit((byTypeBB[PieceType.PAWN.getValue()]), capsq);
	GlobalMembers.clear_bit((byTypeBB[0]), capsq); // HACK: byTypeBB[0] == occupied squares
	board[capsq.getValue()] = Piece.EMPTY;

	// Remove moving piece from source square:
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), from);
	GlobalMembers.clear_bit((byTypeBB[PieceType.PAWN.getValue()]), from);
	GlobalMembers.clear_bit((byTypeBB[0]), from); // HACK: byTypeBB[0] == occupied squares

	// Put moving piece on destination square:
	GlobalMembers.set_bit((byColorBB[us.getValue()]), to);
	GlobalMembers.set_bit((byTypeBB[PieceType.PAWN.getValue()]), to);
	GlobalMembers.set_bit((byTypeBB[0]), to); // HACK: byTypeBB[0] == occupied squares
	board[to.getValue()] = board[from.getValue()];
	board[from.getValue()] = Piece.EMPTY;

	// Update material hash key:
	materialKey ^= zobMaterial[them.getValue()][PieceType.PAWN.getValue()][pieceCount[them.getValue()][PieceType.PAWN.getValue()]];

	// Update piece count:
	pieceCount[them.getValue()][PieceType.PAWN.getValue()]--;

	// Update piece list:
	pieceList[us.getValue()][PieceType.PAWN.getValue()][index[from.getValue()]] = to;
	index[to.getValue()] = index[from.getValue()];
	pieceList[them.getValue()][PieceType.PAWN.getValue()][index[capsq.getValue()]] = pieceList[them.getValue()][PieceType.PAWN.getValue()][pieceCount[them.getValue()][PieceType.PAWN.getValue()]];
	index[pieceList[them.getValue()][PieceType.PAWN.getValue()][index[capsq.getValue()]].getValue()] = index[capsq.getValue()];

	// Update hash key:
	key ^= zobrist[us.getValue()][PieceType.PAWN.getValue()][from.getValue()] ^ zobrist[us.getValue()][PieceType.PAWN.getValue()][to.getValue()];
	key ^= zobrist[them.getValue()][PieceType.PAWN.getValue()][capsq.getValue()];
	key ^= zobEp[epSquare.getValue()];

	// Update pawn hash key:
	pawnKey ^= zobrist[us.getValue()][PieceType.PAWN.getValue()][from.getValue()] ^ zobrist[us.getValue()][PieceType.PAWN.getValue()][to.getValue()];
	pawnKey ^= zobrist[them.getValue()][PieceType.PAWN.getValue()][capsq.getValue()];

	// Update incremental scores:
	mgValue -= this.mg_pst(them, PieceType.PAWN, capsq);
	mgValue -= this.mg_pst(us, PieceType.PAWN, from);
	mgValue += this.mg_pst(us, PieceType.PAWN, to);
	egValue -= this.eg_pst(them, PieceType.PAWN, capsq);
	egValue -= this.eg_pst(us, PieceType.PAWN, from);
	egValue += this.eg_pst(us, PieceType.PAWN, to);

	// Reset en passant square:
	epSquare = Square.SQ_NONE;

	// Reset rule 50 counter:
	rule50 = 0;

	// Update checkers BB:
	checkersBB = attacks_to(this.king_square(them), us);
  }


  /// Position::undo_castle_move() is a private method used to unmake a castling
  /// move.  It is called from the main Position::undo_move function.  Note that
  /// castling moves are encoded as "king captures friendly rook" moves, for
  /// instance white short castling in a non-Chess960 game is encoded as e1h1.

  private void undo_castle_move(Move m)
  {
	Color us;
	Color them;
	Square kfrom;
	Square kto;
	Square rfrom;
	Square rto;

	assert move_is_ok(m);
	assert GlobalMembers.move_is_castle(m);

	// When we have arrived here, some work has already been done by
	// Position::undo_move.  In particular, the side to move has been switched,
	// so the code below is correct.
	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	// Find source squares for king and rook:
	kfrom = GlobalMembers.move_from(m);
	rfrom = GlobalMembers.move_to(m); // HACK: See comment at beginning of function.

	// Find destination squares for king and rook:
	if (rfrom.getValue() > kfrom.getValue())
	{ // O-O
	  kto = GlobalMembers.relative_square(us, Square.SQ_G1);
	  rto = GlobalMembers.relative_square(us, Square.SQ_F1);
	}
	else
	{ // O-O-O
	  kto = GlobalMembers.relative_square(us, Square.SQ_C1);
	  rto = GlobalMembers.relative_square(us, Square.SQ_D1);
	}

	assert this.piece_on(kto) == GlobalMembers.king_of_color(us);
	assert this.piece_on(rto) == GlobalMembers.rook_of_color(us);

	// Remove pieces from destination squares:
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), kto);
	GlobalMembers.clear_bit((byTypeBB[PieceType.KING.getValue()]), kto);
	GlobalMembers.clear_bit((byTypeBB[0]), kto); // HACK: byTypeBB[0] == occupied squares
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), rto);
	GlobalMembers.clear_bit((byTypeBB[PieceType.ROOK.getValue()]), rto);
	GlobalMembers.clear_bit((byTypeBB[0]), rto); // HACK: byTypeBB[0] == occupied squares

	// Put pieces on source squares:
	GlobalMembers.set_bit((byColorBB[us.getValue()]), kfrom);
	GlobalMembers.set_bit((byTypeBB[PieceType.KING.getValue()]), kfrom);
	GlobalMembers.set_bit((byTypeBB[0]), kfrom); // HACK: byTypeBB[0] == occupied squares
	GlobalMembers.set_bit((byColorBB[us.getValue()]), rfrom);
	GlobalMembers.set_bit((byTypeBB[PieceType.ROOK.getValue()]), rfrom);
	GlobalMembers.set_bit((byTypeBB[0]), rfrom); // HACK: byTypeBB[0] == occupied squares

	// Update board:
	board[rto.getValue()] = board[kto.getValue()] = Piece.EMPTY;
	board[rfrom.getValue()] = GlobalMembers.rook_of_color(us);
	board[kfrom.getValue()] = GlobalMembers.king_of_color(us);

	// Update king square:
	kingSquare[us.getValue()] = kfrom;

	// Update piece lists:
	pieceList[us.getValue()][PieceType.KING.getValue()][index[kto.getValue()]] = kfrom;
	pieceList[us.getValue()][PieceType.ROOK.getValue()][index[rto.getValue()]] = rfrom;
	int tmp = index[rto.getValue()]; // Necessary because we may have rto == kfrom in FRC.
	index[kfrom.getValue()] = index[kto.getValue()];
	index[rfrom.getValue()] = tmp;
  }


  /// Position::undo_promotion_move() is a private method used to unmake a
  /// promotion move.  It is called from the main Position::do_move
  /// function.  The UndoInfo object, which has been initialized in
  /// Position::do_move, is used to put back the captured piece (if any).

  private void undo_promotion_move(Move m, UndoInfo u)
  {
	Color us;
	Color them;
	Square from;
	Square to;
	PieceType capture;
	PieceType promotion;

	assert move_is_ok(m);
	assert GlobalMembers.move_promotion(m);

	// When we have arrived here, some work has already been done by
	// Position::undo_move.  In particular, the side to move has been switched,
	// so the code below is correct.
	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	from = GlobalMembers.move_from(m);
	to = GlobalMembers.move_to(m);

	assert GlobalMembers.pawn_rank(us, to) == Rank.RANK_8;
	assert this.piece_on(from) == Piece.EMPTY;

	// Remove promoted piece:
	promotion = GlobalMembers.move_promotion(m);
	assert this.piece_on(to) == GlobalMembers.piece_of_color_and_type(us, promotion);
	assert promotion.getValue() >= PieceType.KNIGHT.getValue() && promotion.getValue() <= PieceType.QUEEN.getValue();
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), to);
	GlobalMembers.clear_bit((byTypeBB[promotion.getValue()]), to);
	GlobalMembers.clear_bit((byTypeBB[0]), to); // HACK: byTypeBB[0] == occupied squares

	// Insert pawn at source square:
	GlobalMembers.set_bit((byColorBB[us.getValue()]), from);
	GlobalMembers.set_bit((byTypeBB[PieceType.PAWN.getValue()]), from);
	GlobalMembers.set_bit((byTypeBB[0]), from); // HACK: byTypeBB[0] == occupied squares
	board[from.getValue()] = GlobalMembers.pawn_of_color(us);

	// Update material:
	npMaterial[us.getValue()] -= GlobalMembers.piece_value_midgame(promotion);

	// Update piece list:
	pieceList[us.getValue()][PieceType.PAWN.getValue()][pieceCount[us.getValue()][PieceType.PAWN.getValue()]] = from;
	index[from.getValue()] = pieceCount[us.getValue()][PieceType.PAWN.getValue()];
	pieceList[us.getValue()][promotion.getValue()][index[to.getValue()]] = pieceList[us.getValue()][promotion.getValue()][pieceCount[us.getValue()][promotion.getValue()] - 1];
	index[pieceList[us.getValue()][promotion.getValue()][index[to.getValue()]].getValue()] = index[to.getValue()];

	// Update piece counts:
	pieceCount[us.getValue()][promotion.getValue()]--;
	pieceCount[us.getValue()][PieceType.PAWN.getValue()]++;

	capture = u.capture;
	if (capture.getValue() != 0)
	{
	  assert capture != PieceType.KING;

	  // Insert captured piece:
	  GlobalMembers.set_bit((byColorBB[them.getValue()]), to);
	  GlobalMembers.set_bit((byTypeBB[capture.getValue()]), to);
	  GlobalMembers.set_bit((byTypeBB[0]), to); // HACK: byTypeBB[0] == occupied squares
	  board[to.getValue()] = GlobalMembers.piece_of_color_and_type(them, capture);

	  // Update material.  Because the move is a promotion move, we know
	  // that the captured piece cannot be a pawn.
	  assert capture != PieceType.PAWN;
	  npMaterial[them.getValue()] += GlobalMembers.piece_value_midgame(capture);

	  // Update piece list:
	  pieceList[them.getValue()][capture.getValue()][pieceCount[them.getValue()][capture.getValue()]] = to;
	  index[to.getValue()] = pieceCount[them.getValue()][capture.getValue()];

	  // Update piece count:
	  pieceCount[them.getValue()][capture.getValue()]++;
	}
	else
	{
	  board[to.getValue()] = Piece.EMPTY;
	}
  }


  /// Position::undo_ep_move() is a private method used to unmake an en passant
  /// capture.  It is called from the main Position::undo_move function.  Because
  /// the captured piece is always a pawn, we don't need to pass an UndoInfo
  /// object from which to retrieve the captured piece.

  private void undo_ep_move(Move m)
  {
	Color us;
	Color them;
	Square from;
	Square to;
	Square capsq;

	assert move_is_ok(m);
	assert GlobalMembers.move_is_ep(m);

	// When we have arrived here, some work has already been done by
	// Position::undo_move.  In particular, the side to move has been switched,
	// so the code below is correct.
	us = this.side_to_move();
	them = GlobalMembers.opposite_color(us);

	// Find from, to and captures squares:
	from = GlobalMembers.move_from(m);
	to = GlobalMembers.move_to(m);
	capsq = (us == Color.WHITE)? (to - SquareDelta.DELTA_N) : (to - SquareDelta.DELTA_S);

	assert to == this.ep_square();
	assert GlobalMembers.pawn_rank(us, to) == Rank.RANK_6;
	assert this.piece_on(to) == GlobalMembers.pawn_of_color(us);
	assert this.piece_on(from) == Piece.EMPTY;
	assert this.piece_on(capsq) == Piece.EMPTY;

	// Replace captured piece:
	GlobalMembers.set_bit((byColorBB[them.getValue()]), capsq);
	GlobalMembers.set_bit((byTypeBB[PieceType.PAWN.getValue()]), capsq);
	GlobalMembers.set_bit((byTypeBB[0]), capsq);
	board[capsq.getValue()] = GlobalMembers.pawn_of_color(them);

	// Remove moving piece from destination square:
	GlobalMembers.clear_bit((byColorBB[us.getValue()]), to);
	GlobalMembers.clear_bit((byTypeBB[PieceType.PAWN.getValue()]), to);
	GlobalMembers.clear_bit((byTypeBB[0]), to);
	board[to.getValue()] = Piece.EMPTY;

	// Replace moving piece at source square:
	GlobalMembers.set_bit((byColorBB[us.getValue()]), from);
	GlobalMembers.set_bit((byTypeBB[PieceType.PAWN.getValue()]), from);
	GlobalMembers.set_bit((byTypeBB[0]), from);
	board[from.getValue()] = GlobalMembers.pawn_of_color(us);

	// Update piece list:
	pieceList[us.getValue()][PieceType.PAWN.getValue()][index[to.getValue()]] = from;
	index[from.getValue()] = index[to.getValue()];
	pieceList[them.getValue()][PieceType.PAWN.getValue()][pieceCount[them.getValue()][PieceType.PAWN.getValue()]] = capsq;
	index[capsq.getValue()] = pieceCount[them.getValue()][PieceType.PAWN.getValue()];

	// Update piece count:
	pieceCount[them.getValue()][PieceType.PAWN.getValue()]++;
  }


  /// Position::find_checkers() computes the checkersBB bitboard, which
  /// contains a nonzero bit for each checking piece (0, 1 or 2).  It
  /// currently works by calling Position::attacks_to, which is probably
  /// inefficient.  Consider rewriting this function to use the last move
  /// played, like in non-bitboard versions of Glaurung.

  private void find_checkers()
  {
	checkersBB = attacks_to(this.king_square(this.side_to_move()), GlobalMembers.opposite_color(this.side_to_move()));
  }

  // Computing hash keys from scratch (for initialization and debugging)
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long compute_key() const;

  /// Position::compute_key() computes the hash key of the position.  The hash
  /// key is usually updated incrementally as moves are made and unmade, the
  /// compute_key() function is only used when a new position is set up, and
  /// to verify the correctness of the hash key when running in debug mode.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong compute_key() const
  private long compute_key()
  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long result = Key(0ULL);
	long result = Key(0);

	for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
	{
	  if (this.square_is_occupied(s))
	  {
		result ^= zobrist[this.color_of_piece_on(s).getValue()][this.type_of_piece_on(s).getValue()][s.getValue()];
	  }
	}

	if (this.ep_square() != Square.SQ_NONE)
	{
	  result ^= zobEp[this.ep_square().getValue()];
	}
	result ^= zobCastle[castleRights];
	if (this.side_to_move() == Color.BLACK)
	{
		result ^= zobSideToMove;
	}

	return result;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long compute_pawn_key() const;

  /// Position::compute_pawn_key() computes the hash key of the position.  The 
  /// hash key is usually updated incrementally as moves are made and unmade, 
  /// the compute_pawn_key() function is only used when a new position is set 
  /// up, and to verify the correctness of the pawn hash key when running in 
  /// debug mode.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong compute_pawn_key() const
  private long compute_pawn_key()
  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long result = Key(0ULL);
	long result = Key(0);
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b;
	long b;
	Square s;

	for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	{
	  b = this.pawns(c);
	  while (b != 0)
	  {
		s = pop_1st_bit(b);
		result ^= zobrist[c.getValue()][PieceType.PAWN.getValue()][s.getValue()];
	  }
	}
	return result;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long compute_material_key() const;

  /// Position::compute_material_key() computes the hash key of the position.
  /// The hash key is usually updated incrementally as moves are made and unmade,
  /// the compute_material_key() function is only used when a new position is set
  /// up, and to verify the correctness of the material hash key when running in
  /// debug mode.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong compute_material_key() const
  private long compute_material_key()
  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long result = Key(0ULL);
	long result = Key(0);
	for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	{
	  for (PieceType pt = PieceType.PAWN; pt.getValue() <= PieceType.QUEEN.getValue(); pt++)
	  {
		int count = this.piece_count(c, pt);
		for (int i = 0; i <= count; i++)
		{
		  result ^= zobMaterial[c.getValue()][pt.getValue()][i];
		}
	  }
	}
	return result;
  }

  // Computing incremental evaluation scores and material counts
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value mg_pst(Color c, PieceType pt, Square s) const
  private Value mg_pst(Color c, PieceType pt, Square s)
  {
	return MgPieceSquareTable[GlobalMembers.piece_of_color_and_type(c, pt).getValue()][s.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value eg_pst(Color c, PieceType pt, Square s) const
  private Value eg_pst(Color c, PieceType pt, Square s)
  {
	return EgPieceSquareTable[GlobalMembers.piece_of_color_and_type(c, pt).getValue()][s.getValue()];
  }


  /// Position::compute_mg_value() and Position::compute_eg_value() compute the
  /// incremental scores for the middle game and the endgame.  These functions
  /// are used to initialize the incremental scores when a new position is set
  /// up, and to verify that the scores are correctly updated by do_move
  /// and undo_move when the program is running in debug mode.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value compute_mg_value() const
  private Value compute_mg_value()
  {
	Value result = Value.forValue(0);
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b;
	long b;
	Square s;

	for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	{
	  for (PieceType pt = PieceType.PAWN; pt.getValue() <= PieceType.KING.getValue(); pt++)
	  {
		b = this.pieces_of_color_and_type(c, pt);
		while (b != 0)
		{
		  s = pop_1st_bit(b);
		  assert this.piece_on(s) == GlobalMembers.piece_of_color_and_type(c, pt);
		  result += this.mg_pst(c, pt, s);
		}
	  }
	}
	result += (this.side_to_move() == Color.WHITE)? (GlobalMembers.TempoValueMidgame / 2) : -(GlobalMembers.TempoValueMidgame / 2);
	return result;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value compute_eg_value() const
  private Value compute_eg_value()
  {
	Value result = Value.forValue(0);
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b;
	long b;
	Square s;

	for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	{
	  for (PieceType pt = PieceType.PAWN; pt.getValue() <= PieceType.KING.getValue(); pt++)
	  {
		b = this.pieces_of_color_and_type(c, pt);
		while (b != 0)
		{
		  s = pop_1st_bit(b);
		  assert this.piece_on(s) == GlobalMembers.piece_of_color_and_type(c, pt);
		  result += this.eg_pst(c, pt, s);
		}
	  }
	}
	result += (this.side_to_move() == Color.WHITE)? (GlobalMembers.TempoValueEndgame / 2) : -(GlobalMembers.TempoValueEndgame / 2);
	return result;
  }


  /// Position::compute_non_pawn_material() computes the total non-pawn middle
  /// game material score for the given side.  Material scores are updated
  /// incrementally during the search, this function is only used while
  /// initializing a new Position object.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value compute_non_pawn_material(Color c) const
  private Value compute_non_pawn_material(Color c)
  {
	Value result = Value.forValue(0);
	Square s;

	for (PieceType pt = PieceType.KNIGHT; pt.getValue() <= PieceType.QUEEN.getValue(); pt++)
	{
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b = this->pieces_of_color_and_type(c, pt);
	  long b = this.pieces_of_color_and_type(c, pt);
	  while (b != 0)
	  {
		s = pop_1st_bit(b);
		assert this.piece_on(s) == GlobalMembers.piece_of_color_and_type(c, pt);
		result += GlobalMembers.piece_value_midgame(pt);
	  }
	}
	return result;
  }

  // Bitboards
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long byColorBB[2], byTypeBB[8];
  private long[] byColorBB = new long[2];
  private long[] byTypeBB = new long[8];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long checkersBB;
  private long checkersBB;

  // Board
  private Piece[] board = new Piece[64];

  // Piece counts
  private int[][] pieceCount = new int[2][8]; // [color][pieceType]

  // Piece lists
  private Square[][][] pieceList = new Square[2][8][16]; // [color][pieceType][index]
  private int[] index = new int[64];

  // Other info
  private Color sideToMove;
  private int castleRights;
  private File initialKFile;
  private File initialKRFile;
  private File initialQRFile;
  private Square epSquare;
  private Square[] kingSquare = new Square[2];
  private Move lastMove;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long key, pawnKey, materialKey, history[MaxGameLength];
  private long key;
  private long pawnKey;
  private long materialKey;
  private long[] history = new long[MaxGameLength];
  private int rule50;
  private int gamePly;
  private Value mgValue;
  private Value egValue;
  private Value[] npMaterial = new Value[2];

  // Static variables
  private static int[] castleRightsMask = new int[64];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: static unsigned long long zobrist[2][8][64];
  private static long[][][] zobrist = new long[2][8][64];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: static unsigned long long zobEp[64];
  private static long[] zobEp = new long[64];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: static unsigned long long zobCastle[16];
  private static long[] zobCastle = new long[16];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: static unsigned long long zobMaterial[2][8][16];
  private static long[][][] zobMaterial = new long[2][8][16];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: static unsigned long long zobSideToMove;
  private static long zobSideToMove;
  private static Value[][] MgPieceSquareTable = new Value[16][64];
  private static Value[][] EgPieceSquareTable = new Value[16][64];
}
////
//// Variables
////


//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long Position::zobrist[2][8][64];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long Position::zobEp[64];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long Position::zobCastle[16];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long Position::zobMaterial[2][8][16];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long Position::zobSideToMove;

