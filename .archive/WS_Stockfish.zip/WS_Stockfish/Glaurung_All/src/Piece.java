public enum Piece
{
  NO_PIECE(0),
  WP(1),
  WN(2),
  WB(3),
  WR(4),
  WQ(5),
  WK(6),
  BP(9),
  BN(10),
  BB(11),
  BR(12),
  BQ(13),
  BK(14),
  EMPTY(16),
  OUTSIDE(17);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Piece> mappings;
	private static java.util.HashMap<Integer, Piece> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Piece.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Piece>();
				}
			}
		}
		return mappings;
	}

	private Piece(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Piece forValue(int value)
	{
		return getMappings().get(value);
	}
}