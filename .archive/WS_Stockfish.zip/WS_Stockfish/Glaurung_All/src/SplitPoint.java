////
//// Types
////

public class SplitPoint
{
  public SplitPoint parent;
  public Position pos = new Position();
  public SearchStack[][] sstack = new SearchStack[THREAD_MAX][PLY_MAX];
  public SearchStack parentSstack;
  public int ply;
  public Depth depth;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile Value alpha, beta, bestValue;
  public Value alpha;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile Value beta;
  public Value beta;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile Value bestValue;
  public Value bestValue;
  public boolean pvNode;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long dcCandidates;
  public long dcCandidates;
  public int master;
  public int[] slaves = new int[THREAD_MAX];
  public Lock lock = new Lock();
  public MovePicker mp;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile int moves;
  public int moves;
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile int cpus;
  public int cpus;
  public boolean finished;
}