////
//// Local definitions
////


  /// Types

  // The RootMove class is used for moves at the root at the tree.  For each
  // root move, we store a score, a node count, and a PV (really a refutation
  // in the case of moves which fail low).

  public class RootMove
  {


	/// The RootMove class

	// Constructor

	public RootMove()
	{
	  nodes = cumulativeNodes = 0;
	}

	public Move move;
	public Value score;
	public long nodes;
	public long cumulativeNodes;
	public Move[] pv = new Move[PLY_MAX_PLUS_2];
  }