/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


////
//// Includes
////


/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/



////
//// Includes
////



////
//// Types
////

/// The History class stores statistics about how often different moves have
/// been successful or unsuccessful during the current search.  These
/// statistics are used for reduction and move ordering decisions.

public class History
{


  ////
  //// Functions
  ////

  /// Constructor

  public History()
  {
	this.clear();
  }


  /// History::clear() clears the history tables.

  public final void clear()
  {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
	memset(history, 0, 2 * 8 * 64 * (Integer.SIZE / Byte.SIZE));
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
	memset(successCount, 0, 2 * 8 * 64 * (Integer.SIZE / Byte.SIZE));
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
	memset(failureCount, 0, 2 * 8 * 64 * (Integer.SIZE / Byte.SIZE));
  }


  /// History::success() registers a move as being successful.  This is done
  /// whenever a non-capturing move causes a beta cutoff in the main search.
  /// The three parameters are the moving piece, the move itself, and the
  /// search depth.

  public final void success(Piece p, Move m, Depth d)
  {
	assert piece_is_ok(p);
	assert move_is_ok(m);

	history[p.getValue()][GlobalMembers.move_to(m).getValue()] += d.getValue() * d.getValue();
	successCount[p.getValue()][GlobalMembers.move_to(m).getValue()]++;

	// Prevent history overflow:
	if (history[p.getValue()][GlobalMembers.move_to(m).getValue()] >= GlobalMembers.HistoryMax)
	{
	  for (int i = 0; i < 16; i++)
	  {
		for (int j = 0; j < 64; j++)
		{
		  history[i][j] /= 2;
		}
	  }
	}
  }


  /// History::failure() registers a move as being unsuccessful.  The function is
  /// called for each non-capturing move which failed to produce a beta cutoff
  /// at a node where a beta cutoff was finally found.

  public final void failure(Piece p, Move m)
  {
	assert piece_is_ok(p);
	assert move_is_ok(m);

	failureCount[p.getValue()][GlobalMembers.move_to(m).getValue()]++;
  }


  /// History::move_ordering_score() returns an integer value used to order the
  /// non-capturing moves in the MovePicker class.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int move_ordering_score(Piece p, Move m) const
  public final int move_ordering_score(Piece p, Move m)
  {
	assert piece_is_ok(p);
	assert move_is_ok(m);

	return history[p.getValue()][GlobalMembers.move_to(m).getValue()];
  }


  /// History::ok_to_prune() decides whether a move has been sufficiently
  /// unsuccessful that it makes sense to prune it entirely. 

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean ok_to_prune(Piece p, Move m, Depth d) const
  public final boolean ok_to_prune(Piece p, Move m, Depth d)
  {
	assert piece_is_ok(p);
	assert move_is_ok(m);

	return (d.getValue() * successCount[p.getValue()][GlobalMembers.move_to(m).getValue()] < failureCount[p.getValue()][GlobalMembers.move_to(m).getValue()]);
  }

  private int[][] history = new int[16][64]; // [piece][square]
  private int[][] successCount = new int[16][64];
  private int[][] failureCount = new int[16][64];
}