import java.io.*;

/// Subclasses for various concrete endgames:

// Generic "mate lone king" eval:
public class KXKEvaluationFunction extends EndgameEvaluationFunction
{
  public KXKEvaluationFunction(Color c)
  {
	  super(c);
  }


  /// Mate with KX vs K.  This function is used to evaluate positions with
  /// King and plenty of material vs a lone king.  It simply gives the
  /// attacking side a bonus for driving the defending king towards the edge
  /// of the board, and for keeping the distance between the two kings small.

  @Override
  public final Value apply(Position pos)
  {

	assert pos.non_pawn_material(weakerSide) == Value(0);
	assert pos.pawn_count(weakerSide) == Value(0);

	Square winnerKSq = pos.king_square(strongerSide);
	Square loserKSq = pos.king_square(weakerSide);

	Value result = pos.non_pawn_material(strongerSide) + pos.pawn_count(strongerSide) * GlobalMembers.PawnValueEndgame.getValue() + GlobalMembers.mate_table(loserKSq) + GlobalMembers.distance_bonus(GlobalMembers.square_distance(winnerKSq, loserKSq));

	if (pos.queen_count(strongerSide) > 0 || pos.rook_count(strongerSide) > 0 || pos.bishop_count(strongerSide) > 1)
	{
	  // TODO: check for two equal-colored bishops!
	  result += Value.VALUE_KNOWN_WIN;
	}

	return (strongerSide == pos.side_to_move())? result : -result;
  }
}