public enum SquareDelta
{
  DELTA_SSW(-021),
  DELTA_SS(-020),
  DELTA_SSE(-017),
  DELTA_SWW(-012),
  DELTA_SW(-011),
  DELTA_S(-010),
  DELTA_SE(-07),
  DELTA_SEE(-06),
  DELTA_W(-01),
  DELTA_ZERO(0),
  DELTA_E(01),
  DELTA_NWW(06),
  DELTA_NW(07),
  DELTA_N(010),
  DELTA_NE(011),
  DELTA_NEE(012),
  DELTA_NNW(017),
  DELTA_NN(020),
  DELTA_NNE(021);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, SquareDelta> mappings;
	private static java.util.HashMap<Integer, SquareDelta> getMappings()
	{
		if (mappings == null)
		{
			synchronized (SquareDelta.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, SquareDelta>();
				}
			}
		}
		return mappings;
	}

	private SquareDelta(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static SquareDelta forValue(int value)
	{
		return getMappings().get(value);
	}
}