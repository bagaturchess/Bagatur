///#endif // !defined(MOVEPICK_H_INCLUDED)



////
//// Local definitions
////


  /// Types

  public enum MovegenPhase
  {
	PH_TT_MOVE(0), // Transposition table move
	PH_MATE_KILLER(1), // Mate killer from the current ply
	PH_GOOD_CAPTURES(2), // Queen promotions and captures with SEE values >= 0
	PH_BAD_CAPTURES(3), // Queen promotions and captures with SEE valuse <= 0
	PH_KILLER_1(4), // Killer move 1 from the current ply (not used yet).
	PH_KILLER_2(5), // Killer move 2 from the current ply (not used yet).
	PH_NONCAPTURES(6), // Non-captures and underpromotions
	PH_EVASIONS(7), // Check evasions
	PH_QCAPTURES(8), // Captures in quiescence search
	PH_QCHECKS(9), // Checks in quiescence search
	PH_STOP(10);

	  public static final int SIZE = java.lang.Integer.SIZE;

	  private int intValue;
	  private static java.util.HashMap<Integer, MovegenPhase> mappings;
	  private static java.util.HashMap<Integer, MovegenPhase> getMappings()
	  {
		  if (mappings == null)
		  {
			  synchronized (MovegenPhase.class)
			  {
				  if (mappings == null)
				  {
					  mappings = new java.util.HashMap<Integer, MovegenPhase>();
				  }
			  }
		  }
		  return mappings;
	  }

	  private MovegenPhase(int value)
	  {
		  intValue = value;
		  getMappings().put(value, this);
	  }

	  public int getValue()
	  {
		  return intValue;
	  }

	  public static MovegenPhase forValue(int value)
	  {
		  return getMappings().get(value);
	  }
  }