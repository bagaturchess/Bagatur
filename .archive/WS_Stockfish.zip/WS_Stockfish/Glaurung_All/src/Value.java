public enum Value
{
  VALUE_DRAW(0),
  VALUE_KNOWN_WIN(15000),
  VALUE_MATE(30000),
  VALUE_INFINITE(30001),
  VALUE_NONE(30002);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Value> mappings;
	private static java.util.HashMap<Integer, Value> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Value.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Value>();
				}
			}
		}
		return mappings;
	}

	private Value(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Value forValue(int value)
	{
		return getMappings().get(value);
	}
}