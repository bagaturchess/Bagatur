import java.io.*;

// KRP vs KR:
public class KRPKRScalingFunction extends ScalingFunction
{
  public KRPKRScalingFunction(Color c)
  {
	  super(c);
  }


  /// KRPKRScalingFunction scales KRP vs KR endgames.  This function knows a
  /// handful of the most important classes of drawn positions, but is far
  /// from perfect.  It would probably be a good idea to add more knowledge
  /// in the future.
  ///
  /// It would also be nice to rewrite the actual code for this function,
  /// which is mostly copied from Glaurung 1.x, and not very pretty.

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(strongerSide) == 1;
	assert pos.non_pawn_material(weakerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(weakerSide) == 0;

	Square wksq = pos.king_square(strongerSide);
	Square wrsq = pos.rook_list(strongerSide, 0);
	Square wpsq = pos.pawn_list(strongerSide, 0);
	Square bksq = pos.king_square(weakerSide);
	Square brsq = pos.rook_list(weakerSide, 0);

	// Orient the board in such a way that the stronger side is white, and the
	// pawn is on the left half of the board:
	if (strongerSide == Color.BLACK)
	{
	  wksq = GlobalMembers.flip_square(wksq);
	  wrsq = GlobalMembers.flip_square(wrsq);
	  wpsq = GlobalMembers.flip_square(wpsq);
	  bksq = GlobalMembers.flip_square(bksq);
	  brsq = GlobalMembers.flip_square(brsq);
	}
	if (GlobalMembers.square_file(wpsq) > File.FILE_D.getValue())
	{
	  wksq = GlobalMembers.flop_square(wksq);
	  wrsq = GlobalMembers.flop_square(wrsq);
	  wpsq = GlobalMembers.flop_square(wpsq);
	  bksq = GlobalMembers.flop_square(bksq);
	  brsq = GlobalMembers.flop_square(brsq);
	}

	File f = GlobalMembers.square_file(wpsq);
	Rank r = GlobalMembers.square_rank(wpsq);
	Square queeningSq = GlobalMembers.make_square(f, Rank.RANK_8);
	int tempo = (pos.side_to_move() == strongerSide);

	// If the pawn is not too far advanced and the defending king defends the
	// queening square, use the third-rank defence:
	if (r.getValue() <= Rank.RANK_5.getValue() && GlobalMembers.square_distance(bksq, queeningSq) <= 1 && wksq.getValue() <= Square.SQ_H5.getValue() && (GlobalMembers.square_rank(brsq) == Rank.RANK_6 || (r.getValue() <= Rank.RANK_3.getValue() && GlobalMembers.square_rank(wrsq) != Rank.RANK_6)))
	{
	  return ScaleFactor(0);
	}

	// The defending side saves a draw by checking from behind in case the pawn
	// has advanced to the 6th rank with the king behind.
	if (r == Rank.RANK_6 && GlobalMembers.square_distance(bksq, queeningSq) <= 1 && GlobalMembers.square_rank(wksq) + tempo <= Rank.RANK_6.getValue().getValue() != 0 && (GlobalMembers.square_rank(brsq) == Rank.RANK_1 || (tempo == 0 && Math.abs(GlobalMembers.square_file(brsq) - f) >= 3)))
	{
	  return ScaleFactor(0);
	}

	if (r.getValue() >= Rank.RANK_6.getValue() && bksq == queeningSq && GlobalMembers.square_rank(brsq) == Rank.RANK_1 && (tempo == 0 || GlobalMembers.square_distance(wksq, wpsq) >= 2))
	{
	  return ScaleFactor(0);
	}

	// White pawn on a7 and rook on a8 is a draw if black's king is on g7 or h7
	// and the black rook is behind the pawn.
	if (wpsq == Square.SQ_A7 && wrsq == Square.SQ_A8 && (bksq == Square.SQ_H7 || bksq == Square.SQ_G7) && GlobalMembers.square_file(brsq) == File.FILE_A && (GlobalMembers.square_rank(brsq) <= Rank.RANK_3.getValue() || GlobalMembers.square_file(wksq) >= File.FILE_D.getValue() || GlobalMembers.square_rank(wksq) <= Rank.RANK_5.getValue()))
	{
	  return ScaleFactor(0);
	}

	// If the defending king blocks the pawn and the attacking king is too far
	// away, it's a draw.
	if (r.getValue() <= Rank.RANK_5.getValue() && bksq == wpsq + SquareDelta.DELTA_N && GlobalMembers.square_distance(wksq, wpsq) - tempo >= 2 && GlobalMembers.square_distance(wksq, brsq) - tempo >= 2)
	{
	  return ScaleFactor(0);
	}

	// Pawn on the 7th rank supported by the rook from behind usually wins if the
	// attacking king is closer to the queening square than the defending king,
	// and the defending king cannot gain tempi by threatening the attacking
	// rook.
	if (r == Rank.RANK_7 && f != File.FILE_A && GlobalMembers.square_file(wrsq) == f && wrsq != queeningSq && (GlobalMembers.square_distance(wksq, queeningSq) < GlobalMembers.square_distance(bksq, queeningSq) - 2 + tempo) && (GlobalMembers.square_distance(wksq, queeningSq) < GlobalMembers.square_distance(bksq, wrsq) + tempo))
	{
	  return ScaleFactor(ScaleFactor.SCALE_FACTOR_MAX - 2 * GlobalMembers.square_distance(wksq, queeningSq));
	}

	// Similar to the above, but with the pawn further back:
	if (f != File.FILE_A && GlobalMembers.square_file(wrsq) == f && wrsq.getValue() < wpsq.getValue() && (GlobalMembers.square_distance(wksq, queeningSq) < GlobalMembers.square_distance(bksq, queeningSq) - 2 + tempo) && (GlobalMembers.square_distance(wksq, wpsq + SquareDelta.DELTA_N) < GlobalMembers.square_distance(bksq, wpsq + SquareDelta.DELTA_N) - 2 + tempo) && (GlobalMembers.square_distance(bksq, wrsq) + tempo >= 3 || (GlobalMembers.square_distance(wksq, queeningSq) < GlobalMembers.square_distance(bksq, wrsq) + tempo && (GlobalMembers.square_distance(wksq, wpsq + SquareDelta.DELTA_N) < GlobalMembers.square_distance(bksq, wrsq) + tempo))))
	{
	  return ScaleFactor(ScaleFactor.SCALE_FACTOR_MAX - (8 * GlobalMembers.square_distance(wpsq, queeningSq) + 2 * GlobalMembers.square_distance(wksq, queeningSq)));
	}

	// If the pawn is not far advanced, and the defending king is somewhere in
	// the pawn's path, it's probably a draw:
	if (r.getValue() <= Rank.RANK_4.getValue() && bksq.getValue() > wpsq.getValue())
	{
	  if (GlobalMembers.square_file(bksq) == GlobalMembers.square_file(wpsq))
	  {
		return ScaleFactor(10);
	  }
	  if (Math.abs(GlobalMembers.square_file(bksq) - GlobalMembers.square_file(wpsq)) == 1 && GlobalMembers.square_distance(wksq, bksq) > 2)
	  {
		return ScaleFactor(24 - 2 * GlobalMembers.square_distance(wksq, bksq));
	  }
	}

	return ScaleFactor.SCALE_FACTOR_NONE;
  }
}