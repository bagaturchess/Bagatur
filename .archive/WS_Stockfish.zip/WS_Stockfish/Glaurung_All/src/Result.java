////
//// Local definitions
////


  public enum Result
  {
	RESULT_UNKNOWN,
	RESULT_INVALID,
	RESULT_WIN,
	RESULT_LOSS,
	RESULT_DRAW;

	  public static final int SIZE = java.lang.Integer.SIZE;

	  public int getValue()
	  {
		  return this.ordinal();
	  }

	  public static Result forValue(int value)
	  {
		  return values()[value];
	  }
  }