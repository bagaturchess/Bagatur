////
//// Local definitions
////


  ///
  /// Types
  ///

  public enum OptionType
  {
	  SPIN,
	  COMBO,
	  CHECK,
	  STRING,
	  BUTTON,
	  OPTION_TYPE_NONE;

	  public static final int SIZE = java.lang.Integer.SIZE;

	  public int getValue()
	  {
		  return this.ordinal();
	  }

	  public static OptionType forValue(int value)
	  {
		  return values()[value];
	  }
  }