import java.io.*;

/// The PawnInfoTable class represents a pawn hash table.  It is basically
/// just an array of PawnInfo objects and a few methods for accessing these
/// objects.  The most important method is get_pawn_info, which looks up a
/// position in the table and returns a pointer to a PawnInfo object.

public class PawnInfoTable implements Closeable
{


  ////
  //// Functions
  ////

  /// Constructor

  public PawnInfoTable(int numOfEntries)
  {
	size = numOfEntries;
	entries = tangible.Arrays.initializeWithDefaultPawnInfoInstances(size);
	if (entries == null)
	{
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	  std::cerr << "Failed to allocate " << (numOfEntries * sizeof(PawnInfo)) << " bytes for pawn hash table." << std::endl;
	  System.exit(1);
	}
	this.clear();
  }


  /// Destructor

  public final void close()
  {
	Arrays.deleteArray(entries);
  }


  /// PawnInfoTable::clear() clears the pawn hash table by setting all
  /// entries to 0.

  public final void clear()
  {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memset(entries, 0, size * sizeof(PawnInfo));
  }


  /// PawnInfoTable::get_pawn_info() takes a position object as input, computes
  /// a PawnInfo object, and returns a pointer to it.  The result is also 
  /// stored in a hash table, so we don't have to recompute everything when
  /// the same pawn structure occurs again.

  public final PawnInfo get_pawn_info(Position pos)
  {
	assert pos.is_ok();

  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long key = pos.get_pawn_key();
	long key = pos.get_pawn_key();
	int index = (int)(key & (size - 1));
	PawnInfo pi = entries + index;

	// If pi->key matches the position's pawn hash key, it means that we
	// have analysed this pawn structure before, and we can simply return the
	// information we found the last time instead of recomputing it:
	if (pi.key == key)
	{
	  return pi;
	}

	// Clear the PawnInfo object, and set the key:
	pi.clear();
	pi.key = key;

	Value[] mgValue = {Value(0), Value(0)};
	Value[] egValue = {Value(0), Value(0)};

	// Loop through the pawns for both colors:
	for (Color us = Color.WHITE; us.getValue() <= Color.BLACK.getValue(); us++)
	{
	  Color them = GlobalMembers.opposite_color(us);
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long ourPawns = pos.pawns(us);
	  long ourPawns = pos.pawns(us);
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long theirPawns = pos.pawns(them);
	  long theirPawns = pos.pawns(them);
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long pawns = ourPawns;
	  long pawns = ourPawns;

	  // Initialize pawn storm scores by giving bonuses for open files:
	  for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); f++)
	  {
		if (pos.file_is_half_open(us, f))
		{
		  pi.ksStormValue[us.getValue()] += GlobalMembers.KStormOpenFileBonus[f.getValue()];
		  pi.qsStormValue[us.getValue()] += GlobalMembers.QStormOpenFileBonus[f.getValue()];
		}
	  }

	  // Loop through all pawns of the current color and score each pawn:
	  while (pawns != 0)
	  {
		Square s = pop_1st_bit(pawns);
		File f = GlobalMembers.square_file(s);
		Rank r = GlobalMembers.square_rank(s);
		boolean passed;
		boolean doubled;
		boolean isolated;
		boolean backward;
		boolean chain;
		boolean candidate;
		int bonus;

		assert pos.piece_on(s) == GlobalMembers.pawn_of_color(us);

		// The file containing the pawn is not half open:
		pi.halfOpenFiles[us.getValue()] &= ~(1 << f.getValue());

		// Passed, isolated or doubled pawn?
		passed = pos.pawn_is_passed(us, s);
		isolated = pos.pawn_is_isolated(us, s);
		doubled = pos.pawn_is_doubled(us, s);

		// We calculate kingside and queenside pawn storm
		// scores for both colors.  These are used when evaluating
		// middle game positions with opposite side castling.
		//
		// Each pawn is given a base score given by a piece square table
		// (KStormTable[] or QStormTable[]).  This score is increased if
		// there are enemy pawns on adjacent files in front of the pawn.
		// This is because we want to be able to open files against the
		// enemy king, and to avoid blocking the pawn structure (e.g. white
		// pawns on h6, g5, black pawns on h7, g6, f7).

		// Kingside pawn storms:
		bonus = GlobalMembers.KStormTable[GlobalMembers.relative_square(us, s).getValue()];
		if (bonus > 0 && (GlobalMembers.outpost_mask(us, s) & theirPawns) != 0)
		{
		  switch (f)
		  {

		  case FILE_F:
			bonus += bonus / 4;
			break;

		  case FILE_G:
			bonus += bonus / 2 + bonus / 4;
			break;

		  case FILE_H:
			bonus += bonus / 2;
			break;

		  default:
			break;
		  }
		}
		pi.ksStormValue[us.getValue()] += bonus;

		// Queenside pawn storms:
		bonus = GlobalMembers.QStormTable[GlobalMembers.relative_square(us, s).getValue()];
		if (bonus > 0 && (GlobalMembers.passed_pawn_mask(us, s) & theirPawns) != 0)
		{
		  switch (f)
		  {

		  case FILE_A:
			bonus += bonus / 2;
			break;

		  case FILE_B:
			bonus += bonus / 2 + bonus / 4;
			break;

		  case FILE_C:
			bonus += bonus / 2;
			break;

		  default:
			break;
		  }
		}
		pi.qsStormValue[us.getValue()] += bonus;

		// Member of a pawn chain?  We could speed up the test a little by
		// introducing an array of masks indexed by color and square for doing
		// the test, but because everything is hashed, it probably won't make
		// any noticable difference.
		chain = (us == Color.WHITE)? (ourPawns & GlobalMembers.neighboring_files_bb(f) & (GlobalMembers.rank_bb(r) | GlobalMembers.rank_bb(r - 1))) != 0 : (ourPawns & GlobalMembers.neighboring_files_bb(f) & (GlobalMembers.rank_bb(r) | GlobalMembers.rank_bb(r + 1))) != 0;


		// Test for backward pawn.

		// If the pawn is isolated, passed, or member of a pawn chain, it cannot
		// be backward:
		if (passed || isolated || chain)
		{
		  backward = false;
		}
		// If the pawn can capture an enemy pawn, it's not backward:
		else if (pos.pawn_attacks(us, s) & theirPawns)
		{
		  backward = false;
		}
		// Check for friendly pawns behind on neighboring files:
		else if (ourPawns & GlobalMembers.in_front_bb(them, r) & GlobalMembers.neighboring_files_bb(f))
		{
		  backward = false;
		}
		else
		{
		  // We now know that there is no friendly pawns beside or behind this
		  // pawn on neighboring files.  We now check whether the pawn is
		  // backward by looking in the forward direction on the neighboring
		  // files, and seeing whether we meet a friendly or an enemy pawn first.
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long b;
		  long b;
		  if (us == Color.WHITE)
		  {
			for (b = pos.pawn_attacks(us, s); !(b & (ourPawns | theirPawns)); b <<= 8)
			{
				;
			}
			backward = ((b | (b << 8)) & theirPawns) != 0;
		  }
		  else
		  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			for (b = pos.pawn_attacks(us, s); !(b & (ourPawns | theirPawns)); b>>>=8)
			{
				;
			}
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			backward = ((b | (b >>> 8)) & theirPawns) != 0;
		  }
		}

		// Test for candidate passed pawn.
		candidate = (!passed && pos.file_is_half_open(them, f) && GlobalMembers.count_1s_max_15(GlobalMembers.neighboring_files_bb(f) & (GlobalMembers.in_front_bb(them, r) | GlobalMembers.rank_bb(r)) & ourPawns) - GlobalMembers.count_1s_max_15(GlobalMembers.neighboring_files_bb(f) & GlobalMembers.in_front_bb(us, r) & theirPawns) >= 0);

		// In order to prevent doubled passed pawns from receiving a too big
		// bonus, only the frontmost passed pawn on each file is considered as
		// a true passed pawn.
		if (passed && (ourPawns & GlobalMembers.squares_in_front_of(us, s)) != 0)
		{
		  // candidate = true;
		  passed = false;
		}

		// Score this pawn:
		Value mv = Value.forValue(0);
		Value ev = Value.forValue(0);
		if (isolated)
		{
		  mv -= GlobalMembers.IsolatedPawnMidgamePenalty[f.getValue()];
		  ev -= GlobalMembers.IsolatedPawnEndgamePenalty[f.getValue()];
		  if (pos.file_is_half_open(them, f))
		  {
			mv -= GlobalMembers.IsolatedPawnMidgamePenalty[f.getValue()] / 2;
			ev -= GlobalMembers.IsolatedPawnEndgamePenalty[f.getValue()] / 2;
		  }
		}
		if (doubled)
		{
		  mv -= GlobalMembers.DoubledPawnMidgamePenalty[f.getValue()];
		  ev -= GlobalMembers.DoubledPawnEndgamePenalty[f.getValue()];
		}
		if (backward)
		{
		  mv -= GlobalMembers.BackwardPawnMidgamePenalty[f.getValue()];
		  ev -= GlobalMembers.BackwardPawnEndgamePenalty[f.getValue()];
		  if (pos.file_is_half_open(them, f))
		  {
			mv -= GlobalMembers.BackwardPawnMidgamePenalty[f.getValue()] / 2;
			ev -= GlobalMembers.BackwardPawnEndgamePenalty[f.getValue()] / 2;
		  }
		}
		if (chain)
		{
		  mv += GlobalMembers.ChainMidgameBonus[f.getValue()];
		  ev += GlobalMembers.ChainEndgameBonus[f.getValue()];
		}
		if (candidate)
		{
		  mv += GlobalMembers.CandidateMidgameBonus[GlobalMembers.pawn_rank(us, s).getValue()];
		  ev += GlobalMembers.CandidateEndgameBonus[GlobalMembers.pawn_rank(us, s).getValue()];
		}

		mgValue[us.getValue()] += mv;
		egValue[us.getValue()] += ev;

		// If the pawn is passed, set the square of the pawn in the passedPawns
		// bitboard:
		if (passed)
		{
		  GlobalMembers.set_bit((pi.passedPawns), s);
		}
	  }
	}

	pi.mgValue = int16_t(mgValue[Color.WHITE.getValue()] - mgValue[Color.BLACK.getValue()]);
	pi.egValue = int16_t(egValue[Color.WHITE.getValue()] - egValue[Color.BLACK.getValue()]);

	return pi;
  }

  private int size;
  private PawnInfo entries;
}