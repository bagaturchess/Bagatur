  // The RootMoveList class is essentially an array of RootMove objects, with
  // a handful of methods for accessing the data in the individual moves.

  public class RootMoveList
  {


	/// The RootMoveList class

	// Constructor

	public RootMoveList(Position pos, Move[] searchMoves)
	{
	  MoveStack[] mlist = tangible.Arrays.initializeWithDefaultMoveStackInstances(MaxRootMoves);
	  boolean includeAllMoves = (searchMoves[0] == Move.MOVE_NONE);
	  int i;
	  int j = 0;
	  int k;

	  // Generate all legal moves
	  count = generate_legal_moves(pos, mlist);

	  // Add each move to the moves[] array
	  for (i = 0; i < count; i++)
	  {
		UndoInfo u = new UndoInfo();
		SearchStack[] ss = tangible.Arrays.initializeWithDefaultSearchStackInstances(GlobalMembers.PLY_MAX_PLUS_2);
		boolean includeMove;

		if (includeAllMoves)
		{
		  includeMove = true;
		}
		else
		{
		  includeMove = false;
		  for (k = 0; searchMoves[k] != Move.MOVE_NONE; k++)
		  {
			if (searchMoves[k] == mlist[i].move)
			{
			  includeMove = true;
			  break;
			}
		  }
		}

		if (includeMove)
		{
		  moves[j].move = mlist[i].move;
		  moves[j].nodes = 0;
		  pos.do_move(moves[j].move, u);
		  moves[j].score = -GlobalMembers.qsearch(pos, ss, -Value.VALUE_INFINITE, Value.VALUE_INFINITE, Depth(0), 1, 0);
		  pos.undo_move(moves[j].move, u);
		  moves[j].pv[0] = moves[i].move;
		  moves[j].pv[1] = Move.MOVE_NONE; // FIXME
		  j++;
		}
	  }
	  count = j;
	  this.sort();
	}


	// Simple accessor methods for the RootMoveList class

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Move get_move(int moveNum) const
	public final Move get_move(int moveNum)
	{
	  return moves[moveNum].move;
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value get_move_score(int moveNum) const
	public final Value get_move_score(int moveNum)
	{
	  return moves[moveNum].score;
	}

	public final void set_move_score(int moveNum, Value score)
	{
	  moves[moveNum].score = score;
	}

	public final void set_move_nodes(int moveNum, long nodes)
	{
	  moves[moveNum].nodes = nodes;
	  moves[moveNum].cumulativeNodes += nodes;
	}

	public final void set_move_pv(int moveNum, Move[] pv)
	{
	  int j;
	  for (j = 0; pv[j] != Move.MOVE_NONE; j++)
	  {
		moves[moveNum].pv[j] = pv[j];
	  }
	  moves[moveNum].pv[j] = Move.MOVE_NONE;
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Move get_move_pv(int moveNum, int i) const
	public final Move get_move_pv(int moveNum, int i)
	{
	  return moves[moveNum].pv[i];
	}

	public final long get_move_cumulative_nodes(int moveNum)
	{
	  return moves[moveNum].cumulativeNodes;
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int move_count() const
	public final int move_count()
	{
	  return count;
	}


	// RootMoveList::scan_for_easy_move() is called at the end of the first
	// iteration, and is used to detect an "easy move", i.e. a move which appears
	// to be much bester than all the rest.  If an easy move is found, the move
	// is returned, otherwise the function returns MOVE_NONE.  It is very
	// important that this function is called at the right moment:  The code
	// assumes that the first iteration has been completed and the moves have
	// been sorted.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Move scan_for_easy_move() const
	public final Move scan_for_easy_move()
	{
	  Value bestMoveValue = this.get_move_score(0);
	  for (int i = 1; i < this.move_count(); i++)
	  {
		if (this.get_move_score(i) >= bestMoveValue.getValue() - GlobalMembers.EasyMoveMargin)
		{
		  return Move.MOVE_NONE;
		}
	  }
	  return this.get_move(0);
	}


	// RootMoveList::sort() sorts the root move list at the beginning of a new
	// iteration.

	public final void sort()
	{
	  for (int i = 1; i < count; i++)
	  {
		RootMove rm = moves[i];
		int j;
		for (j = i; j > 0 && compare_root_moves(moves[j - 1], rm); j--)
		{
		  moves[j] = moves[j - 1];
		}
		moves[j] = rm;
	  }
	}


	// RootMoveList::sort_multipv() sorts the first few moves in the root move
	// list by their scores and depths.  It is used to order the different PVs
	// correctly in MultiPV mode.

	public final void sort_multipv(int n)
	{
	  for (int i = 1; i <= n; i++)
	  {
		RootMove rm = moves[i];
		int j;
		for (j = i; j > 0 && moves[j - 1].score.getValue() < rm.score.getValue(); j--)
		{
		  moves[j] = moves[j - 1];
		}
		moves[j] = rm;
	  }
	}


	// RootMoveList::compare_root_moves() is the comparison function used by
	// RootMoveList::sort when sorting the moves.  A move m1 is considered to
	// be better than a move m2 if it has a higher score, or if the moves have
	// equal score but m1 has the higher node count.

	private static int compare_root_moves(RootMove rm1, RootMove rm2)
	{
	  if (rm1.score.getValue() < rm2.score.getValue())
	  {
		  return 1;
	  }
	  else if (rm1.score.getValue() > rm2.score.getValue())
	  {
		  return 0;
	  }
	  else if (rm1.nodes < rm2.nodes)
	  {
		  return 1;
	  }
	  else if (rm1.nodes > rm2.nodes)
	  {
		  return 0;
	  }
	  else
	  {
		  return 1;
	  }
	}

	private static final int MaxRootMoves = 500;
	private RootMove[] moves = tangible.Arrays.initializeWithDefaultRootMoveInstances(MaxRootMoves);
	private int count;
  }
  // init_thread() is the function which is called when a new thread is
  // launched.  It simply calls the idle_loop() function with the supplied
  // threadID.  There are two versions of this function; one for POSIX threads
  // and one for Windows threads.




