import java.util.*;

public class GlobalMembers
{


////
//// Functions
////

/// benchmark() runs a simple benchmark by letting Glaurung analyze 15
/// positions for 60 seconds each.  There are two parameters; the
/// transposition table size and the number of search threads that should
/// be used.  The analysis is written to a file named bench.txt.

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Prototypes
	////

	public static void benchmark(String ttSize, String threads)
	{
	  Position pos = new Position();
	  Move[] moves = {Move.MOVE_NONE};
	  int i;

	  i = Integer.parseInt(ttSize);
	  if (i < 4 || i > 1024)
	  {
		std::cerr << "The hash table size must be between 4 and 1024" << std::endl;
		System.exit(1);
	  }

	  i = Integer.parseInt(threads);
	  if (i < 1 || i > THREAD_MAX)
	  {
		std::cerr << "The number of threads must be between 1 and " << THREAD_MAX << std::endl;
		System.exit(1);
	  }

	  set_option_value("Hash", ttSize);
	  set_option_value("Threads", threads);
	  set_option_value("OwnBook", "false");
	  set_option_value("Use Search Log", "true");
	  set_option_value("Search Log Filename", "bench.txt");

	  for (i = 0; i < 15; i++)
	  {
		pos.from_fen(BenchmarkPositions[i]);
		think(pos, true, false, 0, 0, 0, 0, 0, 60000, moves);
	  }

	}





	////
	//// Variables
	////

	public static final String[] BenchmarkPositions = {"r4rk1/1b2qppp/p1n1p3/1p6/1b1PN3/3BRN2/PP3PPP/R2Q2K1 b - - 7 16", "4r1k1/ppq3pp/3b4/2pP4/2Q1p3/4B1P1/PP5P/R5K1 b - - 0 20", "4rrk1/pp1n3p/3q2pQ/2p1pb2/2PP4/2P3N1/P2B2PP/4RRK1 b - - 7 19", "rq3rk1/ppp2ppp/1bnpb3/3N2B1/3NP3/7P/PPPQ1PP1/2KR3R w - - 7 14", "r1bq1r1k/1pp1n1pp/1p1p4/4p2Q/4Pp2/1BNP4/PPP2PPP/3R1RK1 w - - 2 14", "r3r1k1/2p2ppp/p1p1bn2/8/1q2P3/2NPQN2/PPP3PP/R4RK1 b - - 2 15", "r1bbk1nr/pp3p1p/2n5/1N4p1/2Np1B2/8/PPP2PPP/2KR1B1R w kq - 0 13", "r1bq1rk1/ppp1nppp/4n3/3p3Q/3P4/1BP1B3/PP1N2PP/R4RK1 w - - 1 16", "4r1k1/r1q2ppp/ppp2n2/4P3/5Rb1/1N1BQ3/PPP3PP/R5K1 w - - 1 17", "2rqkb1r/ppp2p2/2npb1p1/1N1Nn2p/2P1PP2/8/PP2B1PP/R1BQK2R b KQ - 0 11", "r1bq1r1k/b1p1npp1/p2p3p/1p6/3PP3/1B2NN2/PP3PPP/R2Q1RK1 w - - 1 16", "3r1rk1/p5pp/bpp1pp2/8/q1PP1P2/b3P3/P2NQRPP/1R2B1K1 b - - 6 22", "r1q2rk1/2p1bppp/2Pp4/p6b/Q1PNp3/4B3/PP1R1PPP/2K4R w - - 2 18", "4k2r/1pb2ppp/1p2p3/1R1p4/3P4/2r1PN2/P4PPP/1R4K1 b  - 3 22", "3q2k1/pb3p1p/4pbp1/2r5/PpN2N2/1P2P2P/5PP1/Q2R2K1 b - - 4 26"};


////
//// Functions
////

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Prototypes
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern void generate_kpk_bitbase(unsigned char bitbase[]);
	public static void generate_kpk_bitbase(byte[] bitbase)
	{
	  // Allocate array and initialize:
	  Bitbase = new Result[IndexMax];
	  initialize();

	  // Iterate until all positions are classified:
//C++ TO JAVA CONVERTER TODO TASK: Variables cannot be declared in if/while/switch conditions in Java:
	  while (next_iteration())
	  {
		  ;
	  }

	  // Compress bitbase into the supplied parameter:
	  int i;
	  int j;
	  int b;
	  for (i = 0; i < 24576; i++)
	  {
		for (b = 0, j = 0; j < 8; b |= (compress_result(Bitbase[8 * i + j]) << j), j++)
		{
			;
		}
		bitbase[i] = (byte)b;
	  }

	  // Release allocated memory:
	  Bitbase = null;
	}


	  public static Result[] Bitbase;
	  public static final int IndexMax = 2 * 24 * 64 * 64;
	  public static int UnknownCount = 0;

	  public static void initialize()
	  {
		KPKPosition p = new KPKPosition();
		for (int i = 0; i < IndexMax; i++)
		{
		  p.from_index(i);
		  if (!p.is_legal())
		  {
			Bitbase[i] = Result.RESULT_INVALID;
		  }
		  else if (p.is_immediate_draw())
		  {
			Bitbase[i] = Result.RESULT_DRAW;
		  }
		  else if (p.is_immediate_win())
		  {
			Bitbase[i] = Result.RESULT_WIN;
		  }
		  else
		  {
			Bitbase[i] = Result.RESULT_UNKNOWN;
			UnknownCount++;
		  }
		}
	  }

	  public static boolean next_iteration()
	  {
		KPKPosition p = new KPKPosition();
		int previousUnknownCount = UnknownCount;

		for (int i = 0; i < IndexMax; i++)
		{
		  if (Bitbase[i] == Result.RESULT_UNKNOWN)
		  {
			p.from_index(i);

			Bitbase[i] = (p.sideToMove == Color.WHITE)? classify_wtm(p) : classify_btm(p);

			if (Bitbase[i] == Result.RESULT_WIN || Bitbase[i] == Result.RESULT_LOSS || Bitbase[i] == Result.RESULT_DRAW)
			{
			  UnknownCount--;
			}
		  }
		}

		return UnknownCount != previousUnknownCount;
	  }

	  public static Result classify_wtm(KPKPosition p)
	  {

		// If one move leads to a position classified as RESULT_LOSS, the result
		// of the current position is RESULT_WIN.  If all moves lead to positions
		// classified as RESULT_DRAW, the current position is classified as
		// RESULT_DRAW.  Otherwise, the current position is classified as
		// RESULT_UNKNOWN.

		boolean unknownFound = false;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		Square s;

		// King moves
		b = p.wk_attacks();
		while (b != 0)
		{
	  tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
		  s = pop_1st_bit(tempRef_b);
		  b = tempRef_b.argValue;
		  switch (Bitbase[compute_index(s, p.blackKingSquare, p.pawnSquare, Color.BLACK)])
		  {
		  case RESULT_LOSS:
			return Result.RESULT_WIN;

		  case RESULT_UNKNOWN:
			unknownFound = true;
			break;

		  case RESULT_DRAW:
	  case RESULT_INVALID:
			break;

		  default:
			assert false;
		  }
		}

		// Pawn moves
		if (square_rank(p.pawnSquare) < Rank.RANK_7.getValue())
		{
		  s = p.pawnSquare + SquareDelta.DELTA_N;
		  switch (Bitbase[compute_index(p.whiteKingSquare, p.blackKingSquare, s, Color.BLACK)])
		  {
		  case RESULT_LOSS:
			return Result.RESULT_WIN;

		  case RESULT_UNKNOWN:
			unknownFound = true;
			break;

		  case RESULT_DRAW:
	  case RESULT_INVALID:
			break;

		  default:
			assert false;
		  }

		  if (square_rank(s) == Rank.RANK_3 && s != p.whiteKingSquare && s != p.blackKingSquare)
		  {
			s += SquareDelta.DELTA_N;
			switch (Bitbase[compute_index(p.whiteKingSquare, p.blackKingSquare, s, Color.BLACK)])
			{
			case RESULT_LOSS:
			  return Result.RESULT_WIN;

			case RESULT_UNKNOWN:
			  unknownFound = true;
			  break;

			case RESULT_DRAW:
		case RESULT_INVALID:
			  break;

			default:
			  assert false;
			}
		  }
		}

		return unknownFound? Result.RESULT_UNKNOWN : Result.RESULT_DRAW;
	  }

	  public static Result classify_btm(KPKPosition p)
	  {

		// If one move leads to a position classified as RESULT_DRAW, the result
		// of the current position is RESULT_DRAW.  If all moves lead to positions
		// classified as RESULT_WIN, the current position is classified as
		// RESULT_LOSS.  Otherwise, the current position is classified as
		// RESULT_UNKNOWN.

		boolean unknownFound = false;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		Square s;

		// King moves
		b = p.bk_attacks();
		while (b != 0)
		{
	  tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
		  s = pop_1st_bit(tempRef_b);
		  b = tempRef_b.argValue;
		  switch (Bitbase[compute_index(p.whiteKingSquare, s, p.pawnSquare, Color.WHITE)])
		  {
		  case RESULT_DRAW:
			return Result.RESULT_DRAW;

		  case RESULT_UNKNOWN:
			unknownFound = true;
			break;

		  case RESULT_WIN:
	  case RESULT_INVALID:
			break;

		  default:
			assert false;
		  }
		}

		return unknownFound? Result.RESULT_UNKNOWN : Result.RESULT_LOSS;
	  }

	  public static int compute_index(Square wksq, Square bksq, Square psq, Color stm)
	  {
		int p = square_file(psq).getValue() + (square_rank(psq).getValue() - 1) * 4;
		int result = stm.getValue() + 2 * bksq.getValue() + 128 * wksq.getValue() + 8192 * p;
		assert result >= 0 && result < IndexMax;
		return result;
	  }

	  public static int compress_result(Result r)
	  {
		return (r == Result.RESULT_WIN || r == Result.RESULT_LOSS)? 1 : 0;
	  }
	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




	////
	//// Defines
	////

	///#define USE_COMPACT_ROOK_ATTACKS
	///#define USE_32BIT_ATTACKS 
	///#define USE_FOLDED_BITSCAN

	///#define BITCOUNT_SWAR_64
	///#define BITCOUNT_SWAR_32
	///#define BITCOUNT_LOOP



	////
	//// Includes
	////



	////
	//// Types
	////



	////
	//// Constants and variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long EmptyBoardBB = 0ULL;
	public static final long EmptyBoardBB = 0;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long WhiteSquaresBB = 0x55AA55AA55AA55AAULL;
	public static final long WhiteSquaresBB = 0x55AA55AA55AA55AA;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long BlackSquaresBB = 0xAA55AA55AA55AA55ULL;
	public static final long BlackSquaresBB = 0xAA55AA55AA55AA55;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long SquaresByColorBB[2];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong SquaresByColorBB[2];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileABB = 0x0101010101010101ULL;
	public static final long FileABB = 0x0101010101010101;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileBBB = 0x0202020202020202ULL;
	public static final long FileBBB = 0x0202020202020202;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileCBB = 0x0404040404040404ULL;
	public static final long FileCBB = 0x0404040404040404;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileDBB = 0x0808080808080808ULL;
	public static final long FileDBB = 0x0808080808080808;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileEBB = 0x1010101010101010ULL;
	public static final long FileEBB = 0x1010101010101010;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileFBB = 0x2020202020202020ULL;
	public static final long FileFBB = 0x2020202020202020;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileGBB = 0x4040404040404040ULL;
	public static final long FileGBB = 0x4040404040404040;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileHBB = 0x8080808080808080ULL;
	public static final long FileHBB = 0x8080808080808080;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long FileBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong FileBB[8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long NeighboringFilesBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong NeighboringFilesBB[8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long ThisAndNeighboringFilesBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong ThisAndNeighboringFilesBB[8];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank1BB = 0xFFULL;
	public static final long Rank1BB = 0xFF;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank2BB = 0xFF00ULL;
	public static final long Rank2BB = 0xFF00;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank3BB = 0xFF0000ULL;
	public static final long Rank3BB = 0xFF0000;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank4BB = 0xFF000000ULL;
	public static final long Rank4BB = 0xFF000000;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank5BB = 0xFF00000000ULL;
	public static final long Rank5BB = 0xFF00000000;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank6BB = 0xFF0000000000ULL;
	public static final long Rank6BB = 0xFF0000000000;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank7BB = 0xFF000000000000ULL;
	public static final long Rank7BB = 0xFF000000000000;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank8BB = 0xFF00000000000000ULL;
	public static final long Rank8BB = 0xFF00000000000000;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long RankBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong RankBB[8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long RelativeRankBB[2][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong RelativeRankBB[2][8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long InFrontBB[2][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong InFrontBB[2][8];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long SetMaskBB[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong SetMaskBB[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long ClearMaskBB[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong ClearMaskBB[64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long StepAttackBB[16][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong StepAttackBB[16][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RayBB[64][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RayBB[64][8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BetweenBB[64][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BetweenBB[64][64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long PassedPawnMask[2][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong PassedPawnMask[2][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long OutpostMask[2][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong OutpostMask[2][64];

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RankAttacks[8][64], FileAttacks[8][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RankAttacks[8][64], FileAttacks[8][64];
	///#else
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long RMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong RMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const int RShift[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern int RAttackIndex[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RAttacks[0x19000];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RAttacks[0x19000];
	///#endif // defined(USE_COMPACT_ROOK_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long BMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong BMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const int BShift[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern int BAttackIndex[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BAttacks[0x1480];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BAttacks[0x1480];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BishopPseudoAttacks[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BishopPseudoAttacks[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RookPseudoAttacks[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RookPseudoAttacks[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long QueenPseudoAttacks[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong QueenPseudoAttacks[64];


	////
	//// Inline functions
	////

	/// Functions for testing whether a given bit is set in a bitboard, and for 
	/// setting and clearing bits.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long set_mask_bb(Square s)
	public static long set_mask_bb(Square s)
	{
	  //  return 1ULL << s;
	  return SetMaskBB[s.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long clear_mask_bb(Square s)
	public static long clear_mask_bb(Square s)
	{
	  //  return ~set_mask_bb(s);
	  return ClearMaskBB[s.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long bit_is_set(unsigned long long b, Square s)
	public static long bit_is_set(long b, Square s)
	{
	  return b & set_mask_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline void set_bit(unsigned long long *b, Square s)
	public static void set_bit(tangible.RefObject<Long> b, Square s)
	{
	  b.argValue |= set_mask_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline void clear_bit(unsigned long long *b, Square s)
	public static void clear_bit(tangible.RefObject<Long> b, Square s)
	{
	  b.argValue &= clear_mask_bb(s);
	}


	/// rank_bb() and file_bb() gives a bitboard containing all squares on a given
	/// file or rank.  It is also possible to pass a square as input to these
	/// functions.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rank_bb(Rank r)
	public static long rank_bb(Rank r)
	{
	  return RankBB[r.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rank_bb(Square s)
	public static long rank_bb(Square s)
	{
	  return rank_bb(square_rank(s));
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long file_bb(File f)
	public static long file_bb(File f)
	{
	  return FileBB[f.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long file_bb(Square s)
	public static long file_bb(Square s)
	{
	  return file_bb(square_file(s));
	}


	/// neighboring_files_bb takes a file or a square as input, and returns a
	/// bitboard representing all squares on the neighboring files.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long neighboring_files_bb(File f)
	public static long neighboring_files_bb(File f)
	{
	  return NeighboringFilesBB[f.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long neighboring_files_bb(Square s)
	public static long neighboring_files_bb(Square s)
	{
	  return neighboring_files_bb(square_file(s));
	}


	/// this_and_neighboring_files_bb takes a file or a square as input, and
	/// returns a bitboard representing all squares on the given and neighboring
	/// files.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long this_and_neighboring_files_bb(File f)
	public static long this_and_neighboring_files_bb(File f)
	{
	  return ThisAndNeighboringFilesBB[f.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long this_and_neighboring_files_bb(Square s)
	public static long this_and_neighboring_files_bb(Square s)
	{
	  return this_and_neighboring_files_bb(square_file(s));
	}


	/// relative_rank_bb() takes a color and a rank as input, and returns a bitboard
	/// representing all squares on the given rank from the given color's point of
	/// view.  For instance, relative_rank_bb(WHITE, 7) gives all squares on the
	/// 7th rank, while relative_rank_bb(BLACK, 7) gives all squares on the 2nd
	/// rank.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long relative_rank_bb(Color c, Rank r)
	public static long relative_rank_bb(Color c, Rank r)
	{
	  return RelativeRankBB[c.getValue()][r.getValue()];
	}


	/// in_front_bb() takes a color and a rank or square as input, and returns a
	/// bitboard representing all the squares on all ranks in front of the rank
	/// (or square), from the given color's point of view.  For instance,
	/// in_front_bb(WHITE, RANK_5) will give all squares on ranks 6, 7 and 8, while
	/// in_front_bb(BLACK, SQ_D3) will give all squares on ranks 1 and 2.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long in_front_bb(Color c, Rank r)
	public static long in_front_bb(Color c, Rank r)
	{
	  return InFrontBB[c.getValue()][r.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long in_front_bb(Color c, Square s)
	public static long in_front_bb(Color c, Square s)
	{
	  return in_front_bb(c, square_rank(s));
	}


	/// ray_bb() gives a bitboard representing all squares along the ray in a
	/// given direction from a given square.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long ray_bb(Square s, SignedDirection d)
	public static long ray_bb(Square s, SignedDirection d)
	{
	  return RayBB[s.getValue()][d.getValue()];
	}


	/// Functions for computing sliding attack bitboards.  rook_attacks_bb(),
	/// bishop_attacks_bb() and queen_attacks_bb() all take a square and a
	/// bitboard of occupied squares as input, and return a bitboard representing
	/// all squares attacked by a rook, bishop or queen on the given square.

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long file_attacks_bb(Square s, unsigned long long blockers)
	public static long file_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = (blockers >> square_file(s)) & 0x01010101010100ULL;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  long b = (long)((blockers >>> square_file(s)) & 0x01010101010100);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return FileAttacks[square_rank(s).getValue()][(b * 0xd6e8802041d0c441) >> 58] & file_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rank_attacks_bb(Square s, unsigned long long blockers)
	public static long rank_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = (blockers >> ((s & 56) + 1)) & 63;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  long b = (long)((blockers >>> ((s & 56) + 1)) & 63);
	  return RankAttacks[square_file(s).getValue()][b] & rank_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rook_attacks_bb(Square s, unsigned long long blockers)
	public static long rook_attacks_bb(Square s, long blockers)
	{
	  return file_attacks_bb(s, blockers) | rank_attacks_bb(s, blockers);
	}

	///#elif USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rook_attacks_bb(Square s, unsigned long long blockers)
	public static long rook_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & RMask[s];
	  long b = blockers & RMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return RAttacks[RAttackIndex[s.getValue()] + (int((int)b * (int)RMult[s.getValue()] ^ (int)(b >>> 32) * (int)(RMult[s.getValue()] >>> 32)) >>> RShift[s.getValue()])];
	}

	///#else

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rook_attacks_bb(Square s, unsigned long long blockers)
	public static long rook_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & RMask[s];
	  long b = blockers & RMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return RAttacks[RAttackIndex[s.getValue()] + ((b * RMult[s.getValue()]) >>> RShift[s.getValue()])];
	}

	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long bishop_attacks_bb(Square s, unsigned long long blockers)
	public static long bishop_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & BMask[s];
	  long b = blockers & BMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return BAttacks[BAttackIndex[s.getValue()] + (int((int)b * (int)BMult[s.getValue()] ^ (int)(b >>> 32) * (int)(BMult[s.getValue()] >>> 32)) >>> BShift[s.getValue()])];
	}

	///#else // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long bishop_attacks_bb(Square s, unsigned long long blockers)
	public static long bishop_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & BMask[s];
	  long b = blockers & BMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return BAttacks[BAttackIndex[s.getValue()] + ((b * BMult[s.getValue()]) >>> BShift[s.getValue()])];
	}

	///#endif // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long queen_attacks_bb(Square s, unsigned long long blockers)
	public static long queen_attacks_bb(Square s, long blockers)
	{
	  return rook_attacks_bb(s, blockers) | bishop_attacks_bb(s, blockers);
	}


	/// squares_between returns a bitboard representing all squares between
	/// two squares.  For instance, squares_between(SQ_C4, SQ_F7) returns a
	/// bitboard with the bits for square d5 and e6 set.  If s1 and s2 are not
	/// on the same line, file or diagonal, EmptyBoardBB is returned.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long squares_between(Square s1, Square s2)
	public static long squares_between(Square s1, Square s2)
	{
	  return BetweenBB[s1.getValue()][s2.getValue()];
	}


	/// squares_in_front_of takes a color and a square as input, and returns a 
	/// bitboard representing all squares along the line in front of the square,
	/// from the point of view of the given color.  For instance, 
	/// squares_in_front_of(BLACK, SQ_E4) returns a bitboard with the squares
	/// e3, e2 and e1 set.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long squares_in_front_of(Color c, Square s)
	public static long squares_in_front_of(Color c, Square s)
	{
	  return in_front_bb(c, s) & file_bb(s);
	}


	/// squares_behind is similar to squares_in_front, but returns the squares
	/// behind the square instead of in front of the square.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long squares_behind(Color c, Square s)
	public static long squares_behind(Color c, Square s)
	{
	  return in_front_bb(opposite_color(c), s) & file_bb(s);
	}


	/// passed_pawn_mask takes a color and a square as input, and returns a 
	/// bitboard mask which can be used to test if a pawn of the given color on 
	/// the given square is a passed pawn.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long passed_pawn_mask(Color c, Square s)
	public static long passed_pawn_mask(Color c, Square s)
	{
	  return PassedPawnMask[c.getValue()][s.getValue()];
	}


	/// outpost_mask takes a color and a square as input, and returns a bitboard
	/// mask which can be used to test whether a piece on the square can possibly
	/// be driven away by an enemy pawn.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long outpost_mask(Color c, Square s)
	public static long outpost_mask(Color c, Square s)
	{
	  return OutpostMask[c.getValue()][s.getValue()];
	}


	/// isolated_pawn_mask takes a square as input, and returns a bitboard mask 
	/// which can be used to test whether a pawn on the given square is isolated.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long isolated_pawn_mask(Square s)
	public static long isolated_pawn_mask(Square s)
	{
	  return neighboring_files_bb(s);
	}


	/// count_1s() counts the number of nonzero bits in a bitboard.

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if BITCOUNT_LOOP

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s(unsigned long long b)
	public static int count_1s(long b)
	{
	  int r;
	  for (r = 0; b; r++, b &= b - 1)
	  {
		  ;
	  }
	  return r;
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s_max_15(unsigned long long b)
	public static int count_1s_max_15(long b)
	{
	  return count_1s(b);
	}

	///#elif BITCOUNT_SWAR_32

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s(unsigned long long b)
	public static int count_1s(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  int w = b >>> 32;
	  int v = (int)b;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  v = v - ((v >>> 1) & 0x55555555);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  w = w - ((w >>> 1) & 0x55555555);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  v = (v & 0x33333333) + ((v >>> 2) & 0x33333333);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  w = (w & 0x33333333) + ((w >>> 2) & 0x33333333);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  v = (v + (v >>> 4)) & 0x0F0F0F0F;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  w = (w + (w >>> 4)) & 0x0F0F0F0F;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  v = ((v + w) * 0x01010101) >>> 24; // mul is fast on amd procs
	  return (int)v;
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s_max_15(unsigned long long b)
	public static int count_1s_max_15(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  int w = b >>> 32;
	  int v = (int)b;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  v = v - ((v >>> 1) & 0x55555555);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  w = w - ((w >>> 1) & 0x55555555);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  v = (v & 0x33333333) + ((v >>> 2) & 0x33333333);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  w = (w & 0x33333333) + ((w >>> 2) & 0x33333333);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  v = ((v + w) * 0x11111111) >>> 28;
	  return (int)v;
	}

	///#elif BITCOUNT_SWAR_64

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s(unsigned long long b)
	public static int count_1s(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b -= ((b>>>1) & 0x5555555555555555);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b = (long)(((b>>>2) & 0x3333333333333333) + (b & 0x3333333333333333));
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b = (long)(((b>>>4) + b) & 0x0F0F0F0F0F0F0F0F);
	  b *= 0x0101010101010101;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return (int)(b >>> 56);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s_max_15(unsigned long long b)
	public static int count_1s_max_15(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b -= (b>>>1) & 0x5555555555555555;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b = (long)(((b>>>2) & 0x3333333333333333) + (b & 0x3333333333333333));
	  b *= 0x1111111111111111;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return (int)(b >>> 60);
	}

	///#endif // BITCOUNT

////
//// Functions
////

/// print_bitboard() prints a bitboard in an easily readable format to the
/// standard output.  This is sometimes useful for debugging.



	////
	//// Prototypes
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern void print_bitboard(unsigned long long b);
	public static void print_bitboard(long b)
	{
	  for (Rank r = Rank.RANK_8; r.getValue() >= Rank.RANK_1.getValue(); r--)
	  {
		System.out.print("+---+---+---+---+---+---+---+---+");
		System.out.print("\n");
		for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); f++)
		{
		  System.out.print("| ");
		  System.out.print((bit_is_set(b, make_square(f, r)) != 0? 'X' : ' '));
		  System.out.print(' ');
		}
		System.out.print("|");
		System.out.print("\n");
	  }
	  System.out.print("+---+---+---+---+---+---+---+---+");
	  System.out.print("\n");
	}

/// init_bitboards() initializes various bitboard arrays.  It is called during
/// program initialization.


	public static void init_bitboards()
	{
	  int[][] rookDeltas =
	  {
		  {0, 1},
		  {0, -1},
		  {1, 0},
		  {-1, 0}
	  };
	  int[][] bishopDeltas =
	  {
		  {1, 1},
		  {-1, 1},
		  {1, -1},
		  {-1, -1}
	  };
	  init_masks();
	  init_ray_bitboards();
	  init_attacks();
	  init_between_bitboards();
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	  init_file_and_rank_attacks();
	///#else
	  init_sliding_attacks(RAttacks, RAttackIndex, RMask, RShift, RMult, rookDeltas);
	///#endif
	  init_sliding_attacks(BAttacks, BAttackIndex, BMask, BShift, BMult, bishopDeltas);
	  init_pseudo_attacks();
	}

/// first_1() finds the least significant nonzero bit in a nonzero bitboard.


	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern Square first_1(unsigned long long b);
	public static Square first_1(long b)
	{
	  b ^= (b - 1);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long fold = int(b) ^ int(b >> 32);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  int fold = (int)b ^ (int)(b >>> 32);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return Square(BitTable[(fold * 0x783a9b23) >>> 26]);
	}

/// pop_1st_bit() finds and clears the least significant nonzero bit in a
/// nonzero bitboard.


	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern Square pop_1st_bit(unsigned long long *b);
	public static Square pop_1st_bit(tangible.RefObject<Long> b)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = *b ^ (*b - 1);
	  long bb = b.argValue ^ (b.argValue - 1);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long fold = int(bb) ^ int(bb >> 32);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  int fold = (int)bb ^ (int)(bb >>> 32);
	  b.argValue &= (b.argValue - 1);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return Square(BitTable[(fold * 0x783a9b23) >>> 26]);
	}





	////
	//// Constants and variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long SquaresByColorBB[2] = {BlackSquaresBB, WhiteSquaresBB};
	public static final long[] SquaresByColorBB = {BlackSquaresBB, WhiteSquaresBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileBB[8] = { FileABB, FileBBB, FileCBB, FileDBB, FileEBB, FileFBB, FileGBB, FileHBB };
	public static final long[] FileBB = {FileABB, FileBBB, FileCBB, FileDBB, FileEBB, FileFBB, FileGBB, FileHBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long NeighboringFilesBB[8] = { FileBBB, FileABB|FileCBB, FileBBB|FileDBB, FileCBB|FileEBB, FileDBB|FileFBB, FileEBB|FileGBB, FileFBB|FileHBB, FileGBB };
	public static final long[] NeighboringFilesBB = {FileBBB, FileABB | FileCBB, FileBBB | FileDBB, FileCBB | FileEBB, FileDBB | FileFBB, FileEBB | FileGBB, FileFBB | FileHBB, FileGBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long ThisAndNeighboringFilesBB[8] = { FileABB|FileBBB, FileABB|FileBBB|FileCBB, FileBBB|FileCBB|FileDBB, FileCBB|FileDBB|FileEBB, FileDBB|FileEBB|FileFBB, FileEBB|FileFBB|FileGBB, FileFBB|FileGBB|FileHBB, FileGBB|FileHBB };
	public static final long[] ThisAndNeighboringFilesBB = {FileABB | FileBBB, FileABB | FileBBB | FileCBB, FileBBB | FileCBB | FileDBB, FileCBB | FileDBB | FileEBB, FileDBB | FileEBB | FileFBB, FileEBB | FileFBB | FileGBB, FileFBB | FileGBB | FileHBB, FileGBB | FileHBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RankBB[8] = { Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB };
	public static final long[] RankBB = {Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RelativeRankBB[2][8] = { { Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB }, { Rank8BB, Rank7BB, Rank6BB, Rank5BB, Rank4BB, Rank3BB, Rank2BB, Rank1BB } };
	public static final long[][] RelativeRankBB =
	{
		{Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB},
		{Rank8BB, Rank7BB, Rank6BB, Rank5BB, Rank4BB, Rank3BB, Rank2BB, Rank1BB}
	};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long InFrontBB[2][8] = { { Rank2BB | Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank6BB | Rank7BB | Rank8BB, Rank7BB | Rank8BB, Rank8BB, EmptyBoardBB }, { EmptyBoardBB, Rank1BB, Rank2BB | Rank1BB, Rank3BB | Rank2BB | Rank1BB, Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank7BB | Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB } };
	public static final long[][] InFrontBB =
	{
		{Rank2BB | Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank6BB | Rank7BB | Rank8BB, Rank7BB | Rank8BB, Rank8BB, EmptyBoardBB},
		{EmptyBoardBB, Rank1BB, Rank2BB | Rank1BB, Rank3BB | Rank2BB | Rank1BB, Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank7BB | Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB}
	};

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RankAttacks[8][64], FileAttacks[8][64];
	public static long[][] RankAttacks = new long[8][64];
	public static long[][] FileAttacks = new long[8][64];

	///#elif USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RMult[64] = { 0xd7445cdec88002c0ULL, 0xd0a505c1f2001722ULL, 0xe065d1c896002182ULL, 0x9a8c41e75a000892ULL, 0x8900b10c89002aa8ULL, 0x9b28d1c1d60005a2ULL, 0x15d6c88de002d9aULL, 0xb1dbfc802e8016a9ULL, 0x149a1042d9d60029ULL, 0xb9c08050599e002fULL, 0x132208c3af300403ULL, 0xc1000ce2e9c50070ULL, 0x9d9aa13c99020012ULL, 0xb6b078daf71e0046ULL, 0x9d880182fb6e002eULL, 0x52889f467e850037ULL, 0xda6dc008d19a8480ULL, 0x468286034f902420ULL, 0x7140ac09dc54c020ULL, 0xd76ffffa39548808ULL, 0xea901c4141500808ULL, 0xc91004093f953a02ULL, 0x2882afa8f6bb402ULL, 0xaebe335692442c01ULL, 0xe904a22079fb91eULL, 0x13a514851055f606ULL, 0x76c782018c8fe632ULL, 0x1dc012a9d116da06ULL, 0x3c9e0037264fffa6ULL, 0x2036002853c6e4a2ULL, 0xe3fe08500afb47d4ULL, 0xf38af25c86b025c2ULL, 0xc0800e2182cf9a40ULL, 0x72002480d1f60673ULL, 0x2500200bae6e9b53ULL, 0xc60018c1eefca252ULL, 0x600590473e3608aULL, 0x46002c4ab3fe51b2ULL, 0xa200011486bcc8d2ULL, 0xb680078095784c63ULL, 0x2742002639bf11aeULL, 0xc7d60021a5bdb142ULL, 0xc8c04016bb83d820ULL, 0xbd520028123b4842ULL, 0x9d1600344ac2a832ULL, 0x6a808005631c8a05ULL, 0x604600a148d5389aULL, 0xe2e40103d40dea65ULL, 0x945b5a0087c62a81ULL, 0x12dc200cd82d28eULL, 0x2431c600b5f9ef76ULL, 0xfb142a006a9b314aULL, 0x6870e00a1c97d62ULL, 0x2a9db2004a2689a2ULL, 0xd3594600caf5d1a2ULL, 0xee0e4900439344a7ULL, 0x89c4d266ca25007aULL, 0x3e0013a2743f97e3ULL, 0x180e31a0431378aULL, 0x3a9e465a4d42a512ULL, 0x98d0a11a0c0d9cc2ULL, 0x8e711c1aba19b01eULL, 0x8dcdc836dd201142ULL, 0x5ac08a4735370479ULL, };
	public static final long[] RMult = {0xd7445cdec88002c0, 0xd0a505c1f2001722, 0xe065d1c896002182, 0x9a8c41e75a000892, 0x8900b10c89002aa8, 0x9b28d1c1d60005a2, 0x15d6c88de002d9a, 0xb1dbfc802e8016a9, 0x149a1042d9d60029, 0xb9c08050599e002f, 0x132208c3af300403, 0xc1000ce2e9c50070, 0x9d9aa13c99020012, 0xb6b078daf71e0046, 0x9d880182fb6e002e, 0x52889f467e850037, 0xda6dc008d19a8480, 0x468286034f902420, 0x7140ac09dc54c020, 0xd76ffffa39548808, 0xea901c4141500808, 0xc91004093f953a02, 0x2882afa8f6bb402, 0xaebe335692442c01, 0xe904a22079fb91e, 0x13a514851055f606, 0x76c782018c8fe632, 0x1dc012a9d116da06, 0x3c9e0037264fffa6, 0x2036002853c6e4a2, 0xe3fe08500afb47d4, 0xf38af25c86b025c2, 0xc0800e2182cf9a40, 0x72002480d1f60673, 0x2500200bae6e9b53, 0xc60018c1eefca252, 0x600590473e3608a, 0x46002c4ab3fe51b2, 0xa200011486bcc8d2, 0xb680078095784c63, 0x2742002639bf11ae, 0xc7d60021a5bdb142, 0xc8c04016bb83d820, 0xbd520028123b4842, 0x9d1600344ac2a832, 0x6a808005631c8a05, 0x604600a148d5389a, 0xe2e40103d40dea65, 0x945b5a0087c62a81, 0x12dc200cd82d28e, 0x2431c600b5f9ef76, 0xfb142a006a9b314a, 0x6870e00a1c97d62, 0x2a9db2004a2689a2, 0xd3594600caf5d1a2, 0xee0e4900439344a7, 0x89c4d266ca25007a, 0x3e0013a2743f97e3, 0x180e31a0431378a, 0x3a9e465a4d42a512, 0x98d0a11a0c0d9cc2, 0x8e711c1aba19b01e, 0x8dcdc836dd201142, 0x5ac08a4735370479};

	public static final int[] RShift = {20, 21, 21, 21, 21, 21, 21, 20, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 20, 21, 21, 21, 21, 21, 21, 20};

	///#else // if defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RMult[64] = { 0xa8002c000108020ULL, 0x4440200140003000ULL, 0x8080200010011880ULL, 0x380180080141000ULL, 0x1a00060008211044ULL, 0x410001000a0c0008ULL, 0x9500060004008100ULL, 0x100024284a20700ULL, 0x802140008000ULL, 0x80c01002a00840ULL, 0x402004282011020ULL, 0x9862000820420050ULL, 0x1001448011100ULL, 0x6432800200800400ULL, 0x40100010002000cULL, 0x2800d0010c080ULL, 0x90c0008000803042ULL, 0x4010004000200041ULL, 0x3010010200040ULL, 0xa40828028001000ULL, 0x123010008000430ULL, 0x24008004020080ULL, 0x60040001104802ULL, 0x582200028400d1ULL, 0x4000802080044000ULL, 0x408208200420308ULL, 0x610038080102000ULL, 0x3601000900100020ULL, 0x80080040180ULL, 0xc2020080040080ULL, 0x80084400100102ULL, 0x4022408200014401ULL, 0x40052040800082ULL, 0xb08200280804000ULL, 0x8a80a008801000ULL, 0x4000480080801000ULL, 0x911808800801401ULL, 0x822a003002001894ULL, 0x401068091400108aULL, 0x4a10a00004cULL, 0x2000800640008024ULL, 0x1486408102020020ULL, 0x100a000d50041ULL, 0x810050020b0020ULL, 0x204000800808004ULL, 0x20048100a000cULL, 0x112000831020004ULL, 0x9000040810002ULL, 0x440490200208200ULL, 0x8910401000200040ULL, 0x6404200050008480ULL, 0x4b824a2010010100ULL, 0x4080801810c0080ULL, 0x400802a0080ULL, 0x8224080110026400ULL, 0x40002c4104088200ULL, 0x1002100104a0282ULL, 0x1208400811048021ULL, 0x3201014a40d02001ULL, 0x5100019200501ULL, 0x101000208001005ULL, 0x2008450080702ULL, 0x1002080301d00cULL, 0x410201ce5c030092ULL };
	public static final long[] RMult = {0xa8002c000108020, 0x4440200140003000, 0x8080200010011880, 0x380180080141000, 0x1a00060008211044, 0x410001000a0c0008, 0x9500060004008100, 0x100024284a20700, 0x802140008000, 0x80c01002a00840, 0x402004282011020, 0x9862000820420050, 0x1001448011100, 0x6432800200800400, 0x40100010002000c, 0x2800d0010c080, 0x90c0008000803042, 0x4010004000200041, 0x3010010200040, 0xa40828028001000, 0x123010008000430, 0x24008004020080, 0x60040001104802, 0x582200028400d1, 0x4000802080044000, 0x408208200420308, 0x610038080102000, 0x3601000900100020, 0x80080040180, 0xc2020080040080, 0x80084400100102, 0x4022408200014401, 0x40052040800082, 0xb08200280804000, 0x8a80a008801000, 0x4000480080801000, 0x911808800801401, 0x822a003002001894, 0x401068091400108a, 0x4a10a00004c, 0x2000800640008024, 0x1486408102020020, 0x100a000d50041, 0x810050020b0020, 0x204000800808004, 0x20048100a000c, 0x112000831020004, 0x9000040810002, 0x440490200208200, 0x8910401000200040, 0x6404200050008480, 0x4b824a2010010100, 0x4080801810c0080, 0x400802a0080, 0x8224080110026400, 0x40002c4104088200, 0x1002100104a0282, 0x1208400811048021, 0x3201014a40d02001, 0x5100019200501, 0x101000208001005, 0x2008450080702, 0x1002080301d00c, 0x410201ce5c030092};

	public static final int[] RShift = {52, 53, 53, 53, 53, 53, 53, 52, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 52, 53, 53, 53, 53, 53, 53, 52};

	///#endif // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !USE_COMPACT_ROOK_ATTACKS
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RMask[64];
	public static long[] RMask = new long[64];
	public static int[] RAttackIndex = new int[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RAttacks[0x19000];
	public static long[] RAttacks = new long[0x19000];
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long BMult[64] = { 0x54142844c6a22981ULL, 0x710358a6ea25c19eULL, 0x704f746d63a4a8dcULL, 0xbfed1a0b80f838c5ULL, 0x90561d5631e62110ULL, 0x2804260376e60944ULL, 0x84a656409aa76871ULL, 0xf0267f64c28b6197ULL, 0x70764ebb762f0585ULL, 0x92aa09e0cfe161deULL, 0x41ee1f6bb266f60eULL, 0xddcbf04f6039c444ULL, 0x5a3fab7bac0d988aULL, 0xd3727877fa4eaa03ULL, 0xd988402d868ddaaeULL, 0x812b291afa075c7cULL, 0x94faf987b685a932ULL, 0x3ed867d8470d08dbULL, 0x92517660b8901de8ULL, 0x2d97e43e058814b4ULL, 0x880a10c220b25582ULL, 0xc7c6520d1f1a0477ULL, 0xdbfc7fbcd7656aa6ULL, 0x78b1b9bfb1a2b84fULL, 0x2f20037f112a0bc1ULL, 0x657171ea2269a916ULL, 0xc08302b07142210eULL, 0x880a4403064080bULL, 0x3602420842208c00ULL, 0x852800dc7e0b6602ULL, 0x595a3fbbaa0f03b2ULL, 0x9f01411558159d5eULL, 0x2b4a4a5f88b394f2ULL, 0x4afcbffc292dd03aULL, 0x4a4094a3b3f10522ULL, 0xb06f00b491f30048ULL, 0xd5b3820280d77004ULL, 0x8b2e01e7c8e57a75ULL, 0x2d342794e886c2e6ULL, 0xc302c410cde21461ULL, 0x111f426f1379c274ULL, 0xe0569220abb31588ULL, 0x5026d3064d453324ULL, 0xe2076040c343cd8aULL, 0x93efd1e1738021eeULL, 0xb680804bed143132ULL, 0x44e361b21986944cULL, 0x44c60170ef5c598cULL, 0xf4da475c195c9c94ULL, 0xa3afbb5f72060b1dULL, 0xbc75f410e41c4ffcULL, 0xb51c099390520922ULL, 0x902c011f8f8ec368ULL, 0x950b56b3d6f5490aULL, 0x3909e0635bf202d0ULL, 0x5744f90206ec10ccULL, 0xdc59fd76317abbc1ULL, 0x881c7c67fcbfc4f6ULL, 0x47ca41e7e440d423ULL, 0xeb0c88112048d004ULL, 0x51c60e04359aef1aULL, 0x1aa1fe0e957a5554ULL, 0xdd9448db4f5e3104ULL, 0xdc01f6dca4bebbdcULL, };
	public static final long[] BMult = {0x54142844c6a22981, 0x710358a6ea25c19e, 0x704f746d63a4a8dc, 0xbfed1a0b80f838c5, 0x90561d5631e62110, 0x2804260376e60944, 0x84a656409aa76871, 0xf0267f64c28b6197, 0x70764ebb762f0585, 0x92aa09e0cfe161de, 0x41ee1f6bb266f60e, 0xddcbf04f6039c444, 0x5a3fab7bac0d988a, 0xd3727877fa4eaa03, 0xd988402d868ddaae, 0x812b291afa075c7c, 0x94faf987b685a932, 0x3ed867d8470d08db, 0x92517660b8901de8, 0x2d97e43e058814b4, 0x880a10c220b25582, 0xc7c6520d1f1a0477, 0xdbfc7fbcd7656aa6, 0x78b1b9bfb1a2b84f, 0x2f20037f112a0bc1, 0x657171ea2269a916, 0xc08302b07142210e, 0x880a4403064080b, 0x3602420842208c00, 0x852800dc7e0b6602, 0x595a3fbbaa0f03b2, 0x9f01411558159d5e, 0x2b4a4a5f88b394f2, 0x4afcbffc292dd03a, 0x4a4094a3b3f10522, 0xb06f00b491f30048, 0xd5b3820280d77004, 0x8b2e01e7c8e57a75, 0x2d342794e886c2e6, 0xc302c410cde21461, 0x111f426f1379c274, 0xe0569220abb31588, 0x5026d3064d453324, 0xe2076040c343cd8a, 0x93efd1e1738021ee, 0xb680804bed143132, 0x44e361b21986944c, 0x44c60170ef5c598c, 0xf4da475c195c9c94, 0xa3afbb5f72060b1d, 0xbc75f410e41c4ffc, 0xb51c099390520922, 0x902c011f8f8ec368, 0x950b56b3d6f5490a, 0x3909e0635bf202d0, 0x5744f90206ec10cc, 0xdc59fd76317abbc1, 0x881c7c67fcbfc4f6, 0x47ca41e7e440d423, 0xeb0c88112048d004, 0x51c60e04359aef1a, 0x1aa1fe0e957a5554, 0xdd9448db4f5e3104, 0xdc01f6dca4bebbdc};

	public static final int[] BShift = {26, 27, 27, 27, 27, 27, 27, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 25, 25, 25, 25, 27, 27, 27, 27, 25, 23, 23, 25, 27, 27, 27, 27, 25, 23, 23, 25, 27, 27, 27, 27, 25, 25, 25, 25, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 26, 27, 27, 27, 27, 27, 27, 26};

	///#else // if defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long BMult[64] = { 0x440049104032280ULL, 0x1021023c82008040ULL, 0x404040082000048ULL, 0x48c4440084048090ULL, 0x2801104026490000ULL, 0x4100880442040800ULL, 0x181011002e06040ULL, 0x9101004104200e00ULL, 0x1240848848310401ULL, 0x2000142828050024ULL, 0x1004024d5000ULL, 0x102044400800200ULL, 0x8108108820112000ULL, 0xa880818210c00046ULL, 0x4008008801082000ULL, 0x60882404049400ULL, 0x104402004240810ULL, 0xa002084250200ULL, 0x100b0880801100ULL, 0x4080201220101ULL, 0x44008080a00000ULL, 0x202200842000ULL, 0x5006004882d00808ULL, 0x200045080802ULL, 0x86100020200601ULL, 0xa802080a20112c02ULL, 0x80411218080900ULL, 0x200a0880080a0ULL, 0x9a01010000104000ULL, 0x28008003100080ULL, 0x211021004480417ULL, 0x401004188220806ULL, 0x825051400c2006ULL, 0x140c0210943000ULL, 0x242800300080ULL, 0xc2208120080200ULL, 0x2430008200002200ULL, 0x1010100112008040ULL, 0x8141050100020842ULL, 0x822081014405ULL, 0x800c049e40400804ULL, 0x4a0404028a000820ULL, 0x22060201041200ULL, 0x360904200840801ULL, 0x881a08208800400ULL, 0x60202c00400420ULL, 0x1204440086061400ULL, 0x8184042804040ULL, 0x64040315300400ULL, 0xc01008801090a00ULL, 0x808010401140c00ULL, 0x4004830c2020040ULL, 0x80005002020054ULL, 0x40000c14481a0490ULL, 0x10500101042048ULL, 0x1010100200424000ULL, 0x640901901040ULL, 0xa0201014840ULL, 0x840082aa011002ULL, 0x10010840084240aULL, 0x420400810420608ULL, 0x8d40230408102100ULL, 0x4a00200612222409ULL, 0xa08520292120600ULL };
	public static final long[] BMult = {0x440049104032280, 0x1021023c82008040, 0x404040082000048, 0x48c4440084048090, 0x2801104026490000, 0x4100880442040800, 0x181011002e06040, 0x9101004104200e00, 0x1240848848310401, 0x2000142828050024, 0x1004024d5000, 0x102044400800200, 0x8108108820112000, 0xa880818210c00046, 0x4008008801082000, 0x60882404049400, 0x104402004240810, 0xa002084250200, 0x100b0880801100, 0x4080201220101, 0x44008080a00000, 0x202200842000, 0x5006004882d00808, 0x200045080802, 0x86100020200601, 0xa802080a20112c02, 0x80411218080900, 0x200a0880080a0, 0x9a01010000104000, 0x28008003100080, 0x211021004480417, 0x401004188220806, 0x825051400c2006, 0x140c0210943000, 0x242800300080, 0xc2208120080200, 0x2430008200002200, 0x1010100112008040, 0x8141050100020842, 0x822081014405, 0x800c049e40400804, 0x4a0404028a000820, 0x22060201041200, 0x360904200840801, 0x881a08208800400, 0x60202c00400420, 0x1204440086061400, 0x8184042804040, 0x64040315300400, 0xc01008801090a00, 0x808010401140c00, 0x4004830c2020040, 0x80005002020054, 0x40000c14481a0490, 0x10500101042048, 0x1010100200424000, 0x640901901040, 0xa0201014840, 0x840082aa011002, 0x10010840084240a, 0x420400810420608, 0x8d40230408102100, 0x4a00200612222409, 0xa08520292120600};

	public static final int[] BShift = {58, 59, 59, 59, 59, 59, 59, 58, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 57, 57, 57, 57, 59, 59, 59, 59, 57, 55, 55, 57, 59, 59, 59, 59, 57, 55, 55, 57, 59, 59, 59, 59, 57, 57, 57, 57, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 58, 59, 59, 59, 59, 59, 59, 58};

	///#endif // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BMask[64];
	public static long[] BMask = new long[64];
	public static int[] BAttackIndex = new int[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BAttacks[0x1480];
	public static long[] BAttacks = new long[0x1480];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long SetMaskBB[64];
	public static long[] SetMaskBB = new long[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long ClearMaskBB[64];
	public static long[] ClearMaskBB = new long[64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long StepAttackBB[16][64];
	public static long[][] StepAttackBB = new long[16][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RayBB[64][8];
	public static long[][] RayBB = new long[64][8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BetweenBB[64][64];
	public static long[][] BetweenBB = new long[64][64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long PassedPawnMask[2][64];
	public static long[][] PassedPawnMask = new long[2][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long OutpostMask[2][64];
	public static long[][] OutpostMask = new long[2][64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BishopPseudoAttacks[64];
	public static long[] BishopPseudoAttacks = new long[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RookPseudoAttacks[64];
	public static long[] RookPseudoAttacks = new long[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long QueenPseudoAttacks[64];
	public static long[] QueenPseudoAttacks = new long[64];

  // All functions below are used to precompute various bitboards during
  // program initialization.  Some of the functions may be difficult to
  // understand, but they all seem to work correctly, and it should never
  // be necessary to touch any of them.



	////
	//// Local definitions
	////

	  public static void init_masks()
	  {
		for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
		{
		  SetMaskBB[s.getValue()] = (long)(1 << s.getValue());
		  ClearMaskBB[s.getValue()] = ~SetMaskBB[s.getValue()];
		}
		for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
		{
		  for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
		  {
			PassedPawnMask[c.getValue()][s.getValue()] = in_front_bb(c, s) & this_and_neighboring_files_bb(s);
			OutpostMask[c.getValue()][s.getValue()] = in_front_bb(c, s) & neighboring_files_bb(s);
		  }
		}
	  }

	  public static void init_ray_bitboards()
	  {
		int[] d = {1, -1, 16, -16, 17, -17, 15, -15};
		for (int i = 0; i < 128; i = i + 9 & ~8)
		{
		  for (int j = 0; j < 8; j++)
		  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			RayBB[(i & 7) | ((i >> 4) << 3)][j] = EmptyBoardBB;
			for (int k = i + d[j]; (k & 0x88) == 0; k += d[j])
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			  set_bit((RayBB[(i & 7) | ((i >> 4)<<3)][j]), Square((k & 7) | ((k>>4) << 3)));
			}
		  }
		}
	  }

	  public static void init_attacks()
	  {
		int i;
		int j;
		int k;
		int l;
		int[][] step =
		{
			{0, 0, 0, 0, 0, 0, 0, 0},
			{7, 9, 0, 0, 0, 0, 0, 0},
			{17, 15, 10, 6, -6, -10, -15, -17},
			{9, 7, -7, -9, 0, 0, 0, 0},
			{8, 1, -1, -8, 0, 0, 0, 0},
			{9, 7, -7, -9, 8, 1, -1, -8},
			{9, 7, -7, -9, 8, 1, -1, -8},
			{0, 0, 0, 0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0, 0, 0, 0},
			{-7, -9, 0, 0, 0, 0, 0, 0},
			{17, 15, 10, 6, -6, -10, -15, -17},
			{9, 7, -7, -9, 0, 0, 0, 0},
			{8, 1, -1, -8, 0, 0, 0, 0},
			{9, 7, -7, -9, 8, 1, -1, -8},
			{9, 7, -7, -9, 8, 1, -1, -8}
		};

		for (i = 0; i < 64; i++)
		{
		  for (j = 0; j <= Piece.BK.getValue(); j++)
		  {
			StepAttackBB[j][i] = EmptyBoardBB;
			for (k = 0; k < 8 && step[j][k] != 0; k++)
			{
			  l = i + step[j][k];
			  if (l >= 0 && l < 64 && Math.abs((i & 7) - (l & 7)) < 3)
			  {
				StepAttackBB[j][i] |= (1 << l);
			  }
			}
		  }
		}
	  }

	  public static void init_between_bitboards()
	  {
		SquareDelta[] step = {SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_S, SquareDelta.DELTA_NE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NW, SquareDelta.DELTA_SE};
		SignedDirection d;
		for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_H8.getValue(); s1++)
		{
		  for (Square s2 = Square.SQ_A1; s2.getValue() <= Square.SQ_H8.getValue(); s2++)
		  {
			BetweenBB[s1.getValue()][s2.getValue()] = EmptyBoardBB;
			d = signed_direction_between_squares(s1, s2);
			if (d != SignedDirection.SIGNED_DIR_NONE)
			{
			  for (Square s3 = s1 + step[d.getValue()]; s3 != s2; s3 += step[d.getValue()])
			  {
				set_bit((BetweenBB[s1.getValue()][s2.getValue()]), s3);
			  }
			}
		  }
		}
	  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin, int fmax, int rmin)
  {
	  return sliding_attacks(sq, block, dirs, deltas, fmin, fmax, rmin, 7);
  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin, int fmax)
  {
	  return sliding_attacks(sq, block, dirs, deltas, fmin, fmax, 0, 7);
  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin)
  {
	  return sliding_attacks(sq, block, dirs, deltas, fmin, 7, 0, 7);
  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas)
  {
	  return sliding_attacks(sq, block, dirs, deltas, 0, 7, 0, 7);
  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long sliding_attacks(int sq, unsigned long long block, int dirs, int deltas[][2], int fmin, int fmax, int rmin, int rmax);
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: ulong sliding_attacks(int sq, ulong block, int dirs, int deltas[][2], int fmin=0, int fmax=7, int rmin=0, int rmax=7)
	  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin, int fmax, int rmin, int rmax)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long result = 0ULL;
		long result = 0;
		int rk = sq / 8;
		int fl = sq % 8;
		int r;
		int f;
		int i;
		for (i = 0; i < dirs; i++)
		{
		  int dx = deltas[i][0];
		  int dy = deltas[i][1];
		  for (f = fl + dx, r = rk + dy; (dx == 0 || (f >= fmin && f <= fmax)) && (dy == 0 || (r >= rmin && r <= rmax)); f += dx, r += dy)
		  {
			result |= (1 << (f + r * 8));
			if ((block & (1 << (f + r * 8))) != 0)
			{
				break;
			}
		  }
		}
		return result;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long index_to_bitboard(int index, unsigned long long mask);
	  public static long index_to_bitboard(int index, long mask)
	  {
		int i;
		int j;
		int bits = count_1s(mask);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long result = 0ULL;
		long result = 0;
		for (i = 0; i < bits; i++)
		{
	  tangible.RefObject<Long> tempRef_mask = new tangible.RefObject<Long>(mask);
		  j = pop_1st_bit(tempRef_mask).getValue();
		  mask = tempRef_mask.argValue;
		  if ((index & (1 << i)) != 0)
		  {
			  result |= (1 << j);
		  }
		}
		return result;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: void init_sliding_attacks(unsigned long long attacks[], int attackIndex[], unsigned long long mask[], const int shift[2], const unsigned long long mult[], int deltas[][2]);
	  public static void init_sliding_attacks(long[] attacks, int[] attackIndex, long[] mask, int[] shift, long[] mult, int[][] deltas)
	  {
		int i;
		int j;
		int k;
		int index = 0;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		for (i = 0; i < 64; i++)
		{
		  attackIndex[i] = index;
		  mask[i] = sliding_attacks(i, 0, 4, deltas, 1, 6, 1, 6);
		  j = (1 << (64 - shift[i]));
		  for (k = 0; k < j; k++)
		  {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_32BIT_ATTACKS
			b = index_to_bitboard(k, mask[i]);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			attacks[index + (int((int)b * (int)mult[i] ^ (int)(b >>> 32) * (int)(mult[i] >>> 32)) >>> shift[i])] = sliding_attacks(i, b, 4, deltas);
	///#else
			b = index_to_bitboard(k, mask[i]);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			attacks[index + ((b * mult[i]) >>> shift[i])] = sliding_attacks(i, b, 4, deltas);
	///#endif
		  }
		  index += j;
		}
	  }

	  public static void init_pseudo_attacks()
	  {
		Square s;
		for (s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
		{
		  BishopPseudoAttacks[s.getValue()] = bishop_attacks_bb(s, EmptyBoardBB);
		  RookPseudoAttacks[s.getValue()] = rook_attacks_bb(s, EmptyBoardBB);
		  QueenPseudoAttacks[s.getValue()] = queen_attacks_bb(s, EmptyBoardBB);
		}
	  }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	  public static void init_file_and_rank_attacks()
	  {
		int i;
		int j;
		int k;
		int l;
		int m;
		int s;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b1, b2;
		long b1;
		long b2;
		for (i = 0; i < 64; i++)
		{

		  for (m = 0; m <= 1; m++)
		  {
			b1 = 0;
			for (j = 0; j < 6; j++)
			{
				if ((i & (1 << j)) != 0)
				{
					b1 |= (1 << ((j + 1) * (1 + m * 7)));
				}
			}
			for (j = 0; j < 8; j++)
			{
			  b2 = 0;
			  for (k = 0, s = 1; k < 2; k++, s *= -1)
			  {
				for (l = j + s; l >= 0 && l <= 7; l += s)
				{
				  b2 |= (m != 0? RankBB[l] : FileBB[l]);
				  if ((b1 & (1 << (l * (1 + m * 7)))) != 0)
				  {
					  break;
				  }
				}
			  }
			  if (m != 0)
			  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				  FileAttacks[j][(b1 * 0xd6e8802041d0c441) >> 58] = b2;
			  }
			  else
			  {
				  RankAttacks[j][i] = b2;
			  }
			}
		  }
		}
	  }
	///#endif

	///#endif


	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_FOLDED_BITSCAN

	public static final int[] BitTable = {63, 30, 3, 32, 25, 41, 22, 33, 15, 50, 42, 13, 11, 53, 19, 34, 61, 29, 2, 51, 21, 43, 45, 10, 18, 47, 1, 54, 9, 57, 0, 35, 62, 31, 40, 4, 49, 5, 52, 26, 60, 6, 23, 44, 46, 27, 56, 16, 7, 39, 48, 24, 59, 14, 12, 55, 38, 28, 58, 20, 37, 17, 36, 8};

	///#else

	public static final int[] BitTable = {0, 1, 2, 7, 3, 13, 8, 19, 4, 25, 14, 28, 9, 34, 20, 40, 5, 17, 26, 38, 15, 46, 29, 48, 10, 31, 35, 54, 21, 50, 41, 57, 63, 6, 12, 18, 24, 27, 33, 39, 16, 37, 45, 47, 30, 53, 49, 56, 62, 11, 23, 32, 36, 44, 52, 55, 61, 22, 43, 51, 60, 42, 59, 58};


	/// first_1() finds the least significant nonzero bit in a nonzero bitboard.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: Square first_1(unsigned long long b)
	public static Square first_1(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square(BitTable[((b & -b) * 0x218a392cd3d5dbf) >> 58]);
	}


	/// pop_1st_bit() finds and clears the least significant nonzero bit in a
	/// nonzero bitboard.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: Square pop_1st_bit(unsigned long long *b)
	public static Square pop_1st_bit(tangible.RefObject<Long> b)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = *b;
	  long bb = b.argValue;
	  b.argValue &= (b.argValue - 1);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square(BitTable[((bb & -bb) * 0x218a392cd3d5dbf) >> 58]);
	}

	///#endif // defined(USE_FOLDED_BITSCAN)


	////
	//// Global variables
	////

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Book OpeningBook;





	////
	//// Global variables
	////

	public static Book OpeningBook = new Book();


	////
	//// Local definitions
	////


	  /// Random numbers from PolyGlot, used to compute book hash keys.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Random64[781] = { 0x9D39247E33776D41ULL, 0x2AF7398005AAA5C7ULL, 0x44DB015024623547ULL, 0x9C15F73E62A76AE2ULL, 0x75834465489C0C89ULL, 0x3290AC3A203001BFULL, 0x0FBBAD1F61042279ULL, 0xE83A908FF2FB60CAULL, 0x0D7E765D58755C10ULL, 0x1A083822CEAFE02DULL, 0x9605D5F0E25EC3B0ULL, 0xD021FF5CD13A2ED5ULL, 0x40BDF15D4A672E32ULL, 0x011355146FD56395ULL, 0x5DB4832046F3D9E5ULL, 0x239F8B2D7FF719CCULL, 0x05D1A1AE85B49AA1ULL, 0x679F848F6E8FC971ULL, 0x7449BBFF801FED0BULL, 0x7D11CDB1C3B7ADF0ULL, 0x82C7709E781EB7CCULL, 0xF3218F1C9510786CULL, 0x331478F3AF51BBE6ULL, 0x4BB38DE5E7219443ULL, 0xAA649C6EBCFD50FCULL, 0x8DBD98A352AFD40BULL, 0x87D2074B81D79217ULL, 0x19F3C751D3E92AE1ULL, 0xB4AB30F062B19ABFULL, 0x7B0500AC42047AC4ULL, 0xC9452CA81A09D85DULL, 0x24AA6C514DA27500ULL, 0x4C9F34427501B447ULL, 0x14A68FD73C910841ULL, 0xA71B9B83461CBD93ULL, 0x03488B95B0F1850FULL, 0x637B2B34FF93C040ULL, 0x09D1BC9A3DD90A94ULL, 0x3575668334A1DD3BULL, 0x735E2B97A4C45A23ULL, 0x18727070F1BD400BULL, 0x1FCBACD259BF02E7ULL, 0xD310A7C2CE9B6555ULL, 0xBF983FE0FE5D8244ULL, 0x9F74D14F7454A824ULL, 0x51EBDC4AB9BA3035ULL, 0x5C82C505DB9AB0FAULL, 0xFCF7FE8A3430B241ULL, 0x3253A729B9BA3DDEULL, 0x8C74C368081B3075ULL, 0xB9BC6C87167C33E7ULL, 0x7EF48F2B83024E20ULL, 0x11D505D4C351BD7FULL, 0x6568FCA92C76A243ULL, 0x4DE0B0F40F32A7B8ULL, 0x96D693460CC37E5DULL, 0x42E240CB63689F2FULL, 0x6D2BDCDAE2919661ULL, 0x42880B0236E4D951ULL, 0x5F0F4A5898171BB6ULL, 0x39F890F579F92F88ULL, 0x93C5B5F47356388BULL, 0x63DC359D8D231B78ULL, 0xEC16CA8AEA98AD76ULL, 0x5355F900C2A82DC7ULL, 0x07FB9F855A997142ULL, 0x5093417AA8A7ED5EULL, 0x7BCBC38DA25A7F3CULL, 0x19FC8A768CF4B6D4ULL, 0x637A7780DECFC0D9ULL, 0x8249A47AEE0E41F7ULL, 0x79AD695501E7D1E8ULL, 0x14ACBAF4777D5776ULL, 0xF145B6BECCDEA195ULL, 0xDABF2AC8201752FCULL, 0x24C3C94DF9C8D3F6ULL, 0xBB6E2924F03912EAULL, 0x0CE26C0B95C980D9ULL, 0xA49CD132BFBF7CC4ULL, 0xE99D662AF4243939ULL, 0x27E6AD7891165C3FULL, 0x8535F040B9744FF1ULL, 0x54B3F4FA5F40D873ULL, 0x72B12C32127FED2BULL, 0xEE954D3C7B411F47ULL, 0x9A85AC909A24EAA1ULL, 0x70AC4CD9F04F21F5ULL, 0xF9B89D3E99A075C2ULL, 0x87B3E2B2B5C907B1ULL, 0xA366E5B8C54F48B8ULL, 0xAE4A9346CC3F7CF2ULL, 0x1920C04D47267BBDULL, 0x87BF02C6B49E2AE9ULL, 0x092237AC237F3859ULL, 0xFF07F64EF8ED14D0ULL, 0x8DE8DCA9F03CC54EULL, 0x9C1633264DB49C89ULL, 0xB3F22C3D0B0B38EDULL, 0x390E5FB44D01144BULL, 0x5BFEA5B4712768E9ULL, 0x1E1032911FA78984ULL, 0x9A74ACB964E78CB3ULL, 0x4F80F7A035DAFB04ULL, 0x6304D09A0B3738C4ULL, 0x2171E64683023A08ULL, 0x5B9B63EB9CEFF80CULL, 0x506AACF489889342ULL, 0x1881AFC9A3A701D6ULL, 0x6503080440750644ULL, 0xDFD395339CDBF4A7ULL, 0xEF927DBCF00C20F2ULL, 0x7B32F7D1E03680ECULL, 0xB9FD7620E7316243ULL, 0x05A7E8A57DB91B77ULL, 0xB5889C6E15630A75ULL, 0x4A750A09CE9573F7ULL, 0xCF464CEC899A2F8AULL, 0xF538639CE705B824ULL, 0x3C79A0FF5580EF7FULL, 0xEDE6C87F8477609DULL, 0x799E81F05BC93F31ULL, 0x86536B8CF3428A8CULL, 0x97D7374C60087B73ULL, 0xA246637CFF328532ULL, 0x043FCAE60CC0EBA0ULL, 0x920E449535DD359EULL, 0x70EB093B15B290CCULL, 0x73A1921916591CBDULL, 0x56436C9FE1A1AA8DULL, 0xEFAC4B70633B8F81ULL, 0xBB215798D45DF7AFULL, 0x45F20042F24F1768ULL, 0x930F80F4E8EB7462ULL, 0xFF6712FFCFD75EA1ULL, 0xAE623FD67468AA70ULL, 0xDD2C5BC84BC8D8FCULL, 0x7EED120D54CF2DD9ULL, 0x22FE545401165F1CULL, 0xC91800E98FB99929ULL, 0x808BD68E6AC10365ULL, 0xDEC468145B7605F6ULL, 0x1BEDE3A3AEF53302ULL, 0x43539603D6C55602ULL, 0xAA969B5C691CCB7AULL, 0xA87832D392EFEE56ULL, 0x65942C7B3C7E11AEULL, 0xDED2D633CAD004F6ULL, 0x21F08570F420E565ULL, 0xB415938D7DA94E3CULL, 0x91B859E59ECB6350ULL, 0x10CFF333E0ED804AULL, 0x28AED140BE0BB7DDULL, 0xC5CC1D89724FA456ULL, 0x5648F680F11A2741ULL, 0x2D255069F0B7DAB3ULL, 0x9BC5A38EF729ABD4ULL, 0xEF2F054308F6A2BCULL, 0xAF2042F5CC5C2858ULL, 0x480412BAB7F5BE2AULL, 0xAEF3AF4A563DFE43ULL, 0x19AFE59AE451497FULL, 0x52593803DFF1E840ULL, 0xF4F076E65F2CE6F0ULL, 0x11379625747D5AF3ULL, 0xBCE5D2248682C115ULL, 0x9DA4243DE836994FULL, 0x066F70B33FE09017ULL, 0x4DC4DE189B671A1CULL, 0x51039AB7712457C3ULL, 0xC07A3F80C31FB4B4ULL, 0xB46EE9C5E64A6E7CULL, 0xB3819A42ABE61C87ULL, 0x21A007933A522A20ULL, 0x2DF16F761598AA4FULL, 0x763C4A1371B368FDULL, 0xF793C46702E086A0ULL, 0xD7288E012AEB8D31ULL, 0xDE336A2A4BC1C44BULL, 0x0BF692B38D079F23ULL, 0x2C604A7A177326B3ULL, 0x4850E73E03EB6064ULL, 0xCFC447F1E53C8E1BULL, 0xB05CA3F564268D99ULL, 0x9AE182C8BC9474E8ULL, 0xA4FC4BD4FC5558CAULL, 0xE755178D58FC4E76ULL, 0x69B97DB1A4C03DFEULL, 0xF9B5B7C4ACC67C96ULL, 0xFC6A82D64B8655FBULL, 0x9C684CB6C4D24417ULL, 0x8EC97D2917456ED0ULL, 0x6703DF9D2924E97EULL, 0xC547F57E42A7444EULL, 0x78E37644E7CAD29EULL, 0xFE9A44E9362F05FAULL, 0x08BD35CC38336615ULL, 0x9315E5EB3A129ACEULL, 0x94061B871E04DF75ULL, 0xDF1D9F9D784BA010ULL, 0x3BBA57B68871B59DULL, 0xD2B7ADEEDED1F73FULL, 0xF7A255D83BC373F8ULL, 0xD7F4F2448C0CEB81ULL, 0xD95BE88CD210FFA7ULL, 0x336F52F8FF4728E7ULL, 0xA74049DAC312AC71ULL, 0xA2F61BB6E437FDB5ULL, 0x4F2A5CB07F6A35B3ULL, 0x87D380BDA5BF7859ULL, 0x16B9F7E06C453A21ULL, 0x7BA2484C8A0FD54EULL, 0xF3A678CAD9A2E38CULL, 0x39B0BF7DDE437BA2ULL, 0xFCAF55C1BF8A4424ULL, 0x18FCF680573FA594ULL, 0x4C0563B89F495AC3ULL, 0x40E087931A00930DULL, 0x8CFFA9412EB642C1ULL, 0x68CA39053261169FULL, 0x7A1EE967D27579E2ULL, 0x9D1D60E5076F5B6FULL, 0x3810E399B6F65BA2ULL, 0x32095B6D4AB5F9B1ULL, 0x35CAB62109DD038AULL, 0xA90B24499FCFAFB1ULL, 0x77A225A07CC2C6BDULL, 0x513E5E634C70E331ULL, 0x4361C0CA3F692F12ULL, 0xD941ACA44B20A45BULL, 0x528F7C8602C5807BULL, 0x52AB92BEB9613989ULL, 0x9D1DFA2EFC557F73ULL, 0x722FF175F572C348ULL, 0x1D1260A51107FE97ULL, 0x7A249A57EC0C9BA2ULL, 0x04208FE9E8F7F2D6ULL, 0x5A110C6058B920A0ULL, 0x0CD9A497658A5698ULL, 0x56FD23C8F9715A4CULL, 0x284C847B9D887AAEULL, 0x04FEABFBBDB619CBULL, 0x742E1E651C60BA83ULL, 0x9A9632E65904AD3CULL, 0x881B82A13B51B9E2ULL, 0x506E6744CD974924ULL, 0xB0183DB56FFC6A79ULL, 0x0ED9B915C66ED37EULL, 0x5E11E86D5873D484ULL, 0xF678647E3519AC6EULL, 0x1B85D488D0F20CC5ULL, 0xDAB9FE6525D89021ULL, 0x0D151D86ADB73615ULL, 0xA865A54EDCC0F019ULL, 0x93C42566AEF98FFBULL, 0x99E7AFEABE000731ULL, 0x48CBFF086DDF285AULL, 0x7F9B6AF1EBF78BAFULL, 0x58627E1A149BBA21ULL, 0x2CD16E2ABD791E33ULL, 0xD363EFF5F0977996ULL, 0x0CE2A38C344A6EEDULL, 0x1A804AADB9CFA741ULL, 0x907F30421D78C5DEULL, 0x501F65EDB3034D07ULL, 0x37624AE5A48FA6E9ULL, 0x957BAF61700CFF4EULL, 0x3A6C27934E31188AULL, 0xD49503536ABCA345ULL, 0x088E049589C432E0ULL, 0xF943AEE7FEBF21B8ULL, 0x6C3B8E3E336139D3ULL, 0x364F6FFA464EE52EULL, 0xD60F6DCEDC314222ULL, 0x56963B0DCA418FC0ULL, 0x16F50EDF91E513AFULL, 0xEF1955914B609F93ULL, 0x565601C0364E3228ULL, 0xECB53939887E8175ULL, 0xBAC7A9A18531294BULL, 0xB344C470397BBA52ULL, 0x65D34954DAF3CEBDULL, 0xB4B81B3FA97511E2ULL, 0xB422061193D6F6A7ULL, 0x071582401C38434DULL, 0x7A13F18BBEDC4FF5ULL, 0xBC4097B116C524D2ULL, 0x59B97885E2F2EA28ULL, 0x99170A5DC3115544ULL, 0x6F423357E7C6A9F9ULL, 0x325928EE6E6F8794ULL, 0xD0E4366228B03343ULL, 0x565C31F7DE89EA27ULL, 0x30F5611484119414ULL, 0xD873DB391292ED4FULL, 0x7BD94E1D8E17DEBCULL, 0xC7D9F16864A76E94ULL, 0x947AE053EE56E63CULL, 0xC8C93882F9475F5FULL, 0x3A9BF55BA91F81CAULL, 0xD9A11FBB3D9808E4ULL, 0x0FD22063EDC29FCAULL, 0xB3F256D8ACA0B0B9ULL, 0xB03031A8B4516E84ULL, 0x35DD37D5871448AFULL, 0xE9F6082B05542E4EULL, 0xEBFAFA33D7254B59ULL, 0x9255ABB50D532280ULL, 0xB9AB4CE57F2D34F3ULL, 0x693501D628297551ULL, 0xC62C58F97DD949BFULL, 0xCD454F8F19C5126AULL, 0xBBE83F4ECC2BDECBULL, 0xDC842B7E2819E230ULL, 0xBA89142E007503B8ULL, 0xA3BC941D0A5061CBULL, 0xE9F6760E32CD8021ULL, 0x09C7E552BC76492FULL, 0x852F54934DA55CC9ULL, 0x8107FCCF064FCF56ULL, 0x098954D51FFF6580ULL, 0x23B70EDB1955C4BFULL, 0xC330DE426430F69DULL, 0x4715ED43E8A45C0AULL, 0xA8D7E4DAB780A08DULL, 0x0572B974F03CE0BBULL, 0xB57D2E985E1419C7ULL, 0xE8D9ECBE2CF3D73FULL, 0x2FE4B17170E59750ULL, 0x11317BA87905E790ULL, 0x7FBF21EC8A1F45ECULL, 0x1725CABFCB045B00ULL, 0x964E915CD5E2B207ULL, 0x3E2B8BCBF016D66DULL, 0xBE7444E39328A0ACULL, 0xF85B2B4FBCDE44B7ULL, 0x49353FEA39BA63B1ULL, 0x1DD01AAFCD53486AULL, 0x1FCA8A92FD719F85ULL, 0xFC7C95D827357AFAULL, 0x18A6A990C8B35EBDULL, 0xCCCB7005C6B9C28DULL, 0x3BDBB92C43B17F26ULL, 0xAA70B5B4F89695A2ULL, 0xE94C39A54A98307FULL, 0xB7A0B174CFF6F36EULL, 0xD4DBA84729AF48ADULL, 0x2E18BC1AD9704A68ULL, 0x2DE0966DAF2F8B1CULL, 0xB9C11D5B1E43A07EULL, 0x64972D68DEE33360ULL, 0x94628D38D0C20584ULL, 0xDBC0D2B6AB90A559ULL, 0xD2733C4335C6A72FULL, 0x7E75D99D94A70F4DULL, 0x6CED1983376FA72BULL, 0x97FCAACBF030BC24ULL, 0x7B77497B32503B12ULL, 0x8547EDDFB81CCB94ULL, 0x79999CDFF70902CBULL, 0xCFFE1939438E9B24ULL, 0x829626E3892D95D7ULL, 0x92FAE24291F2B3F1ULL, 0x63E22C147B9C3403ULL, 0xC678B6D860284A1CULL, 0x5873888850659AE7ULL, 0x0981DCD296A8736DULL, 0x9F65789A6509A440ULL, 0x9FF38FED72E9052FULL, 0xE479EE5B9930578CULL, 0xE7F28ECD2D49EECDULL, 0x56C074A581EA17FEULL, 0x5544F7D774B14AEFULL, 0x7B3F0195FC6F290FULL, 0x12153635B2C0CF57ULL, 0x7F5126DBBA5E0CA7ULL, 0x7A76956C3EAFB413ULL, 0x3D5774A11D31AB39ULL, 0x8A1B083821F40CB4ULL, 0x7B4A38E32537DF62ULL, 0x950113646D1D6E03ULL, 0x4DA8979A0041E8A9ULL, 0x3BC36E078F7515D7ULL, 0x5D0A12F27AD310D1ULL, 0x7F9D1A2E1EBE1327ULL, 0xDA3A361B1C5157B1ULL, 0xDCDD7D20903D0C25ULL, 0x36833336D068F707ULL, 0xCE68341F79893389ULL, 0xAB9090168DD05F34ULL, 0x43954B3252DC25E5ULL, 0xB438C2B67F98E5E9ULL, 0x10DCD78E3851A492ULL, 0xDBC27AB5447822BFULL, 0x9B3CDB65F82CA382ULL, 0xB67B7896167B4C84ULL, 0xBFCED1B0048EAC50ULL, 0xA9119B60369FFEBDULL, 0x1FFF7AC80904BF45ULL, 0xAC12FB171817EEE7ULL, 0xAF08DA9177DDA93DULL, 0x1B0CAB936E65C744ULL, 0xB559EB1D04E5E932ULL, 0xC37B45B3F8D6F2BAULL, 0xC3A9DC228CAAC9E9ULL, 0xF3B8B6675A6507FFULL, 0x9FC477DE4ED681DAULL, 0x67378D8ECCEF96CBULL, 0x6DD856D94D259236ULL, 0xA319CE15B0B4DB31ULL, 0x073973751F12DD5EULL, 0x8A8E849EB32781A5ULL, 0xE1925C71285279F5ULL, 0x74C04BF1790C0EFEULL, 0x4DDA48153C94938AULL, 0x9D266D6A1CC0542CULL, 0x7440FB816508C4FEULL, 0x13328503DF48229FULL, 0xD6BF7BAEE43CAC40ULL, 0x4838D65F6EF6748FULL, 0x1E152328F3318DEAULL, 0x8F8419A348F296BFULL, 0x72C8834A5957B511ULL, 0xD7A023A73260B45CULL, 0x94EBC8ABCFB56DAEULL, 0x9FC10D0F989993E0ULL, 0xDE68A2355B93CAE6ULL, 0xA44CFE79AE538BBEULL, 0x9D1D84FCCE371425ULL, 0x51D2B1AB2DDFB636ULL, 0x2FD7E4B9E72CD38CULL, 0x65CA5B96B7552210ULL, 0xDD69A0D8AB3B546DULL, 0x604D51B25FBF70E2ULL, 0x73AA8A564FB7AC9EULL, 0x1A8C1E992B941148ULL, 0xAAC40A2703D9BEA0ULL, 0x764DBEAE7FA4F3A6ULL, 0x1E99B96E70A9BE8BULL, 0x2C5E9DEB57EF4743ULL, 0x3A938FEE32D29981ULL, 0x26E6DB8FFDF5ADFEULL, 0x469356C504EC9F9DULL, 0xC8763C5B08D1908CULL, 0x3F6C6AF859D80055ULL, 0x7F7CC39420A3A545ULL, 0x9BFB227EBDF4C5CEULL, 0x89039D79D6FC5C5CULL, 0x8FE88B57305E2AB6ULL, 0xA09E8C8C35AB96DEULL, 0xFA7E393983325753ULL, 0xD6B6D0ECC617C699ULL, 0xDFEA21EA9E7557E3ULL, 0xB67C1FA481680AF8ULL, 0xCA1E3785A9E724E5ULL, 0x1CFC8BED0D681639ULL, 0xD18D8549D140CAEAULL, 0x4ED0FE7E9DC91335ULL, 0xE4DBF0634473F5D2ULL, 0x1761F93A44D5AEFEULL, 0x53898E4C3910DA55ULL, 0x734DE8181F6EC39AULL, 0x2680B122BAA28D97ULL, 0x298AF231C85BAFABULL, 0x7983EED3740847D5ULL, 0x66C1A2A1A60CD889ULL, 0x9E17E49642A3E4C1ULL, 0xEDB454E7BADC0805ULL, 0x50B704CAB602C329ULL, 0x4CC317FB9CDDD023ULL, 0x66B4835D9EAFEA22ULL, 0x219B97E26FFC81BDULL, 0x261E4E4C0A333A9DULL, 0x1FE2CCA76517DB90ULL, 0xD7504DFA8816EDBBULL, 0xB9571FA04DC089C8ULL, 0x1DDC0325259B27DEULL, 0xCF3F4688801EB9AAULL, 0xF4F5D05C10CAB243ULL, 0x38B6525C21A42B0EULL, 0x36F60E2BA4FA6800ULL, 0xEB3593803173E0CEULL, 0x9C4CD6257C5A3603ULL, 0xAF0C317D32ADAA8AULL, 0x258E5A80C7204C4BULL, 0x8B889D624D44885DULL, 0xF4D14597E660F855ULL, 0xD4347F66EC8941C3ULL, 0xE699ED85B0DFB40DULL, 0x2472F6207C2D0484ULL, 0xC2A1E7B5B459AEB5ULL, 0xAB4F6451CC1D45ECULL, 0x63767572AE3D6174ULL, 0xA59E0BD101731A28ULL, 0x116D0016CB948F09ULL, 0x2CF9C8CA052F6E9FULL, 0x0B090A7560A968E3ULL, 0xABEEDDB2DDE06FF1ULL, 0x58EFC10B06A2068DULL, 0xC6E57A78FBD986E0ULL, 0x2EAB8CA63CE802D7ULL, 0x14A195640116F336ULL, 0x7C0828DD624EC390ULL, 0xD74BBE77E6116AC7ULL, 0x804456AF10F5FB53ULL, 0xEBE9EA2ADF4321C7ULL, 0x03219A39EE587A30ULL, 0x49787FEF17AF9924ULL, 0xA1E9300CD8520548ULL, 0x5B45E522E4B1B4EFULL, 0xB49C3B3995091A36ULL, 0xD4490AD526F14431ULL, 0x12A8F216AF9418C2ULL, 0x001F837CC7350524ULL, 0x1877B51E57A764D5ULL, 0xA2853B80F17F58EEULL, 0x993E1DE72D36D310ULL, 0xB3598080CE64A656ULL, 0x252F59CF0D9F04BBULL, 0xD23C8E176D113600ULL, 0x1BDA0492E7E4586EULL, 0x21E0BD5026C619BFULL, 0x3B097ADAF088F94EULL, 0x8D14DEDB30BE846EULL, 0xF95CFFA23AF5F6F4ULL, 0x3871700761B3F743ULL, 0xCA672B91E9E4FA16ULL, 0x64C8E531BFF53B55ULL, 0x241260ED4AD1E87DULL, 0x106C09B972D2E822ULL, 0x7FBA195410E5CA30ULL, 0x7884D9BC6CB569D8ULL, 0x0647DFEDCD894A29ULL, 0x63573FF03E224774ULL, 0x4FC8E9560F91B123ULL, 0x1DB956E450275779ULL, 0xB8D91274B9E9D4FBULL, 0xA2EBEE47E2FBFCE1ULL, 0xD9F1F30CCD97FB09ULL, 0xEFED53D75FD64E6BULL, 0x2E6D02C36017F67FULL, 0xA9AA4D20DB084E9BULL, 0xB64BE8D8B25396C1ULL, 0x70CB6AF7C2D5BCF0ULL, 0x98F076A4F7A2322EULL, 0xBF84470805E69B5FULL, 0x94C3251F06F90CF3ULL, 0x3E003E616A6591E9ULL, 0xB925A6CD0421AFF3ULL, 0x61BDD1307C66E300ULL, 0xBF8D5108E27E0D48ULL, 0x240AB57A8B888B20ULL, 0xFC87614BAF287E07ULL, 0xEF02CDD06FFDB432ULL, 0xA1082C0466DF6C0AULL, 0x8215E577001332C8ULL, 0xD39BB9C3A48DB6CFULL, 0x2738259634305C14ULL, 0x61CF4F94C97DF93DULL, 0x1B6BACA2AE4E125BULL, 0x758F450C88572E0BULL, 0x959F587D507A8359ULL, 0xB063E962E045F54DULL, 0x60E8ED72C0DFF5D1ULL, 0x7B64978555326F9FULL, 0xFD080D236DA814BAULL, 0x8C90FD9B083F4558ULL, 0x106F72FE81E2C590ULL, 0x7976033A39F7D952ULL, 0xA4EC0132764CA04BULL, 0x733EA705FAE4FA77ULL, 0xB4D8F77BC3E56167ULL, 0x9E21F4F903B33FD9ULL, 0x9D765E419FB69F6DULL, 0xD30C088BA61EA5EFULL, 0x5D94337FBFAF7F5BULL, 0x1A4E4822EB4D7A59ULL, 0x6FFE73E81B637FB3ULL, 0xDDF957BC36D8B9CAULL, 0x64D0E29EEA8838B3ULL, 0x08DD9BDFD96B9F63ULL, 0x087E79E5A57D1D13ULL, 0xE328E230E3E2B3FBULL, 0x1C2559E30F0946BEULL, 0x720BF5F26F4D2EAAULL, 0xB0774D261CC609DBULL, 0x443F64EC5A371195ULL, 0x4112CF68649A260EULL, 0xD813F2FAB7F5C5CAULL, 0x660D3257380841EEULL, 0x59AC2C7873F910A3ULL, 0xE846963877671A17ULL, 0x93B633ABFA3469F8ULL, 0xC0C0F5A60EF4CDCFULL, 0xCAF21ECD4377B28CULL, 0x57277707199B8175ULL, 0x506C11B9D90E8B1DULL, 0xD83CC2687A19255FULL, 0x4A29C6465A314CD1ULL, 0xED2DF21216235097ULL, 0xB5635C95FF7296E2ULL, 0x22AF003AB672E811ULL, 0x52E762596BF68235ULL, 0x9AEBA33AC6ECC6B0ULL, 0x944F6DE09134DFB6ULL, 0x6C47BEC883A7DE39ULL, 0x6AD047C430A12104ULL, 0xA5B1CFDBA0AB4067ULL, 0x7C45D833AFF07862ULL, 0x5092EF950A16DA0BULL, 0x9338E69C052B8E7BULL, 0x455A4B4CFE30E3F5ULL, 0x6B02E63195AD0CF8ULL, 0x6B17B224BAD6BF27ULL, 0xD1E0CCD25BB9C169ULL, 0xDE0C89A556B9AE70ULL, 0x50065E535A213CF6ULL, 0x9C1169FA2777B874ULL, 0x78EDEFD694AF1EEDULL, 0x6DC93D9526A50E68ULL, 0xEE97F453F06791EDULL, 0x32AB0EDB696703D3ULL, 0x3A6853C7E70757A7ULL, 0x31865CED6120F37DULL, 0x67FEF95D92607890ULL, 0x1F2B1D1F15F6DC9CULL, 0xB69E38A8965C6B65ULL, 0xAA9119FF184CCCF4ULL, 0xF43C732873F24C13ULL, 0xFB4A3D794A9A80D2ULL, 0x3550C2321FD6109CULL, 0x371F77E76BB8417EULL, 0x6BFA9AAE5EC05779ULL, 0xCD04F3FF001A4778ULL, 0xE3273522064480CAULL, 0x9F91508BFFCFC14AULL, 0x049A7F41061A9E60ULL, 0xFCB6BE43A9F2FE9BULL, 0x08DE8A1C7797DA9BULL, 0x8F9887E6078735A1ULL, 0xB5B4071DBFC73A66ULL, 0x230E343DFBA08D33ULL, 0x43ED7F5A0FAE657DULL, 0x3A88A0FBBCB05C63ULL, 0x21874B8B4D2DBC4FULL, 0x1BDEA12E35F6A8C9ULL, 0x53C065C6C8E63528ULL, 0xE34A1D250E7A8D6BULL, 0xD6B04D3B7651DD7EULL, 0x5E90277E7CB39E2DULL, 0x2C046F22062DC67DULL, 0xB10BB459132D0A26ULL, 0x3FA9DDFB67E2F199ULL, 0x0E09B88E1914F7AFULL, 0x10E8B35AF3EEAB37ULL, 0x9EEDECA8E272B933ULL, 0xD4C718BC4AE8AE5FULL, 0x81536D601170FC20ULL, 0x91B534F885818A06ULL, 0xEC8177F83F900978ULL, 0x190E714FADA5156EULL, 0xB592BF39B0364963ULL, 0x89C350C893AE7DC1ULL, 0xAC042E70F8B383F2ULL, 0xB49B52E587A1EE60ULL, 0xFB152FE3FF26DA89ULL, 0x3E666E6F69AE2C15ULL, 0x3B544EBE544C19F9ULL, 0xE805A1E290CF2456ULL, 0x24B33C9D7ED25117ULL, 0xE74733427B72F0C1ULL, 0x0A804D18B7097475ULL, 0x57E3306D881EDB4FULL, 0x4AE7D6A36EB5DBCBULL, 0x2D8D5432157064C8ULL, 0xD1E649DE1E7F268BULL, 0x8A328A1CEDFE552CULL, 0x07A3AEC79624C7DAULL, 0x84547DDC3E203C94ULL, 0x990A98FD5071D263ULL, 0x1A4FF12616EEFC89ULL, 0xF6F7FD1431714200ULL, 0x30C05B1BA332F41CULL, 0x8D2636B81555A786ULL, 0x46C9FEB55D120902ULL, 0xCCEC0A73B49C9921ULL, 0x4E9D2827355FC492ULL, 0x19EBB029435DCB0FULL, 0x4659D2B743848A2CULL, 0x963EF2C96B33BE31ULL, 0x74F85198B05A2E7DULL, 0x5A0F544DD2B1FB18ULL, 0x03727073C2E134B1ULL, 0xC7F6AA2DE59AEA61ULL, 0x352787BAA0D7C22FULL, 0x9853EAB63B5E0B35ULL, 0xABBDCDD7ED5C0860ULL, 0xCF05DAF5AC8D77B0ULL, 0x49CAD48CEBF4A71EULL, 0x7A4C10EC2158C4A6ULL, 0xD9E92AA246BF719EULL, 0x13AE978D09FE5557ULL, 0x730499AF921549FFULL, 0x4E4B705B92903BA4ULL, 0xFF577222C14F0A3AULL, 0x55B6344CF97AAFAEULL, 0xB862225B055B6960ULL, 0xCAC09AFBDDD2CDB4ULL, 0xDAF8E9829FE96B5FULL, 0xB5FDFC5D3132C498ULL, 0x310CB380DB6F7503ULL, 0xE87FBB46217A360EULL, 0x2102AE466EBB1148ULL, 0xF8549E1A3AA5E00DULL, 0x07A69AFDCC42261AULL, 0xC4C118BFE78FEAAEULL, 0xF9F4892ED96BD438ULL, 0x1AF3DBE25D8F45DAULL, 0xF5B4B0B0D2DEEEB4ULL, 0x962ACEEFA82E1C84ULL, 0x046E3ECAAF453CE9ULL, 0xF05D129681949A4CULL, 0x964781CE734B3C84ULL, 0x9C2ED44081CE5FBDULL, 0x522E23F3925E319EULL, 0x177E00F9FC32F791ULL, 0x2BC60A63A6F3B3F2ULL, 0x222BBFAE61725606ULL, 0x486289DDCC3D6780ULL, 0x7DC7785B8EFDFC80ULL, 0x8AF38731C02BA980ULL, 0x1FAB64EA29A2DDF7ULL, 0xE4D9429322CD065AULL, 0x9DA058C67844F20CULL, 0x24C0E332B70019B0ULL, 0x233003B5A6CFE6ADULL, 0xD586BD01C5C217F6ULL, 0x5E5637885F29BC2BULL, 0x7EBA726D8C94094BULL, 0x0A56A5F0BFE39272ULL, 0xD79476A84EE20D06ULL, 0x9E4C1269BAA4BF37ULL, 0x17EFEE45B0DEE640ULL, 0x1D95B0A5FCF90BC6ULL, 0x93CBE0B699C2585DULL, 0x65FA4F227A2B6D79ULL, 0xD5F9E858292504D5ULL, 0xC2B5A03F71471A6FULL, 0x59300222B4561E00ULL, 0xCE2F8642CA0712DCULL, 0x7CA9723FBB2E8988ULL, 0x2785338347F2BA08ULL, 0xC61BB3A141E50E8CULL, 0x150F361DAB9DEC26ULL, 0x9F6A419D382595F4ULL, 0x64A53DC924FE7AC9ULL, 0x142DE49FFF7A7C3DULL, 0x0C335248857FA9E7ULL, 0x0A9C32D5EAE45305ULL, 0xE6C42178C4BBB92EULL, 0x71F1CE2490D20B07ULL, 0xF1BCC3D275AFE51AULL, 0xE728E8C83C334074ULL, 0x96FBF83A12884624ULL, 0x81A1549FD6573DA5ULL, 0x5FA7867CAF35E149ULL, 0x56986E2EF3ED091BULL, 0x917F1DD5F8886C61ULL, 0xD20D8C88C8FFE65FULL, 0x31D71DCE64B2C310ULL, 0xF165B587DF898190ULL, 0xA57E6339DD2CF3A0ULL, 0x1EF6E6DBB1961EC9ULL, 0x70CC73D90BC26E24ULL, 0xE21A6B35DF0C3AD7ULL, 0x003A93D8B2806962ULL, 0x1C99DED33CB890A1ULL, 0xCF3145DE0ADD4289ULL, 0xD0E4427A5514FB72ULL, 0x77C621CC9FB3A483ULL, 0x67A34DAC4356550BULL, 0xF8D626AAAF278509ULL };
	  public static final long[] Random64 = {0x9D39247E33776D41, 0x2AF7398005AAA5C7, 0x44DB015024623547, 0x9C15F73E62A76AE2, 0x75834465489C0C89, 0x3290AC3A203001BF, 0x0FBBAD1F61042279, 0xE83A908FF2FB60CA, 0x0D7E765D58755C10, 0x1A083822CEAFE02D, 0x9605D5F0E25EC3B0, 0xD021FF5CD13A2ED5, 0x40BDF15D4A672E32, 0x011355146FD56395, 0x5DB4832046F3D9E5, 0x239F8B2D7FF719CC, 0x05D1A1AE85B49AA1, 0x679F848F6E8FC971, 0x7449BBFF801FED0B, 0x7D11CDB1C3B7ADF0, 0x82C7709E781EB7CC, 0xF3218F1C9510786C, 0x331478F3AF51BBE6, 0x4BB38DE5E7219443, 0xAA649C6EBCFD50FC, 0x8DBD98A352AFD40B, 0x87D2074B81D79217, 0x19F3C751D3E92AE1, 0xB4AB30F062B19ABF, 0x7B0500AC42047AC4, 0xC9452CA81A09D85D, 0x24AA6C514DA27500, 0x4C9F34427501B447, 0x14A68FD73C910841, 0xA71B9B83461CBD93, 0x03488B95B0F1850F, 0x637B2B34FF93C040, 0x09D1BC9A3DD90A94, 0x3575668334A1DD3B, 0x735E2B97A4C45A23, 0x18727070F1BD400B, 0x1FCBACD259BF02E7, 0xD310A7C2CE9B6555, 0xBF983FE0FE5D8244, 0x9F74D14F7454A824, 0x51EBDC4AB9BA3035, 0x5C82C505DB9AB0FA, 0xFCF7FE8A3430B241, 0x3253A729B9BA3DDE, 0x8C74C368081B3075, 0xB9BC6C87167C33E7, 0x7EF48F2B83024E20, 0x11D505D4C351BD7F, 0x6568FCA92C76A243, 0x4DE0B0F40F32A7B8, 0x96D693460CC37E5D, 0x42E240CB63689F2F, 0x6D2BDCDAE2919661, 0x42880B0236E4D951, 0x5F0F4A5898171BB6, 0x39F890F579F92F88, 0x93C5B5F47356388B, 0x63DC359D8D231B78, 0xEC16CA8AEA98AD76, 0x5355F900C2A82DC7, 0x07FB9F855A997142, 0x5093417AA8A7ED5E, 0x7BCBC38DA25A7F3C, 0x19FC8A768CF4B6D4, 0x637A7780DECFC0D9, 0x8249A47AEE0E41F7, 0x79AD695501E7D1E8, 0x14ACBAF4777D5776, 0xF145B6BECCDEA195, 0xDABF2AC8201752FC, 0x24C3C94DF9C8D3F6, 0xBB6E2924F03912EA, 0x0CE26C0B95C980D9, 0xA49CD132BFBF7CC4, 0xE99D662AF4243939, 0x27E6AD7891165C3F, 0x8535F040B9744FF1, 0x54B3F4FA5F40D873, 0x72B12C32127FED2B, 0xEE954D3C7B411F47, 0x9A85AC909A24EAA1, 0x70AC4CD9F04F21F5, 0xF9B89D3E99A075C2, 0x87B3E2B2B5C907B1, 0xA366E5B8C54F48B8, 0xAE4A9346CC3F7CF2, 0x1920C04D47267BBD, 0x87BF02C6B49E2AE9, 0x092237AC237F3859, 0xFF07F64EF8ED14D0, 0x8DE8DCA9F03CC54E, 0x9C1633264DB49C89, 0xB3F22C3D0B0B38ED, 0x390E5FB44D01144B, 0x5BFEA5B4712768E9, 0x1E1032911FA78984, 0x9A74ACB964E78CB3, 0x4F80F7A035DAFB04, 0x6304D09A0B3738C4, 0x2171E64683023A08, 0x5B9B63EB9CEFF80C, 0x506AACF489889342, 0x1881AFC9A3A701D6, 0x6503080440750644, 0xDFD395339CDBF4A7, 0xEF927DBCF00C20F2, 0x7B32F7D1E03680EC, 0xB9FD7620E7316243, 0x05A7E8A57DB91B77, 0xB5889C6E15630A75, 0x4A750A09CE9573F7, 0xCF464CEC899A2F8A, 0xF538639CE705B824, 0x3C79A0FF5580EF7F, 0xEDE6C87F8477609D, 0x799E81F05BC93F31, 0x86536B8CF3428A8C, 0x97D7374C60087B73, 0xA246637CFF328532, 0x043FCAE60CC0EBA0, 0x920E449535DD359E, 0x70EB093B15B290CC, 0x73A1921916591CBD, 0x56436C9FE1A1AA8D, 0xEFAC4B70633B8F81, 0xBB215798D45DF7AF, 0x45F20042F24F1768, 0x930F80F4E8EB7462, 0xFF6712FFCFD75EA1, 0xAE623FD67468AA70, 0xDD2C5BC84BC8D8FC, 0x7EED120D54CF2DD9, 0x22FE545401165F1C, 0xC91800E98FB99929, 0x808BD68E6AC10365, 0xDEC468145B7605F6, 0x1BEDE3A3AEF53302, 0x43539603D6C55602, 0xAA969B5C691CCB7A, 0xA87832D392EFEE56, 0x65942C7B3C7E11AE, 0xDED2D633CAD004F6, 0x21F08570F420E565, 0xB415938D7DA94E3C, 0x91B859E59ECB6350, 0x10CFF333E0ED804A, 0x28AED140BE0BB7DD, 0xC5CC1D89724FA456, 0x5648F680F11A2741, 0x2D255069F0B7DAB3, 0x9BC5A38EF729ABD4, 0xEF2F054308F6A2BC, 0xAF2042F5CC5C2858, 0x480412BAB7F5BE2A, 0xAEF3AF4A563DFE43, 0x19AFE59AE451497F, 0x52593803DFF1E840, 0xF4F076E65F2CE6F0, 0x11379625747D5AF3, 0xBCE5D2248682C115, 0x9DA4243DE836994F, 0x066F70B33FE09017, 0x4DC4DE189B671A1C, 0x51039AB7712457C3, 0xC07A3F80C31FB4B4, 0xB46EE9C5E64A6E7C, 0xB3819A42ABE61C87, 0x21A007933A522A20, 0x2DF16F761598AA4F, 0x763C4A1371B368FD, 0xF793C46702E086A0, 0xD7288E012AEB8D31, 0xDE336A2A4BC1C44B, 0x0BF692B38D079F23, 0x2C604A7A177326B3, 0x4850E73E03EB6064, 0xCFC447F1E53C8E1B, 0xB05CA3F564268D99, 0x9AE182C8BC9474E8, 0xA4FC4BD4FC5558CA, 0xE755178D58FC4E76, 0x69B97DB1A4C03DFE, 0xF9B5B7C4ACC67C96, 0xFC6A82D64B8655FB, 0x9C684CB6C4D24417, 0x8EC97D2917456ED0, 0x6703DF9D2924E97E, 0xC547F57E42A7444E, 0x78E37644E7CAD29E, 0xFE9A44E9362F05FA, 0x08BD35CC38336615, 0x9315E5EB3A129ACE, 0x94061B871E04DF75, 0xDF1D9F9D784BA010, 0x3BBA57B68871B59D, 0xD2B7ADEEDED1F73F, 0xF7A255D83BC373F8, 0xD7F4F2448C0CEB81, 0xD95BE88CD210FFA7, 0x336F52F8FF4728E7, 0xA74049DAC312AC71, 0xA2F61BB6E437FDB5, 0x4F2A5CB07F6A35B3, 0x87D380BDA5BF7859, 0x16B9F7E06C453A21, 0x7BA2484C8A0FD54E, 0xF3A678CAD9A2E38C, 0x39B0BF7DDE437BA2, 0xFCAF55C1BF8A4424, 0x18FCF680573FA594, 0x4C0563B89F495AC3, 0x40E087931A00930D, 0x8CFFA9412EB642C1, 0x68CA39053261169F, 0x7A1EE967D27579E2, 0x9D1D60E5076F5B6F, 0x3810E399B6F65BA2, 0x32095B6D4AB5F9B1, 0x35CAB62109DD038A, 0xA90B24499FCFAFB1, 0x77A225A07CC2C6BD, 0x513E5E634C70E331, 0x4361C0CA3F692F12, 0xD941ACA44B20A45B, 0x528F7C8602C5807B, 0x52AB92BEB9613989, 0x9D1DFA2EFC557F73, 0x722FF175F572C348, 0x1D1260A51107FE97, 0x7A249A57EC0C9BA2, 0x04208FE9E8F7F2D6, 0x5A110C6058B920A0, 0x0CD9A497658A5698, 0x56FD23C8F9715A4C, 0x284C847B9D887AAE, 0x04FEABFBBDB619CB, 0x742E1E651C60BA83, 0x9A9632E65904AD3C, 0x881B82A13B51B9E2, 0x506E6744CD974924, 0xB0183DB56FFC6A79, 0x0ED9B915C66ED37E, 0x5E11E86D5873D484, 0xF678647E3519AC6E, 0x1B85D488D0F20CC5, 0xDAB9FE6525D89021, 0x0D151D86ADB73615, 0xA865A54EDCC0F019, 0x93C42566AEF98FFB, 0x99E7AFEABE000731, 0x48CBFF086DDF285A, 0x7F9B6AF1EBF78BAF, 0x58627E1A149BBA21, 0x2CD16E2ABD791E33, 0xD363EFF5F0977996, 0x0CE2A38C344A6EED, 0x1A804AADB9CFA741, 0x907F30421D78C5DE, 0x501F65EDB3034D07, 0x37624AE5A48FA6E9, 0x957BAF61700CFF4E, 0x3A6C27934E31188A, 0xD49503536ABCA345, 0x088E049589C432E0, 0xF943AEE7FEBF21B8, 0x6C3B8E3E336139D3, 0x364F6FFA464EE52E, 0xD60F6DCEDC314222, 0x56963B0DCA418FC0, 0x16F50EDF91E513AF, 0xEF1955914B609F93, 0x565601C0364E3228, 0xECB53939887E8175, 0xBAC7A9A18531294B, 0xB344C470397BBA52, 0x65D34954DAF3CEBD, 0xB4B81B3FA97511E2, 0xB422061193D6F6A7, 0x071582401C38434D, 0x7A13F18BBEDC4FF5, 0xBC4097B116C524D2, 0x59B97885E2F2EA28, 0x99170A5DC3115544, 0x6F423357E7C6A9F9, 0x325928EE6E6F8794, 0xD0E4366228B03343, 0x565C31F7DE89EA27, 0x30F5611484119414, 0xD873DB391292ED4F, 0x7BD94E1D8E17DEBC, 0xC7D9F16864A76E94, 0x947AE053EE56E63C, 0xC8C93882F9475F5F, 0x3A9BF55BA91F81CA, 0xD9A11FBB3D9808E4, 0x0FD22063EDC29FCA, 0xB3F256D8ACA0B0B9, 0xB03031A8B4516E84, 0x35DD37D5871448AF, 0xE9F6082B05542E4E, 0xEBFAFA33D7254B59, 0x9255ABB50D532280, 0xB9AB4CE57F2D34F3, 0x693501D628297551, 0xC62C58F97DD949BF, 0xCD454F8F19C5126A, 0xBBE83F4ECC2BDECB, 0xDC842B7E2819E230, 0xBA89142E007503B8, 0xA3BC941D0A5061CB, 0xE9F6760E32CD8021, 0x09C7E552BC76492F, 0x852F54934DA55CC9, 0x8107FCCF064FCF56, 0x098954D51FFF6580, 0x23B70EDB1955C4BF, 0xC330DE426430F69D, 0x4715ED43E8A45C0A, 0xA8D7E4DAB780A08D, 0x0572B974F03CE0BB, 0xB57D2E985E1419C7, 0xE8D9ECBE2CF3D73F, 0x2FE4B17170E59750, 0x11317BA87905E790, 0x7FBF21EC8A1F45EC, 0x1725CABFCB045B00, 0x964E915CD5E2B207, 0x3E2B8BCBF016D66D, 0xBE7444E39328A0AC, 0xF85B2B4FBCDE44B7, 0x49353FEA39BA63B1, 0x1DD01AAFCD53486A, 0x1FCA8A92FD719F85, 0xFC7C95D827357AFA, 0x18A6A990C8B35EBD, 0xCCCB7005C6B9C28D, 0x3BDBB92C43B17F26, 0xAA70B5B4F89695A2, 0xE94C39A54A98307F, 0xB7A0B174CFF6F36E, 0xD4DBA84729AF48AD, 0x2E18BC1AD9704A68, 0x2DE0966DAF2F8B1C, 0xB9C11D5B1E43A07E, 0x64972D68DEE33360, 0x94628D38D0C20584, 0xDBC0D2B6AB90A559, 0xD2733C4335C6A72F, 0x7E75D99D94A70F4D, 0x6CED1983376FA72B, 0x97FCAACBF030BC24, 0x7B77497B32503B12, 0x8547EDDFB81CCB94, 0x79999CDFF70902CB, 0xCFFE1939438E9B24, 0x829626E3892D95D7, 0x92FAE24291F2B3F1, 0x63E22C147B9C3403, 0xC678B6D860284A1C, 0x5873888850659AE7, 0x0981DCD296A8736D, 0x9F65789A6509A440, 0x9FF38FED72E9052F, 0xE479EE5B9930578C, 0xE7F28ECD2D49EECD, 0x56C074A581EA17FE, 0x5544F7D774B14AEF, 0x7B3F0195FC6F290F, 0x12153635B2C0CF57, 0x7F5126DBBA5E0CA7, 0x7A76956C3EAFB413, 0x3D5774A11D31AB39, 0x8A1B083821F40CB4, 0x7B4A38E32537DF62, 0x950113646D1D6E03, 0x4DA8979A0041E8A9, 0x3BC36E078F7515D7, 0x5D0A12F27AD310D1, 0x7F9D1A2E1EBE1327, 0xDA3A361B1C5157B1, 0xDCDD7D20903D0C25, 0x36833336D068F707, 0xCE68341F79893389, 0xAB9090168DD05F34, 0x43954B3252DC25E5, 0xB438C2B67F98E5E9, 0x10DCD78E3851A492, 0xDBC27AB5447822BF, 0x9B3CDB65F82CA382, 0xB67B7896167B4C84, 0xBFCED1B0048EAC50, 0xA9119B60369FFEBD, 0x1FFF7AC80904BF45, 0xAC12FB171817EEE7, 0xAF08DA9177DDA93D, 0x1B0CAB936E65C744, 0xB559EB1D04E5E932, 0xC37B45B3F8D6F2BA, 0xC3A9DC228CAAC9E9, 0xF3B8B6675A6507FF, 0x9FC477DE4ED681DA, 0x67378D8ECCEF96CB, 0x6DD856D94D259236, 0xA319CE15B0B4DB31, 0x073973751F12DD5E, 0x8A8E849EB32781A5, 0xE1925C71285279F5, 0x74C04BF1790C0EFE, 0x4DDA48153C94938A, 0x9D266D6A1CC0542C, 0x7440FB816508C4FE, 0x13328503DF48229F, 0xD6BF7BAEE43CAC40, 0x4838D65F6EF6748F, 0x1E152328F3318DEA, 0x8F8419A348F296BF, 0x72C8834A5957B511, 0xD7A023A73260B45C, 0x94EBC8ABCFB56DAE, 0x9FC10D0F989993E0, 0xDE68A2355B93CAE6, 0xA44CFE79AE538BBE, 0x9D1D84FCCE371425, 0x51D2B1AB2DDFB636, 0x2FD7E4B9E72CD38C, 0x65CA5B96B7552210, 0xDD69A0D8AB3B546D, 0x604D51B25FBF70E2, 0x73AA8A564FB7AC9E, 0x1A8C1E992B941148, 0xAAC40A2703D9BEA0, 0x764DBEAE7FA4F3A6, 0x1E99B96E70A9BE8B, 0x2C5E9DEB57EF4743, 0x3A938FEE32D29981, 0x26E6DB8FFDF5ADFE, 0x469356C504EC9F9D, 0xC8763C5B08D1908C, 0x3F6C6AF859D80055, 0x7F7CC39420A3A545, 0x9BFB227EBDF4C5CE, 0x89039D79D6FC5C5C, 0x8FE88B57305E2AB6, 0xA09E8C8C35AB96DE, 0xFA7E393983325753, 0xD6B6D0ECC617C699, 0xDFEA21EA9E7557E3, 0xB67C1FA481680AF8, 0xCA1E3785A9E724E5, 0x1CFC8BED0D681639, 0xD18D8549D140CAEA, 0x4ED0FE7E9DC91335, 0xE4DBF0634473F5D2, 0x1761F93A44D5AEFE, 0x53898E4C3910DA55, 0x734DE8181F6EC39A, 0x2680B122BAA28D97, 0x298AF231C85BAFAB, 0x7983EED3740847D5, 0x66C1A2A1A60CD889, 0x9E17E49642A3E4C1, 0xEDB454E7BADC0805, 0x50B704CAB602C329, 0x4CC317FB9CDDD023, 0x66B4835D9EAFEA22, 0x219B97E26FFC81BD, 0x261E4E4C0A333A9D, 0x1FE2CCA76517DB90, 0xD7504DFA8816EDBB, 0xB9571FA04DC089C8, 0x1DDC0325259B27DE, 0xCF3F4688801EB9AA, 0xF4F5D05C10CAB243, 0x38B6525C21A42B0E, 0x36F60E2BA4FA6800, 0xEB3593803173E0CE, 0x9C4CD6257C5A3603, 0xAF0C317D32ADAA8A, 0x258E5A80C7204C4B, 0x8B889D624D44885D, 0xF4D14597E660F855, 0xD4347F66EC8941C3, 0xE699ED85B0DFB40D, 0x2472F6207C2D0484, 0xC2A1E7B5B459AEB5, 0xAB4F6451CC1D45EC, 0x63767572AE3D6174, 0xA59E0BD101731A28, 0x116D0016CB948F09, 0x2CF9C8CA052F6E9F, 0x0B090A7560A968E3, 0xABEEDDB2DDE06FF1, 0x58EFC10B06A2068D, 0xC6E57A78FBD986E0, 0x2EAB8CA63CE802D7, 0x14A195640116F336, 0x7C0828DD624EC390, 0xD74BBE77E6116AC7, 0x804456AF10F5FB53, 0xEBE9EA2ADF4321C7, 0x03219A39EE587A30, 0x49787FEF17AF9924, 0xA1E9300CD8520548, 0x5B45E522E4B1B4EF, 0xB49C3B3995091A36, 0xD4490AD526F14431, 0x12A8F216AF9418C2, 0x001F837CC7350524, 0x1877B51E57A764D5, 0xA2853B80F17F58EE, 0x993E1DE72D36D310, 0xB3598080CE64A656, 0x252F59CF0D9F04BB, 0xD23C8E176D113600, 0x1BDA0492E7E4586E, 0x21E0BD5026C619BF, 0x3B097ADAF088F94E, 0x8D14DEDB30BE846E, 0xF95CFFA23AF5F6F4, 0x3871700761B3F743, 0xCA672B91E9E4FA16, 0x64C8E531BFF53B55, 0x241260ED4AD1E87D, 0x106C09B972D2E822, 0x7FBA195410E5CA30, 0x7884D9BC6CB569D8, 0x0647DFEDCD894A29, 0x63573FF03E224774, 0x4FC8E9560F91B123, 0x1DB956E450275779, 0xB8D91274B9E9D4FB, 0xA2EBEE47E2FBFCE1, 0xD9F1F30CCD97FB09, 0xEFED53D75FD64E6B, 0x2E6D02C36017F67F, 0xA9AA4D20DB084E9B, 0xB64BE8D8B25396C1, 0x70CB6AF7C2D5BCF0, 0x98F076A4F7A2322E, 0xBF84470805E69B5F, 0x94C3251F06F90CF3, 0x3E003E616A6591E9, 0xB925A6CD0421AFF3, 0x61BDD1307C66E300, 0xBF8D5108E27E0D48, 0x240AB57A8B888B20, 0xFC87614BAF287E07, 0xEF02CDD06FFDB432, 0xA1082C0466DF6C0A, 0x8215E577001332C8, 0xD39BB9C3A48DB6CF, 0x2738259634305C14, 0x61CF4F94C97DF93D, 0x1B6BACA2AE4E125B, 0x758F450C88572E0B, 0x959F587D507A8359, 0xB063E962E045F54D, 0x60E8ED72C0DFF5D1, 0x7B64978555326F9F, 0xFD080D236DA814BA, 0x8C90FD9B083F4558, 0x106F72FE81E2C590, 0x7976033A39F7D952, 0xA4EC0132764CA04B, 0x733EA705FAE4FA77, 0xB4D8F77BC3E56167, 0x9E21F4F903B33FD9, 0x9D765E419FB69F6D, 0xD30C088BA61EA5EF, 0x5D94337FBFAF7F5B, 0x1A4E4822EB4D7A59, 0x6FFE73E81B637FB3, 0xDDF957BC36D8B9CA, 0x64D0E29EEA8838B3, 0x08DD9BDFD96B9F63, 0x087E79E5A57D1D13, 0xE328E230E3E2B3FB, 0x1C2559E30F0946BE, 0x720BF5F26F4D2EAA, 0xB0774D261CC609DB, 0x443F64EC5A371195, 0x4112CF68649A260E, 0xD813F2FAB7F5C5CA, 0x660D3257380841EE, 0x59AC2C7873F910A3, 0xE846963877671A17, 0x93B633ABFA3469F8, 0xC0C0F5A60EF4CDCF, 0xCAF21ECD4377B28C, 0x57277707199B8175, 0x506C11B9D90E8B1D, 0xD83CC2687A19255F, 0x4A29C6465A314CD1, 0xED2DF21216235097, 0xB5635C95FF7296E2, 0x22AF003AB672E811, 0x52E762596BF68235, 0x9AEBA33AC6ECC6B0, 0x944F6DE09134DFB6, 0x6C47BEC883A7DE39, 0x6AD047C430A12104, 0xA5B1CFDBA0AB4067, 0x7C45D833AFF07862, 0x5092EF950A16DA0B, 0x9338E69C052B8E7B, 0x455A4B4CFE30E3F5, 0x6B02E63195AD0CF8, 0x6B17B224BAD6BF27, 0xD1E0CCD25BB9C169, 0xDE0C89A556B9AE70, 0x50065E535A213CF6, 0x9C1169FA2777B874, 0x78EDEFD694AF1EED, 0x6DC93D9526A50E68, 0xEE97F453F06791ED, 0x32AB0EDB696703D3, 0x3A6853C7E70757A7, 0x31865CED6120F37D, 0x67FEF95D92607890, 0x1F2B1D1F15F6DC9C, 0xB69E38A8965C6B65, 0xAA9119FF184CCCF4, 0xF43C732873F24C13, 0xFB4A3D794A9A80D2, 0x3550C2321FD6109C, 0x371F77E76BB8417E, 0x6BFA9AAE5EC05779, 0xCD04F3FF001A4778, 0xE3273522064480CA, 0x9F91508BFFCFC14A, 0x049A7F41061A9E60, 0xFCB6BE43A9F2FE9B, 0x08DE8A1C7797DA9B, 0x8F9887E6078735A1, 0xB5B4071DBFC73A66, 0x230E343DFBA08D33, 0x43ED7F5A0FAE657D, 0x3A88A0FBBCB05C63, 0x21874B8B4D2DBC4F, 0x1BDEA12E35F6A8C9, 0x53C065C6C8E63528, 0xE34A1D250E7A8D6B, 0xD6B04D3B7651DD7E, 0x5E90277E7CB39E2D, 0x2C046F22062DC67D, 0xB10BB459132D0A26, 0x3FA9DDFB67E2F199, 0x0E09B88E1914F7AF, 0x10E8B35AF3EEAB37, 0x9EEDECA8E272B933, 0xD4C718BC4AE8AE5F, 0x81536D601170FC20, 0x91B534F885818A06, 0xEC8177F83F900978, 0x190E714FADA5156E, 0xB592BF39B0364963, 0x89C350C893AE7DC1, 0xAC042E70F8B383F2, 0xB49B52E587A1EE60, 0xFB152FE3FF26DA89, 0x3E666E6F69AE2C15, 0x3B544EBE544C19F9, 0xE805A1E290CF2456, 0x24B33C9D7ED25117, 0xE74733427B72F0C1, 0x0A804D18B7097475, 0x57E3306D881EDB4F, 0x4AE7D6A36EB5DBCB, 0x2D8D5432157064C8, 0xD1E649DE1E7F268B, 0x8A328A1CEDFE552C, 0x07A3AEC79624C7DA, 0x84547DDC3E203C94, 0x990A98FD5071D263, 0x1A4FF12616EEFC89, 0xF6F7FD1431714200, 0x30C05B1BA332F41C, 0x8D2636B81555A786, 0x46C9FEB55D120902, 0xCCEC0A73B49C9921, 0x4E9D2827355FC492, 0x19EBB029435DCB0F, 0x4659D2B743848A2C, 0x963EF2C96B33BE31, 0x74F85198B05A2E7D, 0x5A0F544DD2B1FB18, 0x03727073C2E134B1, 0xC7F6AA2DE59AEA61, 0x352787BAA0D7C22F, 0x9853EAB63B5E0B35, 0xABBDCDD7ED5C0860, 0xCF05DAF5AC8D77B0, 0x49CAD48CEBF4A71E, 0x7A4C10EC2158C4A6, 0xD9E92AA246BF719E, 0x13AE978D09FE5557, 0x730499AF921549FF, 0x4E4B705B92903BA4, 0xFF577222C14F0A3A, 0x55B6344CF97AAFAE, 0xB862225B055B6960, 0xCAC09AFBDDD2CDB4, 0xDAF8E9829FE96B5F, 0xB5FDFC5D3132C498, 0x310CB380DB6F7503, 0xE87FBB46217A360E, 0x2102AE466EBB1148, 0xF8549E1A3AA5E00D, 0x07A69AFDCC42261A, 0xC4C118BFE78FEAAE, 0xF9F4892ED96BD438, 0x1AF3DBE25D8F45DA, 0xF5B4B0B0D2DEEEB4, 0x962ACEEFA82E1C84, 0x046E3ECAAF453CE9, 0xF05D129681949A4C, 0x964781CE734B3C84, 0x9C2ED44081CE5FBD, 0x522E23F3925E319E, 0x177E00F9FC32F791, 0x2BC60A63A6F3B3F2, 0x222BBFAE61725606, 0x486289DDCC3D6780, 0x7DC7785B8EFDFC80, 0x8AF38731C02BA980, 0x1FAB64EA29A2DDF7, 0xE4D9429322CD065A, 0x9DA058C67844F20C, 0x24C0E332B70019B0, 0x233003B5A6CFE6AD, 0xD586BD01C5C217F6, 0x5E5637885F29BC2B, 0x7EBA726D8C94094B, 0x0A56A5F0BFE39272, 0xD79476A84EE20D06, 0x9E4C1269BAA4BF37, 0x17EFEE45B0DEE640, 0x1D95B0A5FCF90BC6, 0x93CBE0B699C2585D, 0x65FA4F227A2B6D79, 0xD5F9E858292504D5, 0xC2B5A03F71471A6F, 0x59300222B4561E00, 0xCE2F8642CA0712DC, 0x7CA9723FBB2E8988, 0x2785338347F2BA08, 0xC61BB3A141E50E8C, 0x150F361DAB9DEC26, 0x9F6A419D382595F4, 0x64A53DC924FE7AC9, 0x142DE49FFF7A7C3D, 0x0C335248857FA9E7, 0x0A9C32D5EAE45305, 0xE6C42178C4BBB92E, 0x71F1CE2490D20B07, 0xF1BCC3D275AFE51A, 0xE728E8C83C334074, 0x96FBF83A12884624, 0x81A1549FD6573DA5, 0x5FA7867CAF35E149, 0x56986E2EF3ED091B, 0x917F1DD5F8886C61, 0xD20D8C88C8FFE65F, 0x31D71DCE64B2C310, 0xF165B587DF898190, 0xA57E6339DD2CF3A0, 0x1EF6E6DBB1961EC9, 0x70CC73D90BC26E24, 0xE21A6B35DF0C3AD7, 0x003A93D8B2806962, 0x1C99DED33CB890A1, 0xCF3145DE0ADD4289, 0xD0E4427A5514FB72, 0x77C621CC9FB3A483, 0x67A34DAC4356550B, 0xF8D626AAAF278509};


	  /// Indices to the Random64[] array

	  public static final int RandomPiece = 0;
	  public static final int RandomCastle = 768;
	  public static final int RandomEnPassant = 772;
	  public static final int RandomTurn = 780;


	  /// Convert pieces to the range 0..1

	  public static final int[] PieceTo12 = {0, 0, 2, 4, 6, 8, 10, 0, 0, 1, 3, 5, 7, 9, 11};


	  /// Prototypes

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long book_key(const Position &pos);
	  public static long book_key(Position pos)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long result = 0ULL;
		long result = 0;

		for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
		{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = pos.pieces_of_color(c);
		  long b = pos.pieces_of_color(c);
		  Square s;
		  Piece p;
		  while (b != EmptyBoardBB)
		  {
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
			s = pop_1st_bit(tempRef_b);
			b = tempRef_b.argValue;
			p = pos.piece_on(s);
			assert piece_is_ok(p);
			assert color_of_piece(p) == c;

			result ^= book_piece_key(p, s);
		  }
		}

		result ^= book_castle_key(pos);
		result ^= book_ep_key(pos);
		result ^= book_color_key(pos);

		return result;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long book_piece_key(Piece p, Square s);
	  public static long book_piece_key(Piece p, Square s)
	  {
		return Random64[RandomPiece + (PieceTo12[p.getValue()] ^ 1) * 64 + s.getValue()];
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long book_castle_key(const Position &pos);
	  public static long book_castle_key(Position pos)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long result = 0ULL;
		long result = 0;

		if (pos.can_castle_kingside(Color.WHITE))
		{
		  result ^= Random64[RandomCastle+0];
		}
		if (pos.can_castle_queenside(Color.WHITE))
		{
		  result ^= Random64[RandomCastle+1];
		}
		if (pos.can_castle_kingside(Color.BLACK))
		{
		  result ^= Random64[RandomCastle+2];
		}
		if (pos.can_castle_queenside(Color.BLACK))
		{
		  result ^= Random64[RandomCastle+3];
		}
		return result;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long book_ep_key(const Position &pos);
	  public static long book_ep_key(Position pos)
	  {
		return (pos.ep_square() == Square.SQ_NONE)? 0 : Random64[RandomEnPassant + square_file(pos.ep_square()).getValue()];
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long book_color_key(const Position &pos);
	  public static long book_color_key(Position pos)
	  {
		return (pos.side_to_move() == Color.WHITE)? Random64[RandomTurn] : 0;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long read_integer(FILE *file, int size);
	  public static long read_integer(FILE file, int size)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long n = 0ULL;
		long n = 0;
		int i;
		int b;

		assert file != null;
		assert size > 0 && size <= 8;

		for (i = 0; i < size; i++)
		{
		  b = fgetc(file);
		  if (b == EOF)
		  {
			std::cerr << "Failed to read " << size << " bytes from book file" << std::endl;
			System.exit(1);
		  }
		  assert b >= 0 && b < 256;
		  n = (long)((n << 8) | b);
		}
		return n;
	  }


	////
	//// Inline functions
	////

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Color operator + (Color c, int i)
	{
		return Color(c.getValue() + i);
	}
	private void increment (tangible.RefObject<Color> c, int i)
	{
		c.argValue = Color(c.argValue.getValue() + 1);
	}

	public static Color opposite_color(Color c)
	{
	  return Color(c.getValue() ^ 1);
	}

////
//// Functions
////

/// color_is_ok(), for debugging:



	////
	//// Prototypes
	////

	public static boolean color_is_ok(Color c)
	{
	  return c == Color.WHITE || c == Color.BLACK;
	}




	////
	//// Variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned char DirectionTable[64][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern byte DirectionTable[64][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned char SignedDirectionTable[64][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern byte SignedDirectionTable[64][64];


	////
	//// Inline functions
	////

	private void increment (tangible.RefObject<Direction> d, int UnnamedParameter)
	{
		d.argValue = Direction(d.argValue.getValue() + 1);
	}

	private void increment (tangible.RefObject<SignedDirection> d, int UnnamedParameter)
	{
	  d.argValue = SignedDirection(d.argValue.getValue() + 1);
	}

	public static Direction direction_between_squares(Square s1, Square s2)
	{
	  return Direction(DirectionTable[s1.getValue()][s2.getValue()]);
	}

	public static SignedDirection signed_direction_between_squares(Square s1, Square s2)
	{
	  return SignedDirection(SignedDirectionTable[s1.getValue()][s2.getValue()]);
	}

////
//// Functions
////



	////
	//// Prototypes
	////

	public static void init_direction_table()
	{
	  SquareDelta[] deltas = {SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_S, SquareDelta.DELTA_NE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NW, SquareDelta.DELTA_SE};
	  for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_H8.getValue(); s1++)
	  {
		for (Square s2 = Square.SQ_A1; s2.getValue() <= Square.SQ_H8.getValue(); s2++)
		{
		  DirectionTable[s1.getValue()][s2.getValue()] = uint8_t(Direction.DIR_NONE);
		  SignedDirectionTable[s1.getValue()][s2.getValue()] = uint8_t(SignedDirection.SIGNED_DIR_NONE);
		  if (s1 == s2)
		  {
			  continue;
		  }
		  for (SignedDirection d = SignedDirection.SIGNED_DIR_E; d.getValue() <= SignedDirection.SIGNED_DIR_SE.getValue(); d++)
		  {
			SquareDelta delta = deltas[d.getValue()];
			Square s3;
			Square s4;
			for (s4 = s1 + delta, s3 = s1; square_distance(s4, s3) == 1 && s4 != s2 && square_is_ok(s4); s3 = s4, s4 += delta)
			{
				;
			}
			if (s4 == s2 && square_distance(s4, s3) == 1)
			{
			  SignedDirectionTable[s1.getValue()][s2.getValue()] = uint8_t(d);
			  DirectionTable[s1.getValue()][s2.getValue()] = uint8_t(d / 2);
			  break;
			}
		  }
		}
	  }
	}





	////
	//// Variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char DirectionTable[64][64];
	public static byte[][] DirectionTable = new byte[64][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char SignedDirectionTable[64][64];
	public static byte[][] SignedDirectionTable = new byte[64][64];



	////
	//// Constants and variables
	////

	// Generic "mate lone king" eval:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KXKEvaluationFunction EvaluateKXK, EvaluateKKX;

	// KBN vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBNKEvaluationFunction EvaluateKBNK, EvaluateKKBN;

	// KP vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KPKEvaluationFunction EvaluateKPK, EvaluateKKP;

	// KR vs KP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRKPEvaluationFunction EvaluateKRKP, EvaluateKPKR;

	// KR vs KB:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRKBEvaluationFunction EvaluateKRKB, EvaluateKBKR;

	// KR vs KN:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRKNEvaluationFunction EvaluateKRKN, EvaluateKNKR;

	// KQ vs KR:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KQKREvaluationFunction EvaluateKQKR, EvaluateKRKQ;

	// KBB vs KN:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBBKNEvaluationFunction EvaluateKBBKN, EvaluateKNKBB;

	// K and two minors vs K and one or two minors:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KmmKmEvaluationFunction EvaluateKmmKm;


	// KBP vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBPKScalingFunction ScaleKBPK, ScaleKKBP;

	// KQ vs KRP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KQKRPScalingFunction ScaleKQKRP, ScaleKRPKQ;

	// KRP vs KR:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRPKRScalingFunction ScaleKRPKR, ScaleKRKRP;

	// KRPP vs KRP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRPPKRPScalingFunction ScaleKRPPKRP, ScaleKRPKRPP;

	// King and pawns vs king:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KPsKScalingFunction ScaleKPsK, ScaleKKPs;

	// KBP vs KB:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBPKBScalingFunction ScaleKBPKB, ScaleKBKBP;

	// KBP vs KN:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBPKNScalingFunction ScaleKBPKN, ScaleKNKBP;

	// KNP vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KNPKScalingFunction ScaleKNPK, ScaleKKNP;

	// KP vs KP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KPKPScalingFunction ScaleKPKPw, ScaleKPKPb;

/// init_bitbases() is called during program initialization, and simply loads
/// bitbases from disk into memory.  At the moment, there is only the bitbase
/// for KP vs K, but we may decide to add other bitbases later.



	////
	//// Prototypes
	////

	public static void init_bitbases()
	{
	  generate_kpk_bitbase(KPKBitbase);
	}





	////
	//// Constants and variables
	////

	/// Evaluation functions

	// Generic "mate lone king" eval:
	public static KXKEvaluationFunction EvaluateKXK = new KXKEvaluationFunction(Color.WHITE);
	public static KXKEvaluationFunction EvaluateKKX = new KXKEvaluationFunction(Color.BLACK);

	// KBN vs K:
	public static KBNKEvaluationFunction EvaluateKBNK = new KBNKEvaluationFunction(Color.WHITE);
	public static KBNKEvaluationFunction EvaluateKKBN = new KBNKEvaluationFunction(Color.BLACK);

	// KP vs K:
	public static KPKEvaluationFunction EvaluateKPK = new KPKEvaluationFunction(Color.WHITE);
	public static KPKEvaluationFunction EvaluateKKP = new KPKEvaluationFunction(Color.BLACK);

	// KR vs KP:
	public static KRKPEvaluationFunction EvaluateKRKP = new KRKPEvaluationFunction(Color.WHITE);
	public static KRKPEvaluationFunction EvaluateKPKR = new KRKPEvaluationFunction(Color.BLACK);

	// KR vs KB:
	public static KRKBEvaluationFunction EvaluateKRKB = new KRKBEvaluationFunction(Color.WHITE);
	public static KRKBEvaluationFunction EvaluateKBKR = new KRKBEvaluationFunction(Color.BLACK);

	// KR vs KN:
	public static KRKNEvaluationFunction EvaluateKRKN = new KRKNEvaluationFunction(Color.WHITE);
	public static KRKNEvaluationFunction EvaluateKNKR = new KRKNEvaluationFunction(Color.BLACK);

	// KQ vs KR:
	public static KQKREvaluationFunction EvaluateKQKR = new KQKREvaluationFunction(Color.WHITE);
	public static KQKREvaluationFunction EvaluateKRKQ = new KQKREvaluationFunction(Color.BLACK);

	// KBB vs KN:
	public static KBBKNEvaluationFunction EvaluateKBBKN = new KBBKNEvaluationFunction(Color.WHITE);
	public static KBBKNEvaluationFunction EvaluateKNKBB = new KBBKNEvaluationFunction(Color.BLACK);

	// K and two minors vs K and one or two minors:
	public static KmmKmEvaluationFunction EvaluateKmmKm = new KmmKmEvaluationFunction(Color.WHITE);


	/// Scaling functions

	// KBP vs K:
	public static KBPKScalingFunction ScaleKBPK = new KBPKScalingFunction(Color.WHITE);
	public static KBPKScalingFunction ScaleKKBP = new KBPKScalingFunction(Color.BLACK);

	// KQ vs KRP:
	public static KQKRPScalingFunction ScaleKQKRP = new KQKRPScalingFunction(Color.WHITE);
	public static KQKRPScalingFunction ScaleKRPKQ = new KQKRPScalingFunction(Color.BLACK);

	// KRP vs KR:
	public static KRPKRScalingFunction ScaleKRPKR = new KRPKRScalingFunction(Color.WHITE);
	public static KRPKRScalingFunction ScaleKRKRP = new KRPKRScalingFunction(Color.BLACK);

	// KRPP vs KRP:
	public static KRPPKRPScalingFunction ScaleKRPPKRP = new KRPPKRPScalingFunction(Color.WHITE);
	public static KRPPKRPScalingFunction ScaleKRPKRPP = new KRPPKRPScalingFunction(Color.BLACK);

	// King and pawns vs king:
	public static KPsKScalingFunction ScaleKPsK = new KPsKScalingFunction(Color.WHITE);
	public static KPsKScalingFunction ScaleKKPs = new KPsKScalingFunction(Color.BLACK);

	// KBP vs KB:
	public static KBPKBScalingFunction ScaleKBPKB = new KBPKBScalingFunction(Color.WHITE);
	public static KBPKBScalingFunction ScaleKBKBP = new KBPKBScalingFunction(Color.BLACK);

	// KBP vs KN:
	public static KBPKNScalingFunction ScaleKBPKN = new KBPKNScalingFunction(Color.WHITE);
	public static KBPKNScalingFunction ScaleKNKBP = new KBPKNScalingFunction(Color.BLACK);

	// KNP vs K:
	public static KNPKScalingFunction ScaleKNPK = new KNPKScalingFunction(Color.WHITE);
	public static KNPKScalingFunction ScaleKKNP = new KNPKScalingFunction(Color.BLACK);

	// KPKP
	public static KPKPScalingFunction ScaleKPKPw = new KPKPScalingFunction(Color.WHITE);
	public static KPKPScalingFunction ScaleKPKPb = new KPKPScalingFunction(Color.BLACK);


	////
	//// Local definitions
	////


	  // Table used to drive the defending king towards the edge of the board
	  // in KX vs K and KQ vs KR endgames:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned char MateTable[64] = { 100, 90, 80, 70, 70, 80, 90, 100, 90, 70, 60, 50, 50, 60, 70, 90, 80, 60, 40, 30, 30, 40, 60, 80, 70, 50, 30, 20, 20, 30, 50, 70, 70, 50, 30, 20, 20, 30, 50, 70, 80, 60, 40, 30, 30, 40, 60, 80, 90, 70, 60, 50, 50, 60, 70, 90, 100, 90, 80, 70, 70, 80, 90, 100, };
	  public static final byte[] MateTable = {100, 90, 80, 70, 70, 80, 90, 100, 90, 70, 60, 50, 50, 60, 70, 90, 80, 60, 40, 30, 30, 40, 60, 80, 70, 50, 30, 20, 20, 30, 50, 70, 70, 50, 30, 20, 20, 30, 50, 70, 80, 60, 40, 30, 30, 40, 60, 80, 90, 70, 60, 50, 50, 60, 70, 90, 100, 90, 80, 70, 70, 80, 90, 100};

	  // Table used to drive the defending king towards a corner square of the
	  // right color in KBN vs K endgames:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned char KBNKMateTable[64] = { 200, 190, 180, 170, 160, 150, 140, 130, 190, 180, 170, 160, 150, 140, 130, 140, 180, 170, 155, 140, 140, 125, 140, 150, 170, 160, 140, 120, 110, 140, 150, 160, 160, 150, 140, 110, 120, 140, 160, 170, 150, 140, 125, 140, 140, 155, 170, 180, 140, 130, 140, 150, 160, 170, 180, 190, 130, 140, 150, 160, 170, 180, 190, 200 };
	  public static final byte[] KBNKMateTable = {(byte)200, (byte)190, (byte)180, (byte)170, (byte)160, (byte)150, (byte)140, (byte)130, (byte)190, (byte)180, (byte)170, (byte)160, (byte)150, (byte)140, (byte)130, (byte)140, (byte)180, (byte)170, (byte)155, (byte)140, (byte)140, 125, (byte)140, (byte)150, (byte)170, (byte)160, (byte)140, 120, 110, (byte)140, (byte)150, (byte)160, (byte)160, (byte)150, (byte)140, 110, 120, (byte)140, (byte)160, (byte)170, (byte)150, (byte)140, 125, (byte)140, (byte)140, (byte)155, (byte)170, (byte)180, (byte)140, (byte)130, (byte)140, (byte)150, (byte)160, (byte)170, (byte)180, (byte)190, (byte)130, (byte)140, (byte)150, (byte)160, (byte)170, (byte)180, (byte)190, (byte)200};

	  // The attacking side is given a descending bonus based on distance between
	  // the two kings in basic endgames:
	  public static final int[] DistanceBonus = {0, 0, 100, 80, 60, 40, 20, 10};

	  // Bitbase for KP vs K:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char KPKBitbase[24576];
	  public static byte[] KPKBitbase = new byte[24576];

	  // Penalty for big distance between king and knight for the defending king
	  // and knight in KR vs KN endgames:
	  public static final int[] KRKNKingKnightDistancePenalty = {0, 0, 4, 10, 20, 32, 48, 70};

	  // Various inline functions for accessing the above arrays:

	  public static Value mate_table(Square s)
	  {
		return Value(MateTable[s.getValue()]);
	  }

	  public static Value kbnk_mate_table(Square s)
	  {
		return Value(KBNKMateTable[s.getValue()]);
	  }

	  public static Value distance_bonus(int d)
	  {
		return Value(DistanceBonus[d]);
	  }

	  public static Value krkn_king_knight_distance_penalty(int d)
	  {
		return Value(KRKNKingKnightDistancePenalty[d]);
	  }

  // Probe the KP vs K bitbase:


	  // Function for probing the KP vs K bitbase:
	  public static int probe_kpk(Square wksq, Square wpsq, Square bksq, Color stm)
	  {
		int wp = square_file(wpsq).getValue() + (square_rank(wpsq).getValue() - 1) * 4;
		int index = stm.getValue() + 2 * bksq.getValue() + 128 * wksq.getValue() + 8192 * wp;

		assert index >= 0 && index < 24576 * 8;
		return KPKBitbase[index / 8] & (1 << (index & 7));
	  }

////
//// Functions
////

/// evaluate() is the main evaluation function.  It always computes two
/// values, an endgame score and a middle game score, and interpolates
/// between them based on the remaining material.



	////
	//// Prototypes
	////

	public static Value evaluate(Position pos, EvalInfo ei, int threadID)
	{
	  Color stm;
	  ScaleFactor[] factor = {ScaleFactor.SCALE_FACTOR_NORMAL, ScaleFactor.SCALE_FACTOR_NORMAL};
	  Phase phase;

//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	  memset(ei, 0, sizeof(EvalInfo));

	  assert pos.is_ok();
	  assert threadID >= 0 && threadID < THREAD_MAX;

	  stm = pos.side_to_move();

	  // Initialize by reading the incrementally updated scores included in the
	  // position object (material + piece square tables):
	  ei.mgValue = pos.mg_value();
	  ei.egValue = pos.eg_value();

	  // Probe the material hash table:
	  ei.mi = MaterialTable[threadID].get_material_info(pos);
	  ei.mgValue += ei.mi.mg_value();
	  ei.egValue += ei.mi.eg_value();

	  factor[Color.WHITE.getValue()] = ei.mi.scale_factor(pos, Color.WHITE);
	  factor[Color.BLACK.getValue()] = ei.mi.scale_factor(pos, Color.BLACK);

	  // If we have a specialized evaluation function for the current material
	  // configuration, call it and return:
	  if (ei.mi.specialized_eval_exists())
	  {
		return ei.mi.evaluate(pos);
	  }

	  phase = pos.game_phase();

	  // Probe the pawn hash table:
	  ei.pi = PawnTable[threadID].get_pawn_info(pos);
	  ei.mgValue += apply_weight(ei.pi.mg_value(), WeightPawnStructureMidgame);
	  ei.egValue += apply_weight(ei.pi.eg_value(), WeightPawnStructureEndgame);

	  // Initialize king attack bitboards and king attack zones for both sides:
	  ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()] = pos.king_attacks(pos.king_square(Color.WHITE));
	  ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()] = pos.king_attacks(pos.king_square(Color.BLACK));
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  ei.attackZone[Color.WHITE.getValue()] = ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()] | (ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()] >>> 8);
	  ei.attackZone[Color.BLACK.getValue()] = ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()] | (ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()] << 8);

	  // Initialize pawn attack bitboards for both sides:
	  ei.attackedBy[Color.WHITE.getValue()][PieceType.PAWN.getValue()] = ((pos.pawns(Color.WHITE) << 9) & ~FileABB) | ((pos.pawns(Color.WHITE) << 7) & ~FileHBB);
	  ei.attackCount[Color.WHITE.getValue()] += count_1s_max_15(ei.attackedBy[Color.WHITE.getValue()][PieceType.PAWN.getValue()] & ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()]) / 2;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  ei.attackedBy[Color.BLACK.getValue()][PieceType.PAWN.getValue()] = ((pos.pawns(Color.BLACK) >>> 7) & ~FileABB) | ((pos.pawns(Color.BLACK) >>> 9) & ~FileHBB);
	  ei.attackCount[Color.BLACK.getValue()] += count_1s_max_15(ei.attackedBy[Color.BLACK.getValue()][PieceType.PAWN.getValue()] & ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()]) / 2;

	  // Evaluate pieces:
	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;

		// Knights
		for (int i = 0; i < pos.knight_count(c); i++)
		{
		  evaluate_knight(pos, pos.knight_list(c, i), c, ei);
		}

		// Bishops
		for (int i = 0; i < pos.bishop_count(c); i++)
		{
		  evaluate_bishop(pos, pos.bishop_list(c, i), c, ei);
		}

		// Rooks
		for (int i = 0; i < pos.rook_count(c); i++)
		{
		  evaluate_rook(pos, pos.rook_list(c, i), c, ei);
		}

		// Queens
		for (int i = 0; i < pos.queen_count(c); i++)
		{
		  evaluate_queen(pos, pos.queen_list(c, i), c, ei);
		}

		// Some special patterns:

		// Trapped bishops on a7/h7/a2/h2
		b = pos.bishops(c) & MaskA7H7[c.getValue()];
		while (b != 0)
		{
	  tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
		  evaluate_trapped_bishop_a7h7(pos, pop_1st_bit(tempRef_b), c, ei);
		  b = tempRef_b.argValue;
		}

		// Trapped bishops on a1/h1/a8/h8 in Chess960:
		if (Chess960)
		{
		  b = pos.bishops(c) & MaskA1H1[c.getValue()];
		  while (b != 0)
		  {
	tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b);
		evaluate_trapped_bishop_a1h1(pos, pop_1st_bit(tempRef_b2), c, ei);
		b = tempRef_b2.argValue;
		  }
		}

		ei.attackedBy[c.getValue()][0] = ei.attackedBy[c.getValue()][PieceType.PAWN.getValue()] | ei.attackedBy[c.getValue()][PieceType.KNIGHT.getValue()] | ei.attackedBy[c.getValue()][PieceType.BISHOP.getValue()] | ei.attackedBy[c.getValue()][PieceType.ROOK.getValue()] | ei.attackedBy[c.getValue()][PieceType.QUEEN.getValue()] | ei.attackedBy[c.getValue()][PieceType.KING.getValue()];
	  }

	  // Kings.  Kings are evaluated after all other pieces for both sides,
	  // because we need complete attack information for all pieces when computing
	  // the king safety evaluation.
	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
	  {
		evaluate_king(pos, pos.king_square(c), c, ei);
	  }

	  // Evaluate passed pawns.  We evaluate passed pawns for both sides at once,
	  // because we need to know which side promotes first in positions where
	  // both sides have an unstoppable passed pawn.
	  if (ei.pi.passed_pawns() != 0)
	  {
		evaluate_passed_pawns(pos, ei);
	  }

	  // Middle-game specific evaluation terms
	  if (phase.getValue() > Phase.PHASE_ENDGAME.getValue())
	  {

		// Pawn storms in positions with opposite castling.
		if (square_file(pos.king_square(Color.WHITE)) >= File.FILE_E.getValue() && square_file(pos.king_square(Color.BLACK)) <= File.FILE_D.getValue())
		{
		  ei.mgValue += ei.pi.queenside_storm_value(Color.WHITE) - ei.pi.kingside_storm_value(Color.BLACK);
		}
		else if (square_file(pos.king_square(Color.WHITE)) <= File.FILE_D.getValue() && square_file(pos.king_square(Color.BLACK)) >= File.FILE_E.getValue())
		{
		  ei.mgValue += ei.pi.kingside_storm_value(Color.WHITE) - ei.pi.queenside_storm_value(Color.BLACK);
		}

		// Evaluate space for both sides.
		if (ei.mi.space_weight() > 0)
		{
		  evaluate_space(pos, Color.WHITE, ei);
		  evaluate_space(pos, Color.BLACK, ei);
		}
	  }

	  // Mobility
	  ei.mgValue += apply_weight(ei.mgMobility, WeightMobilityMidgame);
	  ei.egValue += apply_weight(ei.egMobility, WeightMobilityEndgame);

	  // If we don't already have an unusual scale factor, check for opposite
	  // colored bishop endgames, and use a lower scale for those:
	  if (phase.getValue() < Phase.PHASE_MIDGAME.getValue() && pos.opposite_colored_bishops() && ((factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL && ei.egValue.getValue() > Value(0)) || (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL && ei.egValue.getValue() < Value(0))))
	  {
		if (pos.non_pawn_material(Color.WHITE) + pos.non_pawn_material(Color.BLACK) == 2 * BishopValueMidgame.getValue() != 0)
		{
		  // Only the two bishops
		  if (pos.pawn_count(Color.WHITE) + pos.pawn_count(Color.BLACK) == 1)
		  {
			// KBP vs KB with only a single pawn; almost certainly a draw.
			if (factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.WHITE.getValue()] = ScaleFactor(8);
			}
			if (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.BLACK.getValue()] = ScaleFactor(8);
			}
		  }
		  else
		  {
			// At least two pawns
			if (factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.WHITE.getValue()] = ScaleFactor(32);
			}
			if (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.BLACK.getValue()] = ScaleFactor(32);
			}
		  }
		}
		else
		{
		  // Endgame with opposite-colored bishops, but also other pieces.
		  // Still a bit drawish, but not as drawish as with only the two
		  // bishops.
		  if (factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
		  {
			factor[Color.WHITE.getValue()] = ScaleFactor(50);
		  }
		  if (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
		  {
			factor[Color.BLACK.getValue()] = ScaleFactor(50);
		  }
		}
	  }

	  // Interpolate between the middle game and the endgame score, and
	  // return:
	  Value value = scale_by_game_phase(ei.mgValue, ei.egValue, phase, factor);

	  if (ei.mateThreat[stm.getValue()] != Move.MOVE_NONE)
	  {
		return 8 * QueenValueMidgame - Sign[stm.getValue()] * value.getValue();
	  }
	  else
	  {
		return Sign[stm.getValue()] * value.getValue();
	  }
	}

/// quick_evaluate() does a very approximate evaluation of the current position.
/// It currently considers only material and piece square table scores.  Perhaps
/// we should add scores from the pawn and material hash tables?


	public static Value quick_evaluate(Position pos)
	{
	  Color stm;
	  Value mgValue;
	  Value egValue;
	  ScaleFactor[] factor = {ScaleFactor.SCALE_FACTOR_NORMAL, ScaleFactor.SCALE_FACTOR_NORMAL};
	  Phase phase;

	  assert pos.is_ok();

	  stm = pos.side_to_move();

	  mgValue = pos.mg_value();
	  egValue = pos.eg_value();
	  phase = pos.game_phase();

	  Value value = scale_by_game_phase(mgValue, egValue, phase, factor);

	  return Sign[stm.getValue()] * value.getValue();
	}

/// init_eval() initializes various tables used by the evaluation function.


	public static void init_eval(int threads)
	{
	  assert threads <= THREAD_MAX;

	  for (int i = 0; i < threads; i++)
	  {
		if (PawnTable[i] == null)
		{
		  PawnTable[i] = new PawnInfoTable(PawnTableSize);
		}
		if (MaterialTable[i] == null)
		{
		  MaterialTable[i] = new MaterialInfoTable(MaterialTableSize);
		}
	  }
	  for (int i = threads; i < THREAD_MAX; i++)
	  {
		if (PawnTable[i] != null)
		{
		  if (PawnTable[i] != null)
		  {
		  PawnTable[i].close();
		  }
		  PawnTable[i] = null;
		}
		if (MaterialTable[i] != null)
		{
		  if (MaterialTable[i] != null)
		  {
		  MaterialTable[i].close();
		  }
		  MaterialTable[i] = null;
		}
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: for(unsigned long long b = 0ULL; b < 256ULL; b++)
	  for (long b = 0; b < 256; b++)
	  {
		BitCount8Bit[b] = (byte)count_1s(b);
	  }
	}

/// quit_eval() releases heap-allocated memory at program termination.


	public static void quit_eval()
	{
	  for (int i = 0; i < THREAD_MAX; i++)
	  {
		if (PawnTable[i] != null)
		{
		PawnTable[i].close();
		}
		if (MaterialTable[i] != null)
		{
		MaterialTable[i].close();
		}
	  }
	}

/// read_weights() reads evaluation weights from the corresponding UCI
/// parameters.


	public static void read_weights(Color sideToMove)
	{
	  WeightMobilityMidgame = compute_weight(get_option_value_int("Mobility (Middle Game)"), WeightMobilityMidgameInternal);
	  WeightMobilityEndgame = compute_weight(get_option_value_int("Mobility (Endgame)"), WeightMobilityEndgameInternal);
	  WeightPawnStructureMidgame = compute_weight(get_option_value_int("Pawn Structure (Middle Game)"), WeightPawnStructureMidgameInternal);
	  WeightPawnStructureEndgame = compute_weight(get_option_value_int("Pawn Structure (Endgame)"), WeightPawnStructureEndgameInternal);
	  WeightPassedPawnsMidgame = compute_weight(get_option_value_int("Passed Pawns (Middle Game)"), WeightPassedPawnsMidgameInternal);
	  WeightPassedPawnsEndgame = compute_weight(get_option_value_int("Passed Pawns (Endgame)"), WeightPassedPawnsEndgameInternal);
	  WeightKingSafety[sideToMove.getValue()] = compute_weight(get_option_value_int("Cowardice"), WeightKingSafetyInternal);
	  WeightKingSafety[opposite_color(sideToMove).getValue()] = compute_weight(get_option_value_int("Aggressiveness"), WeightKingSafetyInternal);
	  WeightSpace = compute_weight(get_option_value_int("Space"), WeightSpaceInternal);

	  init_safety();
	}





	////
	//// Local definitions
	////


	  public static final int[] Sign = {1, -1};

	  // Evaluation grain size, must be a power of 2.
	  public static final int GrainSize = 4;

	  // Evaluation weights
	  public static int WeightMobilityMidgame = 0x100;
	  public static int WeightMobilityEndgame = 0x100;
	  public static int WeightPawnStructureMidgame = 0x100;
	  public static int WeightPawnStructureEndgame = 0x100;
	  public static int WeightPassedPawnsMidgame = 0x100;
	  public static int WeightPassedPawnsEndgame = 0x100;
	  public static int[] WeightKingSafety = {0x100, 0x100};
	  public static int WeightSpace;

	  // Internal evaluation weights.  These are applied on top of the evaluation
	  // weights read from UCI parameters.  The purpose is to be able to change
	  // the evaluation weights while keeping the default values of the UCI
	  // parameters at 100, which looks prettier.
	  public static final int WeightMobilityMidgameInternal = 0x100;
	  public static final int WeightMobilityEndgameInternal = 0x100;
	  public static final int WeightPawnStructureMidgameInternal = 0x100;
	  public static final int WeightPawnStructureEndgameInternal = 0x100;
	  public static final int WeightPassedPawnsMidgameInternal = 0x100;
	  public static final int WeightPassedPawnsEndgameInternal = 0x100;
	  public static final int WeightKingSafetyInternal = 0x110;
	  public static final int WeightSpaceInternal = 0x30;

	  // Knight mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly piecess.
	  public static final Value[] MidgameKnightMobilityBonus = {Value(-30), Value(-20), Value(-10), Value(0), Value(10), Value(20), Value(25), Value(30), Value(30)};

	  public static final Value[] EndgameKnightMobilityBonus = {Value(-30), Value(-20), Value(-10), Value(0), Value(10), Value(20), Value(25), Value(30), Value(30)};

	  // Bishop mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly pieces.  X-ray attacks through
	  // queens are also included.
	  public static final Value[] MidgameBishopMobilityBonus = {Value(-30), Value(-15), Value(0), Value(15), Value(30), Value(45), Value(58), Value(66), Value(72), Value(76), Value(78), Value(80), Value(81), Value(82), Value(83), Value(83)};

	  public static final Value[] EndgameBishopMobilityBonus = {Value(-30), Value(-15), Value(0), Value(15), Value(30), Value(45), Value(58), Value(66), Value(72), Value(76), Value(78), Value(80), Value(81), Value(82), Value(83), Value(83)};

	  // Rook mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly pieces.  X-ray attacks through
	  // queens and rooks are also included.
	  public static final Value[] MidgameRookMobilityBonus = {Value(-18), Value(-12), Value(-6), Value(0), Value(6), Value(12), Value(16), Value(21), Value(24), Value(27), Value(28), Value(29), Value(30), Value(31), Value(32), Value(33)};

	  public static final Value[] EndgameRookMobilityBonus = {Value(-30), Value(-18), Value(-6), Value(6), Value(18), Value(30), Value(42), Value(54), Value(66), Value(74), Value(78), Value(80), Value(81), Value(82), Value(83), Value(83)};

	  // Queen mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly pieces.
	  public static final Value[] MidgameQueenMobilityBonus = {Value(-10), Value(-8), Value(-6), Value(-4), Value(-2), Value(0), Value(2), Value(4), Value(6), Value(8), Value(10), Value(12), Value(13), Value(14), Value(15), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16)};

	  public static final Value[] EndgameQueenMobilityBonus = {Value(-20), Value(-15), Value(-10), Value(-5), Value(0), Value(5), Value(10), Value(15), Value(19), Value(23), Value(27), Value(29), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30), Value(30)};


	  // Outpost bonuses for knights and bishops, indexed by square (from white's
	  // point of view).
	  public static final Value[] KnightOutpostBonus = {Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(5), Value(10), Value(10), Value(5), Value(0), Value(0), Value(0), Value(5), Value(20), Value(30), Value(30), Value(20), Value(5), Value(0), Value(0), Value(10), Value(30), Value(40), Value(40), Value(30), Value(10), Value(0), Value(0), Value(5), Value(20), Value(20), Value(20), Value(20), Value(5), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0)};

	  public static final Value[] BishopOutpostBonus = {Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(5), Value(5), Value(5), Value(5), Value(0), Value(0), Value(0), Value(5), Value(10), Value(10), Value(10), Value(10), Value(5), Value(0), Value(0), Value(10), Value(20), Value(20), Value(20), Value(20), Value(10), Value(0), Value(0), Value(5), Value(8), Value(8), Value(8), Value(8), Value(5), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0), Value(0)};

	  // Bonus for unstoppable passed pawns:
	  public static final Value UnstoppablePawnValue = 0x500;

	  // Rooks and queens on the 7th rank:
	  public static final Value MidgameRookOn7thBonus = 50;
	  public static final Value EndgameRookOn7thBonus = 100;
	  public static final Value MidgameQueenOn7thBonus = 25;
	  public static final Value EndgameQueenOn7thBonus = 50;

	  // Rooks on open files:
	  public static final Value RookOpenFileBonus = 40;
	  public static final Value RookHalfOpenFileBonus = 20;

	  // Penalty for rooks trapped inside a friendly king which has lost the
	  // right to castle:
	  public static final Value TrappedRookPenalty = 180;

	  // Penalty for a bishop on a7/h7 (a2/h2 for black) which is trapped by
	  // enemy pawns:
	  public static final Value TrappedBishopA7H7Penalty = 300;

	  // Bitboard masks for detecting trapped bishops on a7/h7 (a2/h2 for black):
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long MaskA7H7[2] = { ((1ULL << SQ_A7) | (1ULL << SQ_H7)), ((1ULL << SQ_A2) | (1ULL << SQ_H2)) };
	  public static final long[] MaskA7H7 = {(long)((1 << Square.SQ_A7.getValue()) | (1 << Square.SQ_H7.getValue())), (long)((1 << Square.SQ_A2.getValue()) | (1 << Square.SQ_H2.getValue()))};

	  // Penalty for a bishop on a1/h1 (a8/h8 for black) which is trapped by
	  // a friendly pawn on b2/g2 (b7/g7 for black).  This can obviously only
	  // happen in Chess960 games.
	  public static final Value TrappedBishopA1H1Penalty = 100;

	  // Bitboard masks for detecting trapped bishops on a1/h1 (a8/h8 for black):
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long MaskA1H1[2] = { ((1ULL << SQ_A1) | (1ULL << SQ_H1)), ((1ULL << SQ_A8) | (1ULL << SQ_H8)) };
	  public static final long[] MaskA1H1 = {(long)((1 << Square.SQ_A1.getValue()) | (1 << Square.SQ_H1.getValue())), (long)((1 << Square.SQ_A8.getValue()) | (1 << Square.SQ_H8.getValue()))};

	  // The SpaceMask[color] contains area of the board which is consdered by
	  // the space evaluation.  In the middle game, each side is given a bonus
	  // based on how many squares inside this area are safe and available for
	  // friendly minor pieces.
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long SpaceMask[2] = { (1ULL<<SQ_C2) | (1ULL<<SQ_D2) | (1ULL<<SQ_E2) | (1ULL<<SQ_F2) | (1ULL<<SQ_C3) | (1ULL<<SQ_D3) | (1ULL<<SQ_E3) | (1ULL<<SQ_F3) | (1ULL<<SQ_C4) | (1ULL<<SQ_D4) | (1ULL<<SQ_E4) | (1ULL<<SQ_F4), (1ULL<<SQ_C7) | (1ULL<<SQ_D7) | (1ULL<<SQ_E7) | (1ULL<<SQ_F7) | (1ULL<<SQ_C6) | (1ULL<<SQ_D6) | (1ULL<<SQ_E6) | (1ULL<<SQ_F6) | (1ULL<<SQ_C5) | (1ULL<<SQ_D5) | (1ULL<<SQ_E5) | (1ULL<<SQ_F5) };
	  public static final long[] SpaceMask = {(long)((1 << Square.SQ_C2.getValue()) | (1 << Square.SQ_D2.getValue()) | (1 << Square.SQ_E2.getValue()) | (1 << Square.SQ_F2.getValue()) | (1 << Square.SQ_C3.getValue()) | (1 << Square.SQ_D3.getValue()) | (1 << Square.SQ_E3.getValue()) | (1 << Square.SQ_F3.getValue()) | (1 << Square.SQ_C4.getValue()) | (1 << Square.SQ_D4.getValue()) | (1 << Square.SQ_E4.getValue()) | (1 << Square.SQ_F4.getValue())), (long)((1 << Square.SQ_C7.getValue()) | (1 << Square.SQ_D7.getValue()) | (1 << Square.SQ_E7.getValue()) | (1 << Square.SQ_F7.getValue()) | (1 << Square.SQ_C6.getValue()) | (1 << Square.SQ_D6.getValue()) | (1 << Square.SQ_E6.getValue()) | (1 << Square.SQ_F6.getValue()) | (1 << Square.SQ_C5.getValue()) | (1 << Square.SQ_D5.getValue()) | (1 << Square.SQ_E5.getValue()) | (1 << Square.SQ_F5.getValue()))};


	  /// King safety constants and variables.  The king safety scores are taken
	  /// from the array SafetyTable[].  Various little "meta-bonuses" measuring
	  /// the strength of the attack are added up into an integer, which is used
	  /// as an index to SafetyTable[].

	  // Attack weights for each piece type.
	  public static final int QueenAttackWeight = 5;
	  public static final int RookAttackWeight = 3;
	  public static final int BishopAttackWeight = 2;
	  public static final int KnightAttackWeight = 2;

	  // Bonuses for safe checks for each piece type.  
	  public static int QueenContactCheckBonus = 3;
	  public static int QueenCheckBonus = 2;
	  public static int RookCheckBonus = 1;
	  public static int BishopCheckBonus = 1;
	  public static int KnightCheckBonus = 1;
	  public static int DiscoveredCheckBonus = 3;

	  // Scan for queen contact mates?
	  public static final boolean QueenContactMates = true;

	  // Bonus for having a mate threat.
	  public static int MateThreatBonus = 3;

	  // InitKingDanger[] contains bonuses based on the position of the defending
	  // king.
	  public static final int[] InitKingDanger = {2, 0, 2, 5, 5, 2, 0, 2, 2, 2, 4, 8, 8, 4, 2, 2, 7, 10, 12, 12, 12, 12, 10, 7, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 0, 0, 0, 0, 0, 0};

	  // SafetyTable[] contains the actual king safety scores.  It is initialized
	  // in init_safety().
	  public static Value[] SafetyTable = new Value[100];


	  // Pawn and material hash tables, indexed by the current thread id:
	  public static PawnInfoTable[] PawnTable =
	  {
		  new PawnInfoTable(null, null),
		  new PawnInfoTable(null, null),
		  new PawnInfoTable(null, null),
		  new PawnInfoTable(null, null)
	  };
	  public static MaterialInfoTable[] MaterialTable =
	  {
		  new MaterialInfoTable(null, null),
		  new MaterialInfoTable(null, null),
		  new MaterialInfoTable(null, null),
		  new MaterialInfoTable(null, null)
	  };

	  // Sizes of pawn and material hash tables:
	  public static final int PawnTableSize = 16384;
	  public static final int MaterialTableSize = 1024;

	  // Array which gives the number of nonzero bits in an 8-bit integer:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char BitCount8Bit[256];
	  public static byte[] BitCount8Bit = new byte[256];

  // evaluate_knight() assigns bonuses and penalties to a knight of a given
  // color on a given square.


	  // Function prototypes:
	  public static void evaluate_knight(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = opposite_color(us);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = p.knight_attacks(s);
		long b = p.knight_attacks(s);
		ei.attackedBy[us.getValue()][PieceType.KNIGHT.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += KnightAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += count_1s_max_15(bb);
		  }
		}

		// Mobility
		int mob = count_1s_max_15(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameKnightMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameKnightMobilityBonus[mob].getValue();

		// Knight outposts:
		if (p.square_is_weak(s, them))
		{
		  Value v;
		  Value bonus;

		  // Initial bonus based on square:
		  v = bonus = KnightOutpostBonus[relative_square(us, s).getValue()];

		  // Increase bonus if supported by pawn, especially if the opponent has
		  // no minor piece which can exchange the outpost piece:
		  if (v.getValue() != 0 && (p.pawn_attacks(them, s) & p.pawns(us)) != 0)
		  {
			bonus += v / 2;
			if (p.knight_count(them) == 0 && (long)(SquaresByColorBB[square_color(s).getValue()] & p.bishops(them)) == EmptyBoardBB)
			{
			  bonus += v;
			}
		  }

		  ei.mgValue += Sign[us.getValue()] * bonus.getValue();
		  ei.egValue += Sign[us.getValue()] * bonus.getValue();
		}
	  }

  // evaluate_bishop() assigns bonuses and penalties to a bishop of a given
  // color on a given square.


	  public static void evaluate_bishop(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = opposite_color(us);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = bishop_attacks_bb(s, p.occupied_squares() & ~p.queens(us));
		long b = bishop_attacks_bb(s, p.occupied_squares() & ~p.queens(us));

		ei.attackedBy[us.getValue()][PieceType.BISHOP.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += BishopAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += count_1s_max_15(bb);
		  }
		}

		// Mobility:
		int mob = count_1s_max_15(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameBishopMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameBishopMobilityBonus[mob].getValue();

		// Bishop outposts:
		if (p.square_is_weak(s, them))
		{
		  Value v;
		  Value bonus;

		  // Initial bonus based on square:
		  v = bonus = BishopOutpostBonus[relative_square(us, s).getValue()];

		  // Increase bonus if supported by pawn, especially if the opponent has
		  // no minor piece which can exchange the outpost piece:
		  if (v.getValue() != 0 && (p.pawn_attacks(them, s) & p.pawns(us)) != 0)
		  {
			bonus += v / 2;
			if (p.knight_count(them) == 0 && (long)(SquaresByColorBB[square_color(s).getValue()] & p.bishops(them)) == EmptyBoardBB)
			{
			  bonus += v;
			}
		  }

		  ei.mgValue += Sign[us.getValue()] * bonus.getValue();
		  ei.egValue += Sign[us.getValue()] * bonus.getValue();
		}
	  }

  // evaluate_rook() assigns bonuses and penalties to a rook of a given
  // color on a given square.


	  public static void evaluate_rook(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = opposite_color(us);

		// Open and half-open files:
		File f = square_file(s);
		if (ei.pi.file_is_half_open(us, f))
		{
		  if (ei.pi.file_is_half_open(them, f))
		  {
			ei.mgValue += Sign[us.getValue()] * RookOpenFileBonus.getValue();
			ei.egValue += Sign[us.getValue()] * RookOpenFileBonus.getValue();
		  }
		  else
		  {
			ei.mgValue += Sign[us.getValue()] * RookHalfOpenFileBonus.getValue();
			ei.egValue += Sign[us.getValue()] * RookHalfOpenFileBonus.getValue();
		  }
		}

		// Rook on 7th rank:
		if (pawn_rank(us, s) == Rank.RANK_7 && pawn_rank(us, p.king_square(them)) == Rank.RANK_8)
		{
		  ei.mgValue += Sign[us.getValue()] * MidgameRookOn7thBonus.getValue();
		  ei.egValue += Sign[us.getValue()] * EndgameRookOn7thBonus.getValue();
		}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = rook_attacks_bb(s, p.occupied_squares() & ~p.rooks_and_queens(us));
		long b = rook_attacks_bb(s, p.occupied_squares() & ~p.rooks_and_queens(us));
		ei.attackedBy[us.getValue()][PieceType.ROOK.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += RookAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += count_1s_max_15(bb);
		  }
		}

		// Mobility
		int mob = count_1s_max_15(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameRookMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameRookMobilityBonus[mob].getValue();

		// Penalize rooks which are trapped inside a king which has lost the
		// right to castle:
		if (mob <= 6 && !ei.pi.file_is_half_open(us, f))
		{
		  Square ksq = p.king_square(us);
		  if (square_file(ksq) >= File.FILE_E.getValue() && square_file(s) > square_file(ksq) && (pawn_rank(us, ksq) == Rank.RANK_1 || square_rank(ksq) == square_rank(s)))
		  {
			// Is there a half-open file between the king and the edge of the
			// board?
			if (!(ei.pi.has_open_file_to_right(us, square_file(ksq))))
			{
			  ei.mgValue -= p.can_castle(us)? Sign[us.getValue()] * ((TrappedRookPenalty - mob * 16) / 2) : Sign[us.getValue()] * (TrappedRookPenalty - mob * 16);
			}
		  }
		  else if (square_file(ksq) <= File.FILE_D.getValue() && square_file(s) < square_file(ksq) && (pawn_rank(us, ksq) == Rank.RANK_1 || square_rank(ksq) == square_rank(s)))
		  {
			// Is there a half-open file between the king and the edge of the
			// board?
			if (!(ei.pi.has_open_file_to_left(us, square_file(ksq))))
			{
			  ei.mgValue -= p.can_castle(us)? Sign[us.getValue()] * ((TrappedRookPenalty - mob * 16) / 2) : Sign[us.getValue()] * (TrappedRookPenalty - mob * 16);
			}
		  }
		}
	  }

  // evaluate_queen() assigns bonuses and penalties to a queen of a given
  // color on a given square.


	  public static void evaluate_queen(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = opposite_color(us);

		// Queen on 7th rank:
		if (pawn_rank(us, s) == Rank.RANK_7 && pawn_rank(us, p.king_square(them)) == Rank.RANK_8)
		{
		  ei.mgValue += Sign[us.getValue()] * MidgameQueenOn7thBonus.getValue();
		  ei.egValue += Sign[us.getValue()] * EndgameQueenOn7thBonus.getValue();
		}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = p.queen_attacks(s);
		long b = p.queen_attacks(s);
		ei.attackedBy[us.getValue()][PieceType.QUEEN.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += QueenAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += count_1s_max_15(bb);
		  }
		}

		// Mobility
		int mob = count_1s(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameQueenMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameQueenMobilityBonus[mob].getValue();
	  }

  // evaluate_king() assigns bonuses and penalties to a king of a given
  // color on a given square.


	  public static void evaluate_king(Position p, Square s, Color us, EvalInfo ei)
	  {

		int shelter = 0;
		int sign = Sign[us.getValue()];

		// King shelter.
		if (pawn_rank(us, s) <= Rank.RANK_4.getValue())
		{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pawns = p.pawns(us) & this_and_neighboring_files_bb(s);
		  long pawns = p.pawns(us) & this_and_neighboring_files_bb(s);
		  Rank r = square_rank(s);
		  for (int i = 0; i < 3; i++)
		  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			shelter += count_1s_8bit(pawns >>> ((r + (i + 1) * sign) * 8)) * (64 >> i);
		  }
		  ei.mgValue += sign * Value(shelter);
		}

		// King safety.  This is quite complicated, and is almost certainly far
		// from optimally tuned.
		Color them = opposite_color(us);
		if (p.queen_count(them) >= 1 && ei.attackCount[them.getValue()] >= 2 && p.non_pawn_material(them) >= QueenValueMidgame.getValue() + RookValueMidgame && ei.attacked[them.getValue()] != 0)
		{

		  // Is it the attackers turn to move?
		  boolean sente = (them == p.side_to_move());

		  // Find the attacked squares around the king which has no defenders
		  // apart from the king itself:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long undefended = ei.attacked_by(them) & ~ei.attacked_by(us, PAWN) & ~ei.attacked_by(us, KNIGHT) & ~ei.attacked_by(us, BISHOP) & ~ei.attacked_by(us, ROOK) & ~ei.attacked_by(us, QUEEN) & ei.attacked_by(us, KING);
		  long undefended = (long)(ei.attacked_by(them) &)~ei.attacked_by(us, PieceType.PAWN) & ~ei.attacked_by(us, PieceType.KNIGHT) & ~ei.attacked_by(us, PieceType.BISHOP) & ~ei.attacked_by(us, PieceType.ROOK) & ~ei.attacked_by(us, PieceType.QUEEN) & ei.attacked_by(us, PieceType.KING);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long occ = p.occupied_squares(), b, b2;
		  long occ = p.occupied_squares();
		  long b;
		  long b2;

		  // Initialize the 'attackUnits' variable, which is used later on as an
		  // index to the SafetyTable[] array.  The initial value is based on the
		  // number and types of the attacking pieces, the number of attacked and
		  // undefended squares around the king, the square of the king, and the
		  // quality of the pawn shelter.
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  int attackUnits = ((((ei.attackCount[them.getValue()] * ei.attackWeight[them.getValue()]) / 2) < (25))? ((ei.attackCount[them.getValue()] * ei.attackWeight[them.getValue()]) / 2) : (25)) + (ei.attacked[them.getValue()] + count_1s_max_15(undefended)) * 3 + InitKingDanger[relative_square(us, s).getValue()] - (shelter >> 5);

		  // Analyse safe queen contact checks:
		  b = (long)(undefended & ei.attacked_by(them, PieceType.QUEEN) &)~p.pieces_of_color(them);
		  if (b != 0)
		  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long attackedByOthers = ei.attacked_by(them, PAWN) | ei.attacked_by(them, KNIGHT) | ei.attacked_by(them, BISHOP) | ei.attacked_by(them, ROOK);
			long attackedByOthers = ei.attacked_by(them, PieceType.PAWN) | ei.attacked_by(them, PieceType.KNIGHT) | ei.attacked_by(them, PieceType.BISHOP) | ei.attacked_by(them, PieceType.ROOK);
			b &= attackedByOthers;
			if (b != 0)
			{
			  // The bitboard b now contains the squares available for safe queen
			  // contact checks.
			  int count = count_1s_max_15(b);
			  attackUnits += QueenContactCheckBonus * count * (sente? 2 : 1);

			  // Is there a mate threat?
			  if (QueenContactMates && !p.is_check())
			  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long escapeSquares = p.king_attacks(s) & ~p.pieces_of_color(us) & ~attackedByOthers;
				long escapeSquares = (long)(p.king_attacks(s) &)~p.pieces_of_color(us) & ~attackedByOthers;
				while (b != 0)
				{
				  Square from;
			  tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
				  Square to = pop_1st_bit(tempRef_b);
				  b = tempRef_b.argValue;
				  if ((escapeSquares & ~queen_attacks_bb(to, occ & clear_mask_bb(s))) == 0)
				  {
					// We have a mate, unless the queen is pinned or there
					// is an X-ray attack through the queen.
					for (int i = 0; i < p.queen_count(them); i++)
					{
					  from = p.queen_list(them, i);
					  if (bit_is_set(p.queen_attacks(from), to) != 0 && bit_is_set(p.pinned_pieces(them), from) == 0 && (rook_attacks_bb(to, occ & clear_mask_bb(from)) & p.rooks_and_queens(us)) == 0 && (rook_attacks_bb(to, occ & clear_mask_bb(from)) & p.rooks_and_queens(us)) == 0)
					  {
						ei.mateThreat[them.getValue()] = make_move(from, to);
					  }
					}
				  }
				}
			  }
			}
		  }

		  // Analyse safe distance checks:
		  if (QueenCheckBonus > 0 || RookCheckBonus > 0)
		  {
			b = (long)(p.rook_attacks(s) &)~p.pieces_of_color(them) & ~ei.attacked_by(us);

			// Queen checks
			b2 = b & ei.attacked_by(them, PieceType.QUEEN);
			if (b2 != 0)
			{
				attackUnits += QueenCheckBonus * count_1s_max_15(b2);
			}

			// Rook checks
			b2 = b & ei.attacked_by(them, PieceType.ROOK);
			if (b2 != 0)
			{
				attackUnits += RookCheckBonus * count_1s_max_15(b2);
			}
		  }
		  if (QueenCheckBonus > 0 || BishopCheckBonus > 0)
		  {
			b = (long)(p.bishop_attacks(s) &)~p.pieces_of_color(them) & ~ei.attacked_by(us);
			// Queen checks
			b2 = b & ei.attacked_by(them, PieceType.QUEEN);
			if (b2 != 0)
			{
				attackUnits += QueenCheckBonus * count_1s_max_15(b2);
			}

			// Bishop checks
			b2 = b & ei.attacked_by(them, PieceType.BISHOP);
			if (b2 != 0)
			{
				attackUnits += BishopCheckBonus * count_1s_max_15(b2);
			}
		  }
		  if (KnightCheckBonus > 0)
		  {
			b = (long)(p.knight_attacks(s) &)~p.pieces_of_color(them) & ~ei.attacked_by(us);
			// Knight checks
			b2 = b & ei.attacked_by(them, PieceType.KNIGHT);
			if (b2 != 0)
			{
				attackUnits += KnightCheckBonus * count_1s_max_15(b2);
			}
		  }

		  // Analyse discovered checks (only for non-pawns right now, consider
		  // adding pawns later).
		  if (DiscoveredCheckBonus != 0)
		  {
			b = (long)(p.discovered_check_candidates(them) &)~p.pawns();
			if (b != 0)
			{
			  attackUnits += DiscoveredCheckBonus * count_1s_max_15(b) * (sente? 2 : 1);
			}
		  }

		  // Has a mate threat been found?  We don't do anything here if the
		  // side with the mating move is the side to move, because in that
		  // case the mating side will get a huge bonus at the end of the main
		  // evaluation function instead.
		  if (ei.mateThreat[them.getValue()] != Move.MOVE_NONE)
		  {
			attackUnits += MateThreatBonus;
		  }

		  // Ensure that attackUnits is between 0 and 99, in order to avoid array
		  // out of bounds errors:
		  if (attackUnits < 0)
		  {
			  attackUnits = 0;
		  }
		  if (attackUnits >= 100)
		  {
			  attackUnits = 99;
		  }

		  // Finally, extract the king safety score from the SafetyTable[] array.
		  // Add the score to the evaluation, and also to ei.futilityMargin.  The
		  // reason for adding the king safety score to the futility margin is
		  // that the king safety scores can sometimes be very big, and that
		  // capturing a single attacking piece can therefore result in a score
		  // change far bigger than the value of the captured piece.
		  Value v = apply_weight(SafetyTable[attackUnits], WeightKingSafety[us.getValue()]);
		  ei.mgValue -= sign * v.getValue();
		  if (us == p.side_to_move())
		  {
			ei.futilityMargin += v;
		  }
		}
	  }

  // evaluate_passed_pawns() evaluates the passed pawns for both sides.


	  public static void evaluate_passed_pawns(Position pos, EvalInfo ei)
	  {
		boolean[] hasUnstoppable = {false, false};
		int[] movesToGo = {100, 100};

		for (Color us = Color.WHITE; us.getValue() <= Color.BLACK.getValue(); us++)
		{
		  Color them = opposite_color(us);
		  Square ourKingSq = pos.king_square(us);
		  Square theirKingSq = pos.king_square(them);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = ei.pi->passed_pawns() & pos.pawns(us), b2, b3, b4;
		  long b = ei.pi.passed_pawns() & pos.pawns(us);
		  long b2;
		  long b3;
		  long b4;

		  while (b != 0)
		  {
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
			Square s = pop_1st_bit(tempRef_b);
			b = tempRef_b.argValue;
			assert pos.piece_on(s) == pawn_of_color(us);
			assert pos.pawn_is_passed(us, s);

			int r = pawn_rank(us, s).getValue() - Rank.RANK_2.getValue();
			int tr = (((0) < (r * (r - 1)))? (r * (r - 1)) : (0));
			Square blockSq = s + pawn_push(us);

			// Base bonus based on rank:
			Value mbonus = 20 * tr;
			Value ebonus = 10 + r * r * 10;

			// Adjust bonus based on king proximity:
			ebonus -= Value(square_distance(ourKingSq, blockSq) * 3 * tr);
			ebonus -= Value(square_distance(ourKingSq, blockSq + pawn_push(us)) * 1 * tr);
			ebonus += Value(square_distance(theirKingSq, blockSq) * 6 * tr);

			// If the pawn is free to advance, increase bonus:
			if (pos.square_is_empty(blockSq))
			{

			  b2 = squares_in_front_of(us, s);
			  b3 = b2 & ei.attacked_by(them);
			  b4 = b2 & ei.attacked_by(us);

			  // If there is an enemy rook or queen attacking the pawn from behind,
			  // add all X-ray attacks by the rook or queen:
			  if (bit_is_set(ei.attacked_by(them, PieceType.ROOK) | ei.attacked_by(them, PieceType.QUEEN), s) != 0 && (squares_behind(us, s) & pos.rooks_and_queens(them)) != 0)
			  {
				b3 = b2;
			  }

			  if ((b2 & pos.pieces_of_color(them)) == EmptyBoardBB)
			  {
				// There are no enemy pieces in the pawn's path!  Are any of the
				// squares in the pawn's path attacked by the enemy?
				if (b3 == EmptyBoardBB)
				{
				  // No enemy attacks, huge bonus!
				  ebonus += Value(tr * ((b2 == b4)? 17 : 15));
				}
				else
				{
				  // OK, there are enemy attacks.  Are those squares which are
				  // attacked by the enemy also attacked by us?  If yes, big bonus
				  // (but smaller than when there are no enemy attacks), if no,
				  // somewhat smaller bonus.
				  ebonus += Value(tr * (((b3 & b4) == b3)? 13 : 8));
				}
			  }
			  else
			  {
				// There are some enemy pieces in the pawn's path.  While this is
				// sad, we still assign a moderate bonus if all squares in the path
				// which are either occupied by or attacked by enemy pieces are
				// also attacked by us.
				if (((b3 | (b2 & pos.pieces_of_color(them))) & ~b4) == EmptyBoardBB)
				{
				  ebonus += Value(tr * 6);
				}
			  }
			  // At last, add a small bonus when there are no *friendly* pieces
			  // in the pawn's path:
			  if ((b2 & pos.pieces_of_color(us)) == EmptyBoardBB)
			  {
				ebonus += Value(tr);
			  }
			}

			// If the pawn is supported by a friendly pawn, increase bonus.
			b2 = pos.pawns(us) & neighboring_files_bb(s);
			if ((b2 & rank_bb(s)) != 0)
			{
			  ebonus += Value(r * 20);
			}
			else if (pos.pawn_attacks(them, s) & b2)
			{
			  ebonus += Value(r * 12);
			}

			// If the other side has only a king, check whether the pawn is
			// unstoppable:
			if (pos.non_pawn_material(them) == Value(0))
			{
			  Square qsq;
			  int d;

			  qsq = relative_square(us, make_square(square_file(s), Rank.RANK_8));
			  d = square_distance(s, qsq) - square_distance(theirKingSq, qsq) + ((us == pos.side_to_move())? 0 : 1);

			  if (d < 0)
			  {
				int mtg = Rank.RANK_8.getValue() - pawn_rank(us, s).getValue();
				int blockerCount = count_1s_max_15(squares_in_front_of(us, s) & pos.occupied_squares());
				mtg += blockerCount;
				d += blockerCount;
				if (d < 0)
				{
				  hasUnstoppable[us.getValue()] = true;
				  movesToGo[us.getValue()] = (((movesToGo[us.getValue()]) < (mtg))? (movesToGo[us.getValue()]) : (mtg));
				}
			  }
			}
			// Rook pawns are a special case:  They are sometimes worse, and
			// sometimes better than other passed pawns.  It is difficult to find
			// good rules for determining whether they are good or bad.  For now,
			// we try the following:  Increase the value for rook pawns if the
			// other side has no pieces apart from a knight, and decrease the
			// value if the other side has a rook or queen.
			if (square_file(s) == File.FILE_A || square_file(s) == File.FILE_H)
			{
			  if (pos.non_pawn_material(them) == KnightValueMidgame && pos.knight_count(them) == 1)
			  {
				ebonus += ebonus / 4;
			  }
			  else if (pos.rooks_and_queens(them))
			  {
				ebonus -= ebonus / 4;
			  }
			}

			// Add the scores for this pawn to the middle game and endgame eval.
			ei.mgValue += apply_weight(Sign[us.getValue()] * mbonus.getValue(), WeightPassedPawnsMidgame);
			ei.egValue += apply_weight(Sign[us.getValue()] * ebonus.getValue(), WeightPassedPawnsEndgame);
		  }
		}

		// Does either side have an unstoppable passed pawn?
		if (hasUnstoppable[Color.WHITE.getValue()] && !hasUnstoppable[Color.BLACK.getValue()])
		{
		  ei.egValue += UnstoppablePawnValue - Value(0x40 * movesToGo[Color.WHITE.getValue()]);
		}
		else if (hasUnstoppable[Color.BLACK.getValue()] && !hasUnstoppable[Color.WHITE.getValue()])
		{
		  ei.egValue -= UnstoppablePawnValue - Value(0x40 * movesToGo[Color.BLACK.getValue()]);
		}
		else if (hasUnstoppable[Color.BLACK.getValue()] && hasUnstoppable[Color.WHITE.getValue()])
		{
		  // Both sides have unstoppable pawns!  Try to find out who queens
		  // first.  We begin by transforming 'movesToGo' to the number of
		  // plies until the pawn queens for both sides:
		  movesToGo[Color.WHITE.getValue()] *= 2;
		  movesToGo[Color.BLACK.getValue()] *= 2;
		  movesToGo[pos.side_to_move().getValue()]--;

		  // If one side queens at least three plies before the other, that
		  // side wins:
		  if (movesToGo[Color.WHITE.getValue()] <= movesToGo[Color.BLACK.getValue()] - 3)
		  {
			ei.egValue += UnstoppablePawnValue - Value(0x40 * (movesToGo[Color.WHITE.getValue()] / 2));
		  }
		  else if (movesToGo[Color.BLACK.getValue()] <= movesToGo[Color.WHITE.getValue()] - 3)
		  {
			ei.egValue -= UnstoppablePawnValue - Value(0x40 * (movesToGo[Color.BLACK.getValue()] / 2));
		  }

		  // We could also add some rules about the situation when one side
		  // queens exactly one ply before the other:  Does the first queen
		  // check the opponent's king, or attack the opponent's queening square?
		  // This is slightly tricky to get right, because it is possible that
		  // the opponent's king has moved somewhere before the first pawn queens.
		}
	  }

  // evaluate_trapped_bishop_a7h7() determines whether a bishop on a7/h7
  // (a2/h2 for black) is trapped by enemy pawns, and assigns a penalty
  // if it is.


	  public static void evaluate_trapped_bishop_a7h7(Position pos, Square s, Color us, EvalInfo ei)
	  {
		Piece pawn = pawn_of_color(opposite_color(us));
		Square b6;
		Square b8;

		assert square_is_ok(s);
		assert pos.piece_on(s) == bishop_of_color(us);

		if (square_file(s) == File.FILE_A)
		{
		  b6 = relative_square(us, Square.SQ_B6);
		  b8 = relative_square(us, Square.SQ_B8);
		}
		else
		{
		  b6 = relative_square(us, Square.SQ_G6);
		  b8 = relative_square(us, Square.SQ_G8);
		}

		if (pos.piece_on(b6) == pawn && pos.see(s, b6) < 0 && pos.see(s, b8) < 0)
		{
		  ei.mgValue -= Sign[us.getValue()] * TrappedBishopA7H7Penalty.getValue();
		  ei.egValue -= Sign[us.getValue()] * TrappedBishopA7H7Penalty.getValue();
		}

	  }

  // evaluate_trapped_bishop_a1h1() determines whether a bishop on a1/h1
  // (a8/h8 for black) is trapped by a friendly pawn on b2/g2 (b7/g7 for
  // black), and assigns a penalty if it is.  This pattern can obviously
  // only occur in Chess960 games.


	  public static void evaluate_trapped_bishop_a1h1(Position pos, Square s, Color us, EvalInfo ei)
	  {
		Piece pawn = pawn_of_color(us);
		Square b2;
		Square b3;
		Square c3;

		assert Chess960;
		assert square_is_ok(s);
		assert pos.piece_on(s) == bishop_of_color(us);

		if (square_file(s) == File.FILE_A)
		{
		  b2 = relative_square(us, Square.SQ_B2);
		  b3 = relative_square(us, Square.SQ_B3);
		  c3 = relative_square(us, Square.SQ_C3);
		}
		else
		{
		  b2 = relative_square(us, Square.SQ_G2);
		  b3 = relative_square(us, Square.SQ_G3);
		  c3 = relative_square(us, Square.SQ_F3);
		}

		if (pos.piece_on(b2) == pawn)
		{
		  Value penalty;

		  if (!pos.square_is_empty(b3))
		  {
			penalty = 2 * TrappedBishopA1H1Penalty;
		  }
		  else if (pos.piece_on(c3) == pawn)
		  {
			penalty = TrappedBishopA1H1Penalty;
		  }
		  else
		  {
			penalty = TrappedBishopA1H1Penalty / 2;
		  }

		  ei.mgValue -= Sign[us.getValue()] * penalty.getValue();
		  ei.egValue -= Sign[us.getValue()] * penalty.getValue();
		}

	  }

  // evaluate_space() computes the space evaluation for a given side.  The
  // space evaluation is a simple bonus based on the number of safe squares
  // available for minor pieces on the central four files on ranks 2--4.  Safe
  // squares one, two or three squares behind a friendly pawn are counted
  // twice.  Finally, the space bonus is scaled by a weight taken from the
  // material hash table.


	  public static void evaluate_space(Position pos, Color us, EvalInfo ei)
	  {
		Color them = opposite_color(us);

		// Find the safe squares for our pieces inside the area defined by
		// SpaceMask[us].  A square is unsafe it is attacked by an enemy
		// pawn, or if it is undefended and attacked by an enemy piece.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long safeSquares = SpaceMask[us] & ~pos.pawns(us) & ~ei.attacked_by(them, PAWN) & ~(~ei.attacked_by(us) & ei.attacked_by(them));
		long safeSquares = (long)(SpaceMask[us.getValue()] &)~pos.pawns(us) & ~ei.attacked_by(them, PieceType.PAWN) & ~(~ei.attacked_by(us) & ei.attacked_by(them));

		// Find all squares which are at most three squares behind some friendly
		// pawn.
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long behindFriendlyPawns = pos.pawns(us);
		long behindFriendlyPawns = pos.pawns(us);
		if (us == Color.WHITE)
		{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		  behindFriendlyPawns |= (behindFriendlyPawns >>> 8);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		  behindFriendlyPawns |= (behindFriendlyPawns >>> 16);
		}
		else
		{
		  behindFriendlyPawns |= (behindFriendlyPawns << 8);
		  behindFriendlyPawns |= (behindFriendlyPawns << 16);
		}

		int space = count_1s_max_15(safeSquares) + count_1s_max_15(behindFriendlyPawns & safeSquares);

		ei.mgValue += Sign[us.getValue()] * apply_weight(Value(space * ei.mi.space_weight()), WeightSpace).getValue();
	  }

  // apply_weight applies() an evaluation weight to a value.


	  public static Value apply_weight(Value v, int w)
	  {
		return (v * w) / 0x100;
	  }

  // scale_by_game_phase() interpolates between a middle game and an endgame
  // score, based on game phase.  It also scales the return value by a
  // ScaleFactor array.


	  public static Value scale_by_game_phase(Value mv, Value ev, Phase ph, ScaleFactor[] sf)
	  {
		assert mv.getValue() > -Value.VALUE_INFINITE && mv.getValue() < Value.VALUE_INFINITE.getValue();
		assert ev.getValue() > -Value.VALUE_INFINITE && ev.getValue() < Value.VALUE_INFINITE.getValue();
		assert ph.getValue() >= Phase.PHASE_ENDGAME.getValue() && ph.getValue() <= Phase.PHASE_MIDGAME.getValue();

		if (ev.getValue() > Value(0))
		{
		  ev = apply_scale_factor(ev, sf[Color.WHITE.getValue()]);
		}
		else
		{
		  ev = apply_scale_factor(ev, sf[Color.BLACK.getValue()]);
		}

		Value result = (int)((mv * ph + ev * (128 - ph)) / 128);
		return Value(result.getValue() & ~(GrainSize - 1));
	  }

  // count_1s_8bit() counts the number of nonzero bits in the 8 least
  // significant bits of an integer.  This function is used by the king
  // shield evaluation.


	  public static int count_1s_8bit(int b)
	  {
		return (int)BitCount8Bit[b & 0xFF];
	  }

  // compute_weight() computes the value of an evaluation weight, by combining
  // an UCI-configurable weight with an internal weight.


	  public static int compute_weight(int uciWeight, int internalWeight)
	  {
		uciWeight = (uciWeight * 0x100) / 100;
		return (uciWeight * internalWeight) / 0x100;
	  }

  // init_safety() initizes the king safety evaluation, based on UCI
  // parameters.  It is called from read_weights().


	  public static void init_safety()
	  {
		double a;
		double b;
		int maxSlope;
		int peak;
		int i;
		int j;

		QueenContactCheckBonus = get_option_value_int("Queen Contact Check Bonus");
		QueenCheckBonus = get_option_value_int("Queen Check Bonus");
		RookCheckBonus = get_option_value_int("Rook Check Bonus");
		BishopCheckBonus = get_option_value_int("Bishop Check Bonus");
		KnightCheckBonus = get_option_value_int("Knight Check Bonus");
		DiscoveredCheckBonus = get_option_value_int("Discovered Check Bonus");
		MateThreatBonus = get_option_value_int("Mate Threat Bonus");

		a = get_option_value_int("King Safety Coefficient") / 100.0;
		b = get_option_value_int("King Safety X Intercept") * 1.0;
		maxSlope = get_option_value_int("King Safety Max Slope");
		peak = (get_option_value_int("King Safety Max Value") * 256) / 100;

		for (i = 0; i < 100; i++)
		{
		  if (i < b)
		  {
			  SafetyTable[i] = Value(0);
		  }
		  else if (get_option_value_string("King Safety Curve").equals("Quadratic"))
		  {
			SafetyTable[i] = Value((int)(a * (i - b) * (i - b)));
		  }
		  else if (get_option_value_string("King Safety Curve").equals("Linear"))
		  {
			SafetyTable[i] = Value((int)(100 * a * (i - b)));
		  }
		}

		for (i = 0; i < 100; i++)
		{
		  if (SafetyTable[i + 1].getValue() - SafetyTable[i].getValue() > maxSlope)
		  {
			for (j = i + 1; j < 100; j++)
			{
			  SafetyTable[j] = SafetyTable[j - 1] + Value(maxSlope);
			}
		  }
		}
		for (i = 0; i < 100; i++)
		{
		  if (SafetyTable[i].getValue() > Value(peak))
		  {
			SafetyTable[i] = Value(peak);
		  }
		}
	  }


	////
	//// Constants and variables
	////

	/// HistoryMax controls how often the history counters will be scaled down:
	/// When the history score for a move gets bigger than HistoryMax, all
	/// entries in the table are divided by 2.  It is difficult to guess what
	/// the ideal value of this constant is.  Scaling down the scores often has
	/// the effect that parts of the search tree which have been searched
	/// recently have a bigger importance for move ordering than the moves which
	/// have been searched a long time ago.
	///
	/// Note that HistoryMax should probably be changed whenever the constant
	/// OnePly in depth.h is changed.  This is somewhat annoying.  Perhaps it
	/// would be better to scale down the history table at regular intervals?

	public static final int HistoryMax = 50000;

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////




	//// 
	//// Functions
	////

	public static void Main(int argc, String[] args)
	{

	  // Disable IO buffering
	  setbuf(stdin, null);
	  setbuf(stdout, null);
	  std::cout.rdbuf().pubsetbuf(null, 0);
	  std::cin.rdbuf().pubsetbuf(null, 0);

	  // Initialization

	  init_mersenne();
	  init_direction_table();
	  init_bitboards();
	  init_uci_options();
	  Position.init_zobrist();
	  Position.init_piece_square_tables();
	  MaterialInfo.init();
	  MovePicker.init_phase_table();
	  init_eval(1);
	  init_bitbases();
	  init_threads();

	  // Make random number generation less deterministic, for book moves
	  int i = Math.abs(get_system_time() % 10000);
	  for (int j = 0; j < i; j++)
	  {
		genrand_int32();
	  }

	  // Process command line arguments
	  if (argc >= 2)
	  {
		if (new String(args[1]).equals("bench" != null))
		{
		  if (argc != 4)
		  {
			System.out.print("Usage: glaurung bench <hash> <threads>");
			System.out.print("\n");
			System.exit(0);
		  }
		  benchmark(new String(args[2]), new String(args[3]));
		}
	  }

	  // Print copyright notice
	  System.out.print(engine_name());
	  System.out.print(".  ");
	  System.out.print("Copyright (C) 2004-2008 Tord Romstad.");
	  System.out.print("\n");

	  // Enter UCI mode
	  uci_main_loop();

	}





	////
	//// Local definitions
	////


	  public static final Value BishopPairMidgameBonus = 100;
	  public static final Value BishopPairEndgameBonus = 100;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KPKMaterialKey, KKPMaterialKey;
	  public static long KPKMaterialKey;
	  public static long KKPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBNKMaterialKey, KKBNMaterialKey;
	  public static long KBNKMaterialKey;
	  public static long KKBNMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRKPMaterialKey, KPKRMaterialKey;
	  public static long KRKPMaterialKey;
	  public static long KPKRMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRKBMaterialKey, KBKRMaterialKey;
	  public static long KRKBMaterialKey;
	  public static long KBKRMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRKNMaterialKey, KNKRMaterialKey;
	  public static long KRKNMaterialKey;
	  public static long KNKRMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KQKRMaterialKey, KRKQMaterialKey;
	  public static long KQKRMaterialKey;
	  public static long KRKQMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBBKNMaterialKey, KNKBBMaterialKey;
	  public static long KBBKNMaterialKey;
	  public static long KNKBBMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRPKRMaterialKey, KRKRPMaterialKey;
	  public static long KRPKRMaterialKey;
	  public static long KRKRPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRPPKRPMaterialKey, KRPKRPPMaterialKey;
	  public static long KRPPKRPMaterialKey;
	  public static long KRPKRPPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KNNKMaterialKey, KKNNMaterialKey;
	  public static long KNNKMaterialKey;
	  public static long KKNNMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBPKBMaterialKey, KBKBPMaterialKey;
	  public static long KBPKBMaterialKey;
	  public static long KBKBPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBPKNMaterialKey, KNKBPMaterialKey;
	  public static long KBPKNMaterialKey;
	  public static long KNKBPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KNPKMaterialKey, KKNPMaterialKey;
	  public static long KNPKMaterialKey;
	  public static long KKNPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KPKPMaterialKey;
	  public static long KPKPMaterialKey;


	/* 
	   A C-program for MT19937, with initialization improved 2002/1/26.
	   Coded by Takuji Nishimura and Makoto Matsumoto.
	
	   Before using, initialize the state by using init_genrand(seed)  
	   or init_by_array(init_key, key_length).
	
	   Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
	   All rights reserved.                          
	
	   Redistribution and use in source and binary forms, with or without
	   modification, are permitted provided that the following conditions
	   are met:
	
	     1. Redistributions of source code must retain the above copyright
	        notice, this list of conditions and the following disclaimer.
	
	     2. Redistributions in binary form must reproduce the above copyright
	        notice, this list of conditions and the following disclaimer in the
	        documentation and/or other materials provided with the distribution.
	
	     3. The names of its contributors may not be used to endorse or promote 
	        products derived from this software without specific prior written 
	        permission.
	
	   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
	   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
	   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
	   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
	   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
	   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
	   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
	   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
	   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	
	
	   Any feedback is very welcome.
	   http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/emt.html
	   email: m-mat @ math.sci.hiroshima-u.ac.jp (remove space)
	*/


	/* Period parameters */  

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: static unsigned long mt[DefineConstants.N];
	public static int[] mt = new int[DefineConstants.N]; // the array for the state vector
	public static int mti = DefineConstants.N + 1; // mti==N+1 means mt[N] is not initialized

	/* initializes mt[N] with a seed */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: void init_genrand(unsigned long s)
	public static void init_genrand(int s)
	{
		mt[0] = s & 0xffffffff;
		for (mti = 1; mti < DefineConstants.N; mti++)
		{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			mt[mti] = (1812433253 * (mt[mti - 1] ^ (mt[mti - 1] >>> 30)) + mti);
			/* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
			/* In the previous versions, MSBs of the seed affect   */
			/* only MSBs of the array mt[].                        */
			/* 2002/01/09 modified by Makoto Matsumoto             */
			mt[mti] &= 0xffffffff;
			/* for >32 bit machines */
		}
	}

	/* initialize by an array with array-length */
	/* init_key is the array for initializing keys */
	/* key_length is its length */
	/* slight change for C++, 2004/2/26 */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: void init_by_array(unsigned long init_key[], int key_length)
	public static void init_by_array(int[] init_key, int key_length)
	{
		int i;
		int j;
		int k;
		init_genrand(19650218);
		i = 1;
		j = 0;
		k = (DefineConstants.N > key_length ? DefineConstants.N : key_length);
		for (; k; k--)
		{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			mt[i] = (mt[i] ^ ((mt[i - 1] ^ (mt[i - 1] >>> 30)) * 1664525)) + init_key[j] + j; // non linear
			mt[i] &= 0xffffffff; // for WORDSIZE > 32 machines
			i++;
			j++;
			if (i >= DefineConstants.N)
			{
				mt[0] = mt[DefineConstants.N - 1];
				i = 1;
			}
			if (j >= key_length)
			{
				j = 0;
			}
		}
		for (k = DefineConstants.N - 1; k; k--)
		{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			mt[i] = (mt[i] ^ ((mt[i - 1] ^ (mt[i - 1] >>> 30)) * 1566083941)) - i; // non linear
			mt[i] &= 0xffffffff; // for WORDSIZE > 32 machines
			i++;
			if (i >= DefineConstants.N)
			{
				mt[0] = mt[DefineConstants.N - 1];
				i = 1;
			}
		}

		mt[0] = 0x80000000; // MSB is 1; assuring non-zero initial array
	}

	/* generates a random number on [0,0xffffffff]-interval */
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long genrand_int32(void)
	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static int[] genrand_int32_mag01 = {0x0, DefineConstants.MATRIX_A};

	public static int genrand_int32()
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long y;
	  int y;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: static unsigned long mag01[2]={0x0UL, DefineConstants.MATRIX_A};
	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//  static uint mag01[2]={0x0UL, DefineConstants.MATRIX_A};
	  /* mag01[x] = x * MATRIX_A  for x=0,1 */

	  if (mti >= DefineConstants.N)
	  { // generate N words at one time
		int kk;

		if (mti == DefineConstants.N + 1) // if init_genrand() has not been called,
		{
		  init_genrand(5489); // a default initial seed is used
		}

		for (kk = 0;kk < DefineConstants.N - DefineConstants.M;kk++)
		{
		  y = (mt[kk] & DefineConstants.UPPER_MASK) | (mt[kk + 1] & DefineConstants.LOWER_MASK);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		  mt[kk] = mt[kk + DefineConstants.M] ^ (y >>> 1) ^ genrand_int32_mag01[y & 0x1];
		}
		for (;kk < DefineConstants.N - 1;kk++)
		{
		  y = (mt[kk] & DefineConstants.UPPER_MASK) | (mt[kk + 1] & DefineConstants.LOWER_MASK);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		  mt[kk] = mt[kk + (DefineConstants.M - DefineConstants.N)] ^ (y >>> 1) ^ genrand_int32_mag01[y & 0x1];
		}
		y = (mt[DefineConstants.N - 1] & DefineConstants.UPPER_MASK) | (mt[0] & DefineConstants.LOWER_MASK);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		mt[DefineConstants.N - 1] = mt[DefineConstants.M - 1] ^ (y >>> 1) ^ genrand_int32_mag01[y & 0x1];

		mti = 0;
	  }

	  y = mt[mti++];

	  /* Tempering */
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  y ^= (y >>> 11);
	  y ^= (y << 7) & 0x9d2c5680;
	  y ^= (y << 15) & 0xefc60000;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  y ^= (y >>> 18);

	  return y;
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long genrand_int64(void)
	public static long genrand_int64()
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long x, y;
	  long x;
	  long y;

	  x = genrand_int32();
	  y = genrand_int32();
	  return (x << 32) | y;
	}

	public static void init_mersenne()
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
	  int[] init = {0x123, 0x234, 0x345, 0x456};
	  int length = 4;
	  init_by_array(init, length);
	}

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER

	//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
	//#include <sys/types.h>
	//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
	//#include <unistd.h>

	///#else

	//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
	//#include "dos.h"
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int gettimeofday(timeval tp, timezone tzp);

	///#endif


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




	////
	//// Includes
	////



	////
	//// Constants
	////


	/// Version number.  If this is left empty, the current date (in the format
	/// YYMMDD) is used as a version number.

	public static final String EngineVersion = "2.2";

//// 
//// Functions
////

/// engine_name() returns the full name of the current Glaurung version.
/// This will be either "Glaurung YYMMDD" (where YYMMDD is the date when the
/// program was compiled) or "Glaurung <version number>", depending on whether
/// the constant EngineVersion (defined in misc.h) is empty.



	////
	//// Macros
	////

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define Min(x, y) (((x) < (y))? (x) : (y))
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define Max(x, y) (((x) < (y))? (y) : (x))


	////
	//// Prototypes
	////

	public static String engine_name()
	{
	  if (EngineVersion.equals(""))
	  {
		final String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	//C++ TO JAVA CONVERTER TODO TASK: There is no direct equivalent in Java to the following C++ macro:
		String dateString = __DATE__;
		std::stringstream s = new std::stringstream();
		int month = 0;
		int day = 0;

		for (int i = 0; i < 12; i++)
		{
		  if (strncmp(dateString, monthNames[i], 3) == 0)
		  {
			month = i + 1;
		  }
		}
		day = Integer.parseInt(dateString.Substring(4));

		s << "Glaurung " << (dateString.Substring(9)) << std::setfill('0') << std::setw(2) << month << std::setfill('0') << std::setw(2) << day;

		return s.str();
	  }
	  else
	  {
		return "Glaurung " + EngineVersion;
	  }
	}

/// get_system_time() returns the current system time, measured in
/// milliseconds.


	public static int get_system_time()
	{
	  timeval t = new timeval();
	  gettimeofday(t, null);
	  return t.tv_sec * 1000 + t.tv_usec / 1000;
	}

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if _SC_NPROCESSORS_ONLN
	public static int cpu_count()
	{
	  return (((sysconf(_SC_NPROCESSORS_ONLN)) < (8))? (sysconf(_SC_NPROCESSORS_ONLN)) : (8));
	}
	///#endif
/* Non-windows version */

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! _WIN32
	public static int Bioskey()
	{
	  fd_set readfds = new fd_set();
	  timeval timeout = new timeval();

	  FD_ZERO(readfds);
	  FD_SET(fileno(stdin), readfds);
	  /* Set to timeout immediately */
	  timeout.tv_sec = 0;
	  timeout.tv_usec = 0;
	  select(16, readfds, 0, 0, timeout);

	  return (FD_ISSET(fileno(stdin), readfds));
	}
	///#endif



	/// cpu_count() tries to detect the number of CPU cores.

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! _SC_NPROCESSORS_ONLN
	public static int cpu_count()
	{
	  return 1;
	}
	///#endif

	///#else

	public static int cpu_count()
	{
	  SYSTEM_INFO s = new SYSTEM_INFO();
	  GetSystemInfo(s);
	  return (((s.dwNumberOfProcessors) < (8))? (s.dwNumberOfProcessors) : (8));
	}

	///#endif


	/*
	  From Beowulf, from Olithink
	*/

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! ! _WIN32
	/* Windows-version */
	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static int Bioskey_init = 0;
	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static int Bioskey_pipe;
	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static HANDLE Bioskey_inh = new HANDLE();

	public static int Bioskey()
	{
	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//	static int init = 0, pipe;
	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//	static int  pipe;;
	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//	static HANDLE inh;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: DWORD dw;
		int dw;
		/* If we're running under XBoard then we can't use _kbhit() as the input
		 * commands are sent to us directly over the internal pipe */

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if FILE_CNT
		if (stdin._cnt > 0)
		{
			return stdin._cnt;
		}
	///#endif
		if (Bioskey_init == 0)
		{
			Bioskey_init = 1;
			Bioskey_inh = GetStdHandle(STD_INPUT_HANDLE);
			Bioskey_pipe = !GetConsoleMode(Bioskey_inh, dw);
			if (Bioskey_pipe == 0)
			{
				SetConsoleMode(Bioskey_inh, dw & ~(ENABLE_MOUSE_INPUT | ENABLE_WINDOW_INPUT));
				FlushConsoleInputBuffer(Bioskey_inh);
			}
		}
		if (Bioskey_pipe != 0)
		{
			if (!PeekNamedPipe(Bioskey_inh, null, 0, null, dw, null))
			{
				return 1;
			}
			return dw;
		}
		else
		{
			GetNumberOfConsoleInputEvents(Bioskey_inh, dw);
			return dw <= 1 ? 0 : dw;
		}
	}
	///#endif



	////
	//// Inline functions
	////

	public static Square move_from(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square((m.getValue() >> 6) & 077);
	}

	public static Square move_to(Move m)
	{
	  return Square(m & 077);
	}

	public static PieceType move_promotion(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return PieceType((m.getValue() >> 12) & 7);
	}

	public static boolean move_is_ep(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return (boolean)((m.getValue() >> 15) & 1);
	}

	public static boolean move_is_castle(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return (boolean)((m.getValue() >> 16) & 1);
	}

	public static boolean move_is_short_castle(Move m)
	{
	  return move_is_castle(m) && (move_to(m) > move_from(m));
	}

	public static boolean move_is_long_castle(Move m)
	{
	  return move_is_castle(m) && (move_to(m) < move_from(m));
	}

	public static Move make_promotion_move(Square from, Square to, PieceType promotion)
	{
	  return Move(to.getValue() | (from.getValue() << 6) | (promotion.getValue() << 12));
	}

	public static Move make_move(Square from, Square to)
	{
	  return Move(to.getValue() | (from.getValue() << 6));
	}

	public static Move make_castle_move(Square from, Square to)
	{
	  return Move(to.getValue() | (from.getValue() << 6) | (1 << 16));
	}

	public static Move make_ep_move(Square from, Square to)
	{
	  return Move(to.getValue() | (from.getValue() << 6) | (1 << 15));
	}

/// Overload the << operator, to make it easier to print moves.



	////
	//// Prototypes
	////

	private std::ostream leftShift (std::ostream os, Move m)
	{
	  return os << move_to_string(m);
	}

////
//// Functions
////

/// move_from_string() takes a position and a string as input, and attempts to
/// convert the string to a move, using simple coordinate notation (g1f3,
/// a7a8q, etc.).  In order to correctly parse en passant captures and castling
/// moves, we need the position.  This function is not robust, and expects that
/// the input move is legal and correctly formatted.


	public static Move move_from_string(Position pos, String str)
	{
	  Square from;
	  Square to;
	  Piece piece;
	  Color us = pos.side_to_move();

	  if (str.length() < 4)
	  {
		  return Move.MOVE_NONE;
	  }

	  // Read the from and to squares:
	  from = square_from_string(str.substring(0, 2));
	  to = square_from_string(str.substring(2, 6));

	  // Find the moving piece:
	  piece = pos.piece_on(from);

	  // If the string has more than 4 characters, try to interpret the 5th
	  // character as a promotion:
	  if (type_of_piece(piece) == PieceType.PAWN && str.length() >= 5)
	  {
		switch (str.charAt(4))
		{
		case 'n':
	case 'N':
		  return make_promotion_move(from, to, PieceType.KNIGHT);
		case 'b':
	case 'B':
		  return make_promotion_move(from, to, PieceType.BISHOP);
		case 'r':
	case 'R':
		  return make_promotion_move(from, to, PieceType.ROOK);
		case 'q':
	case 'Q':
		  return make_promotion_move(from, to, PieceType.QUEEN);
		}
	  }

	  if (piece == king_of_color(us))
	  {
		// Is this a castling move?  A king move is assumed to be a castling
		// move if the destination square is occupied by a friendly rook, or
		// if the distance between the source and destination squares is more
		// than 1.
		if (pos.piece_on(to) == rook_of_color(us))
		{
		  return make_castle_move(from, to);
		}
		else if (square_distance(from, to) > 1)
		{
		  // This is a castling move, but we have to translate it to the
		  // internal "king captures rook" representation.
		  SquareDelta delta = (to.getValue() > from.getValue())? SquareDelta.DELTA_E : SquareDelta.DELTA_W;
		  Square s;
		  for (s = from + delta; pawn_rank(us, s) == Rank.RANK_1 && pos.piece_on(s) != rook_of_color(us); s += delta)
		  {
			  ;
		  }
		  if (pawn_rank(us, s) == Rank.RANK_1 && pos.piece_on(s) == rook_of_color(us))
		  {
			return make_castle_move(from, s);
		  }
		}
	  }
	  else if (piece == pawn_of_color(us))
	  {
		// En passant move?  We assume that a pawn move is an en passant move
		// without further testing if the destination square is epSquare.
		if (to == pos.ep_square())
		{
		  return make_ep_move(from, to);
		}
	  }

	  return make_move(from, to);
	}

/// move_to_string() converts a move to a string in coordinate notation
/// (g1f3, a7a8q, etc.).  The only special case is castling moves, where we
/// print in the e1g1 notation in normal chess mode, and in e1h1 notation in
/// Chess960 mode.


	public static String move_to_string(Move move)
	{
	  String str;

	  if (move == Move.MOVE_NONE)
	  {
		str = "(none)";
	  }
	  else if (move == Move.MOVE_NULL)
	  {
		str = "0000";
	  }
	  else
	  {
		if (!Chess960)
		{
		  if (move_from(move) == Square.SQ_E1 && move_is_short_castle(move))
		  {
			str = "e1g1";
			return str;
		  }
		  else if (move_from(move) == Square.SQ_E1 && move_is_long_castle(move))
		  {
			str = "e1c1";
			return str;
		  }
		  if (move_from(move) == Square.SQ_E8 && move_is_short_castle(move))
		  {
			str = "e8g8";
			return str;
		  }
		  else if (move_from(move) == Square.SQ_E8 && move_is_long_castle(move))
		  {
			str = "e8c8";
			return str;
		  }
		}
		str = square_to_string(move_from(move)) + square_to_string(move_to(move));
		if (move_promotion(move).getValue() != 0)
		{
		  str += piece_type_to_char(move_promotion(move), false);
		}
	  }
	  return str;
	}

/// move_is_ok(), for debugging.


	public static boolean move_is_ok(Move m)
	{
	  return square_is_ok(move_from(m)) && square_is_ok(move_to(m));
	}



////
//// Functions
////


/// generate_captures generates() all pseudo-legal captures and queen
/// promotions.  The return value is the number of moves generated.

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Prototypes
	////

	public static int generate_captures(Position pos, MoveStack mlist)
	{
	  Color us = pos.side_to_move();
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long target = pos.pieces_of_color(opposite_color(us));
	  long target = pos.pieces_of_color(opposite_color(us));
	  int n = 0;

	  assert pos.is_ok();
	  assert!pos.is_check();

	  if (us == Color.WHITE)
	  {
		n += generate_white_pawn_captures(pos, mlist);
	  }
	  else
	  {
		n += generate_black_pawn_captures(pos, mlist);
	  }
	  n += generate_knight_moves(pos, mlist + n, us, target);
	  n += generate_bishop_moves(pos, mlist + n, us, target);
	  n += generate_rook_moves(pos, mlist + n, us, target);
	  n += generate_queen_moves(pos, mlist + n, us, target);
	  n += generate_king_moves(pos, mlist + n, pos.king_square(us), target);

	  return n;
	}

/// generate_noncaptures() generates all pseudo-legal non-captures and 
/// underpromotions.  The return value is the number of moves generated.


	public static int generate_noncaptures(Position pos, MoveStack mlist)
	{
	  Color us = pos.side_to_move();
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long target = pos.empty_squares();
	  long target = pos.empty_squares();
	  int n = 0;

	  assert pos.is_ok();
	  assert!pos.is_check();

	  if (us == Color.WHITE)
	  {
		n += generate_white_pawn_noncaptures(pos, mlist);
	  }
	  else
	  {
		n += generate_black_pawn_noncaptures(pos, mlist);
	  }
	  n += generate_knight_moves(pos, mlist + n, us, target);
	  n += generate_bishop_moves(pos, mlist + n, us, target);
	  n += generate_rook_moves(pos, mlist + n, us, target);
	  n += generate_queen_moves(pos, mlist + n, us, target);
	  n += generate_king_moves(pos, mlist + n, pos.king_square(us), target);
	  n += generate_castle_moves(pos, mlist + n, us);

	  return n;
	}

/// generate_checks() generates all pseudo-legal non-capturing, non-promoting
/// checks, except castling moves (will add this later).  It returns the
/// number of generated moves.  


	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern int generate_checks(const Position &pos, MoveStack *mlist, unsigned long long dc);
	public static int generate_checks(Position pos, MoveStack[] mlist, long dc)
	{
	  Color us;
	  Color them;
	  Square ksq;
	  Square from;
	  Square to;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long empty, checkSqs, b1, b2, b3;
	  long empty;
	  long checkSqs;
	  long b1;
	  long b2;
	  long b3;
	  int n = 0;

	  assert pos.is_ok();
	  assert!pos.is_check();

	  us = pos.side_to_move();
	  them = opposite_color(us);

	  ksq = pos.king_square(them);
	  assert pos.piece_on(ksq) == king_of_color(them);

	  dc = pos.discovered_check_candidates(us);
	  empty = pos.empty_squares();

	  // Pawn moves.  This is somewhat messy, and we use separate code for white
	  // and black, because we can't shift by negative numbers in C/C++.  :-(

	  if (us == Color.WHITE)
	  {
		// Pawn moves which give discovered check.  This is possible only if the
		// pawn is not on the same file as the enemy king, because we don't
		// generate captures.

		// Find all friendly pawns not on the enemy king's file:
		b1 = (long)(pos.pawns(us) &)~file_bb(ksq);

		// Discovered checks, single pawn pushes:
		b2 = b3 = (long)(((b1 & dc) << 8) &)~Rank8BB & empty;
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b3 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b3);
		  b3 = tempRef_b3.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_N, to);
		}

		// Discovered checks, double pawn pushes:
		b3 = ((b2 & Rank3BB) << 8) & empty;
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b32 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b32);
		  b3 = tempRef_b32.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_N - SquareDelta.DELTA_N, to);
		}

		// Direct checks.  These are possible only for pawns on neighboring files
		// of the enemy king:

		b1 &= (~dc & neighboring_files_bb(ksq));

		// Direct checks, single pawn pushes:
		b2 = (b1 << 8) & empty;
		b3 = b2 & pos.black_pawn_attacks(ksq);
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b33 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b33);
		  b3 = tempRef_b33.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_N, to);
		}

		// Direct checks, double pawn pushes:
		b3 = ((b2 & Rank3BB) << 8) & empty & pos.black_pawn_attacks(ksq);
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b34 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b34);
		  b3 = tempRef_b34.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_N - SquareDelta.DELTA_N, to);
		}
	  }
	  else
	  { // (us == BLACK)

		// Pawn moves which give discovered check.  This is possible only if the
		// pawn is not on the same file as the enemy king, because we don't
		// generate captures.

		// Find all friendly pawns not on the enemy king's file:
		b1 = (long)(pos.pawns(us) &)~file_bb(ksq);

		// Discovered checks, single pawn pushes:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b2 = b3 = (long)(((b1 & dc) >>> 8) &)~Rank1BB & empty;
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b35 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b35);
		  b3 = tempRef_b35.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_S, to);
		}

		// Discovered checks, double pawn pushes:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b3 = ((b2 & Rank6BB) >>> 8) & empty;
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b36 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b36);
		  b3 = tempRef_b36.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_S - SquareDelta.DELTA_S, to);
		}

		// Direct checks.  These are possible only for pawns on neighboring files
		// of the enemy king:

		b1 &= (~dc & neighboring_files_bb(ksq));

		// Direct checks, single pawn pushes:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b2 = (b1 >>> 8) & empty;
		b3 = b2 & pos.white_pawn_attacks(ksq);
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b37 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b37);
		  b3 = tempRef_b37.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_S, to);
		}

		// Direct checks, double pawn pushes:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b3 = ((b2 & Rank6BB) >>> 8) & empty & pos.white_pawn_attacks(ksq);
		while (b3 != 0)
		{
	  tangible.RefObject<Long> tempRef_b38 = new tangible.RefObject<Long>(b3);
		  to = pop_1st_bit(tempRef_b38);
		  b3 = tempRef_b38.argValue;
		  mlist[n++].move = make_move(to - SquareDelta.DELTA_S - SquareDelta.DELTA_S, to);
		}
	  }

	  // Knight moves
	  b1 = pos.knights(us);
	  if (b1 != 0)
	  {
		// Discovered knight checks:
		b2 = b1 & dc;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b2);
		  from = pop_1st_bit(tempRef_b2);
		  b2 = tempRef_b2.argValue;
		  b3 = pos.knight_attacks(from) & empty;
		  while (b3 != 0)
		  {
		tangible.RefObject<Long> tempRef_b39 = new tangible.RefObject<Long>(b3);
			to = pop_1st_bit(tempRef_b39);
			b3 = tempRef_b39.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}

		// Direct knight checks:
		b2 = (long)(b1 &)~dc;
		checkSqs = pos.knight_attacks(ksq) & empty;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b22 = new tangible.RefObject<Long>(b2);
		  from = pop_1st_bit(tempRef_b22);
		  b2 = tempRef_b22.argValue;
		  b3 = pos.knight_attacks(from) & checkSqs;
		  while (b3 != 0)
		  {
		tangible.RefObject<Long> tempRef_b310 = new tangible.RefObject<Long>(b3);
			to = pop_1st_bit(tempRef_b310);
			b3 = tempRef_b310.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
	  }

	  // Bishop moves
	  b1 = pos.bishops(us);
	  if (b1 != 0)
	  {
		// Discovered bishop checks:
		b2 = b1 & dc;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b23 = new tangible.RefObject<Long>(b2);
		  from = pop_1st_bit(tempRef_b23);
		  b2 = tempRef_b23.argValue;
		  b3 = pos.bishop_attacks(from) & empty;
		  while (b3 != 0)
		  {
		tangible.RefObject<Long> tempRef_b311 = new tangible.RefObject<Long>(b3);
			to = pop_1st_bit(tempRef_b311);
			b3 = tempRef_b311.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}

		// Direct bishop checks:
		b2 = (long)(b1 &)~dc;
		checkSqs = pos.bishop_attacks(ksq) & empty;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b24 = new tangible.RefObject<Long>(b2);
		  from = pop_1st_bit(tempRef_b24);
		  b2 = tempRef_b24.argValue;
		  b3 = pos.bishop_attacks(from) & checkSqs;
		  while (b3 != 0)
		  {
		tangible.RefObject<Long> tempRef_b312 = new tangible.RefObject<Long>(b3);
			to = pop_1st_bit(tempRef_b312);
			b3 = tempRef_b312.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
	  }

	  // Rook moves
	  b1 = pos.rooks(us);
	  if (b1 != 0)
	  {
		// Discovered rook checks:
		b2 = b1 & dc;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b25 = new tangible.RefObject<Long>(b2);
		  from = pop_1st_bit(tempRef_b25);
		  b2 = tempRef_b25.argValue;
		  b3 = pos.rook_attacks(from) & empty;
		  while (b3 != 0)
		  {
		tangible.RefObject<Long> tempRef_b313 = new tangible.RefObject<Long>(b3);
			to = pop_1st_bit(tempRef_b313);
			b3 = tempRef_b313.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}

		// Direct rook checks:
		b2 = (long)(b1 &)~dc;
		checkSqs = pos.rook_attacks(ksq) & empty;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b26 = new tangible.RefObject<Long>(b2);
		  from = pop_1st_bit(tempRef_b26);
		  b2 = tempRef_b26.argValue;
		  b3 = pos.rook_attacks(from) & checkSqs;
		  while (b3 != 0)
		  {
		tangible.RefObject<Long> tempRef_b314 = new tangible.RefObject<Long>(b3);
			to = pop_1st_bit(tempRef_b314);
			b3 = tempRef_b314.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
	  }

	  // Queen moves
	  b1 = pos.queens(us);
	  if (b1 != 0)
	  {
		// Discovered queen checks are impossible!

		// Direct queen checks:
		checkSqs = pos.queen_attacks(ksq) & empty;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b1 = new tangible.RefObject<Long>(b1);
		  from = pop_1st_bit(tempRef_b1);
		  b1 = tempRef_b1.argValue;
		  b2 = pos.queen_attacks(from) & checkSqs;
		  while (b2 != 0)
		  {
		tangible.RefObject<Long> tempRef_b27 = new tangible.RefObject<Long>(b2);
			to = pop_1st_bit(tempRef_b27);
			b2 = tempRef_b27.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
	  }

	  // King moves
	  from = pos.king_square(us);
	  if (bit_is_set(dc, from) != 0)
	  {
		b1 = (long)(pos.king_attacks(from) & empty &)~QueenPseudoAttacks[ksq.getValue()];
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b12 = new tangible.RefObject<Long>(b1);
		  to = pop_1st_bit(tempRef_b12);
		  b1 = tempRef_b12.argValue;
		  mlist[n++].move = make_move(from, to);
		}
	  }

	  // TODO: Castling moves!

	  return n;
	}

/// generate_evasions() generates all check evasions when the side to move is
/// in check.  Unlike the other move generation functions, this one generates
/// only legal moves.  It returns the number of generated moves.  This
/// function is very ugly, and needs cleaning up some time later.  FIXME


	public static int generate_evasions(Position pos, MoveStack[] mlist)
	{
	  Color us;
	  Color them;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long checkers = pos.checkers();
	  long checkers = pos.checkers();
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pinned, b1, b2;
	  long pinned;
	  long b1;
	  long b2;
	  Square ksq;
	  Square from;
	  Square to;
	  int n = 0;

	  assert pos.is_ok();
	  assert pos.is_check();

	  us = pos.side_to_move();
	  them = opposite_color(us);

	  ksq = pos.king_square(us);
	  assert pos.piece_on(ksq) == king_of_color(us);

	  // Generate evasions for king:
	  b1 = (long)(pos.king_attacks(ksq) &)~pos.pieces_of_color(us);
	  b2 = pos.occupied_squares();
  tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b2);
	  clear_bit(tempRef_b2, ksq);
	  b2 = tempRef_b2.argValue;
	  while (b1 != 0)
	  {
	tangible.RefObject<Long> tempRef_b1 = new tangible.RefObject<Long>(b1);
		to = pop_1st_bit(tempRef_b1);
		b1 = tempRef_b1.argValue;

		// Make sure to is not attacked by the other side.  This is a bit ugly,
		// because we can't use Position::square_is_attacked.  Instead we use
		// the low-level bishop_attacks_bb and rook_attacks_bb with the bitboard
		// b2 (the occupied squares with the king removed) in order to test whether
		// the king will remain in check on the destination square.
		if (((pos.pawn_attacks(us, to) & pos.pawns(them)) == EmptyBoardBB) && ((pos.knight_attacks(to) & pos.knights(them)) == EmptyBoardBB) && ((pos.king_attacks(to) & pos.kings(them)) == EmptyBoardBB) && ((bishop_attacks_bb(to, b2) & pos.bishops_and_queens(them)) == EmptyBoardBB) && ((rook_attacks_bb(to, b2) & pos.rooks_and_queens(them)) == EmptyBoardBB))
		{
		  mlist[n++].move = make_move(ksq, to);
		}
	  }


	  // Generate evasions for other pieces only if not double check.  We use a
	  // simple bit twiddling hack here rather than calling count_1s in order to
	  // save some time (we know that pos.checkers() has at most two nonzero bits).
	  if ((checkers & (checkers - 1)) == 0)
	  {
		Square checksq = first_1(checkers);
		assert pos.color_of_piece_on(checksq) == them;

		// Find pinned pieces:
		pinned = pos.pinned_pieces(us);

		// Generate captures of the checking piece:

		// Pawn captures:
		b1 = (long)(pos.pawn_attacks(them, checksq) & pos.pawns(us) &)~pinned;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b12 = new tangible.RefObject<Long>(b1);
		  from = pop_1st_bit(tempRef_b12);
		  b1 = tempRef_b12.argValue;
		  if (pawn_rank(us, checksq) == Rank.RANK_8)
		  {
			mlist[n++].move = make_promotion_move(from, checksq, PieceType.QUEEN);
			mlist[n++].move = make_promotion_move(from, checksq, PieceType.ROOK);
			mlist[n++].move = make_promotion_move(from, checksq, PieceType.BISHOP);
			mlist[n++].move = make_promotion_move(from, checksq, PieceType.KNIGHT);
		  }
		  else
		  {
			mlist[n++].move = make_move(from, checksq);
		  }
		}

		// Knight captures:
		b1 = (long)(pos.knight_attacks(checksq) & pos.knights(us) &)~pinned;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b13 = new tangible.RefObject<Long>(b1);
		  from = pop_1st_bit(tempRef_b13);
		  b1 = tempRef_b13.argValue;
		  mlist[n++].move = make_move(from, checksq);
		}

		// Bishop and queen captures:
		b1 = (long)(pos.bishop_attacks(checksq) & pos.bishops_and_queens(us) &)~pinned;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b14 = new tangible.RefObject<Long>(b1);
		  from = pop_1st_bit(tempRef_b14);
		  b1 = tempRef_b14.argValue;
		  mlist[n++].move = make_move(from, checksq);
		}

		// Rook and queen captures:
		b1 = (long)(pos.rook_attacks(checksq) & pos.rooks_and_queens(us) &)~pinned;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b15 = new tangible.RefObject<Long>(b1);
		  from = pop_1st_bit(tempRef_b15);
		  b1 = tempRef_b15.argValue;
		  mlist[n++].move = make_move(from, checksq);
		}

		// Blocking check evasions are possible only if the checking piece is
		// a slider:
		if ((checkers & pos.sliders()) != 0)
		{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long blockSquares = squares_between(checksq, ksq);
		  long blockSquares = squares_between(checksq, ksq);
		  assert (pos.occupied_squares() & blockSquares) == EmptyBoardBB;

		  // Pawn moves.  Because a blocking evasion can never be a capture, we
		  // only generate pawn pushes.  As so often, the code for pawns is a bit
		  // ugly, and uses separate clauses for white and black pawns. :-(
		  if (us == Color.WHITE)
		  {
			// Find non-pinned pawns:
			b1 = (long)(pos.pawns(Color.WHITE) &)~pinned;

			// Single pawn pushes.  We don't have to AND with empty squares here,
			// because the blocking squares will always be empty.
			b2 = (b1 << 8) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b22 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b22);
			  b2 = tempRef_b22.argValue;
			  assert pos.piece_on(to) == Piece.EMPTY;
			  if (square_rank(to) == Rank.RANK_8)
			  {
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_N, to, PieceType.QUEEN);
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_N, to, PieceType.ROOK);
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_N, to, PieceType.BISHOP);
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_N, to, PieceType.KNIGHT);
			  }
			  else
			  {
				mlist[n++].move = make_move(to - SquareDelta.DELTA_N, to);
			  }
			}
			// Double pawn pushes.
			b2 = (((b1 << 8) & pos.empty_squares() & Rank3BB) << 8) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b23 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b23);
			  b2 = tempRef_b23.argValue;
			  assert pos.piece_on(to) == Piece.EMPTY;
			  assert square_rank(to) == Rank.RANK_4;
			  mlist[n++].move = make_move(to - SquareDelta.DELTA_N - SquareDelta.DELTA_N, to);
			}
		  }
		  else
		  { // (us == BLACK)
			// Find non-pinned pawns:
			b1 = (long)(pos.pawns(Color.BLACK) &)~pinned;

			// Single pawn pushes.  We don't have to AND with empty squares here,
			// because the blocking squares will always be empty.
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			b2 = (b1 >>> 8) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b24 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b24);
			  b2 = tempRef_b24.argValue;
			  assert pos.piece_on(to) == Piece.EMPTY;
			  if (square_rank(to) == Rank.RANK_1)
			  {
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_S, to, PieceType.QUEEN);
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_S, to, PieceType.ROOK);
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_S, to, PieceType.BISHOP);
				mlist[n++].move = make_promotion_move(to - SquareDelta.DELTA_S, to, PieceType.KNIGHT);
			  }
			  else
			  {
				mlist[n++].move = make_move(to - SquareDelta.DELTA_S, to);
			  }
			}
			// Double pawn pushes.
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			b2 = (((b1 >>> 8) & pos.empty_squares() & Rank6BB) >> 8) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b25 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b25);
			  b2 = tempRef_b25.argValue;
			  assert pos.piece_on(to) == Piece.EMPTY;
			  assert square_rank(to) == Rank.RANK_5;
			  mlist[n++].move = make_move(to - SquareDelta.DELTA_S - SquareDelta.DELTA_S, to);
			}
		  }

		  // Knight moves
		  b1 = (long)(pos.knights(us) &)~pinned;
		  while (b1 != 0)
		  {
		tangible.RefObject<Long> tempRef_b16 = new tangible.RefObject<Long>(b1);
			from = pop_1st_bit(tempRef_b16);
			b1 = tempRef_b16.argValue;
			b2 = pos.knight_attacks(from) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b26 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b26);
			  b2 = tempRef_b26.argValue;
			  mlist[n++].move = make_move(from, to);
			}
		  }

		  // Bishop moves
		  b1 = (long)(pos.bishops(us) &)~pinned;
		  while (b1 != 0)
		  {
		tangible.RefObject<Long> tempRef_b17 = new tangible.RefObject<Long>(b1);
			from = pop_1st_bit(tempRef_b17);
			b1 = tempRef_b17.argValue;
			b2 = pos.bishop_attacks(from) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b27 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b27);
			  b2 = tempRef_b27.argValue;
			  mlist[n++].move = make_move(from, to);
			}
		  }

		  // Rook moves
		  b1 = (long)(pos.rooks(us) &)~pinned;
		  while (b1 != 0)
		  {
		tangible.RefObject<Long> tempRef_b18 = new tangible.RefObject<Long>(b1);
			from = pop_1st_bit(tempRef_b18);
			b1 = tempRef_b18.argValue;
			b2 = pos.rook_attacks(from) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b28 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b28);
			  b2 = tempRef_b28.argValue;
			  mlist[n++].move = make_move(from, to);
			}
		  }

		  // Queen moves
		  b1 = (long)(pos.queens(us) &)~pinned;
		  while (b1 != 0)
		  {
		tangible.RefObject<Long> tempRef_b19 = new tangible.RefObject<Long>(b1);
			from = pop_1st_bit(tempRef_b19);
			b1 = tempRef_b19.argValue;
			b2 = pos.queen_attacks(from) & blockSquares;
			while (b2 != 0)
			{
		  tangible.RefObject<Long> tempRef_b29 = new tangible.RefObject<Long>(b2);
			  to = pop_1st_bit(tempRef_b29);
			  b2 = tempRef_b29.argValue;
			  mlist[n++].move = make_move(from, to);
			}
		  }
		}

		// Finally, the ugly special case of en passant captures.  An en passant
		// capture can only be a check evasion if the check is not a discovered
		// check.  If pos.ep_square() is set, the last move made must have been
		// a double pawn push.  If, furthermore, the checking piece is a pawn,
		// an en passant check evasion may be possible.
		if (pos.ep_square() != Square.SQ_NONE && (checkers & pos.pawns(them)) != 0)
		{
		  to = pos.ep_square();
		  b1 = pos.pawn_attacks(them, to) & pos.pawns(us);
		  assert b1 != EmptyBoardBB;
		  b1 &= ~pinned;
		  while (b1 != 0)
		  {
		tangible.RefObject<Long> tempRef_b110 = new tangible.RefObject<Long>(b1);
			from = pop_1st_bit(tempRef_b110);
			b1 = tempRef_b110.argValue;

			// Before generating the move, we have to make sure it is legal.
			// This is somewhat tricky, because the two disappearing pawns may
			// cause new "discovered checks".  We test this by removing the
			// two relevant bits from the occupied squares bitboard, and using
			// the low-level bitboard functions for bishop and rook attacks.
			b2 = pos.occupied_squares();
		tangible.RefObject<Long> tempRef_b210 = new tangible.RefObject<Long>(b2);
			clear_bit(tempRef_b210, from);
			b2 = tempRef_b210.argValue;
		tangible.RefObject<Long> tempRef_b211 = new tangible.RefObject<Long>(b2);
			clear_bit(tempRef_b211, checksq);
			b2 = tempRef_b211.argValue;
			if (((bishop_attacks_bb(ksq, b2) & pos.bishops_and_queens(them)) == EmptyBoardBB) && ((rook_attacks_bb(ksq, b2) & pos.rooks_and_queens(them)) == EmptyBoardBB))
			{
			  mlist[n++].move = make_ep_move(from, to);
			}
		  }
		}
	  }

	  return n;
	}

/// generate_legal_moves() computes a complete list of legal moves in the
/// current position.  This function is not very fast, and should be used
/// only in situations where performance is unimportant.  It wouldn't be
/// very hard to write an efficient legal move generator, but for the moment
/// we don't need it.


	public static int generate_legal_moves(Position pos, MoveStack[] mlist)
	{
	  assert pos.is_ok();

	  if (pos.is_check())
	  {
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: return generate_evasions(pos, mlist);
		return generate_evasions(pos, new MoveStack(mlist));
	  }
	  else
	  {
		int i;
		int n;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pinned = pos.pinned_pieces(pos.side_to_move());
		long pinned = pos.pinned_pieces(pos.side_to_move());

		// Generate pseudo-legal moves:
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to contain a copy constructor call - this should be verified and a copy constructor should be created:
//ORIGINAL LINE: n = generate_captures(pos, mlist);
		n = generate_captures(pos, new MoveStack(mlist));
		n += generate_noncaptures(pos, mlist + n);

		// Remove illegal moves from the list:
		for (i = 0; i < n; i++)
		{
		  if (!pos.move_is_legal(mlist[i].move, pinned))
		  {
			mlist[i--].move = mlist[--n].move;
		  }
		}

		return n;
	  }
	}

/// generate_move_if_legal() takes a position and a (not necessarily
/// pseudo-legal) move and a pinned pieces bitboard as input, and tests
/// whether the move is legal.  If the move is legal, the move itself is
/// returned.  If not, the function returns MOVE_NONE.  This function must
/// only be used when the side to move is not in check.


	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern Move generate_move_if_legal(const Position &pos, Move m, unsigned long long pinned);
	public static Move generate_move_if_legal(Position pos, Move m, long pinned)
	{
	  Color us;
	  Color them;
	  Square from;
	  Square to;
	  Piece pc;

	  assert pos.is_ok();
	  assert!pos.is_check();
	  assert move_is_ok(m);

	  us = pos.side_to_move();
	  them = opposite_color(us);
	  from = move_from(m);
	  pc = pos.piece_on(from);

	  // If the from square is not occupied by a piece belonging to the side to
	  // move, the move is obviously not legal.
	  if (color_of_piece(pc) != us)
	  {
		return Move.MOVE_NONE;
	  }

	  to = move_to(m);

	  // En passant moves:
	  if (move_is_ep(m))
	  {

		// The piece must be a pawn:
		if (type_of_piece(pc) != PieceType.PAWN)
		{
		  return Move.MOVE_NONE;
		}

		// The destination square must be the en passant square:
		if (to != pos.ep_square())
		{
		  return Move.MOVE_NONE;
		}

		assert pos.square_is_empty(to);
		assert pos.piece_on(to - pawn_push(us)) == pawn_of_color(them);

		// The move is pseudo-legal.  If it is legal, return it.
		if (pos.move_is_legal(m))
		{
		  return m;
		}
		else
		{
		  return Move.MOVE_NONE;
		}
	  }

	  // Castling moves:
	  else if (move_is_short_castle(m))
	  {

		// The piece must be a king:
		if (type_of_piece(pc) != PieceType.KING)
		{
		  return Move.MOVE_NONE;
		}

		// The side to move must still have the right to castle kingside:
		if (!pos.can_castle_kingside(us))
		{
		  return Move.MOVE_NONE;
		}

		assert from == pos.king_square(us);
		assert to == pos.initial_kr_square(us);
		assert pos.piece_on(to) == rook_of_color(us);

		Square g1 = relative_square(us, Square.SQ_G1);
		Square f1 = relative_square(us, Square.SQ_F1);
		Square s;
		boolean illegal = false;

		for (s = (((from).getValue() < (g1).getValue())? (from) : (g1)); s.getValue() <= (((from).getValue() < (g1).getValue())? (g1) : (from)); s++)
		{
		  if ((s != from && s != to && !pos.square_is_empty(s)) || pos.square_is_attacked(s, them))
		  {
			illegal = true;
		  }
		}
		for (s = (((to).getValue() < (f1).getValue())? (to) : (f1)); s.getValue() <= (((to).getValue() < (f1).getValue())? (f1) : (to)); s++)
		{
		  if (s != from && s != to && !pos.square_is_empty(s))
		  {
			illegal = true;
		  }
		}

		if (!illegal)
		{
		  return m;
		}
		else
		{
		  return Move.MOVE_NONE;
		}
	  }
	  else if (move_is_long_castle(m))
	  {

		// The piece must be a king:
		if (type_of_piece(pc) != PieceType.KING)
		{
		  return Move.MOVE_NONE;
		}

		// The side to move must still have the right to castle kingside:
		if (!pos.can_castle_queenside(us))
		{
		  return Move.MOVE_NONE;
		}

		assert from == pos.king_square(us);
		assert to == pos.initial_qr_square(us);
		assert pos.piece_on(to) == rook_of_color(us);

		Square c1 = relative_square(us, Square.SQ_C1);
		Square d1 = relative_square(us, Square.SQ_D1);
		Square s;
		boolean illegal = false;

		for (s = (((from).getValue() < (c1).getValue())? (from) : (c1)); s.getValue() <= (((from).getValue() < (c1).getValue())? (c1) : (from)); s++)
		{
		  if ((s != from && s != to && !pos.square_is_empty(s)) || pos.square_is_attacked(s, them))
		  {
			illegal = true;
		  }
		}
		for (s = (((to).getValue() < (d1).getValue())? (to) : (d1)); s.getValue() <= (((to).getValue() < (d1).getValue())? (d1) : (to)); s++)
		{
		  if (s != from && s != to && !pos.square_is_empty(s))
		  {
			illegal = true;
		  }
		}
		if (square_file(to) == File.FILE_B && (pos.piece_on(to + SquareDelta.DELTA_W) == rook_of_color(them) || pos.piece_on(to + SquareDelta.DELTA_W) == queen_of_color(them)))
		{
		  illegal = true;
		}

		if (!illegal)
		{
		  return m;
		}
		else
		{
		  return Move.MOVE_NONE;
		}
	  }

	  // Normal moves
	  else
	  {

		// The destination square cannot be occupied by a friendly piece:
		if (pos.color_of_piece_on(to) == us)
		{
		  return Move.MOVE_NONE;
		}

		// Proceed according to the type of the moving piece.
		switch (type_of_piece(pc))
		{

		case PAWN:
		  // Pawn moves, as usual, are somewhat messy.
		  if (us == Color.WHITE)
		  {
			// If the destination square is on the 8th rank, the move must be a
			// promotion.
			if (square_rank(to) == Rank.RANK_8 && move_promotion(m).getValue() == 0)
			{
			  return Move.MOVE_NONE;
			}

			// Proceed according to the square delta between the source and
			// destionation squares.
			switch (to - from)
			{

			case DELTA_NW:
		case DELTA_NE:
			  // Capture.  The destination square must be occupied by an enemy piece
			  // (en passant captures was handled earlier).
			  if (pos.color_of_piece_on(to) != them)
			  {
				return Move.MOVE_NONE;
			  }
			  break;

			case DELTA_N:
			  // Pawn push.  The destination square must be empty.
			  if (!pos.square_is_empty(to))
			  {
				return Move.MOVE_NONE;
			  }
			  break;

			case DELTA_NN:
			  // Double pawn push.  The destination square must be on the fourth
			  // rank, and both the destination square and the square between the
			  // source and destination squares must be empty.
			  if (square_rank(to) != Rank.RANK_4 || !pos.square_is_empty(to) || !pos.square_is_empty(from + SquareDelta.DELTA_N))
			  {
				return Move.MOVE_NONE;
			  }
			  break;

			default:
			  return Move.MOVE_NONE;
			}
		  }
		  else
		  { // (us == BLACK)
			// If the destination square is on the 1st rank, the move must be a
			// promotion.
			if (square_rank(to) == Rank.RANK_1 && move_promotion(m).getValue() == 0)
			{
			  return Move.MOVE_NONE;
			}

			// Proceed according to the square delta between the source and
			// destionation squares.
			switch (to - from)
			{

			case DELTA_SW:
		case DELTA_SE:
			  // Capture.  The destination square must be occupied by an enemy piece
			  // (en passant captures was handled earlier).
			  if (pos.color_of_piece_on(to) != them)
			  {
				return Move.MOVE_NONE;
			  }
			  break;

			case DELTA_S:
			  // Pawn push.  The destination square must be empty.
			  if (!pos.square_is_empty(to))
			  {
				return Move.MOVE_NONE;
			  }
			  break;

			case DELTA_SS:
			  // Double pawn push.  The destination square must be on the fifth
			  // rank, and both the destination square and the square between the
			  // source and destination squares must be empty.
			  if (square_rank(to) != Rank.RANK_5 || !pos.square_is_empty(to) || !pos.square_is_empty(from + SquareDelta.DELTA_S))
			  {
				return Move.MOVE_NONE;
			  }
			  break;

			default:
			  return Move.MOVE_NONE;
			}
		  }
		  // The move is pseudo-legal.  Return it if it is legal.
		  if (pos.move_is_legal(m))
		  {
			return m;
		  }
		  else
		  {
			return Move.MOVE_NONE;
		  }
		  break;

		case KNIGHT:
		  if (pos.knight_attacks_square(from, to) && pos.move_is_legal(m) && move_promotion(m).getValue() == 0)
		  {
			return m;
		  }
		  else
		  {
			return Move.MOVE_NONE;
		  }
		  break;

		case BISHOP:
		  if (pos.bishop_attacks_square(from, to) && pos.move_is_legal(m) && move_promotion(m).getValue() == 0)
		  {
			return m;
		  }
		  else
		  {
			return Move.MOVE_NONE;
		  }
		  break;

		case ROOK:
		  if (pos.rook_attacks_square(from, to) && pos.move_is_legal(m) && move_promotion(m).getValue() == 0)
		  {
			return m;
		  }
		  else
		  {
			return Move.MOVE_NONE;
		  }
		  break;

		case QUEEN:
		  if (pos.queen_attacks_square(from, to) && pos.move_is_legal(m) && move_promotion(m).getValue() == 0)
		  {
			return m;
		  }
		  else
		  {
			return Move.MOVE_NONE;
		  }
		  break;

		case KING:
		  if (pos.king_attacks_square(from, to) && pos.move_is_legal(m) && move_promotion(m).getValue() == 0)
		  {
			return m;
		  }
		  else
		  {
			return Move.MOVE_NONE;
		  }
		  break;

		default:
		  assert false;
		}
	  }

	  assert false;
	  return Move.MOVE_NONE;
	}




	////
	//// Local definitions
	////


	  public static int generate_white_pawn_captures(Position pos, MoveStack[] mlist)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pawns = pos.pawns(WHITE);
		long pawns = pos.pawns(Color.WHITE);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long enemyPieces = pos.pieces_of_color(BLACK);
		long enemyPieces = pos.pieces_of_color(Color.BLACK);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b1, b2;
		long b1;
		long b2;
		Square sq;
		int n = 0;

		// Captures in the a1-h8 direction:
		b1 = (long)((pawns << 9) &)~FileABB & enemyPieces;

		// Promotions:
		b2 = b1 & Rank8BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b2);
		  b2 = tempRef_b2.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NE, sq, PieceType.QUEEN);
		}

		// Non-promotions:
		b2 = (long)(b1 &)~Rank8BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b22 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b22);
		  b2 = tempRef_b22.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_NE, sq);
		}

		// Captures in the h1-a8 direction:
		b1 = (long)((pawns << 7) &)~FileHBB & enemyPieces;

		// Promotions:
		b2 = b1 & Rank8BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b23 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b23);
		  b2 = tempRef_b23.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NW, sq, PieceType.QUEEN);
		}

		// Non-promotions:
		b2 = (long)(b1 &)~Rank8BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b24 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b24);
		  b2 = tempRef_b24.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_NW, sq);
		}

		// Non-capturing promotions:
		b1 = (pawns << 8) & pos.empty_squares() & Rank8BB;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b1 = new tangible.RefObject<Long>(b1);
		  sq = pop_1st_bit(tempRef_b1);
		  b1 = tempRef_b1.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_N, sq, PieceType.QUEEN);
		}

		// En passant captures:
		if (pos.ep_square() != Square.SQ_NONE)
		{
		  assert square_rank(pos.ep_square()) == Rank.RANK_6;
		  b1 = pawns & pos.black_pawn_attacks(pos.ep_square());
		  assert b1 != EmptyBoardBB;
		  while (b1 != 0)
		  {
		tangible.RefObject<Long> tempRef_b12 = new tangible.RefObject<Long>(b1);
			sq = pop_1st_bit(tempRef_b12);
			b1 = tempRef_b12.argValue;
			mlist[n++].move = make_ep_move(sq, pos.ep_square());
		  }
		}

		return n;
	  }

	  public static int generate_black_pawn_captures(Position pos, MoveStack[] mlist)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pawns = pos.pawns(BLACK);
		long pawns = pos.pawns(Color.BLACK);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long enemyPieces = pos.pieces_of_color(WHITE);
		long enemyPieces = pos.pieces_of_color(Color.WHITE);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b1, b2;
		long b1;
		long b2;
		Square sq;
		int n = 0;

		// Captures in the a8-h1 direction:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b1 = (long)((pawns >>> 7) &)~FileABB & enemyPieces;

		// Promotions:
		b2 = b1 & Rank1BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b2);
		  b2 = tempRef_b2.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SE, sq, PieceType.QUEEN);
		}

		// Non-promotions:
		b2 = (long)(b1 &)~Rank1BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b22 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b22);
		  b2 = tempRef_b22.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_SE, sq);
		}

		// Captures in the h8-a1 direction:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b1 = (long)((pawns >>> 9) &)~FileHBB & enemyPieces;

		// Promotions:
		b2 = b1 & Rank1BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b23 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b23);
		  b2 = tempRef_b23.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SW, sq, PieceType.QUEEN);
		}

		// Non-promotions:
		b2 = (long)(b1 &)~Rank1BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b24 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b24);
		  b2 = tempRef_b24.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_SW, sq);
		}

		// Non-capturing promotions:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b1 = (pawns >>> 8) & pos.empty_squares() & Rank1BB;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b1 = new tangible.RefObject<Long>(b1);
		  sq = pop_1st_bit(tempRef_b1);
		  b1 = tempRef_b1.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_S, sq, PieceType.QUEEN);
		}

		// En passant captures:
		if (pos.ep_square() != Square.SQ_NONE)
		{
		  assert square_rank(pos.ep_square()) == Rank.RANK_3;
		  b1 = pawns & pos.white_pawn_attacks(pos.ep_square());
		  assert b1 != EmptyBoardBB;
		  while (b1 != 0)
		  {
		tangible.RefObject<Long> tempRef_b12 = new tangible.RefObject<Long>(b1);
			sq = pop_1st_bit(tempRef_b12);
			b1 = tempRef_b12.argValue;
			mlist[n++].move = make_ep_move(sq, pos.ep_square());
		  }
		}

		return n;
	  }

	  public static int generate_white_pawn_noncaptures(Position pos, MoveStack[] mlist)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pawns = pos.pawns(WHITE);
		long pawns = pos.pawns(Color.WHITE);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long enemyPieces = pos.pieces_of_color(BLACK);
		long enemyPieces = pos.pieces_of_color(Color.BLACK);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long emptySquares = pos.empty_squares();
		long emptySquares = pos.empty_squares();
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b1, b2;
		long b1;
		long b2;
		Square sq;
		int n = 0;

		// Underpromotion captures in the a1-h8 direction:
		b1 = (long)((pawns << 9) &)~FileABB & enemyPieces & Rank8BB;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b1 = new tangible.RefObject<Long>(b1);
		  sq = pop_1st_bit(tempRef_b1);
		  b1 = tempRef_b1.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NE, sq, PieceType.ROOK);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NE, sq, PieceType.BISHOP);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NE, sq, PieceType.KNIGHT);
		}

		// Underpromotion captures in the h1-a8 direction:
		b1 = (long)((pawns << 7) &)~FileHBB & enemyPieces & Rank8BB;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b12 = new tangible.RefObject<Long>(b1);
		  sq = pop_1st_bit(tempRef_b12);
		  b1 = tempRef_b12.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NW, sq, PieceType.ROOK);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NW, sq, PieceType.BISHOP);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_NW, sq, PieceType.KNIGHT);
		}

		// Single pawn pushes:
		b1 = (pawns << 8) & emptySquares;
		b2 = b1 & Rank8BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b2);
		  b2 = tempRef_b2.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_N, sq, PieceType.ROOK);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_N, sq, PieceType.BISHOP);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_N, sq, PieceType.KNIGHT);
		}
		b2 = (long)(b1 &)~Rank8BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b22 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b22);
		  b2 = tempRef_b22.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_N, sq);
		}

		// Double pawn pushes:
		b2 = ((b1 & Rank3BB) << 8) & emptySquares;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b23 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b23);
		  b2 = tempRef_b23.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_N - SquareDelta.DELTA_N, sq);
		}

		return n;
	  }

	  public static int generate_black_pawn_noncaptures(Position pos, MoveStack[] mlist)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pawns = pos.pawns(BLACK);
		long pawns = pos.pawns(Color.BLACK);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long enemyPieces = pos.pieces_of_color(WHITE);
		long enemyPieces = pos.pieces_of_color(Color.WHITE);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long emptySquares = pos.empty_squares();
		long emptySquares = pos.empty_squares();
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b1, b2;
		long b1;
		long b2;
		Square sq;
		int n = 0;

		// Underpromotion captures in the a8-h1 direction:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b1 = (long)((pawns >>> 7) &)~FileABB & enemyPieces & Rank1BB;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b1 = new tangible.RefObject<Long>(b1);
		  sq = pop_1st_bit(tempRef_b1);
		  b1 = tempRef_b1.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SE, sq, PieceType.ROOK);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SE, sq, PieceType.BISHOP);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SE, sq, PieceType.KNIGHT);
		}

		// Underpromotion captures in the h8-a1 direction:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b1 = (long)((pawns >>> 9) &)~FileHBB & enemyPieces & Rank1BB;
		while (b1 != 0)
		{
	  tangible.RefObject<Long> tempRef_b12 = new tangible.RefObject<Long>(b1);
		  sq = pop_1st_bit(tempRef_b12);
		  b1 = tempRef_b12.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SW, sq, PieceType.ROOK);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SW, sq, PieceType.BISHOP);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_SW, sq, PieceType.KNIGHT);
		}

		// Single pawn pushes:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b1 = (pawns >>> 8) & emptySquares;
		b2 = b1 & Rank1BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b2 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b2);
		  b2 = tempRef_b2.argValue;
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_S, sq, PieceType.ROOK);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_S, sq, PieceType.BISHOP);
		  mlist[n++].move = make_promotion_move(sq - SquareDelta.DELTA_S, sq, PieceType.KNIGHT);
		}
		b2 = (long)(b1 &)~Rank1BB;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b22 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b22);
		  b2 = tempRef_b22.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_S, sq);
		}

		// Double pawn pushes:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		b2 = ((b1 & Rank6BB) >>> 8) & emptySquares;
		while (b2 != 0)
		{
	  tangible.RefObject<Long> tempRef_b23 = new tangible.RefObject<Long>(b2);
		  sq = pop_1st_bit(tempRef_b23);
		  b2 = tempRef_b23.argValue;
		  mlist[n++].move = make_move(sq - SquareDelta.DELTA_S - SquareDelta.DELTA_S, sq);
		}

		return n;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: int generate_knight_moves(const Position &pos, MoveStack *mlist, Color side, unsigned long long target);
	  public static int generate_knight_moves(Position pos, MoveStack[] mlist, Color side, long target)
	  {
		Square from;
		Square to;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		int i;
		int n = 0;

		for (i = 0; i < pos.knight_count(side); i++)
		{
		  from = pos.knight_list(side, i);
		  b = pos.knight_attacks(from) & target;
		  while (b != 0)
		  {
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
			to = pop_1st_bit(tempRef_b);
			b = tempRef_b.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
		return n;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: int generate_bishop_moves(const Position &pos, MoveStack *mlist, Color side, unsigned long long target);
	  public static int generate_bishop_moves(Position pos, MoveStack[] mlist, Color side, long target)
	  {
		Square from;
		Square to;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		int i;
		int n = 0;

		for (i = 0; i < pos.bishop_count(side); i++)
		{
		  from = pos.bishop_list(side, i);
		  b = pos.bishop_attacks(from) & target;
		  while (b != 0)
		  {
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
			to = pop_1st_bit(tempRef_b);
			b = tempRef_b.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
		return n;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: int generate_rook_moves(const Position &pos, MoveStack *mlist, Color side, unsigned long long target);
	  public static int generate_rook_moves(Position pos, MoveStack[] mlist, Color side, long target)
	  {
		Square from;
		Square to;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		int i;
		int n = 0;

		for (i = 0; i < pos.rook_count(side); i++)
		{
		  from = pos.rook_list(side, i);
		  b = pos.rook_attacks(from) & target;
		  while (b != 0)
		  {
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
			to = pop_1st_bit(tempRef_b);
			b = tempRef_b.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
		return n;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: int generate_queen_moves(const Position &pos, MoveStack *mlist, Color side, unsigned long long target);
	  public static int generate_queen_moves(Position pos, MoveStack[] mlist, Color side, long target)
	  {
		Square from;
		Square to;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		int i;
		int n = 0;

		for (i = 0; i < pos.queen_count(side); i++)
		{
		  from = pos.queen_list(side, i);
		  b = pos.queen_attacks(from) & target;
		  while (b != 0)
		  {
		tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
			to = pop_1st_bit(tempRef_b);
			b = tempRef_b.argValue;
			mlist[n++].move = make_move(from, to);
		  }
		}
		return n;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: int generate_king_moves(const Position &pos, MoveStack *mlist, Square from, unsigned long long target);
	  public static int generate_king_moves(Position pos, MoveStack[] mlist, Square from, long target)
	  {
		Square to;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		int n = 0;

		b = pos.king_attacks(from) & target;
		while (b != 0)
		{
	  tangible.RefObject<Long> tempRef_b = new tangible.RefObject<Long>(b);
		  to = pop_1st_bit(tempRef_b);
		  b = tempRef_b.argValue;
		  mlist[n++].move = make_move(from, to);
		}
		return n;
	  }

	  public static int generate_castle_moves(Position pos, MoveStack[] mlist, Color us)
	  {
		int n = 0;

		if (pos.can_castle(us))
		{
		  Color them = opposite_color(us);
		  Square ksq = pos.king_square(us);
		  assert pos.piece_on(ksq) == king_of_color(us);

		  if (pos.can_castle_kingside(us))
		  {
			Square rsq = pos.initial_kr_square(us);
			Square g1 = relative_square(us, Square.SQ_G1);
			Square f1 = relative_square(us, Square.SQ_F1);
			Square s;
			boolean illegal = false;

			assert pos.piece_on(rsq) == rook_of_color(us);

			for (s = (((ksq).getValue() < (g1).getValue())? (ksq) : (g1)); s.getValue() <= (((ksq).getValue() < (g1).getValue())? (g1) : (ksq)); s++)
			{
			  if ((s != ksq && s != rsq && pos.square_is_occupied(s)) || pos.square_is_attacked(s, them))
			  {
				illegal = true;
			  }
			}
			for (s = (((rsq).getValue() < (f1).getValue())? (rsq) : (f1)); s.getValue() <= (((rsq).getValue() < (f1).getValue())? (f1) : (rsq)); s++)
			{
			  if (s != ksq && s != rsq && pos.square_is_occupied(s))
			  {
				illegal = true;
			  }
			}

			if (!illegal)
			{
			  mlist[n++].move = make_castle_move(ksq, rsq);
			}
		  }

		  if (pos.can_castle_queenside(us))
		  {
			Square rsq = pos.initial_qr_square(us);
			Square c1 = relative_square(us, Square.SQ_C1);
			Square d1 = relative_square(us, Square.SQ_D1);
			Square s;
			boolean illegal = false;

			assert pos.piece_on(rsq) == rook_of_color(us);

			for (s = (((ksq).getValue() < (c1).getValue())? (ksq) : (c1)); s.getValue() <= (((ksq).getValue() < (c1).getValue())? (c1) : (ksq)); s++)
			{
			  if ((s != ksq && s != rsq && pos.square_is_occupied(s)) || pos.square_is_attacked(s, them))
			  {
				illegal = true;
			  }
			}
			for (s = (((rsq).getValue() < (d1).getValue())? (rsq) : (d1)); s.getValue() <= (((rsq).getValue() < (d1).getValue())? (d1) : (rsq)); s++)
			{
			  if (s != ksq && s != rsq && pos.square_is_occupied(s))
			  {
				illegal = true;
			  }
			}
			if (square_file(rsq) == File.FILE_B && (pos.piece_on(relative_square(us, Square.SQ_A1)) == rook_of_color(them) || pos.piece_on(relative_square(us, Square.SQ_A1)) == queen_of_color(them)))
			{
			   illegal = true;
			}

			if (!illegal)
			{
			  mlist[n++].move = make_castle_move(ksq, rsq);
			}
		  }
		}

		return n;
	  }


	  /// Variables

	  public static MovegenPhase[] PhaseTable = new MovegenPhase[32];
	  public static int MainSearchPhaseIndex;
	  public static int EvasionsPhaseIndex;
	  public static int QsearchWithChecksPhaseIndex;
	  public static int QsearchWithoutChecksPhaseIndex;







	////
	//// Local definitions
	////


	  /// Constants and variables

	  // Doubled pawn penalty by file, middle game.
	  public static final Value[] DoubledPawnMidgamePenalty = {Value(20), Value(30), Value(34), Value(34), Value(34), Value(34), Value(30), Value(20)};

	  // Doubled pawn penalty by file, endgame.
	  public static final Value[] DoubledPawnEndgamePenalty = {Value(35), Value(40), Value(40), Value(40), Value(40), Value(40), Value(40), Value(35)};

	  // Isolated pawn penalty by file, middle game.
	  public static final Value[] IsolatedPawnMidgamePenalty = {Value(20), Value(30), Value(34), Value(34), Value(34), Value(34), Value(30), Value(20)};

	  // Isolated pawn penalty by file, endgame.
	  public static final Value[] IsolatedPawnEndgamePenalty = {Value(35), Value(40), Value(40), Value(40), Value(40), Value(40), Value(40), Value(35)};

	  // Backward pawn penalty by file, middle game.
	  public static final Value[] BackwardPawnMidgamePenalty = {Value(16), Value(24), Value(27), Value(27), Value(27), Value(27), Value(24), Value(16)};

	  // Backward pawn penalty by file, endgame.
	  public static final Value[] BackwardPawnEndgamePenalty = {Value(28), Value(32), Value(32), Value(32), Value(32), Value(32), Value(32), Value(28)};

	  // Pawn chain membership bonus by file, middle game. 
	  public static final Value[] ChainMidgameBonus = {Value(14), Value(16), Value(17), Value(18), Value(18), Value(17), Value(16), Value(14)};

	  // Pawn chain membership bonus by file, endgame. 
	  public static final Value[] ChainEndgameBonus = {Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16)};

	  // Candidate passed pawn bonus by rank, middle game.
	  public static final Value[] CandidateMidgameBonus = {Value(0), Value(12), Value(12), Value(20), Value(40), Value(90), Value(0), Value(0)};

	  // Candidate passed pawn bonus by rank, endgame.
	  public static final Value[] CandidateEndgameBonus = {Value(0), Value(24), Value(24), Value(40), Value(80), Value(180), Value(0), Value(0)};

	  // Pawn storm tables for positions with opposite castling:
	  public static final int[] QStormTable = {0, 0, 0, 0, 0, 0, 0, 0, -22, -22, -22, -13, -4, 0, 0, 0, -4, -9, -9, -9, -4, 0, 0, 0, 9, 18, 22, 18, 9, 0, 0, 0, 22, 31, 31, 22, 0, 0, 0, 0, 31, 40, 40, 31, 0, 0, 0, 0, 31, 40, 40, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	  public static final int[] KStormTable = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -4, -13, -22, -27, -27, 0, 0, 0, -4, -9, -13, -18, -18, 0, 0, 0, 0, 9, 9, 9, 9, 0, 0, 0, 0, 9, 18, 27, 27, 0, 0, 0, 0, 9, 27, 40, 36, 0, 0, 0, 0, 0, 31, 40, 31, 0, 0, 0, 0, 0, 0, 0, 0};

	  // Pawn storm open file bonuses by file:
	  public static final int[] KStormOpenFileBonus = {45, 45, 30, 0, 0, 0, 0, 0};

	  public static final int[] QStormOpenFileBonus = {0, 0, 0, 0, 0, 30, 45, 30};




	////
	//// Constants and variables
	////

	public static final PieceType PieceTypeMin = PieceType.PAWN;
	public static final PieceType PieceTypeMax = PieceType.KING;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const int SlidingArray[18];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const SquareDelta Directions[16][16];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const SquareDelta PawnPush[2];


	//// 
	//// Inline functions
	////

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Piece operator + (Piece p, int i)
	{
		return Piece(p.getValue() + i);
	}
	private void increment (tangible.RefObject<Piece> p, int UnnamedParameter)
	{
		p.argValue = Piece(p.argValue.getValue() + 1);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Piece operator - (Piece p, int i)
	{
		return Piece(p.getValue() - i);
	}
	private void decrement (tangible.RefObject<Piece> p, int UnnamedParameter)
	{
		p.argValue = Piece(p.argValue.getValue() - 1);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	PieceType operator + (PieceType p, int i)
	{
		return PieceType(p.getValue() + i);
	}
	private void increment (tangible.RefObject<PieceType> p, int UnnamedParameter)
	{
		p.argValue = PieceType(p.argValue.getValue() + 1);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	PieceType operator - (PieceType p, int i)
	{
		return PieceType(p.getValue() - i);
	}
	private void decrement (tangible.RefObject<PieceType> p, int UnnamedParameter)
	{
		p.argValue = PieceType(p.argValue.getValue() - 1);
	}

	public static PieceType type_of_piece(Piece p)
	{
	  return PieceType(p.getValue() & 7);
	}

	public static Color color_of_piece(Piece p)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Color(p.getValue() >> 3);
	}

	public static Piece piece_of_color_and_type(Color c, PieceType pt)
	{
	  return Piece((c.getValue() << 3) | pt.getValue());
	}

	public static Piece pawn_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.PAWN);
	}

	public static Piece knight_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.KNIGHT);
	}

	public static Piece bishop_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.BISHOP);
	}

	public static Piece rook_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.ROOK);
	}

	public static Piece queen_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.QUEEN);
	}

	public static Piece king_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.KING);
	}

	public static int piece_is_slider(Piece p)
	{
	  return SlidingArray[p.getValue()];
	}

	public static int piece_type_is_slider(PieceType pt)
	{
	  return SlidingArray[pt.getValue()];
	}

	public static SquareDelta pawn_push(Color c)
	{
	  return PawnPush[c.getValue()];
	}
public static char piece_type_to_char(PieceType pt)
{
	return piece_type_to_char(pt, false);
}


	////
	//// Prototypes
	////

//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: char piece_type_to_char(PieceType pt, boolean upcase = false)
	public static char piece_type_to_char(PieceType pt, boolean upcase)
	{
	  return upcase? toupper(PieceChars.charAt(pt)) : PieceChars.charAt(pt);
	}

	public static PieceType piece_type_from_char(char c)
	{
//C++ TO JAVA CONVERTER TODO TASK: Java does not have an equivalent to pointers to value types:
//ORIGINAL LINE: const char *ch = strchr(PieceChars, tolower(c));
	  char ch = tangible.StringFunctions.strChr(PieceChars, tolower(c));
	  return ch? PieceType(ch - PieceChars) : PieceType.NO_PIECE_TYPE;
	}

/// piece_is_ok() and piece_type_is_ok(), for debugging:


	public static boolean piece_is_ok(Piece pc)
	{
	  return piece_type_is_ok(type_of_piece(pc)) && color_is_ok(color_of_piece(pc));
	}

	public static boolean piece_type_is_ok(PieceType pc)
	{
	  return pc.getValue() >= PieceType.PAWN.getValue() && pc.getValue() <= PieceType.KING.getValue();
	}





	////
	//// Constants and variables
	////

	public static final int[] SlidingArray = {0, 0, 0, 1, 2, 3, 0, 0, 0, 0, 0, 1, 2, 3, 0, 0, 0, 0};

	public static final SquareDelta[][] Directions =
	{
		{SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_NW, SquareDelta.DELTA_NE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SSW, SquareDelta.DELTA_SSE, SquareDelta.DELTA_SWW, SquareDelta.DELTA_SEE, SquareDelta.DELTA_NWW, SquareDelta.DELTA_NEE, SquareDelta.DELTA_NNW, SquareDelta.DELTA_NNE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SW, SquareDelta.DELTA_SE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SSW, SquareDelta.DELTA_SSE, SquareDelta.DELTA_SWW, SquareDelta.DELTA_SEE, SquareDelta.DELTA_NWW, SquareDelta.DELTA_NEE, SquareDelta.DELTA_NNW, SquareDelta.DELTA_NNE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null}
	};

	public static final SquareDelta[] PawnPush = {SquareDelta.DELTA_N, SquareDelta.DELTA_S};


	////
	//// Functions
	////

	/// Translating piece types to/from English piece letters:

	public static final String PieceChars = " pnbrqk";

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Constants
	////

	/// FEN string for the initial position:
	public static final String StartPosition = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

	/// Maximum number of plies per game (220 should be enough, because the
	/// maximum search depth is 100, and during position setup we reset the
	/// move counter for every non-reversible move):
	public static final int MaxGameLength = 220;

////
//// Functions
////

/// move_to_san() takes a position and a move as input, where it is assumed
/// that the move is a legal move from the position.  The return value is
/// a string containing the move in short algebraic notation.

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////




	////
	//// Prototypes
	////

	public static String move_to_san(Position pos, Move m)
	{
	  String str;

	  assert pos.is_ok();
	  assert move_is_ok(m);

	  if (m == Move.MOVE_NONE)
	  {
		str = "(none)";
		return str;
	  }
	  else if (m == Move.MOVE_NULL)
	  {
		str = "(null)";
		return str;
	  }
	  else if (move_is_long_castle(m))
	  {
		str = "O-O-O";
	  }
	  else if (move_is_short_castle(m))
	  {
		str = "O-O";
	  }
	  else
	  {
		Square from;
		Square to;
		Piece pc;

		from = move_from(m);
		to = move_to(m);
		pc = pos.piece_on(move_from(m));

		str = "";

		if (type_of_piece(pc) == PieceType.PAWN)
		{
		  if (pos.move_is_capture(m))
		  {
			str += file_to_char(square_file(move_from(m)));
		  }
		}
		else
		{
		  str += piece_type_to_char(type_of_piece(pc), true);

		  Ambiguity amb = move_ambiguity(pos, m);
		  switch (amb)
		  {

		  case AMBIGUITY_NONE:
			break;

		  case AMBIGUITY_FILE:
			str += file_to_char(square_file(from));
			break;

		  case AMBIGUITY_RANK:
			str += rank_to_char(square_rank(from));
			break;

		  case AMBIGUITY_BOTH:
			str += square_to_string(from);
			break;

		  default:
			assert false;
		  }
		}

		if (pos.move_is_capture(m))
		{
		  str += "x";
		}

		str += square_to_string(move_to(m));

		if (move_promotion(m).getValue() != 0)
		{
		  str += "=";
		  str += piece_type_to_char(move_promotion(m), true);
		}
	  }

	  // Is the move check?  We don't use pos.move_is_check(m) here, because
	  // Position::move_is_check doesn't detect all checks (not castling moves,
	  // promotions and en passant captures).
	  UndoInfo u = new UndoInfo();
	  pos.do_move(m, u);
	  if (pos.is_check())
	  {
		str += pos.is_mate()? "#" : "+";
	  }
	  pos.undo_move(m, u);

	  return str;
	}

/// move_from_san() takes a position and a string as input, and tries to
/// interpret the string as a move in short algebraic notation.  On success,
/// the move is returned.  On failure (i.e. if the string is unparsable, or
/// if the move is illegal or ambiguous), MOVE_NONE is returned.


	public static Move move_from_san(Position pos, String movestr)
	{
	  assert pos.is_ok();

	  MovePicker mp = new MovePicker(pos, false, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, OnePly);

	  // Castling moves
	  if (movestr.equals("O-O-O"))
	  {
		Move m;
		while ((m = mp.get_next_move()) != Move.MOVE_NONE)
		{
		  if (move_is_long_castle(m) && pos.move_is_legal(m))
		  {
			return m;
		  }
		}
		return Move.MOVE_NONE;
	  }
	  else if (movestr.equals("O-O"))
	  {
		Move m;
		while ((m = mp.get_next_move()) != Move.MOVE_NONE)
		{
		  if (move_is_short_castle(m) && pos.move_is_legal(m))
		  {
			return m;
		  }
		}
		return Move.MOVE_NONE;
	  }

	  // Normal moves
//C++ TO JAVA CONVERTER TODO TASK: Java does not have an equivalent to pointers to value types:
//ORIGINAL LINE: const char *cstr = movestr.c_str();
	  char cstr = movestr;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
	  char * c;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
	  char * cc;
	  String str = new String(new char[10]);
	  int i;

	  // Initialize str[] by making a copy of movestr with the characters
	  // 'x', '=', '+' and '#' removed.
	  cc = str;
	  for (i = 0, c = cstr; i < 10 && *c != '\0' && *c != '\n' && *c != ' '; i++, c++)
	  {
		if (!tangible.StringFunctions.strChr("x=+#", *c))
		{
		  *cc = tangible.StringFunctions.strChr("nrq", *c)? toupper(*c) : *c;
		  cc++;
		}
	  }
	  *cc = '\0';

	  int left = 0;
	  int right = str.length() - 1;
	  PieceType pt = PieceType.NO_PIECE_TYPE;
	  PieceType promotion;
	  Square to;
	  File fromFile = File.FILE_NONE;
	  Rank fromRank = Rank.RANK_NONE;

	  // Promotion?
	  if (tangible.StringFunctions.strChr("BNRQ", str.charAt(right)))
	  {
		promotion = piece_type_from_char(str.charAt(right));
		right--;
	  }
	  else
	  {
		promotion = PieceType.NO_PIECE_TYPE;
	  }

	  // Find the moving piece:
	  if (left < right)
	  {
		if (tangible.StringFunctions.strChr("BNRQK", str.charAt(left)))
		{
		  pt = piece_type_from_char(str.charAt(left));
		  left++;
		}
		else
		{
		  pt = PieceType.PAWN;
		}
	  }

	  // Find the to square:
	  if (left < right)
	  {
		if (str.charAt(right) < '1' || str.charAt(right) > '8' || str.charAt(right - 1) < 'a' || str.charAt(right - 1) > 'h')
		{
		  return Move.MOVE_NONE;
		}
		to = make_square(file_from_char(str.charAt(right - 1)), rank_from_char(str.charAt(right)));
		right -= 2;
	  }
	  else
	  {
		return Move.MOVE_NONE;
	  }

	  // Find the file and/or rank of the from square:
	  if (left <= right)
	  {
		if (tangible.StringFunctions.strChr("abcdefgh", str.charAt(left)))
		{
		  fromFile = file_from_char(str.charAt(left));
		  left++;
		}
		if (tangible.StringFunctions.strChr("12345678", str.charAt(left)))
		{
		  fromRank = rank_from_char(str.charAt(left));
		}
	  }

	  // Look for a matching move:
	  Move m;
	  Move move = Move.MOVE_NONE;
	  int matches = 0;

	  while ((m = mp.get_next_move()) != Move.MOVE_NONE)
	  {
		boolean match = true;
		if (pos.type_of_piece_on(move_from(m)) != pt)
		{
		  match = false;
		}
		else if (move_to(m) != to)
		{
		  match = false;
		}
		else if (move_promotion(m) != promotion)
		{
		  match = false;
		}
		else if (fromFile != File.FILE_NONE && fromFile != square_file(move_from(m)))
		{
		  match = false;
		}
		else if (fromRank != Rank.RANK_NONE && fromRank != square_rank(move_from(m)))
		{
		  match = false;
		}
		if (match)
		{
		  move = m;
		  matches++;
		}
	  }

	  if (matches == 1)
	  {
		return move;
	  }
	  else
	  {
		return Move.MOVE_NONE;
	  }
	}

/// line_to_san() takes a position and a line (an array of moves representing
/// a sequence of legal moves from the position) as input, and returns a
/// string containing the line in short algebraic notation.  If the boolean
/// parameter 'breakLines' is true, line breaks are inserted, with a line
/// length of 80 characters.  After a line break, 'startColumn' spaces are
/// inserted at the beginning of the new line.


	public static String line_to_san(Position pos, Move[] line, int startColumn, boolean breakLines)
	{
	  Position p = new Position(pos);
	  UndoInfo u = new UndoInfo();
	  std::stringstream s = new std::stringstream();
	  String moveStr;
	  int length;
	  int maxLength;

	  length = 0;
	  maxLength = 80 - startColumn;

	  for (int i = 0; line[i] != Move.MOVE_NONE; i++)
	  {
		moveStr = move_to_san(p, line[i]);
		length += moveStr.length() + 1;
		if (breakLines && length > maxLength)
		{
		  s << "\n";
		  for (int j = 0; j < startColumn; j++)
		  {
			s << " ";
		  }
		  length = moveStr.length() + 1;
		}
		s << moveStr << " ";

		if (line[i] == Move.MOVE_NULL)
		{
		  p.do_null_move(u);
		}
		else
		{
		  p.do_move(line[i], u);
		}
	  }

	  return s.str();
	}

/// pretty_pv() creates a human-readable string from a position and a PV.
/// It is used to write search information to the log file (which is created
/// when the UCI parameter "Use Search Log" is "true").


	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const std::string pretty_pv(const Position &pos, int time, int depth, unsigned long long nodes, Value score, Move pv[]);
	public static String pretty_pv(Position pos, int time, int depth, long nodes, Value score, Move[] pv)
	{
	  std::stringstream s = new std::stringstream();

	  // Depth
	  s << std::setw(2) << std::setfill(' ') << depth << "  ";

	  // Score
	  s << std::setw(8) << score_string(score);

	  // Time
	  s << std::setw(8) << std::setfill(' ') << time_string(time) << " ";

	  // Nodes
	  if (nodes < 1000000)
	  {
		s << std::setw(8) << std::setfill(' ') << nodes << " ";
	  }
	  else if (nodes < 1000000000)
	  {
		s << std::setw(7) << std::setfill(' ') << nodes / 1000 << 'k' << " ";
	  }
	  else
	  {
		s << std::setw(7) << std::setfill(' ') << nodes / 1000000 << 'M' << " ";
	  }

	  // PV
	  s << line_to_san(pos, pv, 30, true);

	  return s.str();
	}


	  /// Functions

	  public static Ambiguity move_ambiguity(Position pos, Move m)
	  {
		Square from;
		Square to;
		Piece pc;

		from = move_from(m);
		to = move_to(m);
		pc = pos.piece_on(from);

		// King moves are never ambiguous, because there is never two kings of
		// the same color.
		if (type_of_piece(pc) == PieceType.KING)
		{
		  return Ambiguity.AMBIGUITY_NONE;
		}

		MovePicker mp = new MovePicker(pos, false, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, OnePly);
		Move mv;
		Move[] moveList = new Move[8];
		int i;
		int j;
		int n;

		n = 0;
		while ((mv = mp.get_next_move()) != Move.MOVE_NONE)
		{
		  if (move_to(mv) == to && pos.piece_on(move_from(mv)) == pc && pos.move_is_legal(mv))
		  {
			moveList[n++] = mv;
		  }
		}
		if (n == 1)
		{
		  return Ambiguity.AMBIGUITY_NONE;
		}

		j = 0;
		for (i = 0; i < n; i++)
		{
		  if (square_file(move_from(moveList[i])) == square_file(from))
		  {
			j++;
		  }
		}
		if (j == 1)
		{
		  return Ambiguity.AMBIGUITY_FILE;
		}

		j = 0;
		for (i = 0; i < n; i++)
		{
		  if (square_rank(move_from(moveList[i])) == square_rank(from))
		  {
			j++;
		  }
		}
		if (j == 1)
		{
		  return Ambiguity.AMBIGUITY_RANK;
		}

		return Ambiguity.AMBIGUITY_BOTH;
	  }

	  public static String time_string(int milliseconds)
	  {
		std::stringstream s = new std::stringstream();

		int hours = milliseconds / (1000 * 60 * 60);
		int minutes = (milliseconds - hours * 1000 * 60 * 60) / (60 * 1000);
		int seconds = (milliseconds - hours * 1000 * 60 * 60 - minutes * 60 * 1000) / 1000;

		if (hours != 0)
		{
		  s << hours << ':';
		}
		s << std::setw(2) << std::setfill('0') << minutes << ':';
		s << std::setw(2) << std::setfill('0') << seconds;

		return s.str();
	  }

	  public static String score_string(Value v)
	  {
		std::stringstream s = new std::stringstream();

		if (Math.abs(v) >= Value.VALUE_MATE.getValue() - 200)
		{
		  if (v.getValue() < 0)
		  {
			s << "-#" << (Value.VALUE_MATE + v) / 2;
		  }
		  else
		  {
			s << "#" << (Value.VALUE_MATE - v + 1) / 2;
		  }
		}
		else
		{
		  float floatScore = (float)v.getValue() / (float)PawnValueMidgame.getValue();
		  if (v.getValue() >= 0)
		  {
			s << '+';
		  }
		  s << std::setprecision(2) << std::fixed << floatScore;
		}
		return s.str();
	  }
	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Constants
	////

	public static final int PLY_MAX = 100;
	public static final int PLY_MAX_PLUS_2 = 102;


	////
	//// Global variables
	////

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern TranspositionTable TT;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern int ActiveThreads;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Lock SMPLock;

	// Perhaps better to make H local, and pass as parameter to MovePicker?
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern History H;

/// init_threads() is called during startup.  It launches all helper threads,
/// and initializes the split point stack and the global locks and condition
/// objects.



	////
	//// Prototypes
	////

	public static void init_threads()
	{
//C++ TO JAVA CONVERTER TODO TASK: 'volatile' has a different meaning in Java:
//ORIGINAL LINE: volatile int i;
	  int i;
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
	  pthread_t[] pthread = tangible.Arrays.initializeWithDefaultpthread_tInstances(1);
	///#endif

	  for (i = 0; i < THREAD_MAX; i++)
	  {
		Threads[i].activeSplitPoints = 0;
	  }

	  // Initialize global locks:
	  lock_init(MPLock, null);
	  lock_init(IOLock, null);

	  init_split_point_stack();

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
	  pthread_mutex_init(WaitLock, null);
	  pthread_cond_init(WaitCond, null);
	///#else
	  for (i = 0; i < THREAD_MAX; i++)
	  {
		SitIdleEvent[i] = CreateEvent(0, false, false, 0);
	  }
	///#endif

	  // All threads except the main thread should be initialized to idle state:
	  for (i = 1; i < THREAD_MAX; i++)
	  {
		Threads[i].stop = false;
		Threads[i].workIsWaiting = false;
		Threads[i].idle = true;
		Threads[i].running = false;
	  }

	  // Launch the helper threads:
	  for (i = 1; i < THREAD_MAX; i++)
	  {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
		pthread_create(pthread, null, init_thread, (Object)(i));
	///#else
		{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: DWORD iID[1];
		  int[] iID = new int[1];
		  CreateThread(null, 0, init_thread, (Object)(i), 0, iID);
		}
	///#endif

		// Wait until the thread has finished launching:
//C++ TO JAVA CONVERTER TODO TASK: Variables cannot be declared in if/while/switch conditions in Java:
		while (!Threads[i].running)
		{
			;
		}
	  }
	}

/// stop_threads() is called when the program exits.  It makes all the
/// helper threads exit cleanly.


	public static void stop_threads()
	{
	  ActiveThreads = THREAD_MAX; // HACK
	  Idle = false; // HACK
	  wake_sleeping_threads();
	  AllThreadsShouldExit = true;
	  for (int i = 1; i < THREAD_MAX; i++)
	  {
		Threads[i].stop = true;
//C++ TO JAVA CONVERTER TODO TASK: Variables cannot be declared in if/while/switch conditions in Java:
		while (Threads[i].running)
		{
			;
		}
	  }
	  destroy_split_point_stack();
	}

////
//// Functions
////

/// think() is the external interface to Glaurung's search, and is called when
/// the program receives the UCI 'go' command.  It initializes various
/// search-related global variables, and calls root_search()


	public static void think(Position pos, boolean infinite, boolean ponder, int time, int increment, int movesToGo, int maxDepth, int maxNodes, int maxTime, Move[] searchMoves)
	{

	  // Look for a book move:
	  if (!infinite && !ponder && get_option_value_bool("OwnBook"))
	  {
		Move bookMove;
		if (!get_option_value_string("Book File").equals(OpeningBook.file_name()))
		{
		  OpeningBook.close();
		  OpeningBook.open("book.bin");
		}
		bookMove = OpeningBook.get_move(pos);
		if (bookMove != Move.MOVE_NONE)
		{
		  System.out.print("bestmove ");
		  System.out.print(bookMove);
		  System.out.print("\n");
		  return;
		}
	  }

	  // Initialize global search variables:
	  Idle = false;
	  SearchStartTime = get_system_time();
	  BestRootMove = Move.MOVE_NONE;
	  PonderMove = Move.MOVE_NONE;
	  EasyMove = Move.MOVE_NONE;
	  for (int i = 0; i < THREAD_MAX; i++)
	  {
		Threads[i].nodes = 0;
		Threads[i].failHighPly1 = false;
	  }
	  NodesSincePoll = 0;
	  InfiniteSearch = infinite;
	  PonderSearch = ponder;
	  StopOnPonderhit = false;
	  AbortSearch = false;
	  Quit = false;
	  FailHigh = false;
	  Problem = false;
	  ExactMaxTime = maxTime;

	  // Read UCI option values:
	  TT.set_size(get_option_value_int("Hash"));
	  if (button_was_pressed("Clear Hash"))
	  {
		TT.clear();
	  }
	  PonderingEnabled = get_option_value_int("Ponder") != 0;
	  MultiPV = get_option_value_int("MultiPV");

	  CheckExtension[1] = Depth(get_option_value_int("Check Extension (PV nodes)"));
	  CheckExtension[0] = Depth(get_option_value_int("Check Extension (non-PV nodes)"));
	  SingleReplyExtension[1] = Depth(get_option_value_int("Single Reply Extension (PV nodes)"));
	  SingleReplyExtension[0] = Depth(get_option_value_int("Single Reply Extension (non-PV nodes)"));
	  PawnPushTo7thExtension[1] = Depth(get_option_value_int("Pawn Push to 7th Extension (PV nodes)"));
	  PawnPushTo7thExtension[0] = Depth(get_option_value_int("Pawn Push to 7th Extension (non-PV nodes)"));
	  PassedPawnExtension[1] = Depth(get_option_value_int("Passed Pawn Extension (PV nodes)"));
	  PassedPawnExtension[0] = Depth(get_option_value_int("Passed Pawn Extension (non-PV nodes)"));
	  PawnEndgameExtension[1] = Depth(get_option_value_int("Pawn Endgame Extension (PV nodes)"));
	  PawnEndgameExtension[0] = Depth(get_option_value_int("Pawn Endgame Extension (non-PV nodes)"));
	  MateThreatExtension[1] = Depth(get_option_value_int("Mate Threat Extension (PV nodes)"));
	  MateThreatExtension[0] = Depth(get_option_value_int("Mate Threat Extension (non-PV nodes)"));

	  LMRPVMoves = get_option_value_int("Full Depth Moves (PV nodes)") + 1;
	  LMRNonPVMoves = get_option_value_int("Full Depth Moves (non-PV nodes)") + 1;
	  ThreatDepth = get_option_value_int("Threat Depth") * OnePly.getValue();
	  SelectiveDepth = get_option_value_int("Selective Plies") * OnePly.getValue();

	  Chess960 = get_option_value_bool("UCI_Chess960");
	  ShowCurrentLine = get_option_value_bool("UCI_ShowCurrLine");
	  UseLogFile = get_option_value_bool("Use Search Log");
	  if (UseLogFile)
	  {
		LogFile.open(get_option_value_string("Search Log Filename"), std::ios.out | std::ios.app);
	  }

	  UseQSearchFutilityPruning = get_option_value_bool("Futility Pruning (Quiescence Search)");
	  UseFutilityPruning = get_option_value_bool("Futility Pruning (Main Search)");

	  FutilityMargin0 = value_from_centipawns(get_option_value_int("Futility Margin 0"));
	  FutilityMargin1 = value_from_centipawns(get_option_value_int("Futility Margin 1"));
	  FutilityMargin2 = value_from_centipawns(get_option_value_int("Futility Margin 2"));

	  RazorDepth = (get_option_value_int("Maximum Razoring Depth") + 1) * OnePly;
	  RazorMargin2 = value_from_centipawns(get_option_value_int("Razoring Margin"));
	  RazorMargin1 = RazorMargin2 / 4;

	  MinimumSplitDepth = get_option_value_int("Minimum Split Depth") * OnePly.getValue();
	  MaxThreadsPerSplitPoint = get_option_value_int("Maximum Number of Threads per Split Point");

	  read_weights(pos.side_to_move());

	  int newActiveThreads = get_option_value_int("Threads");
	  if (newActiveThreads != ActiveThreads)
	  {
		ActiveThreads = newActiveThreads;
		init_eval(ActiveThreads);
	  }

	  // Write information to search log file:
	  if (UseLogFile)
	  {
		LogFile << "Searching: " << pos.to_fen() << '\n';
		LogFile << "infinite: " << infinite << " ponder: " << ponder << " time: " << time << " increment: " << increment << " moves to go: " << movesToGo << '\n';
	  }

	  // Wake up sleeping threads:
	  wake_sleeping_threads();

	  for (int i = 1; i < ActiveThreads; i++)
	  {
		assert thread_is_available(i, 0);
	  }

	  // Set thinking time:
	  if (movesToGo == 0)
	  { // Sudden death time control
		if (increment != 0)
		{
		  MaxSearchTime = time / 30 + increment;
		  AbsoluteMaxSearchTime = (((time / 4) < (increment - 100))? (increment - 100) : (time / 4));
		}
		else
		{ // Blitz game without increment
		  MaxSearchTime = time / 40;
		  AbsoluteMaxSearchTime = time / 8;
		}
	  }
	  else
	  { // (x moves) / (y minutes)
		if (movesToGo == 1)
		{
		  MaxSearchTime = time / 2;
		  AbsoluteMaxSearchTime = (((time / 2) < (time - 500))? (time / 2) : (time - 500));
		}
		else
		{
		  MaxSearchTime = time / (((movesToGo) < (20))? (movesToGo) : (20));
		  AbsoluteMaxSearchTime = ((((4 * time) / movesToGo) < (time / 3))? ((4 * time) / movesToGo) : (time / 3));
		}
	  }
	  if (PonderingEnabled)
	  {
		MaxSearchTime += MaxSearchTime / 4;
		MaxSearchTime = (((MaxSearchTime) < (AbsoluteMaxSearchTime))? (MaxSearchTime) : (AbsoluteMaxSearchTime));
	  }

	  // Fixed depth or fixed number of nodes?
	  MaxDepth = maxDepth;
	  if (MaxDepth != 0)
	  {
		InfiniteSearch = true; // HACK
	  }

	  MaxNodes = maxNodes;
	  if (MaxNodes != 0)
	  {
		NodesBetweenPolls = (((MaxNodes) < (30000))? (MaxNodes) : (30000));
		InfiniteSearch = true; // HACK
	  }
	  else
	  {
		NodesBetweenPolls = 30000;
	  }

	  // We're ready to start thinking.  Call the iterative deepening loop
	  // function:
	  id_loop(pos, searchMoves);

	  if (UseLogFile)
	  {
		LogFile.close();
	  }

	  if (Quit)
	  {
		OpeningBook.close();
		stop_threads();
		quit_eval();
		System.exit(0);
	  }

	  Idle = true;
	}

/// nodes_searched() returns the total number of nodes searched so far in
/// the current search.


	public static long nodes_searched()
	{
	  long result = 0;
	  for (int i = 0; i < ActiveThreads; i++)
	  {
		result += Threads[i].nodes;
	  }
	  return result;
	}


	  /// Constants and variables

	  // Minimum number of full depth (i.e. non-reduced) moves at PV and non-PV
	  // nodes:
	  public static int LMRPVMoves = 15;
	  public static int LMRNonPVMoves = 4;

	  // Depth limit for use of dynamic threat detection:
	  public static Depth ThreatDepth = 5 * OnePly;

	  // Depth limit for selective search:
	  public static Depth SelectiveDepth = 7 * OnePly;

	  // Use internal iterative deepening?
	  public static final boolean UseIIDAtPVNodes = true;
	  public static final boolean UseIIDAtNonPVNodes = false;

	  // Internal iterative deepening margin.  At Non-PV moves, when
	  // UseIIDAtNonPVNodes is true, we do an internal iterative deepening search
	  // when the static evaluation is at most IIDMargin below beta.
	  public static final Value IIDMargin = 0x100;

	  // Easy move margin.  An easy move candidate must be at least this much
	  // better than the second best move.
	  public static final Value EasyMoveMargin = 0x200;

	  // Problem margin.  If the score of the first move at iteration N+1 has
	  // dropped by more than this since iteration N, the boolean variable
	  // "Problem" is set to true, which will make the program spend some extra
	  // time looking for a better move.
	  public static final Value ProblemMargin = 0x28;

	  // No problem margin.  If the boolean "Problem" is true, and a new move
	  // is found at the root which is less than NoProblemMargin worse than the
	  // best move from the previous iteration, Problem is set back to false.
	  public static final Value NoProblemMargin = 0x14;

	  // Null move margin.  A null move search will not be done if the approximate
	  // evaluation of the position is more than NullMoveMargin below beta.
	  public static final Value NullMoveMargin = 0x300;

	  // Pruning criterions.  See the code and comments in ok_to_prune() to
	  // understand their precise meaning.
	  public static final boolean PruneEscapeMoves = false;
	  public static final boolean PruneDefendingMoves = false;
	  public static final boolean PruneBlockingMoves = false;

	  // Use futility pruning?
	  public static boolean UseQSearchFutilityPruning = true;
	  public static boolean UseFutilityPruning = true;

	  // Margins for futility pruning in the quiescence search, at frontier
	  // nodes, and at pre-frontier nodes:
	  public static Value FutilityMargin0 = 0x80;
	  public static Value FutilityMargin1 = 0x100;
	  public static Value FutilityMargin2 = 0x200;

	  // Razoring
	  public static Depth RazorDepth = 4 * OnePly;
	  public static Value RazorMargin1 = 0x100;
	  public static Value RazorMargin2 = 0x300;

	  // Extensions.  Array index 0 is used at non-PV nodes, index 1 at PV nodes.
	  public static Depth[] CheckExtension = {OnePly, OnePly};
	  public static Depth[] SingleReplyExtension = {OnePly / 2, OnePly / 2};
	  public static Depth[] PawnPushTo7thExtension = {OnePly / 2, OnePly / 2};
	  public static Depth[] PassedPawnExtension = {Depth(0), Depth(0)};
	  public static Depth[] PawnEndgameExtension = {OnePly, OnePly};
	  public static Depth[] MateThreatExtension = {Depth(0), Depth(0)};

	  // Search depth at iteration 1:
	  public static final Depth InitialDepth = OnePly;

	  // Node counters
	  public static int NodesSincePoll;
	  public static int NodesBetweenPolls = 30000;

	  // Iteration counter:
	  public static int Iteration;

	  // Scores and number of times the best move changed for each iteration:
	  public static Value[] ValueByIteration = new Value[PLY_MAX_PLUS_2];
	  public static int[] BestMoveChangesByIteration = new int[PLY_MAX_PLUS_2];

	  // MultiPV mode:
	  public static int MultiPV = 1;

	  // Time managment variables
	  public static int SearchStartTime;
	  public static int MaxNodes;
	  public static int MaxDepth;
	  public static int MaxSearchTime;
	  public static int AbsoluteMaxSearchTime;
	  public static int ExtraSearchTime;
	  public static Move BestRootMove;
	  public static Move PonderMove;
	  public static Move EasyMove;
	  public static int RootMoveNumber;
	  public static boolean InfiniteSearch;
	  public static boolean PonderSearch;
	  public static boolean StopOnPonderhit;
	  public static boolean AbortSearch;
	  public static boolean Quit;
	  public static boolean FailHigh;
	  public static boolean Problem;
	  public static boolean PonderingEnabled;
	  public static int ExactMaxTime;

	  // Show current line?
	  public static boolean ShowCurrentLine = false;

	  // Log file
	  public static boolean UseLogFile = false;
	  public static std::ofstream LogFile = new std::ofstream();

	  // MP related variables
	  public static Depth MinimumSplitDepth = 4 * OnePly;
	  public static int MaxThreadsPerSplitPoint = 4;
	  public static Thread[] Threads = tangible.Arrays.initializeWithDefaultThreadInstances(THREAD_MAX);
	  public static Lock MPLock = new Lock();
	  public static boolean AllThreadsShouldExit = false;
	  public static final int MaxActiveSplitPoints = 8;
	  public static SplitPoint[][] SplitPointStack = new SplitPoint[THREAD_MAX][MaxActiveSplitPoints];
	  public static boolean Idle = true;

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
	  public static pthread_cond_t WaitCond = new pthread_cond_t();
	  public static pthread_mutex_t WaitLock = new pthread_mutex_t();
	///#else
	  public static HANDLE[] SitIdleEvent = tangible.Arrays.initializeWithDefaultHANDLEInstances(THREAD_MAX);
	///#endif

  // id_loop() is the main iterative deepening loop.  It calls root_search
  // repeatedly with increasing depth until the allocated thinking time has
  // been consumed, the user stops the search, or the maximum search depth is
  // reached.



	  /// Functions

	  public static void id_loop(Position pos, Move[] searchMoves)
	  {
		Position p = new Position(pos);
		RootMoveList rml = new RootMoveList(p, searchMoves);
		SearchStack[] ss = tangible.Arrays.initializeWithDefaultSearchStackInstances(PLY_MAX_PLUS_2);

		// Initialize
		TT.new_search();
		H.clear();
		init_search_stack(ss);

		ValueByIteration[0] = Value(0);
		ValueByIteration[1] = rml.get_move_score(0);
		Iteration = 1;

		EasyMove = rml.scan_for_easy_move();

		// Iterative deepening loop
		while (!AbortSearch && Iteration < PLY_MAX)
		{

		  // Initialize iteration
		  rml.sort();
		  Iteration++;
		  BestMoveChangesByIteration[Iteration] = 0;
		  if (Iteration <= 5)
		  {
			ExtraSearchTime = 0;
		  }

		  System.out.print("info depth ");
		  System.out.print(Iteration);
		  System.out.print("\n");

		  // Search to the current depth
		  ValueByIteration[Iteration] = root_search(p, ss, rml);

		  // Erase the easy move if it differs from the new best move
		  if (ss[0].pv[0] != EasyMove)
		  {
			EasyMove = Move.MOVE_NONE;
		  }

		  Problem = false;

		  if (!InfiniteSearch)
		  {
			// Time to stop?
			boolean stopSearch = false;

			// Stop search early if there is only a single legal move:
			if (Iteration >= 6 && rml.move_count() == 1)
			{
			  stopSearch = true;
			}

			// Stop search early when the last two iterations returned a mate
			// score:
			if (Iteration >= 6 && Math.abs(ValueByIteration[Iteration]) >= Math.abs(Value.VALUE_MATE) - 100 && Math.abs(ValueByIteration[Iteration - 1]) >= Math.abs(Value.VALUE_MATE) - 100)
			{
			  stopSearch = true;
			}

			// Stop search early if one move seems to be much better than the
			// rest:
			long nodes = nodes_searched();
			if (Iteration >= 8 && EasyMove == ss[0].pv[0] && ((rml.get_move_cumulative_nodes(0) > (nodes * 85) / 100 && current_search_time() > MaxSearchTime / 16) || (rml.get_move_cumulative_nodes(0) > (nodes * 98) / 100 && current_search_time() > MaxSearchTime / 32)))
			{
			  stopSearch = true;
			}

			// Add some extra time if the best move has changed during the last
			// two iterations:
			if (Iteration > 5 && Iteration <= 50)
			{
			  ExtraSearchTime = BestMoveChangesByIteration[Iteration] * (MaxSearchTime / 2) + BestMoveChangesByIteration[Iteration - 1] * (MaxSearchTime / 3);
			}

			// Stop search if most of MaxSearchTime is consumed at the end of the
			// iteration.  We probably don't have enough time to search the first
			// move at the next iteration anyway.
			if (current_search_time() > ((MaxSearchTime + ExtraSearchTime) * 80) / 128)
			{
			  stopSearch = true;
			}

			if (stopSearch)
			{
			  if (!PonderSearch)
			  {
				break;
			  }
			  else
			  {
				StopOnPonderhit = true;
			  }
			}
		  }

		  // Write PV to transposition table, in case the relevant entries have
		  // been overwritten during the search:
		  TT.insert_pv(p, ss[0].pv);

		  if (MaxDepth != 0 && Iteration >= MaxDepth)
		  {
			break;
		  }
		}

		rml.sort();

		// If we are pondering, we shouldn't print the best move before we
		// are told to do so
		if (PonderSearch)
		{
		  wait_for_stop_or_ponderhit();
		}
		else
		{
		  // Print final search statistics
		  System.out.print("info nodes ");
		  System.out.print(nodes_searched());
		  System.out.print(" nps ");
		  System.out.print(nps());
		  System.out.print(" time ");
		  System.out.print(current_search_time());
		  System.out.print(" hashfull ");
		  System.out.print(TT.full());
		  System.out.print("\n");
		}

		// Print the best move and the ponder move to the standard output:
		System.out.print("bestmove ");
		System.out.print(ss[0].pv[0]);
		if (ss[0].pv[1] != Move.MOVE_NONE)
		{
		  System.out.print(" ponder ");
		  System.out.print(ss[0].pv[1]);
		}
		System.out.print("\n");

		if (UseLogFile)
		{
		  UndoInfo u = new UndoInfo();
		  LogFile << "Nodes: " << nodes_searched() << '\n';
		  LogFile << "Nodes/second: " << nps() << '\n';
		  LogFile << "Best move: " << move_to_san(p, ss[0].pv[0]) << '\n';
		  p.do_move(ss[0].pv[0], u);
		  LogFile << "Ponder move: " << move_to_san(p, ss[0].pv[1]) << '\n';
		  LogFile << std::endl;
		}
	  }

  // root_search() is the function which searches the root node.  It is
  // similar to search_pv except that it uses a different move ordering
  // scheme (perhaps we should try to use this at internal PV nodes, too?)
  // and prints some information to the standard output.


	  public static Value root_search(Position pos, SearchStack[] ss, RootMoveList rml)
	  {
		Value alpha = -Value.VALUE_INFINITE;
		Value beta = Value.VALUE_INFINITE;
		Value value;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long dcCandidates = pos.discovered_check_candidates(pos.side_to_move());
		long dcCandidates = pos.discovered_check_candidates(pos.side_to_move());

		// Loop through all the moves in the root move list:
		for (int i = 0; i < rml.move_count() && !AbortSearch; i++)
		{
		  long nodes;
		  Move move;
		  UndoInfo u = new UndoInfo();
		  Depth ext;
		  Depth newDepth;

		  RootMoveNumber = i + 1;
		  FailHigh = false;

		  // Remember the node count before the move is searched.  The node counts
		  // are used to sort the root moves at the next iteration.
		  nodes = nodes_searched();

		  // Pick the next root move, and print the move and the move number to
		  // the standard output:
		  move = ss[0].currentMove = rml.get_move(i);
		  if (current_search_time() >= 1000)
		  {
			System.out.print("info currmove ");
			System.out.print(move);
			System.out.print(" currmovenumber ");
			System.out.print(i + 1);
			System.out.print("\n");
		  }

		  // Decide search depth for this move:
		  ext = extension(pos, move, true, pos.move_is_check(move), false, false);
		  newDepth = (Iteration - 2) * OnePly + ext + InitialDepth;

		  // Make the move, and search it.
		  pos.do_move(move, u, dcCandidates);

		  if (i < MultiPV)
		  {
			value = -search_pv(pos, ss, -beta, Value.VALUE_INFINITE, newDepth, 1, 0);
			// If the value has dropped a lot compared to the last iteration,
			// set the boolean variable Problem to true.  This variable is used
			// for time managment:  When Problem is true, we try to complete the
			// current iteration before playing a move.
			Problem = (Iteration >= 2 && value.getValue() <= ValueByIteration[Iteration - 1].getValue() - ProblemMargin);
			if (Problem && StopOnPonderhit)
			{
			  StopOnPonderhit = false;
			}
		  }
		  else
		  {
			value = -search(pos, ss, -alpha, newDepth, 1, true, 0);
			if (value.getValue() > alpha.getValue())
			{
			  // Fail high!  Set the boolean variable FailHigh to true, and
			  // re-search the move with a big window.  The variable FailHigh is
			  // used for time managment:  We try to avoid aborting the search
			  // prematurely during a fail high research.
			  FailHigh = true;
			  value = -search_pv(pos, ss, -beta, -alpha, newDepth, 1, 0);
			}
		  }

		  pos.undo_move(move, u);

		  // Finished searching the move.  If AbortSearch is true, the search
		  // was aborted because the user interrupted the search or because we
		  // ran out of time.  In this case, the return value of the search cannot
		  // be trusted, and we break out of the loop without updating the best
		  // move and/or PV:
		  if (AbortSearch)
		  {
			break;
		  }

		  // Remember the node count for this move.  The node counts are used to
		  // sort the root moves at the next iteration.
		  rml.set_move_nodes(i, nodes_searched() - nodes);

		  assert value.getValue() >= -Value.VALUE_INFINITE && value.getValue() <= Value.VALUE_INFINITE.getValue();

		  if (value.getValue() <= alpha.getValue() && i >= MultiPV)
		  {
			rml.set_move_score(i, -Value.VALUE_INFINITE);
		  }
		  else
		  {
			// New best move!

			// Update PV:
			rml.set_move_score(i, value);
			update_pv(ss, 0);
			rml.set_move_pv(i, ss[0].pv);

			if (MultiPV == 1)
			{
			  // We record how often the best move has been changed in each
			  // iteration.  This information is used for time managment:  When
			  // the best move changes frequently, we allocate some more time.
			  if (i > 0)
			  {
				BestMoveChangesByIteration[Iteration]++;
			  }

			  // Print search information to the standard output:
			  System.out.print("info depth ");
			  System.out.print(Iteration);
			  System.out.print(" score ");
			  System.out.print(value_to_string(value));
			  System.out.print(" time ");
			  System.out.print(current_search_time());
			  System.out.print(" nodes ");
			  System.out.print(nodes_searched());
			  System.out.print(" nps ");
			  System.out.print(nps());
			  System.out.print(" pv ");
			  for (int j = 0; ss[0].pv[j] != Move.MOVE_NONE && j < PLY_MAX; j++)
			  {
				System.out.print(ss[0].pv[j]);
				System.out.print(" ");
			  }
			  System.out.print("\n");

			  if (UseLogFile)
			  {
				LogFile << pretty_pv(pos, current_search_time(), Iteration, nodes_searched(), value, ss[0].pv) << std::endl;
			  }

			  alpha = value;

			  // Reset the global variable Problem to false if the value isn't too
			  // far below the final value from the last iteration.
			  if (value.getValue() > ValueByIteration[Iteration - 1].getValue() - NoProblemMargin)
			  {
				Problem = false;
			  }
			}
			else
			{ // MultiPV > 1
			  rml.sort_multipv(i);
			  for (int j = 0; j < (((MultiPV) < (rml.move_count()))? (MultiPV) : (rml.move_count())); j++)
			  {
				int k;
				System.out.print("info multipv ");
				System.out.print(j + 1);
				System.out.print(" score ");
				System.out.print(value_to_string(rml.get_move_score(j)));
				System.out.print(" depth ");
				System.out.print(((j <= i)? Iteration : Iteration - 1));
				System.out.print(" time ");
				System.out.print(current_search_time());
				System.out.print(" nodes ");
				System.out.print(nodes_searched());
				System.out.print(" nps ");
				System.out.print(nps());
				System.out.print(" pv ");
				for (k = 0; rml.get_move_pv(j, k) != Move.MOVE_NONE && k < PLY_MAX; k++)
				{
				  System.out.print(rml.get_move_pv(j, k));
				  System.out.print(" ");
				}
				System.out.print("\n");
			  }
			  alpha = rml.get_move_score((((i) < (MultiPV - 1))? (i) : (MultiPV - 1)));
			}
		  }
		}
		return alpha;
	  }

  // search_pv() is the main search function for PV nodes.


	  public static Value search_pv(Position pos, SearchStack[] ss, Value alpha, Value beta, Depth depth, int ply, int threadID)
	  {
		assert alpha.getValue() >= -Value.VALUE_INFINITE && alpha.getValue() <= Value.VALUE_INFINITE.getValue();
		assert beta.getValue() > alpha.getValue() && beta.getValue() <= Value.VALUE_INFINITE.getValue();
		assert ply >= 0 && ply < PLY_MAX;
		assert threadID >= 0 && threadID < ActiveThreads;

		EvalInfo ei = new EvalInfo();

		// Initialize, and make an early exit in case of an aborted search,
		// an instant draw, maximum ply reached, etc.
		Value oldAlpha = alpha;

		if (AbortSearch || thread_should_stop(threadID))
		{
		  return Value(0);
		}

		if (depth.getValue() < OnePly.getValue())
		{
		  return qsearch(pos, ss, alpha, beta, Depth(0), ply, threadID);
		}

		init_node(pos, ss, ply, threadID);

		if (pos.is_draw())
		{
		  return Value.VALUE_DRAW;
		}

		if (ply >= PLY_MAX - 1)
		{
		  return evaluate(pos, ei, threadID);
		}

		// Mate distance pruning
		alpha = (((value_mated_in(ply)) < (alpha).getValue())? (alpha) : (value_mated_in(ply)));
		beta = (((value_mate_in(ply + 1)) < (beta).getValue())? (value_mate_in(ply + 1)) : (beta));
		if (alpha.getValue() >= beta.getValue())
		{
		  return alpha;
		}

		// Transposition table lookup.  At PV nodes, we don't use the TT for
		// pruning, but only for move ordering.
		Value ttValue;
		Depth ttDepth;
		Move ttMove = Move.MOVE_NONE;
		ValueType ttValueType;

		TT.retrieve(pos, ttValue, ttDepth, ttMove, ttValueType);

		// Internal iterative deepening.
		if (UseIIDAtPVNodes && ttMove == Move.MOVE_NONE && depth.getValue() >= 5 * OnePly)
		{
		  search_pv(pos, ss, alpha, beta, depth - 2 * OnePly, ply, threadID);
		  ttMove = ss[ply].pv[ply];
		}

		// Initialize a MovePicker object for the current position, and prepare
		// to search all moves:
		MovePicker mp = new MovePicker(pos, true, ttMove, ss[ply].mateKiller, ss[ply].killer1, ss[ply].killer2, depth);
		Move move;
		Move[] movesSearched = new Move[256];
		int moveCount = 0;
		Value value;
		Value bestValue = -Value.VALUE_INFINITE;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long dcCandidates = mp.discovered_check_candidates();
		long dcCandidates = mp.discovered_check_candidates();
		boolean mateThreat = MateThreatExtension[1].getValue() > Depth(0) && pos.has_mate_threat(opposite_color(pos.side_to_move()));

		// Loop through all legal moves until no moves remain or a beta cutoff
		// occurs.
		while (alpha.getValue() < beta.getValue() && !thread_should_stop(threadID) && (move = mp.get_next_move()) != Move.MOVE_NONE)
		{
		  UndoInfo u = new UndoInfo();
		  Depth ext;
		  Depth newDepth;
		  boolean singleReply = (pos.is_check() && mp.number_of_moves() == 1);
		  boolean moveIsCheck = pos.move_is_check(move, dcCandidates);
		  boolean moveIsCapture = pos.move_is_capture(move);
		  boolean moveIsPassedPawnPush = pos.move_is_passed_pawn_push(move);

		  assert move_is_ok(move);
		  movesSearched[moveCount++] = ss[ply].currentMove = move;

		  ss[ply].currentMoveCaptureValue = move_is_ep(move)? PawnValueMidgame : pos.midgame_value_of_piece_on(move_to(move));

		  // Decide the new search depth.
		  ext = extension(pos, move, true, moveIsCheck, singleReply, mateThreat);
		  newDepth = depth - OnePly + ext;

		  // Make and search the move.
		  pos.do_move(move, u, dcCandidates);

		  if (moveCount == 1)
		  {
			value = -search_pv(pos, ss, -beta, -alpha, newDepth, ply + 1, threadID);
		  }
		  else
		  {
			if (depth.getValue() >= 2 * OnePly && ext == Depth(0) && moveCount >= LMRPVMoves && !moveIsCapture && move_promotion(move).getValue() == 0 && !moveIsPassedPawnPush && !move_is_castle(move) && move != ss[ply].killer1 && move != ss[ply].killer2)
			{
			  ss[ply].reduction = OnePly;
			  value = -search(pos, ss, -alpha, newDepth - OnePly, ply + 1, true, threadID);
			}
			else
			{
				value = alpha + 1;
			}
			if (value.getValue() > alpha.getValue())
			{
			  ss[ply].reduction = Depth(0);
			  value = -search(pos, ss, -alpha, newDepth, ply + 1, true, threadID);
			  if (value.getValue() > alpha.getValue() && value.getValue() < beta.getValue())
			  {
				if (ply == 1 && RootMoveNumber == 1)
				{
				  // When the search fails high at ply 1 while searching the first
				  // move at the root, set the flag failHighPly1.  This is used for
				  // time managment:  We don't want to stop the search early in
				  // such cases, because resolving the fail high at ply 1 could
				  // result in a big drop in score at the root.
				  Threads[threadID].failHighPly1 = true;
				}
				value = -search_pv(pos, ss, -beta, -alpha, newDepth, ply + 1, threadID);
				Threads[threadID].failHighPly1 = false;
			  }
			}
		  }
		  pos.undo_move(move, u);

		  assert value.getValue() > -Value.VALUE_INFINITE && value.getValue() < Value.VALUE_INFINITE.getValue();

		  // New best move?
		  if (value.getValue() > bestValue.getValue())
		  {
			bestValue = value;
			if (value.getValue() > alpha.getValue())
			{
			  alpha = value;
			  update_pv(ss, ply);
			  if (value == value_mate_in(ply + 1))
			  {
				ss[ply].mateKiller = move;
			  }
			}
			// If we are at ply 1, and we are searching the first root move at
			// ply 0, set the 'Problem' variable if the score has dropped a lot
			// (from the computer's point of view) since the previous iteration:
			if (ply == 1 && Iteration >= 2 && -value.getValue() <= ValueByIteration[Iteration - 1].getValue() - ProblemMargin)
			{
			  Problem = true;
			}
		  }

		  // Split?
	  tangible.RefObject<Integer> tempRef_moveCount = new tangible.RefObject<Integer>(moveCount);
		  if (ActiveThreads > 1 && bestValue.getValue() < beta.getValue() && depth.getValue() >= MinimumSplitDepth.getValue() && Iteration <= 99 && idle_thread_exists(threadID) && !AbortSearch && !thread_should_stop(threadID) && split(pos, ss, ply, alpha, beta, bestValue, depth, tempRef_moveCount, mp, dcCandidates, threadID, true))
		  {
			  moveCount = tempRef_moveCount.argValue;
			break;
		  }
		  else
		  {
			  moveCount = tempRef_moveCount.argValue;
		  }
		}

		// All legal moves have been searched.  A special case: If there were
		// no legal moves, it must be mate or stalemate:
		if (moveCount == 0)
		{
		  if (pos.is_check())
		  {
			return value_mated_in(ply);
		  }
		  else
		  {
			return Value.VALUE_DRAW;
		  }
		}

		// If the search is not aborted, update the transposition table,
		// history counters, and killer moves.  This code is somewhat messy,
		// and definitely needs to be cleaned up.  FIXME
		if (!AbortSearch && !thread_should_stop(threadID))
		{
		  if (bestValue.getValue() <= oldAlpha.getValue())
		  {
			TT.store(pos, value_to_tt(bestValue, ply), depth, Move.MOVE_NONE, ValueType.VALUE_TYPE_UPPER);
		  }
		  else if (bestValue.getValue() >= beta.getValue())
		  {
			Move m = ss[ply].pv[ply];
			if (pos.square_is_empty(move_to(m)) && move_promotion(m).getValue() == 0 && !move_is_ep(m))
			{
			  for (int i = 0; i < moveCount - 1; i++)
			  {
				if (pos.square_is_empty(move_to(movesSearched[i])) && move_promotion(movesSearched[i]).getValue() == 0 && !move_is_ep(movesSearched[i]))
				{
				  H.failure(pos.piece_on(move_from(movesSearched[i])), movesSearched[i]);
				}
			  }

			  H.success(pos.piece_on(move_from(m)), m, depth);

			  if (m != ss[ply].killer1)
			  {
				ss[ply].killer2 = ss[ply].killer1;
				ss[ply].killer1 = m;
			  }
			}
			TT.store(pos, value_to_tt(bestValue, ply), depth, m, ValueType.VALUE_TYPE_LOWER);
		  }
		  else
		  {
			TT.store(pos, value_to_tt(bestValue, ply), depth, ss[ply].pv[ply], ValueType.VALUE_TYPE_EXACT);
		  }
		}

		return bestValue;
	  }

  // search() is the search function for zero-width nodes.


	  public static Value search(Position pos, SearchStack[] ss, Value beta, Depth depth, int ply, boolean allowNullmove, int threadID)
	  {
		assert beta.getValue() >= -Value.VALUE_INFINITE && beta.getValue() <= Value.VALUE_INFINITE.getValue();
		assert ply >= 0 && ply < PLY_MAX;
		assert threadID >= 0 && threadID < ActiveThreads;

		EvalInfo ei = new EvalInfo();

		// Initialize, and make an early exit in case of an aborted search,
		// an instant draw, maximum ply reached, etc.
		if (AbortSearch || thread_should_stop(threadID))
		{
		  return Value(0);
		}

		if (depth.getValue() < OnePly.getValue())
		{
		  return qsearch(pos, ss, beta - 1, beta, Depth(0), ply, threadID);
		}

		init_node(pos, ss, ply, threadID);

		if (pos.is_draw())
		{
		  return Value.VALUE_DRAW;
		}

		if (ply >= PLY_MAX - 1)
		{
		  return evaluate(pos, ei, threadID);
		}

		// Mate distance pruning
		if (value_mated_in(ply) >= beta.getValue())
		{
		  return beta;
		}
		if (value_mate_in(ply + 1) < beta.getValue())
		{
		  return beta - 1;
		}

		// Transposition table lookup
		boolean ttFound;
		Value ttValue;
		Depth ttDepth;
		Move ttMove = Move.MOVE_NONE;
		ValueType ttValueType;

		ttFound = TT.retrieve(pos, ttValue, ttDepth, ttMove, ttValueType);
		if (ttFound)
		{
		  ttValue = value_from_tt(ttValue, ply);
		  if (ttDepth.getValue() >= depth.getValue() || ttValue.getValue() >= (((value_mate_in(100)) < (beta).getValue())? (beta) : (value_mate_in(100))) || ttValue.getValue() < (((value_mated_in(100)) < (beta).getValue())? (value_mated_in(100)) : (beta)))
		  {
			if ((is_lower_bound(ttValueType) && ttValue.getValue() >= beta.getValue()) || (is_upper_bound(ttValueType) && ttValue.getValue() < beta.getValue()))
			{
			  ss[ply].currentMove = ttMove;
			  return ttValue;
			}
		  }
		}

		Value approximateEval = quick_evaluate(pos);
		boolean mateThreat = false;

		// Null move search
		if (!pos.is_check() && allowNullmove && ok_to_do_nullmove(pos) && approximateEval.getValue() >= beta.getValue() - NullMoveMargin)
		{
		  UndoInfo u = new UndoInfo();
		  Value nullValue;

		  ss[ply].currentMove = Move.MOVE_NULL;
		  pos.do_null_move(u);
		  nullValue = -search(pos, ss, -(beta - 1), depth - 4 * OnePly, ply + 1, false, threadID);
		  pos.undo_null_move(u);

		  if (nullValue.getValue() >= beta.getValue())
		  {
			if (depth.getValue() >= 6 * OnePly)
			{ // Do zugzwang verification search
			  Value v = search(pos, ss, beta, depth - 5 * OnePly, ply, false, threadID);
			  if (v.getValue() >= beta.getValue())
			  {
				return beta;
			  }
			}
			else
			{
			  return beta;
			}
		  }
		  else
		  {
			// The null move failed low, which means that we may be faced with
			// some kind of threat.  If the previous move was reduced, check if
			// the move that refuted the null move was somehow connected to the
			// move which was reduced.  If a connection is found, return a fail
			// low score (which will cause the reduced move to fail high in the
			// parent node, which will trigger a re-search with full depth).
			if (nullValue == value_mated_in(ply + 2))
			{
			  mateThreat = true;
			}
			ss[ply].threatMove = ss[ply + 1].currentMove;
			if (depth.getValue() < ThreatDepth.getValue() && ss[ply - 1].reduction.getValue() != 0 && connected_moves(pos, ss[ply - 1].currentMove, ss[ply].threatMove))
			{
			  return beta - 1;
			}
		  }
		}
		// Razoring:
		else if ((depth.getValue() < RazorDepth.getValue() && approximateEval.getValue() < beta.getValue() - RazorMargin2) || (depth.getValue() < 2 * OnePly && approximateEval.getValue() < beta.getValue() - RazorMargin1))
		{
		  Value v = qsearch(pos, ss, beta - 1, beta, Depth(0), ply, threadID);
		  if (v.getValue() < beta.getValue())
		  {
			return v;
		  }
		}

		// Internal iterative deepening
		if (UseIIDAtNonPVNodes && ttMove == Move.MOVE_NONE && depth.getValue() >= 8 * OnePly && evaluate(pos, ei, threadID) >= beta.getValue() - IIDMargin)
		{
		  search(pos, ss, beta, (((depth / 2) < (depth - 2 * OnePly))? (depth / 2) : (depth - 2 * OnePly)), ply, false, threadID);
		  ttMove = ss[ply].pv[ply];
		}

		// Initialize a MovePicker object for the current position, and prepare
		// to search all moves:
		MovePicker mp = new MovePicker(pos, false, ttMove, ss[ply].mateKiller, ss[ply].killer1, ss[ply].killer2, depth);
		Move move;
		Move[] movesSearched = new Move[256];
		int moveCount = 0;
		Value value;
		Value bestValue = -Value.VALUE_INFINITE;
		Value futilityValue = Value.VALUE_NONE;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long dcCandidates = mp.discovered_check_candidates();
		long dcCandidates = mp.discovered_check_candidates();
		boolean isCheck = pos.is_check();
		boolean useFutilityPruning = UseFutilityPruning && depth.getValue() < SelectiveDepth.getValue() && !isCheck;

		// Loop through all legal moves until no moves remain or a beta cutoff
		// occurs.
		while (bestValue.getValue() < beta.getValue() && !thread_should_stop(threadID) && (move = mp.get_next_move()) != Move.MOVE_NONE)
		{
		  UndoInfo u = new UndoInfo();
		  Depth ext;
		  Depth newDepth;
		  boolean singleReply = (isCheck && mp.number_of_moves() == 1);
		  boolean moveIsCheck = pos.move_is_check(move, dcCandidates);
		  boolean moveIsCapture = pos.move_is_capture(move);
		  boolean moveIsPassedPawnPush = pos.move_is_passed_pawn_push(move);

		  assert move_is_ok(move);
		  movesSearched[moveCount++] = ss[ply].currentMove = move;

		  // Decide the new search depth.
		  ext = extension(pos, move, false, moveIsCheck, singleReply, mateThreat);
		  newDepth = depth - OnePly + ext;

		  // Futility pruning
		  if (useFutilityPruning && ext == Depth(0) && !moveIsCapture && !moveIsPassedPawnPush && move_promotion(move).getValue() == 0)
		  {

			if (moveCount >= 2 + depth.getValue() && ok_to_prune(pos, move, ss[ply].threatMove, depth))
			{
			  continue;
			}

			if (depth.getValue() < 6 * OnePly && approximateEval.getValue() < beta.getValue())
			{
			  if (futilityValue == Value.VALUE_NONE)
			  {
				futilityValue = evaluate(pos, ei, threadID) + ((depth.getValue() < 2 * OnePly)? FutilityMargin1 : FutilityMargin2 + (depth - 2 * OnePly) * 32);
			  }
			  if (futilityValue.getValue() < beta.getValue())
			  {
				if (futilityValue.getValue() > bestValue.getValue())
				{
				  bestValue = futilityValue;
				}
				continue;
			  }
			}
		  }

		  // Make and search the move.
		  pos.do_move(move, u, dcCandidates);

		  if (depth.getValue() >= 2 * OnePly && ext == Depth(0) && moveCount >= LMRNonPVMoves && !moveIsCapture && move_promotion(move).getValue() == 0 && !moveIsPassedPawnPush && !move_is_castle(move) && move != ss[ply].killer1 && move != ss[ply].killer2)
		  {
			ss[ply].reduction = OnePly;
			value = -search(pos, ss, -(beta - 1), newDepth - OnePly, ply + 1, true, threadID);
		  }
		  else
		  {
			value = beta;
		  }
		  if (value.getValue() >= beta.getValue())
		  {
			ss[ply].reduction = Depth(0);
			value = -search(pos, ss, -(beta - 1), newDepth, ply + 1, true, threadID);
		  }
		  pos.undo_move(move, u);

		  assert value.getValue() > -Value.VALUE_INFINITE && value.getValue() < Value.VALUE_INFINITE.getValue();

		  // New best move?
		  if (value.getValue() > bestValue.getValue())
		  {
			bestValue = value;
			if (value.getValue() >= beta.getValue())
			{
			  update_pv(ss, ply);
			}
			if (value == value_mate_in(ply + 1))
			{
			  ss[ply].mateKiller = move;
			}
		  }

		  // Split?
	  tangible.RefObject<Integer> tempRef_moveCount = new tangible.RefObject<Integer>(moveCount);
		  if (ActiveThreads > 1 && bestValue.getValue() < beta.getValue() && depth.getValue() >= MinimumSplitDepth.getValue() && Iteration <= 99 && idle_thread_exists(threadID) && !AbortSearch && !thread_should_stop(threadID) && split(pos, ss, ply, beta, beta, bestValue, depth, tempRef_moveCount, mp, dcCandidates, threadID, false))
		  {
			  moveCount = tempRef_moveCount.argValue;
			break;
		  }
		  else
		  {
			  moveCount = tempRef_moveCount.argValue;
		  }
		}

		// All legal moves have been searched.  A special case: If there were
		// no legal moves, it must be mate or stalemate:
		if (moveCount == 0)
		{
		  if (pos.is_check())
		  {
			return value_mated_in(ply);
		  }
		  else
		  {
			return Value.VALUE_DRAW;
		  }
		}

		// If the search is not aborted, update the transposition table,
		// history counters, and killer moves.  This code is somewhat messy,
		// and definitely needs to be cleaned up.  FIXME
		if (!AbortSearch && !thread_should_stop(threadID))
		{
		  if (bestValue.getValue() < beta.getValue())
		  {
			TT.store(pos, value_to_tt(bestValue, ply), depth, Move.MOVE_NONE, ValueType.VALUE_TYPE_UPPER);
		  }
		  else
		  {
			Move m = ss[ply].pv[ply];

			if (pos.square_is_empty(move_to(m)) && move_promotion(m).getValue() == 0 && !move_is_ep(m))
			{
			  for (int i = 0; i < moveCount - 1; i++)
			  {
				if (pos.square_is_empty(move_to(movesSearched[i])) && move_promotion(movesSearched[i]).getValue() == 0 && !move_is_ep(movesSearched[i]))
				{
				  H.failure(pos.piece_on(move_from(movesSearched[i])), movesSearched[i]);
				}
			  }
			  H.success(pos.piece_on(move_from(m)), m, depth);

			  if (m != ss[ply].killer1)
			  {
				ss[ply].killer2 = ss[ply].killer1;
				ss[ply].killer1 = m;
			  }
			}
			TT.store(pos, value_to_tt(bestValue, ply), depth, m, ValueType.VALUE_TYPE_LOWER);
		  }
		}

		return bestValue;
	  }

  // qsearch() is the quiescence search function, which is called by the main
  // search function when the remaining depth is zero (or, to be more precise,
  // less than OnePly).


	  public static Value qsearch(Position pos, SearchStack[] ss, Value alpha, Value beta, Depth depth, int ply, int threadID)
	  {
		Value staticValue;
		Value bestValue;
		Value value;
		EvalInfo ei = new EvalInfo();

		assert alpha.getValue() >= -Value.VALUE_INFINITE && alpha.getValue() <= Value.VALUE_INFINITE.getValue();
		assert beta.getValue() >= -Value.VALUE_INFINITE && beta.getValue() <= Value.VALUE_INFINITE.getValue();
		assert depth.getValue() <= 0;
		assert ply >= 0 && ply < PLY_MAX;
		assert threadID >= 0 && threadID < ActiveThreads;

		// Initialize, and make an early exit in case of an aborted search,
		// an instant draw, maximum ply reached, etc.
		if (AbortSearch || thread_should_stop(threadID))
		{
		  return Value(0);
		}

		init_node(pos, ss, ply, threadID);

		if (pos.is_draw())
		{
		  return Value.VALUE_DRAW;
		}

		// Evaluate the position statically:
		staticValue = evaluate(pos, ei, threadID);

		if (ply == PLY_MAX - 1)
		{
			return staticValue;
		}

		// Initialize "stand pat score", and return it immediately if it is
		// at least beta.
		if (pos.is_check())
		{
		  bestValue = -Value.VALUE_INFINITE;
		}
		else
		{
		  bestValue = staticValue;
		  if (bestValue.getValue() >= beta.getValue())
		  {
			return bestValue;
		  }
		  if (bestValue.getValue() > alpha.getValue())
		  {
			alpha = bestValue;
		  }
		}

		// Initialize a MovePicker object for the current position, and prepare
		// to search the moves.  Because the depth is <= 0 here, only captures,
		// queen promotions and checks (only if depth == 0) will be generated.
		MovePicker mp = new MovePicker(pos, false, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, Move.MOVE_NONE, depth);
		Move move;
		int moveCount = 0;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long dcCandidates = mp.discovered_check_candidates();
		long dcCandidates = mp.discovered_check_candidates();
		boolean isCheck = pos.is_check();

		// Loop through the moves until no moves remain or a beta cutoff
		// occurs.
		while (alpha.getValue() < beta.getValue() && ((move = mp.get_next_move()) != Move.MOVE_NONE))
		{
		  UndoInfo u = new UndoInfo();
		  boolean moveIsCheck = pos.move_is_check(move, dcCandidates);
		  boolean moveIsPassedPawnPush = pos.move_is_passed_pawn_push(move);

		  assert move_is_ok(move);

		  moveCount++;
		  ss[ply].currentMove = move;

		  // Futility pruning
		  if (UseQSearchFutilityPruning && !isCheck && !moveIsCheck && move_promotion(move).getValue() == 0 && !moveIsPassedPawnPush && beta - alpha == 1.getValue() != 0 && pos.non_pawn_material(pos.side_to_move()) > RookValueMidgame.getValue())
		  {
			Value futilityValue = staticValue + (((pos.midgame_value_of_piece_on(move_to(move))) < (pos.endgame_value_of_piece_on(move_to(move))))? (pos.endgame_value_of_piece_on(move_to(move))) : (pos.midgame_value_of_piece_on(move_to(move)))) + FutilityMargin0 + ei.futilityMargin;
			if (futilityValue.getValue() < alpha.getValue())
			{
			  if (futilityValue.getValue() > bestValue.getValue())
			  {
				bestValue = futilityValue;
			  }
			  continue;
			}
		  }

		  // Don't search captures and checks with negative SEE values.
		  if (!isCheck && move_promotion(move).getValue() == 0 && pos.midgame_value_of_piece_on(move_from(move)) > pos.midgame_value_of_piece_on(move_to(move)) && pos.see(move) < 0)
		  {
			continue;
		  }

		  // Make and search the move.
		  pos.do_move(move, u, dcCandidates);
		  value = -qsearch(pos, ss, -beta, -alpha, depth - OnePly, ply + 1, threadID);
		  pos.undo_move(move, u);

		  assert value.getValue() > -Value.VALUE_INFINITE && value.getValue() < Value.VALUE_INFINITE.getValue();

		  // New best move?
		  if (value.getValue() > bestValue.getValue())
		  {
			bestValue = value;
			if (value.getValue() > alpha.getValue())
			{
			  alpha = value;
			  update_pv(ss, ply);
			}
		  }
		}

		// All legal moves have been searched.  A special case: If we're in check
		// and no legal moves were found, it is checkmate:
		if (pos.is_check() && moveCount == 0) // Mate!
		{
		  return value_mated_in(ply);
		}

		assert bestValue.getValue() > -Value.VALUE_INFINITE && bestValue.getValue() < Value.VALUE_INFINITE.getValue();

		return bestValue;
	  }

  // sp_search() is used to search from a split point.  This function is called
  // by each thread working at the split point.  It is similar to the normal
  // search() function, but simpler.  Because we have already probed the hash
  // table, done a null move search, and searched the first move before
  // splitting, we don't have to repeat all this work in sp_search().  We
  // also don't need to store anything to the hash table here:  This is taken
  // care of after we return from the split point.


	  public static void sp_search(SplitPoint sp, int threadID)
	  {
		assert threadID >= 0 && threadID < ActiveThreads;
		assert ActiveThreads > 1;

		Position pos = new Position(sp.pos);
		SearchStack[] ss = sp.sstack[threadID];
		Value value;
		Move move;
		int moveCount = sp.moves;
		boolean isCheck = pos.is_check();
		boolean useFutilityPruning = UseFutilityPruning && sp.depth.getValue() < SelectiveDepth.getValue() && !isCheck;

		while (sp.bestValue.getValue() < sp.beta.getValue() && !thread_should_stop(threadID) && (move = sp.mp.get_next_move(sp.lock)) != Move.MOVE_NONE)
		{
		  UndoInfo u = new UndoInfo();
		  Depth ext;
		  Depth newDepth;
		  boolean moveIsCheck = pos.move_is_check(move, sp.dcCandidates);
		  boolean moveIsCapture = pos.move_is_capture(move);
		  boolean moveIsPassedPawnPush = pos.move_is_passed_pawn_push(move);

		  assert move_is_ok(move);

		  lock_grab((sp.lock));
		  sp.moves++;
		  moveCount = sp.moves;
		  lock_release((sp.lock));

		  ss[sp.ply].currentMove = move;

		  // Decide the new search depth.
		  ext = extension(pos, move, false, moveIsCheck, false, false);
		  newDepth = sp.depth - OnePly + ext;

		  // Prune?
		  if (useFutilityPruning && ext == Depth(0) && !moveIsCapture && !moveIsPassedPawnPush && move_promotion(move).getValue() == 0 && moveCount >= 2 + sp.depth.getValue() && ok_to_prune(pos, move, ss[sp.ply].threatMove, sp.depth))
		  {
			continue;
		  }

		  // Make and search the move.
		  pos.do_move(move, u, sp.dcCandidates);
		  if (ext == Depth(0) && moveCount >= LMRNonPVMoves && !moveIsCapture && move_promotion(move).getValue() == 0 && !moveIsPassedPawnPush && !move_is_castle(move) && move != ss[sp.ply].killer1 && move != ss[sp.ply].killer2)
		  {
			ss[sp.ply].reduction = OnePly;
			value = -search(pos, ss, -(sp.beta - 1), newDepth - OnePly, sp.ply + 1, true, threadID);
		  }
		  else
		  {
			value = sp.beta;
		  }
		  if (value.getValue() >= sp.beta.getValue())
		  {
			ss[sp.ply].reduction = Depth(0);
			value = -search(pos, ss, -(sp.beta - 1), newDepth, sp.ply + 1, true, threadID);
		  }
		  pos.undo_move(move, u);

		  assert value.getValue() > -Value.VALUE_INFINITE && value.getValue() < Value.VALUE_INFINITE.getValue();

		  if (thread_should_stop(threadID))
		  {
			break;
		  }

		  // New best move?
		  lock_grab((sp.lock));
		  if (value.getValue() > sp.bestValue.getValue() && !thread_should_stop(threadID))
		  {
			sp.bestValue = value;
			if (sp.bestValue.getValue() >= sp.beta.getValue())
			{
			  sp_update_pv(sp.parentSstack, ss, sp.ply);
			  for (int i = 0; i < ActiveThreads; i++)
			  {
				if (i != threadID && (i == sp.master || sp.slaves[i] != 0))
				{
				  Threads[i].stop = true;
				}
			  }
			  sp.finished = true;
			}
		  }
		  lock_release((sp.lock));
		}

		lock_grab((sp.lock));

		// If this is the master thread and we have been asked to stop because of
		// a beta cutoff higher up in the tree, stop all slave threads:
		if (sp.master == threadID && thread_should_stop(threadID))
		{
		  for (int i = 0; i < ActiveThreads; i++)
		  {
			if (sp.slaves[i] != 0)
			{
			  Threads[i].stop = true;
			}
		  }
		}

		sp.cpus--;
		sp.slaves[threadID] = 0;

		lock_release((sp.lock));
	  }

  // sp_search_pv() is used to search from a PV split point.  This function
  // is called by each thread working at the split point.  It is similar to
  // the normal search_pv() function, but simpler.  Because we have already
  // probed the hash table and searched the first move before splitting, we
  // don't have to repeat all this work in sp_search_pv().  We also don't
  // need to store anything to the hash table here:  This is taken care of
  // after we return from the split point.


	  public static void sp_search_pv(SplitPoint sp, int threadID)
	  {
		assert threadID >= 0 && threadID < ActiveThreads;
		assert ActiveThreads > 1;

		Position pos = new Position(sp.pos);
		SearchStack[] ss = sp.sstack[threadID];
		Value value;
		Move move;
		int moveCount = sp.moves;

		while (sp.alpha.getValue() < sp.beta.getValue() && !thread_should_stop(threadID) && (move = sp.mp.get_next_move(sp.lock)) != Move.MOVE_NONE)
		{
		  UndoInfo u = new UndoInfo();
		  Depth ext;
		  Depth newDepth;
		  boolean moveIsCheck = pos.move_is_check(move, sp.dcCandidates);
		  boolean moveIsCapture = pos.move_is_capture(move);
		  boolean moveIsPassedPawnPush = pos.move_is_passed_pawn_push(move);

		  assert move_is_ok(move);

		  ss[sp.ply].currentMoveCaptureValue = move_is_ep(move)? PawnValueMidgame : pos.midgame_value_of_piece_on(move_to(move));

		  lock_grab((sp.lock));
		  sp.moves++;
		  moveCount = sp.moves;
		  lock_release((sp.lock));

		  ss[sp.ply].currentMove = move;

		  // Decide the new search depth.
		  ext = extension(pos, move, true, moveIsCheck, false, false);
		  newDepth = sp.depth - OnePly + ext;

		  // Make and search the move.
		  pos.do_move(move, u, sp.dcCandidates);
		  if (ext == Depth(0) && moveCount >= LMRPVMoves && !moveIsCapture && move_promotion(move).getValue() == 0 && !moveIsPassedPawnPush && !move_is_castle(move) && move != ss[sp.ply].killer1 && move != ss[sp.ply].killer2)
		  {
			ss[sp.ply].reduction = OnePly;
			value = -search(pos, ss, -sp.alpha, newDepth - OnePly, sp.ply + 1, true, threadID);
		  }
		  else
		  {
			value = sp.alpha + 1;
		  }
		  if (value.getValue() > sp.alpha.getValue())
		  {
			ss[sp.ply].reduction = Depth(0);
			value = -search(pos, ss, -sp.alpha, newDepth, sp.ply + 1, true, threadID);
			if (value.getValue() > sp.alpha.getValue() && value.getValue() < sp.beta.getValue())
			{
			  if (sp.ply == 1 && RootMoveNumber == 1)
			  {
				// When the search fails high at ply 1 while searching the first
				// move at the root, set the flag failHighPly1.  This is used for
				// time managment:  We don't want to stop the search early in
				// such cases, because resolving the fail high at ply 1 could
				// result in a big drop in score at the root.
				Threads[threadID].failHighPly1 = true;
			  }
			  value = -search_pv(pos, ss, -sp.beta, -sp.alpha, newDepth, sp.ply + 1, threadID);
			  Threads[threadID].failHighPly1 = false;
			}
		  }
		  pos.undo_move(move, u);

		  assert value.getValue() > -Value.VALUE_INFINITE && value.getValue() < Value.VALUE_INFINITE.getValue();

		  if (thread_should_stop(threadID))
		  {
			break;
		  }

		  // New best move?
		  lock_grab((sp.lock));
		  if (value.getValue() > sp.bestValue.getValue() && !thread_should_stop(threadID))
		  {
			sp.bestValue = value;
			if (value.getValue() > sp.alpha.getValue())
			{
			  sp.alpha = value;
			  sp_update_pv(sp.parentSstack, ss, sp.ply);
			  if (value == value_mate_in(sp.ply + 1))
			  {
				ss[sp.ply].mateKiller = move;
			  }
			  if (value.getValue() >= sp.beta.getValue())
			  {
				for (int i = 0; i < ActiveThreads; i++)
				{
				  if (i != threadID && (i == sp.master || sp.slaves[i] != 0))
				  {
					Threads[i].stop = true;
				  }
				}
				sp.finished = true;
			  }
			}
			// If we are at ply 1, and we are searching the first root move at
			// ply 0, set the 'Problem' variable if the score has dropped a lot
			// (from the computer's point of view) since the previous iteration:
			if (Iteration >= 2 && -value.getValue() <= ValueByIteration[Iteration - 1].getValue() - ProblemMargin)
			{
			  Problem = true;
			}
		  }
		  lock_release((sp.lock));
		}

		lock_grab((sp.lock));

		// If this is the master thread and we have been asked to stop because of
		// a beta cutoff higher up in the tree, stop all slave threads:
		if (sp.master == threadID && thread_should_stop(threadID))
		{
		  for (int i = 0; i < ActiveThreads; i++)
		  {
			if (sp.slaves[i] != 0)
			{
			  Threads[i].stop = true;
			}
		  }
		}

		sp.cpus--;
		sp.slaves[threadID] = 0;

		lock_release((sp.lock));
	  }

  // init_search_stack() initializes a search stack at the beginning of a
  // new search from the root.


	  public static void init_search_stack(SearchStack[] ss)
	  {
		for (int i = 0; i < 3; i++)
		{
		  ss[i].pv[i] = Move.MOVE_NONE;
		  ss[i].pv[i + 1] = Move.MOVE_NONE;
		  ss[i].currentMove = Move.MOVE_NONE;
		  ss[i].mateKiller = Move.MOVE_NONE;
		  ss[i].killer1 = Move.MOVE_NONE;
		  ss[i].killer2 = Move.MOVE_NONE;
		  ss[i].threatMove = Move.MOVE_NONE;
		  ss[i].reduction = Depth(0);
		}
	  }

  // init_node() is called at the beginning of all the search functions
  // (search(), search_pv(), qsearch(), and so on) and initializes the search
  // stack object corresponding to the current node.  Once every
  // NodesBetweenPolls nodes, init_node() also calls poll(), which polls
  // for user input and checks whether it is time to stop the search.


	  public static void init_node(Position pos, SearchStack[] ss, int ply, int threadID)
	  {
		assert ply >= 0 && ply < PLY_MAX;
		assert threadID >= 0 && threadID < ActiveThreads;

		Threads[threadID].nodes++;

		if (threadID == 0)
		{
		  NodesSincePoll++;
		  if (NodesSincePoll >= NodesBetweenPolls)
		  {
			poll();
			NodesSincePoll = 0;
		  }
		}

		ss[ply].pv[ply] = ss[ply].pv[ply + 1] = ss[ply].currentMove = Move.MOVE_NONE;
		ss[ply + 2].mateKiller = Move.MOVE_NONE;
		ss[ply + 2].killer1 = ss[ply + 2].killer2 = Move.MOVE_NONE;
		ss[ply].threatMove = Move.MOVE_NONE;
		ss[ply].reduction = Depth(0);
		ss[ply].currentMoveCaptureValue = Value(0);

		if (Threads[threadID].printCurrentLine)
		{
		  print_current_line(ss, ply, threadID);
		}
	  }

  // update_pv() is called whenever a search returns a value > alpha.  It
  // updates the PV in the SearchStack object corresponding to the current
  // node.


	  public static void update_pv(SearchStack[] ss, int ply)
	  {
		assert ply >= 0 && ply < PLY_MAX;

		ss[ply].pv[ply] = ss[ply].currentMove;
		int p;
		for (p = ply + 1; ss[ply + 1].pv[p] != Move.MOVE_NONE; p++)
		{
		  ss[ply].pv[p] = ss[ply + 1].pv[p];
		}
		ss[ply].pv[p] = Move.MOVE_NONE;
	  }

  // sp_update_pv() is a variant of update_pv for use at split points.  The
  // difference between the two functions is that sp_update_pv also updates
  // the PV at the parent node.


	  public static void sp_update_pv(SearchStack[] pss, SearchStack[] ss, int ply)
	  {
		assert ply >= 0 && ply < PLY_MAX;

		ss[ply].pv[ply] = pss[ply].pv[ply] = ss[ply].currentMove;
		int p;
		for (p = ply + 1; ss[ply + 1].pv[p] != Move.MOVE_NONE; p++)
		{
		  ss[ply].pv[p] = pss[ply].pv[p] = ss[ply + 1].pv[p];
		}
		ss[ply].pv[p] = pss[ply].pv[p] = Move.MOVE_NONE;
	  }

  // connected_moves() tests whether two moves are 'connected' in the sense
  // that the first move somehow made the second move possible (for instance
  // if the moving piece is the same in both moves).  The first move is
  // assumed to be the move that was made to reach the current position, while
  // the second move is assumed to be a move from the current position.


	  public static boolean connected_moves(Position pos, Move m1, Move m2)
	  {
		Square f1;
		Square t1;
		Square f2;
		Square t2;

		assert move_is_ok(m1);
		assert move_is_ok(m2);

		if (m2 == Move.MOVE_NONE)
		{
		  return false;
		}

		// Case 1: The moving piece is the same in both moves.
		f2 = move_from(m2);
		t1 = move_to(m1);
		if (f2 == t1)
		{
		  return true;
		}

		// Case 2: The destination square for m2 was vacated by m1.
		t2 = move_to(m2);
		f1 = move_from(m1);
		if (t2 == f1)
		{
		  return true;
		}

		// Case 3: Moving through the vacated square:
		if (piece_is_slider(pos.piece_on(f2)) != 0 && bit_is_set(squares_between(f2, t2), f1) != 0)
		{
		  return true;
		}

		// Case 4: The destination square for m2 is attacked by the moving piece
		// in m1:
		if (pos.piece_attacks_square(t1, t2))
		{
		  return true;
		}

		// Case 5: Discovered check, checking piece is the piece moved in m1:
		if (piece_is_slider(pos.piece_on(t1)) != 0 && bit_is_set(squares_between(t1, pos.king_square(pos.side_to_move())), f2) != 0 && bit_is_set(squares_between(t2, pos.king_square(pos.side_to_move())), t2) == 0)
		{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long occ = pos.occupied_squares();
		  long occ = pos.occupied_squares();
		  Color us = pos.side_to_move();
		  Square ksq = pos.king_square(us);
	  tangible.RefObject<Long> tempRef_occ = new tangible.RefObject<Long>(occ);
		  clear_bit(tempRef_occ, f2);
		  occ = tempRef_occ.argValue;
		  if (pos.type_of_piece_on(t1) == PieceType.BISHOP)
		  {
			if (bit_is_set(bishop_attacks_bb(ksq, occ), t1) != 0)
			{
			  return true;
			}
		  }
		  else if (pos.type_of_piece_on(t1) == PieceType.ROOK)
		  {
			if (bit_is_set(rook_attacks_bb(ksq, occ), t1) != 0)
			{
			  return true;
			}
		  }
		  else
		  {
			assert pos.type_of_piece_on(t1) == PieceType.QUEEN;
			if (bit_is_set(queen_attacks_bb(ksq, occ), t1) != 0)
			{
			  return true;
			}
		  }
		}

		return false;
	  }

  // extension() decides whether a move should be searched with normal depth,
  // or with extended depth.  Certain classes of moves (checking moves, in
  // particular) are searched with bigger depth than ordinary moves.


	  public static Depth extension(Position pos, Move m, boolean pvNode, boolean check, boolean singleReply, boolean mateThreat)
	  {
		Depth result = Depth.forValue(0);

		if (check)
		{
		  result += CheckExtension[pvNode];
		}
		if (singleReply)
		{
		  result += SingleReplyExtension[pvNode];
		}
		if (pos.move_is_pawn_push_to_7th(m))
		{
		  result += PawnPushTo7thExtension[pvNode];
		}
		if (pos.move_is_passed_pawn_push(m))
		{
		  result += PassedPawnExtension[pvNode];
		}
		if (mateThreat)
		{
		  result += MateThreatExtension[pvNode];
		}
		if (pos.midgame_value_of_piece_on(move_to(m)) >= RookValueMidgame.getValue() && (pos.non_pawn_material(Color.WHITE) + pos.non_pawn_material(Color.BLACK) - pos.midgame_value_of_piece_on(move_to(m)) == Value(0)).getValue() != 0 && move_promotion(m).getValue() == 0)
		{
		  result += PawnEndgameExtension[pvNode];
		}
		if (pvNode && pos.move_is_capture(m) && pos.type_of_piece_on(move_to(m)) != PieceType.PAWN && pos.see(m) >= 0)
		{
		  result += OnePly / 2;
		}

		return (((result).getValue() < (OnePly).getValue())? (result) : (OnePly));
	  }

  // ok_to_do_nullmove() looks at the current position and decides whether
  // doing a 'null move' should be allowed.  In order to avoid zugzwang
  // problems, null moves are not allowed when the side to move has very
  // little material left.  Currently, the test is a bit too simple:  Null
  // moves are avoided only when the side to move has only pawns left.  It's
  // probably a good idea to avoid null moves in at least some more
  // complicated endgames, e.g. KQ vs KR.  FIXME


	  public static boolean ok_to_do_nullmove(Position pos)
	  {
		if (pos.non_pawn_material(pos.side_to_move()) == Value(0))
		{
		  return false;
		}
		return true;
	  }

  // ok_to_prune() tests whether it is safe to forward prune a move.  Only
  // non-tactical moves late in the move list close to the leaves are
  // candidates for pruning.


	  public static boolean ok_to_prune(Position pos, Move m, Move threat, Depth d)
	  {
		Square mfrom;
		Square mto;
		Square tfrom;
		Square tto;

		assert move_is_ok(m);
		assert threat == Move.MOVE_NONE || move_is_ok(threat);
		assert!move_promotion(m);
		assert!pos.move_is_check(m);
		assert!pos.move_is_capture(m);
		assert!pos.move_is_passed_pawn_push(m);
		assert d.getValue() >= OnePly.getValue();

		mfrom = move_from(m);
		mto = move_to(m);
		tfrom = move_from(threat);
		tto = move_to(threat);

		// Case 1: Castling moves are never pruned.
		if (move_is_castle(m))
		{
		  return false;
		}

		// Case 2: Don't prune moves which move the threatened piece
		if (!PruneEscapeMoves && threat != Move.MOVE_NONE && mfrom == tto)
		{
		  return false;
		}

		// Case 3: If the threatened piece has value less than or equal to the
		// value of the threatening piece, don't prune move which defend it.
		if (!PruneDefendingMoves && threat != Move.MOVE_NONE && (piece_value_midgame(pos.piece_on(tfrom)) >= piece_value_midgame(pos.piece_on(tto))) && pos.move_attacks_square(m, tto))
		{
		  return false;
		}

		// Case 4: Don't prune moves with good history.
		if (!H.ok_to_prune(pos.piece_on(move_from(m)), m, d))
		{
		  return false;
		}

		// Case 5: If the moving piece in the threatened move is a slider, don't
		// prune safe moves which block its ray.
		if (!PruneBlockingMoves && threat != Move.MOVE_NONE && piece_is_slider(pos.piece_on(tfrom)) != 0 && bit_is_set(squares_between(tfrom, tto), mto) != 0 && pos.see(m) >= 0)
		{
		  return false;
		}

		return true;
	  }

  // fail_high_ply_1() checks if some thread is currently resolving a fail
  // high at ply 1 at the node below the first root node.  This information
  // is used for time managment.


	  public static boolean fail_high_ply_1()
	  {
		for (int i = 0; i < ActiveThreads; i++)
		{
		  if (Threads[i].failHighPly1)
		  {
			return true;
		  }
		}
		return false;
	  }

  // current_search_time() returns the number of milliseconds which have passed
  // since the beginning of the current search.


	  public static int current_search_time()
	  {
		return get_system_time() - SearchStartTime;
	  }

  // nps() computes the current nodes/second count.


	  public static int nps()
	  {
		int t = current_search_time();
		return (t > 0)? (int)((nodes_searched() * 1000) / t) : 0;
	  }

  // poll() performs two different functions:  It polls for user input, and it
  // looks at the time consumed so far and decides if it's time to abort the
  // search.


	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	  public static int poll_lastInfoTime;

	  public static void poll()
	  {
		int t;
		int data;
	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//	static int lastInfoTime;

		t = current_search_time();

		//  Poll for input
		data = Bioskey();
		if (data != 0)
		{
		  String input = new String(new char[256]);
		  if (fgets(input, 255, stdin) == null)
		  {
			input = "quit\n";
		  }
		  if (strncmp(input, "quit", 4) == 0)
		  {
			AbortSearch = true;
			PonderSearch = false;
			Quit = true;
		  }
		  else if (strncmp(input, "stop", 4) == 0)
		  {
			AbortSearch = true;
			PonderSearch = false;
		  }
		  else if (strncmp(input, "ponderhit", 9) == 0)
		  {
			ponderhit();
		  }
		}

		// Print search information
		if (t < 1000)
		{
		  poll_lastInfoTime = 0;
		}
		else if (poll_lastInfoTime > t)
		{
		  // HACK: Must be a new search where we searched less than
		  // NodesBetweenPolls nodes during the first second of search.
		  poll_lastInfoTime = 0;
		}
		else if (t - poll_lastInfoTime >= 1000)
		{
		  poll_lastInfoTime = t;
		  lock_grab(IOLock);
		  System.out.print("info nodes ");
		  System.out.print(nodes_searched());
		  System.out.print(" nps ");
		  System.out.print(nps());
		  System.out.print(" time ");
		  System.out.print(t);
		  System.out.print(" hashfull ");
		  System.out.print(TT.full());
		  System.out.print("\n");
		  lock_release(IOLock);
		  if (ShowCurrentLine)
		  {
			Threads[0].printCurrentLine = true;
		  }
		}

		// Should we stop the search?
		if (!PonderSearch && Iteration >= 2 && (!InfiniteSearch && (t > AbsoluteMaxSearchTime || (RootMoveNumber == 1 && t > MaxSearchTime + ExtraSearchTime) || (!FailHigh && !fail_high_ply_1() && !Problem && t > 6 * (MaxSearchTime + ExtraSearchTime)))))
		{
		  AbortSearch = true;
		}

		if (!PonderSearch && ExactMaxTime != 0 && t >= ExactMaxTime)
		{
		  AbortSearch = true;
		}

		if (!PonderSearch && Iteration >= 3 && MaxNodes != 0 && nodes_searched() >= MaxNodes)
		{
		  AbortSearch = true;
		}
	  }

  // ponderhit() is called when the program is pondering (i.e. thinking while
  // it's the opponent's turn to move) in order to let the engine know that
  // it correctly predicted the opponent's move.


	  public static void ponderhit()
	  {
		int t = current_search_time();
		PonderSearch = false;
		if (Iteration >= 2 && (!InfiniteSearch && (StopOnPonderhit || t > AbsoluteMaxSearchTime || (RootMoveNumber == 1 && t > MaxSearchTime + ExtraSearchTime) || (!FailHigh && !fail_high_ply_1() && !Problem && t > 6 * (MaxSearchTime + ExtraSearchTime)))))
		{
		  AbortSearch = true;
		}
	  }

  // print_current_line() prints the current line of search for a given
  // thread.  Called when the UCI option UCI_ShowCurrLine is 'true'.


	  public static void print_current_line(SearchStack[] ss, int ply, int threadID)
	  {
		assert ply >= 0 && ply < PLY_MAX;
		assert threadID >= 0 && threadID < ActiveThreads;

		if (!Threads[threadID].idle)
		{
		  lock_grab(IOLock);
		  System.out.print("info currline ");
		  System.out.print((threadID + 1));
		  for (int p = 0; p < ply; p++)
		  {
			System.out.print(" ");
			System.out.print(ss[p].currentMove);
		  }
		  System.out.print("\n");
		  lock_release(IOLock);
		}
		Threads[threadID].printCurrentLine = false;
		if (threadID + 1 < ActiveThreads)
		{
		  Threads[threadID + 1].printCurrentLine = true;
		}
	  }

  // wait_for_stop_or_ponderhit() is called when the maximum depth is reached
  // while the program is pondering.  The point is to work around a wrinkle in
  // the UCI protocol:  When pondering, the engine is not allowed to give a
  // "bestmove" before the GUI sends it a "stop" or "ponderhit" command.
  // We simply wait here until one of these commands is sent, and return,
  // after which the bestmove and pondermove will be printed (in id_loop()).


	  public static void wait_for_stop_or_ponderhit()
	  {
		String command;

		while (true)
		{
		  if (!command = new Scanner(System.in).nextLine())
		  {
			command = "quit";
		  }

		  if (command.equals("quit"))
		  {
			OpeningBook.close();
			stop_threads();
			quit_eval();
			System.exit(0);
		  }
		  else if (command.equals("ponderhit") || command.equals("stop"))
		  {
			break;
		  }
		}
	  }

  // idle_loop() is where the threads are parked when they have no work to do.
  // The parameter "waitSp", if non-NULL, is a pointer to an active SplitPoint
  // object for which the current thread is the master.


	  public static void idle_loop(int threadID, SplitPoint waitSp)
	  {
		assert threadID >= 0 && threadID < THREAD_MAX;

		Threads[threadID].running = true;

		while (true)
		{
		  if (AllThreadsShouldExit && threadID != 0)
		  {
			break;
		  }

		  // If we are not thinking, wait for a condition to be signaled instead
		  // of wasting CPU time polling for work:
		  while (threadID != 0 && (Idle || threadID >= ActiveThreads))
		  {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
			pthread_mutex_lock(WaitLock);
			if (Idle || threadID >= ActiveThreads)
			{
			  pthread_cond_wait(WaitCond, WaitLock);
			}
			pthread_mutex_unlock(WaitLock);
	///#else
			WaitForSingleObject(SitIdleEvent[threadID], INFINITE);
	///#endif
		  }

		  // If this thread has been assigned work, launch a search:
		  if (Threads[threadID].workIsWaiting)
		  {
			Threads[threadID].workIsWaiting = false;
			if (Threads[threadID].splitPoint.pvNode)
			{
			  sp_search_pv(Threads[threadID].splitPoint, threadID);
			}
			else
			{
			  sp_search(Threads[threadID].splitPoint, threadID);
			}
			Threads[threadID].idle = true;
		  }

		  // If this thread is the master of a split point and all threads have
		  // finished their work at this split point, return from the idle loop:
		  if (waitSp != null && waitSp.cpus == 0)
		  {
			return;
		  }
		}

		Threads[threadID].running = false;
	  }

  // init_split_point_stack() is called during program initialization, and
  // initializes all split point objects.


	  public static void init_split_point_stack()
	  {
		for (int i = 0; i < THREAD_MAX; i++)
		{
		  for (int j = 0; j < MaxActiveSplitPoints; j++)
		  {
			SplitPointStack[i][j].parent = null;
			lock_init((SplitPointStack[i][j].lock), null);
		  }
		}
	  }

  // destroy_split_point_stack() is called when the program exits, and
  // destroys all locks in the precomputed split point objects.


	  public static void destroy_split_point_stack()
	  {
		for (int i = 0; i < THREAD_MAX; i++)
		{
		  for (int j = 0; j < MaxActiveSplitPoints; j++)
		  {
			lock_destroy((SplitPointStack[i][j].lock));
		  }
		}
	  }

  // thread_should_stop() checks whether the thread with a given threadID has
  // been asked to stop, directly or indirectly.  This can happen if a beta
  // cutoff has occured in thre thread's currently active split point, or in
  // some ancestor of the current split point.


	  public static boolean thread_should_stop(int threadID)
	  {
		assert threadID >= 0 && threadID < ActiveThreads;

		SplitPoint sp;

		if (Threads[threadID].stop)
		{
		  return true;
		}
		if (ActiveThreads <= 2)
		{
		  return false;
		}
		for (sp = Threads[threadID].splitPoint; sp != null; sp = sp.parent)
		{
		  if (sp.finished)
		  {
			Threads[threadID].stop = true;
			return true;
		  }
		}
		return false;
	  }

  // thread_is_available() checks whether the thread with threadID "slave" is
  // available to help the thread with threadID "master" at a split point.  An
  // obvious requirement is that "slave" must be idle.  With more than two
  // threads, this is not by itself sufficient:  If "slave" is the master of
  // some active split point, it is only available as a slave to the other
  // threads which are busy searching the split point at the top of "slave"'s
  // split point stack (the "helpful master concept" in YBWC terminology).


	  public static boolean thread_is_available(int slave, int master)
	  {
		assert slave >= 0 && slave < ActiveThreads;
		assert master >= 0 && master < ActiveThreads;
		assert ActiveThreads > 1;

		if (!Threads[slave].idle || slave == master)
		{
		  return false;
		}

		if (Threads[slave].activeSplitPoints == 0)
		{
		  // No active split points means that the thread is available as a slave
		  // for any other thread.
		  return true;
		}

		if (ActiveThreads == 2)
		{
		  return true;
		}

		// Apply the "helpful master" concept if possible.
		if ((SplitPointStack[slave][Threads[slave].activeSplitPoints - 1].slaves[master]) != 0)
		{
		  return true;
		}

		return false;
	  }

  // idle_thread_exists() tries to find an idle thread which is available as
  // a slave for the thread with threadID "master".


	  public static boolean idle_thread_exists(int master)
	  {
		assert master >= 0 && master < ActiveThreads;
		assert ActiveThreads > 1;

		for (int i = 0; i < ActiveThreads; i++)
		{
		  if (thread_is_available(i, master))
		  {
			return true;
		  }
		}
		return false;
	  }

  // split() does the actual work of distributing the work at a node between
  // several threads at PV nodes.  If it does not succeed in splitting the
  // node (because no idle threads are available, or because we have no unused
  // split point objects), the function immediately returns false.  If
  // splitting is possible, a SplitPoint object is initialized with all the
  // data that must be copied to the helper threads (the current position and
  // search stack, alpha, beta, the search depth, etc.), and we tell our
  // helper threads that they have been assigned work.  This will cause them
  // to instantly leave their idle loops and call sp_search_pv().  When all
  // threads have returned from sp_search_pv (or, equivalently, when
  // splitPoint->cpus becomes 0), split() returns true.


	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: bool split(const Position &pos, SearchStack *ss, int ply, Value *alpha, Value *beta, Value *bestValue, Depth depth, int *moves, MovePicker *mp, unsigned long long dcCandidates, int master, bool pvNode);
	  public static boolean split(Position p, SearchStack sstck, int ply, Value alpha, Value beta, Value bestValue, Depth depth, tangible.RefObject<Integer> moves, MovePicker mp, long dcCandidates, int master, boolean pvNode)
	  {
		assert p.is_ok();
		assert sstck != null;
		assert ply >= 0 && ply < PLY_MAX;
		assert * bestValue.getValue() >= -Value.VALUE_INFINITE && bestValue.getValue() <= alpha.getValue();
		assert!pvNode || alpha.getValue() < beta.getValue();
		assert beta.getValue() <= Value.VALUE_INFINITE.getValue();
		assert depth.getValue() > Depth(0);
		assert master >= 0 && master < ActiveThreads;
		assert ActiveThreads > 1;

		SplitPoint splitPoint;
		int i;

		lock_grab(MPLock);

		// If no other thread is available to help us, or if we have too many
		// active split points, don't split:
		if (!idle_thread_exists(master) || Threads[master].activeSplitPoints >= MaxActiveSplitPoints)
		{
		  lock_release(MPLock);
		  return false;
		}

		// Pick the next available split point object from the split point stack:
		splitPoint = SplitPointStack[master] + Threads[master].activeSplitPoints;
		Threads[master].activeSplitPoints++;

		// Initialize the split point object:
		splitPoint.parent = Threads[master].splitPoint;
		splitPoint.finished = false;
		splitPoint.ply = ply;
		splitPoint.depth = depth;
		splitPoint.alpha = pvNode? alpha : (beta - 1);
		splitPoint.beta = beta;
		splitPoint.pvNode = pvNode;
		splitPoint.dcCandidates = dcCandidates;
		splitPoint.bestValue = bestValue;
		splitPoint.master = master;
		splitPoint.mp = mp;
		splitPoint.moves = moves.argValue;
		splitPoint.cpus = 1;
		splitPoint.pos.copy(p);
		splitPoint.parentSstack = sstck;
		for (i = 0; i < ActiveThreads; i++)
		{
		  splitPoint.slaves[i] = 0;
		}

		// Copy the current position and the search stack to the master thread:
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
		memcpy(splitPoint.sstack[master], sstck, (ply + 1) * sizeof(SearchStack));
		Threads[master].splitPoint = splitPoint;

		// Make copies of the current position and search stack for each thread:
		for (i = 0; i < ActiveThreads && splitPoint.cpus < MaxThreadsPerSplitPoint; i++)
		{
		  if (thread_is_available(i, master))
		  {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
			memcpy(splitPoint.sstack[i], sstck, (ply + 1) * sizeof(SearchStack));
			Threads[i].splitPoint = splitPoint;
			splitPoint.slaves[i] = 1;
			splitPoint.cpus++;
		  }
		}

		// Tell the threads that they have work to do.  This will make them leave
		// their idle loop.
		for (i = 0; i < ActiveThreads; i++)
		{
		  if (i == master || splitPoint.slaves[i] != 0)
		  {
			Threads[i].workIsWaiting = true;
			Threads[i].idle = false;
			Threads[i].stop = false;
		  }
		}

		lock_release(MPLock);

		// Everything is set up.  The master thread enters the idle loop, from
		// which it will instantly launch a search, because its workIsWaiting
		// slot is 'true'.  We send the split point as a second parameter to the
		// idle loop, which means that the main thread will return from the idle
		// loop when all threads have finished their work at this split point
		// (i.e. when // splitPoint->cpus == 0).
		idle_loop(master, splitPoint);

		// We have returned from the idle loop, which means that all threads are
		// finished.  Update alpha, beta and bestvalue, and return:
		lock_grab(MPLock);
		if (pvNode)
		{
			alpha = splitPoint.alpha;
		}
		beta = splitPoint.beta;
		bestValue = splitPoint.bestValue;
		Threads[master].stop = false;
		Threads[master].idle = false;
		Threads[master].activeSplitPoints--;
		Threads[master].splitPoint = splitPoint.parent;
		lock_release(MPLock);

		return true;
	  }

  // wake_sleeping_threads() wakes up all sleeping threads when it is time
  // to start a new search from the root.


	  public static void wake_sleeping_threads()
	  {
		if (ActiveThreads > 1)
		{
		  for (int i = 1; i < ActiveThreads; i++)
		  {
			Threads[i].idle = true;
			Threads[i].workIsWaiting = false;
		  }
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
		  pthread_mutex_lock(WaitLock);
		  pthread_cond_broadcast(WaitCond);
		  pthread_mutex_unlock(WaitLock);
	///#else
		  for (int i = 1; i < THREAD_MAX; i++)
		  {
			SetEvent(SitIdleEvent[i]);
		  }
	///#endif
		}
	  }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !_MSC_VER
	  public static Object init_thread(Object threadID)
	  {
		idle_loop((int)threadID, null);
		return null;
	  }
	///#endif

	///#else
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: DWORD WINAPI init_thread(LPVOID threadID);
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! !_MSC_VER
//C++ TO JAVA CONVERTER NOTE: WINAPI is not available in Java:
//ORIGINAL LINE: uint WINAPI init_thread(Object* threadID)
	  public static int init_thread(Object threadID)
	  {
		idle_loop((int)threadID, null);
		return null;
	  }
	///#endif

	///#endif



	////
	//// Global variables
	////

	// The main transposition table
	public static TranspositionTable TT = new TranspositionTable(TTDefaultSize);


	// Number of active threads:
	public static int ActiveThreads = 1;

	// Locks.  In principle, there is no need for IOLock to be a global variable,
	// but it could turn out to be useful for debugging.
	public static Lock IOLock = new Lock();

	public static History H = new History(); // Should be made local?


	////
	//// Constants
	////

	public static final int FlipMask = 070;
	public static final int FlopMask = 07;


	//// 
	//// Inline functions
	////

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	File operator + (File x, int i)
	{
		return File(x.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	File operator + (File x, File y)
	{
		return x + y.getValue();
	}
	private void increment (tangible.RefObject<File> x, int UnnamedParameter)
	{
		x.argValue = File(x.argValue.getValue() + 1);
	}
	private void addAssignment (tangible.RefObject<File> x, int i)
	{
		x.argValue = File(x.argValue.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	File operator - (File x, int i)
	{
		return File(x.getValue() - i);
	}
	private void decrement (tangible.RefObject<File> x, int UnnamedParameter)
	{
		x.argValue = File(x.argValue.getValue() - 1);
	}
	private void subtractAssignment (tangible.RefObject<File> x, int i)
	{
		x.argValue = File(x.argValue.getValue() - i);
	}

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Rank operator + (Rank x, int i)
	{
		return Rank(x.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Rank operator + (Rank x, Rank y)
	{
		return x + y.getValue();
	}
	private void increment (tangible.RefObject<Rank> x, int UnnamedParameter)
	{
		x.argValue = Rank(x.argValue.getValue() + 1);
	}
	private void addAssignment (tangible.RefObject<Rank> x, int i)
	{
		x.argValue = Rank(x.argValue.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Rank operator - (Rank x, int i)
	{
		return Rank(x.getValue() - i);
	}
	private void decrement (tangible.RefObject<Rank> x, int UnnamedParameter)
	{
		x.argValue = Rank(x.argValue.getValue() - 1);
	}
	private void subtractAssignment (tangible.RefObject<Rank> x, int i)
	{
		x.argValue = Rank(x.argValue.getValue() - i);
	}

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Square operator + (Square x, int i)
	{
		return Square(x.getValue() + i);
	}
	private void increment (tangible.RefObject<Square> x, int UnnamedParameter)
	{
		x.argValue = Square(x.argValue.getValue() + 1);
	}
	private void addAssignment (tangible.RefObject<Square> x, int i)
	{
		x.argValue = Square(x.argValue.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Square operator - (Square x, int i)
	{
		return Square(x.getValue() - i);
	}
	private void decrement (tangible.RefObject<Square> x, int UnnamedParameter)
	{
		x.argValue = Square(x.argValue.getValue() - 1);
	}
	private void subtractAssignment (tangible.RefObject<Square> x, int i)
	{
		x.argValue = Square(x.argValue.getValue() - i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Square operator + (Square x, SquareDelta i)
	{
		return Square(x.getValue() + i);
	}
	private void addAssignment (tangible.RefObject<Square> x, SquareDelta i)
	{
		x.argValue = Square(x.argValue.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Square operator - (Square x, SquareDelta i)
	{
		return Square(x.getValue() - i);
	}
	private void subtractAssignment (tangible.RefObject<Square> x, SquareDelta i)
	{
		x.argValue = Square(x.argValue.getValue() - i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	SquareDelta operator - (Square x, Square y)
	{
	  return SquareDelta(x.getValue() - y.getValue());
	}

	public static Square make_square(File f, Rank r)
	{
	  return Square(f.getValue() | (r.getValue() << 3));
	}

	public static File square_file(Square s)
	{
	  return File(s.getValue() & 7);
	}

	public static Rank square_rank(Square s)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Rank(s.getValue() >> 3);
	}

	public static Square flip_square(Square s)
	{
	  return Square(s.getValue() ^ FlipMask);
	}

	public static Square flop_square(Square s)
	{
	  return Square(s.getValue() ^ FlopMask);
	}

	public static Square relative_square(Color c, Square s)
	{
	  return Square(s.getValue() ^ (c.getValue() * FlipMask));
	}

	public static Rank pawn_rank(Color c, Square s)
	{
	  return square_rank(relative_square(c, s));
	}

	public static Color square_color(Square s)
	{
	  return Color((square_file(s).getValue() + square_rank(s).getValue()) & 1);
	}

	public static int file_distance(File f1, File f2)
	{
	  return Math.abs(f1.getValue() - f2.getValue());
	}

	public static int file_distance(Square s1, Square s2)
	{
	  return file_distance(square_file(s1), square_file(s2));
	}

	public static int rank_distance(Rank r1, Rank r2)
	{
	  return Math.abs(r1.getValue() - r2.getValue());
	}

	public static int rank_distance(Square s1, Square s2)
	{
	  return rank_distance(square_rank(s1), square_rank(s2));
	}

	public static int square_distance(Square s1, Square s2)
	{
	  return (((file_distance(s1, s2)) < (rank_distance(s1, s2)))? (rank_distance(s1, s2)) : (file_distance(s1, s2)));
	}

////
//// Functions
////


/// Translating files, ranks and squares to/from characters and strings:



	//// 
	//// Prototypes
	////

	public static File file_from_char(char c)
	{
	  return File(c - 'a') + File.FILE_A;
	}

	public static char file_to_char(File f)
	{
	  return (char)(f - File.FILE_A) + 'a';
	}

	public static Rank rank_from_char(char c)
	{
	  return Rank(c - '1') + Rank.RANK_1;
	}

	public static char rank_to_char(Rank r)
	{
	  return (char)(r - Rank.RANK_1) + '1';
	}

	public static Square square_from_string(String str)
	{
	  return make_square(file_from_char(str.charAt(0)), rank_from_char(str.charAt(1)));
	}

	public static String square_to_string(Square s)
	{
	  String str;
	  str += file_to_char(square_file(s));
	  str += rank_to_char(square_rank(s));
	  return str;
	}

/// file_is_ok(), rank_is_ok() and square_is_ok(), for debugging:


	public static boolean file_is_ok(File f)
	{
	  return f.getValue() >= File.FILE_A.getValue() && f.getValue() <= File.FILE_H.getValue();
	}

	public static boolean rank_is_ok(Rank r)
	{
	  return r.getValue() >= Rank.RANK_1.getValue() && r.getValue() <= Rank.RANK_8.getValue();
	}

	public static boolean square_is_ok(Square s)
	{
	  return file_is_ok(square_file(s)) && rank_is_ok(square_rank(s));
	}


	/*
	   (c) Copyright 1992 Eric Backus
	
	   This software may be used freely so long as this copyright notice is
	   left intact.  There is no warrantee on this software.
	 */
	//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
	//#include "dos.h"


	public static int gettimeofday(timeval tp, timezone tzp)
	{
		SYSTEMTIME systime = new SYSTEMTIME();

		if (tp != null)
		{
			tm tmrec = new tm();
			time_t theTime = time(null);


			tmrec = *localtime(theTime);
			tp.tv_sec = mktime(tmrec);
			GetLocalTime(systime); // system time

			tp.tv_usec = systime.wMilliseconds * 1000;
		}
		return 0;
	}



	////
	//// Constants and variables
	////

	// Default transposition table size, in megabytes:
	public static final int TTDefaultSize = 32;


////
//// Functions
////

/// uci_main_loop() is the only global function in this file.  It is
/// called immediately after the program has finished initializing.
/// The program remains in this loop until it receives the "quit" UCI
/// command.

	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Prototypes
	////

	public static void uci_main_loop()
	{
	  RootPosition.from_fen(StartPosition);
	  while (true)
	  {
		  wait_for_command();
	  }
	}


	  // The root position.  This is set up when the user (or in practice, the GUI)
	  // sends the "position" UCI command.  The root position is sent to the think()
	  // function when the program receives the "go" command.
	  public static Position RootPosition = new Position();

  /// 
  /// Other functions
  ///


  // wait_for_command() waits for a command from the user, and passes
  // this command to handle_command.  wait_for_command also intercepts
  // EOF from stdin, by translating EOF to the "quit" command.  This
  // ensures that Glaurung exits gracefully if the GUI dies
  // unexpectedly.


	  // Local functions
	  public static void wait_for_command()
	  {
		String command;
		if (!command = new Scanner(System.in).nextLine())
		{
			command = "quit";
		}
		handle_command(command);
	  }

  // handle_command() takes a text string as input, uses a
  // UCIInputParser object to parse this text string as a UCI command,
  // and calls the appropriate functions.  In addition to the UCI
  // commands, the function also supports a few debug commands.


	  public static void handle_command(String command)
	  {
		UCIInputParser uip = new UCIInputParser(command);
		String s = uip.get_next_token();

		if (s.equals("quit"))
		{
		  OpeningBook.close();
		  stop_threads();
		  quit_eval();
		  System.exit(0);
		}
		else if (s.equals("uci"))
		{
		  System.out.print("id name ");
		  System.out.print(engine_name());
		  System.out.print("\n");
		  System.out.print("id author Tord Romstad");
		  System.out.print("\n");
		  print_uci_options();
		  System.out.print("uciok");
		  System.out.print("\n");
		}
		else if (s.equals("ucinewgame"))
		{
		  TT.clear();
		  Position.init_piece_square_tables();
		  RootPosition.from_fen(StartPosition);
		}
		else if (s.equals("isready"))
		{
		  System.out.print("readyok");
		  System.out.print("\n");
		}
		else if (s.equals("position"))
		{
		  set_position(uip);
		}
		else if (s.equals("setoption"))
		{
		  set_option(uip);
		}
		else if (s.equals("go"))
		{
		  go(uip);
		}

		// The remaining commands are for debugging purposes only.
		// Perhaps they should be removed later in order to reduce the
		// size of the program binary.
		else if (s.equals("d"))
		{
		  RootPosition.print();
		}
		else if (s.equals("flip"))
		{
		  Position p = new Position(RootPosition);
		  RootPosition.flipped_copy(p);
		}
		else if (s.equals("eval"))
		{
		  EvalInfo ei = new EvalInfo();
		  System.out.print("Incremental mg: ");
		  System.out.print(RootPosition.mg_value());
		  System.out.print("\n");
		  System.out.print("Incremental eg: ");
		  System.out.print(RootPosition.eg_value());
		  System.out.print("\n");
		  System.out.print("Full eval: ");
		  System.out.print(evaluate(RootPosition, ei, 0));
		  System.out.print("\n");
		}
		else if (s.equals("key"))
		{
		  System.out.print("key: ");
		  System.out.print(RootPosition.get_key());
		  System.out.print(" material key: ");
		  System.out.print(RootPosition.get_material_key());
		  System.out.print(" pawn key: ");
		  System.out.print(RootPosition.get_pawn_key());
		  System.out.print("\n");
		}
		else
		{
		  System.out.print("Unknown command: ");
		  System.out.print(command);
		  System.out.print("\n");
		  while (!uip.at_end_of_line())
		  {
			System.out.print(uip.get_next_token());
			System.out.print("\n");
		  }
		}
	  }

  // set_option() is called when Glaurung receives the "setoption" UCI
  // command.  The input parameter is a UCIInputParser.  It is assumed
  // that this parser has consumed the first token of the UCI command
  // ("setoption"), and is ready to read the second token ("name", if
  // the input is well-formed).


	  public static void set_option(UCIInputParser uip)
	  {
		String token;
		if (!uip.at_end_of_line())
		{
		  token = uip.get_next_token();
		  if (token.equals("name") && !uip.at_end_of_line())
		  {
			String name = uip.get_next_token();
			String nextToken;
			while (!uip.at_end_of_line() && !(nextToken = uip.get_next_token()).equals("value"))
			{
			  name += (" " + nextToken);
			}
			if (nextToken.equals("value"))
			{
			  set_option_value(name, uip.get_rest_of_line());
			}
			else
			{
			  push_button(name);
			}
		  }
		}
	  }

  // set_position() is called when Glaurung receives the "position" UCI
  // command.  The input parameter is a UCIInputParser.  It is assumed
  // that this parser has consumed the first token of the UCI command
  // ("position"), and is ready to read the second token ("startpos"
  // or "fen", if the input is well-formed).


	  public static void set_position(UCIInputParser uip)
	  {
		String token;

		token = uip.get_next_token();
		if (token.equals("startpos"))
		{
		  RootPosition.from_fen(StartPosition);
		}
		else if (token.equals("fen"))
		{
		  String fen;
		  while (!token.equals("moves") && !uip.at_end_of_line())
		  {
			token = uip.get_next_token();
			fen += token;
			fen += ' ';
		  }
		  RootPosition.from_fen(fen);
		}

		if (!uip.at_end_of_line())
		{
		  if (!token.equals("moves"))
		  {
			token = uip.get_next_token();
		  }
		  if (token.equals("moves"))
		  {
			Move move;
			UndoInfo u = new UndoInfo();
			while (!uip.at_end_of_line())
			{
			  token = uip.get_next_token();
			  move = move_from_string(RootPosition, token);
			  RootPosition.do_move(move, u);
			  if (RootPosition.rule_50_counter() == 0)
			  {
				RootPosition.reset_game_ply();
			  }
			}
		  }
		}
	  }

  // go() is called when Glaurung receives the "go" UCI command.  The
  // input parameter is a UCIInputParser.  It is assumed that this
  // parser has consumed the first token of the UCI command ("go"),
  // and is ready to read the second token.  The function sets the
  // thinking time and other parameters from the input string, and
  // calls think() (defined in search.cpp) with the appropriate
  // parameters.


	  public static void go(UCIInputParser uip)
	  {
		String token;
		int[] time = {0, 0};
		int[] inc = {0, 0};
		int movesToGo = 0;
		int depth = 0;
		int nodes = 0;
		int moveTime = 0;
		boolean infinite = false;
		boolean ponder = false;
		Move[] searchMoves = new Move[500];

		searchMoves[0] = Move.MOVE_NONE;

		while (!uip.at_end_of_line())
		{
		  token = uip.get_next_token();

		  if (token.equals("infinite"))
		  {
			infinite = true;
		  }
		  else if (token.equals("ponder"))
		  {
			ponder = true;
		  }
		  else if (token.equals("wtime"))
		  {
			if (!uip.at_end_of_line())
			{
			  time[0] = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("btime"))
		  {
			if (!uip.at_end_of_line())
			{
			  time[1] = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("winc"))
		  {
			if (!uip.at_end_of_line())
			{
			  inc[0] = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("binc"))
		  {
			if (!uip.at_end_of_line())
			{
			  inc[1] = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("movestogo"))
		  {
			if (!uip.at_end_of_line())
			{
			  movesToGo = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("depth"))
		  {
			if (!uip.at_end_of_line())
			{
			  depth = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("nodes"))
		  {
			if (!uip.at_end_of_line())
			{
			  nodes = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("movetime"))
		  {
			if (!uip.at_end_of_line())
			{
			  moveTime = Integer.parseInt(uip.get_next_token());
			}
		  }
		  else if (token.equals("searchmoves") && !uip.at_end_of_line())
		  {
			int numOfMoves = 0;
			while (!uip.at_end_of_line())
			{
			  token = uip.get_next_token();
			  searchMoves[numOfMoves++] = move_from_string(RootPosition, token);
			}
			searchMoves[numOfMoves] = Move.MOVE_NONE;
		  }
		}

		if (moveTime != 0)
		{
		  infinite = true; // HACK
		}

		think(RootPosition, infinite, ponder, time[RootPosition.side_to_move().getValue()], inc[RootPosition.side_to_move().getValue()], movesToGo, depth, nodes, moveTime, searchMoves);
	  }
	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Variables
	////

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern boolean Chess960;

////
//// Functions
////

/// init_uci_options() initializes the UCI options.  Currently, the only
/// thing this function does is to initialize the default value of the
/// "Threads" parameter to the number of available CPU cores.



	////
	//// Prototypes
	////

	public static void init_uci_options()
	{
	  Option o;

	  o = option_with_name("Threads");
	  assert o != null;

	  // Limit the default value of "Threads" to 7 even if we have 8 CPU cores.
	  // According to Ken Dail's tests, Glaurung plays much better with 7 than
	  // with 8 threads.  This is weird, but it is probably difficult to find out
	  // why before I have a 8-core computer to experiment with myself.
	  o.defaultValue = String.format("%d", (((cpu_count()) < (7))? (cpu_count()) : (7)));
	  o.currentValue = String.format("%d", (((cpu_count()) < (7))? (cpu_count()) : (7)));

	  // Increase the minimum split depth when the number of CPUs is big.
	  // It would probably be better to let this depend on the number of threads
	  // instead.
	  o = option_with_name("Minimum Split Depth");
	  assert o != null;
	  if (cpu_count() > 4)
	  {
		o.defaultValue = String.format("%d", 6);
		o.defaultValue = String.format("%d", 6);
	  }
	}

/// print_uci_options() prints all the UCI options to the standard output,
/// in the format defined by the UCI protocol.


	public static void print_uci_options()
	{
	  final String[] optionTypeName = {"spin", "combo", "check", "string", "button"};
	  for (Option * o = Options; o.type != OptionType.OPTION_TYPE_NONE; o++)
	  {
		System.out.printf("option name %s type %s", o.name, optionTypeName[o.type.getValue()]);
		if (o.type != OptionType.BUTTON)
		{
		  System.out.printf(" default %s", o.defaultValue);
		  if (o.type == OptionType.SPIN)
		  {
			System.out.printf(" min %d max %d", o.minValue, o.maxValue);
		  }
		  else if (o.type == OptionType.COMBO)
		  {
			for (int i = 0; String.valueOf(o.comboValues[i]).length() > 0; i++)
			{
			  System.out.printf(" var %s", o.comboValues[i]);
			}
		  }
		}
		System.out.print("\n");
	  }
	}

/// get_option_value_bool() returns the current value of a UCI parameter of
/// type "check".


	public static boolean get_option_value_bool(String optionName)
	{
	  Option o = option_with_name(optionName);
	  return o != null && strcmp(o.currentValue, "true") == 0;
	}

/// get_option_value_int() returns the value of a UCI parameter as an integer.
/// Normally, this function will be used for a parameter of type "spin", but
/// it could also be used with a "combo" parameter, where all the available
/// values are integers.


	public static int get_option_value_int(String optionName)
	{
	  Option o = option_with_name(optionName);
	  return Integer.parseInt(o.currentValue);
	}

/// get_option_value_string() returns the current value of a UCI parameter as
/// a string.  It is used with parameters of type "combo" and "string".


	public static String get_option_value_string(String optionName)
	{
	  Option o = option_with_name(optionName);
	  return o.currentValue;
	}

/// button_was_pressed() tests whether a UCI parameter of type "button" has
/// been selected since the last time the function was called.


	public static boolean button_was_pressed(String buttonName)
	{
	  if (get_option_value_bool(buttonName))
	  {
		set_option_value(buttonName, "false");
		return true;
	  }
	  else
	  {
		return false;
	  }
	}

/// set_option_value() inserts a new value for a UCI parameter.  Note that
/// the function does not check that the new value is legal for the given
/// parameter:  This is assumed to be the responsibility of the GUI.


	public static void set_option_value(String optionName, String newValue)
	{
	  Option o = option_with_name(optionName);

	  if (o != null)
	  {
		o.currentValue = newValue;
	  }
	  else
	  {
		System.out.print("No such option: ");
		System.out.print(optionName);
		System.out.print("\n");
	  }
	}

/// push_button() is used to tell the engine that a UCI parameter of type
/// "button" has been selected:


	public static void push_button(String buttonName)
	{
	  set_option_value(buttonName, "true");
	}





	////
	//// Variables
	////

	public static boolean Chess960 = false;


	  ///
	  /// Variables
	  ///

	  public static Option[] Options =
	  {
		  new Option("Use Search Log", "false", "false", OptionType.CHECK, 0, 0, {""}),
		  new Option("Search Log Filename", "SearchLog.txt", "SearchLog.txt", OptionType.STRING, 0, 0, {""}),
		  new Option("Book File", "book.bin", "book.bin", OptionType.STRING, 0, 0, {""}),
		  new Option("Mobility (Middle Game)", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Mobility (Endgame)", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Pawn Structure (Middle Game)", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Pawn Structure (Endgame)", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Passed Pawns (Middle Game)", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Passed Pawns (Endgame)", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Space", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Aggressiveness", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("Cowardice", "100", "100", OptionType.SPIN, 0, 200, {""}),
		  new Option("King Safety Curve", "Quadratic", "Quadratic", OptionType.COMBO, 0, 0, {"Quadratic", "Linear"}),
		  new Option("King Safety Coefficient", "40", "40", OptionType.SPIN, 1, 100, {""}),
		  new Option("King Safety X Intercept", "0", "0", OptionType.SPIN, 0, 20, {""}),
		  new Option("King Safety Max Slope", "30", "30", OptionType.SPIN, 10, 100, {""}),
		  new Option("King Safety Max Value", "500", "500", OptionType.SPIN, 100, 1000, {""}),
		  new Option("Queen Contact Check Bonus", "3", "3", OptionType.SPIN, 0, 8, {""}),
		  new Option("Queen Check Bonus", "2", "2", OptionType.SPIN, 0, 4, {""}),
		  new Option("Rook Check Bonus", "1", "1", OptionType.SPIN, 0, 4, {""}),
		  new Option("Bishop Check Bonus", "1", "1", OptionType.SPIN, 0, 4, {""}),
		  new Option("Knight Check Bonus", "1", "1", OptionType.SPIN, 0, 4, {""}),
		  new Option("Discovered Check Bonus", "3", "3", OptionType.SPIN, 0, 8, {""}),
		  new Option("Mate Threat Bonus", "3", "3", OptionType.SPIN, 0, 8, {""}),
		  new Option("Check Extension (PV nodes)", "2", "2", OptionType.SPIN, 0, 2, {""}),
		  new Option("Check Extension (non-PV nodes)", "1", "1", OptionType.SPIN, 0, 2, {""}),
		  new Option("Single Reply Extension (PV nodes)", "2", "2", OptionType.SPIN, 0, 2, {""}),
		  new Option("Single Reply Extension (non-PV nodes)", "2", "2", OptionType.SPIN, 0, 2, {""}),
		  new Option("Mate Threat Extension (PV nodes)", "0", "0", OptionType.SPIN, 0, 2, {""}),
		  new Option("Mate Threat Extension (non-PV nodes)", "0", "0", OptionType.SPIN, 0, 2, {""}),
		  new Option("Pawn Push to 7th Extension (PV nodes)", "1", "1", OptionType.SPIN, 0, 2, {""}),
		  new Option("Pawn Push to 7th Extension (non-PV nodes)", "1", "1", OptionType.SPIN, 0, 2, {""}),
		  new Option("Passed Pawn Extension (PV nodes)", "1", "1", OptionType.SPIN, 0, 2, {""}),
		  new Option("Passed Pawn Extension (non-PV nodes)", "0", "0", OptionType.SPIN, 0, 2, {""}),
		  new Option("Pawn Endgame Extension (PV nodes)", "2", "2", OptionType.SPIN, 0, 2, {""}),
		  new Option("Pawn Endgame Extension (non-PV nodes)", "2", "2", OptionType.SPIN, 0, 2, {""}),
		  new Option("Full Depth Moves (PV nodes)", "14", "14", OptionType.SPIN, 1, 100, {""}),
		  new Option("Full Depth Moves (non-PV nodes)", "3", "3", OptionType.SPIN, 1, 100, {""}),
		  new Option("Threat Depth", "5", "5", OptionType.SPIN, 0, 100, {""}),
		  new Option("Selective Plies", "7", "7", OptionType.SPIN, 0, 10, {""}),
		  new Option("Futility Pruning (Main Search)", "true", "true", OptionType.CHECK, 0, 0, {""}),
		  new Option("Futility Pruning (Quiescence Search)", "true", "true", OptionType.CHECK, 0, 0, {""}),
		  new Option("Futility Margin 0", "50", "50", OptionType.SPIN, 0, 1000, {""}),
		  new Option("Futility Margin 1", "100", "100", OptionType.SPIN, 0, 1000, {""}),
		  new Option("Futility Margin 2", "200", "200", OptionType.SPIN, 0, 1000, {""}),
		  new Option("Maximum Razoring Depth", "3", "3", OptionType.SPIN, 0, 4, {""}),
		  new Option("Razoring Margin", "300", "300", OptionType.SPIN, 150, 600, {""}),
		  new Option("Randomness", "0", "0", OptionType.SPIN, 0, 10, {""}),
		  new Option("Minimum Split Depth", "4", "4", OptionType.SPIN, 4, 7, {""}),
		  new Option("Maximum Number of Threads per Split Point", "5", "5", OptionType.SPIN, 4, 8, {""}),
		  new Option("Threads", "1", "1", OptionType.SPIN, 1, 8, {""}),
		  new Option("Hash", "32", "32", OptionType.SPIN, 4, 4096, {""}),
		  new Option("Clear Hash", "false", "false", OptionType.BUTTON, 0, 0, {""}),
		  new Option("Ponder", "true", "true", OptionType.CHECK, 0, 0, {""}),
		  new Option("OwnBook", "true", "true", OptionType.CHECK, 0, 0, {""}),
		  new Option("MultiPV", "1", "1", OptionType.SPIN, 1, 500, {""}),
		  new Option("UCI_ShowCurrLine", "false", "false", OptionType.CHECK, 0, 0, {""}),
		  new Option("UCI_Chess960", "false", "false", OptionType.CHECK, 0, 0, {""}),
		  new Option("", "", "", OptionType.OPTION_TYPE_NONE, 0, 0, {""})
	  };

  // option_with_name() tries to find a UCI option with a given
  // name.  It returns a pointer to the UCI option or the null pointer,
  // depending on whether an option with the given name exists.



	  ///
	  /// Functions
	  ///

	  public static Option option_with_name(String optionName)
	  {
		for (Option * o = Options; o.type != OptionType.OPTION_TYPE_NONE; o++)
		{
		  if (strcmp(o.name, optionName) == 0)
		  {
			return o;
		  }
		}
		return null;
	  }


	////
	//// Constants and variables
	////

	/// Piece values, middle game and endgame

	/// Important: If the material values are changed, one must also
	/// adjust the piece square tables, and the method game_phase() in the
	/// Position class!

	public static final Value PawnValueMidgame = 0xCC;
	public static final Value PawnValueEndgame = 0x100;
	public static final Value KnightValueMidgame = 0x340;
	public static final Value KnightValueEndgame = 0x340;
	public static final Value BishopValueMidgame = 0x340;
	public static final Value BishopValueEndgame = 0x340;
	public static final Value RookValueMidgame = 0x505;
	public static final Value RookValueEndgame = 0x505;
	public static final Value QueenValueMidgame = 0xA00;
	public static final Value QueenValueEndgame = 0xA00;

	public static final Value[] PieceValueMidgame = {Value(0), PawnValueMidgame, KnightValueMidgame, BishopValueMidgame, RookValueMidgame, QueenValueMidgame, Value(0), Value(0), Value(0), PawnValueMidgame, KnightValueMidgame, BishopValueMidgame, RookValueMidgame, QueenValueMidgame, Value(0), Value(0), Value(0)};

	public static final Value[] PieceValueEndgame = {Value(0), PawnValueEndgame, KnightValueEndgame, BishopValueEndgame, RookValueEndgame, QueenValueEndgame, Value(0), Value(0), Value(0), PawnValueEndgame, KnightValueEndgame, BishopValueEndgame, RookValueEndgame, QueenValueEndgame, Value(0), Value(0), Value(0)};

	/// Bonus for having the side to move

	public static final Value TempoValueMidgame = 50;
	public static final Value TempoValueEndgame = 20;


	////
	//// Inline functions
	////

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator + (Value v, int i)
	{
		return Value(v.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator + (Value v1, Value v2)
	{
		return Value(v1.getValue() + v2.getValue());
	}
	private void addAssignment (tangible.RefObject<Value> v1, Value v2)
	{
	  v1.argValue = Value(v1.argValue.getValue() + v2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator - (Value v, int i)
	{
		return Value(v.getValue() - i);
	}
	private Value subtract (Value v)
	{
		return Value(-v.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator - (Value v1, Value v2)
	{
		return Value(v1.getValue() - v2.getValue());
	}
	private void subtractAssignment (tangible.RefObject<Value> v1, Value v2)
	{
	  v1.argValue = Value(v1.argValue.getValue() - v2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator * (Value v, int i)
	{
		return Value(v.getValue() * i);
	}
	private void multiplyAssignment (tangible.RefObject<Value> v, int i)
	{
		v.argValue = Value(v.argValue.getValue() * i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator * (int i, Value v)
	{
		return Value(v.getValue() * i);
	}
	private Value divide (Value v, int i)
	{
		return Value(v.getValue() / i);
	}
	private void divideAssignment (tangible.RefObject<Value> v, int i)
	{
		v.argValue = Value(v.argValue.getValue() / i);
	}


	public static Value value_mate_in(int ply)
	{
	  return Value(Value.VALUE_MATE - Value(ply));
	}

	public static Value value_mated_in(int ply)
	{
	  return Value(-Value.VALUE_MATE + Value(ply));
	}

	public static boolean is_upper_bound(ValueType vt)
	{
	  return (vt.getValue() & ValueType.VALUE_TYPE_UPPER.getValue()) != 0;
	}

	public static boolean is_lower_bound(ValueType vt)
	{
	  return (vt.getValue() & ValueType.VALUE_TYPE_LOWER.getValue()) != 0;
	}

	public static Value piece_value_midgame(PieceType pt)
	{
	  return PieceValueMidgame[pt.getValue()];
	}

	public static Value piece_value_endgame(PieceType pt)
	{
	  return PieceValueEndgame[pt.getValue()];
	}

	public static Value piece_value_midgame(Piece p)
	{
	  return PieceValueMidgame[p.getValue()];
	}

	public static Value piece_value_endgame(Piece p)
	{
	  return PieceValueEndgame[p.getValue()];
	}

////
//// Functions
////

/// value_to_tt() adjusts a mate score from "plies to mate from the root" to
/// "plies to mate from the current ply".  Non-mate scores are unchanged.
/// The function is called before storing a value to the transposition table.



	////
	//// Prototypes
	////

	public static Value value_to_tt(Value v, int ply)
	{
	  if (v.getValue() >= value_mate_in(100))
	  {
		return v + ply;
	  }
	  else if (v.getValue() <= value_mated_in(100))
	  {
		return v - ply;
	  }
	  else
	  {
		return v;
	  }
	}

/// value_from_tt() is the inverse of value_to_tt():  It adjusts a mate score
/// from the transposition table to a mate score corrected for the current
/// ply depth.


	public static Value value_from_tt(Value v, int ply)
	{
	  if (v.getValue() >= value_mate_in(100))
	  {
		return v - ply;
	  }
	  else if (v.getValue() <= value_mated_in(100))
	  {
		return v + ply;
	  }
	  else
	  {
		return v;
	  }
	}

/// value_to_centipawns() converts a value from Glaurung's somewhat unusual
/// scale of pawn = 256 to the more conventional pawn = 100.


	public static int value_to_centipawns(Value v)
	{
	  return (v.getValue() * 100) / PawnValueMidgame.getValue();
	}

/// value_from_centipawns() converts a centipawn value to Glaurung's internal
/// evaluation scale.  It's used when reading the values of UCI options
/// containing material values (e.g. futility pruning margins).


	public static Value value_from_centipawns(int cp)
	{
	  return Value((cp * 256) / 100);
	}

/// value_to_string() converts a value to a string suitable for use with the
/// UCI protocol.


	public static String value_to_string(Value v)
	{
	  std::stringstream s = new std::stringstream();

	  if (Math.abs(v) < Value.VALUE_MATE.getValue() - 200)
	  {
		s << "cp " << value_to_centipawns(v);
	  }
	  else
	  {
		s << "mate ";
		if (v.getValue() > 0)
		{
		  s << (Value.VALUE_MATE - v + 1) / 2;
		}
		else
		{
		  s << -(Value.VALUE_MATE + v) / 2;
		}
	  }
	  return s.str();
	}




	////
	//// Constants
	////

	/// Note: If OnePly is changed, the constant HistoryMax in history.h should
	/// probably also be changed.

	public static final Depth OnePly = 2;


	////
	//// Inline functions
	////

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator + (Depth d, int i)
	{
		return Depth(d.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator + (Depth d1, Depth d2)
	{
		return Depth(d1.getValue() + d2.getValue());
	}
	private void addAssignment (tangible.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() + i);
	}
	private void addAssignment (Depth d1, Depth d2)
	{
		d1 += d2.getValue();
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator - (Depth d, int i)
	{
		return Depth(d.getValue() - i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator - (Depth d1, Depth d2)
	{
		return Depth(d1.getValue() - d2.getValue());
	}
	private void subtractAssignment (tangible.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() - i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator * (Depth d, int i)
	{
		return Depth(d.getValue() * i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator * (int i, Depth d)
	{
		return Depth(d.getValue() * i);
	}
	private void multiplyAssignment (tangible.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() * i);
	}
	private Depth divide (Depth d, int i)
	{
		return Depth(d.getValue() / i);
	}
	private void divideAssignment (tangible.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() / i);
	}



	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




	// x86 assembly language locks or OS spin locks may perform faster than
	// mutex locks on some platforms.  On my machine, mutexes seem to be the
	// best.

	///#define ASM_LOCK
	///#define OS_SPIN_LOCK


	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ASM_LOCK


	//C++ TO JAVA CONVERTER TODO TASK: Typedefs defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	//typedef volatile int Lock;

	public static void LockX86(tangible.RefObject<Integer> lock)
	{
	  int dummy;
//C++ TO JAVA CONVERTER TODO TASK: Java does not allow embedded assembly instructions:
	//  asm __volatile__("1:          movl    $1, %0" "\n\t" + "            xchgl   (%1), %0" "\n\t" "            testl   %0, %0" "\n\t" + "            jz      3f" "\n\t" "2:          pause" "\n\t" + "            movl    (%1), %0" "\n\t" "            testl   %0, %0" "\n\t" + "            jnz     2b" "\n\t" "            jmp     1b" "\n\t" "3:" + "\n\t":"=&q"(dummy) :"q"(lock) :"cc");
	}

	public static void UnlockX86(tangible.RefObject<Integer> lock)
	{
	  int dummy;
//C++ TO JAVA CONVERTER TODO TASK: Java does not allow embedded assembly instructions:
	//  asm __volatile__("movl    $0, (%1)":"=&q"(dummy) :"q"(lock));
	}

	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_init(x, y) (*(x) = 0)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_grab(x) LockX86(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_release(x) UnlockX86(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_destroy(x)


	///#elif OS_SPIN_LOCK


	//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
	//#include <libkern/OSAtomic.h>

	//C++ TO JAVA CONVERTER TODO TASK: Typedefs defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	//typedef OSSpinLock Lock;

	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_init(x, y) (*(x) = 0)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_grab(x) OSSpinLockLock(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_release(x) OSSpinLockUnlock(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_destroy(x)


	///#elif !_MSC_VER

	//C++ TO JAVA CONVERTER WARNING: The following #include directive was ignored:
	//#include <pthread.h>

	//C++ TO JAVA CONVERTER TODO TASK: Typedefs defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	//typedef pthread_mutex_t Lock;

	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_init(x, y) pthread_mutex_init(x, y)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_grab(x) pthread_mutex_lock(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_release(x) pthread_mutex_unlock(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_destroy(x) pthread_mutex_destroy(x)


	///#else



	//C++ TO JAVA CONVERTER TODO TASK: Typedefs defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	//typedef CRITICAL_SECTION Lock;
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_init(x, y) InitializeCriticalSection(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_grab(x) EnterCriticalSection(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_release(x) LeaveCriticalSection(x)
	//C++ TO JAVA CONVERTER TODO TASK: #define macros defined in multiple preprocessor conditionals can only be replaced within the scope of the preprocessor conditional:
	///#define lock_destroy(x) DeleteCriticalSection(x)


	///#endif



	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Prototypes
	////

//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
	//uint32_t genrand_int32();
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
	//uint64_t genrand_int64();
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
	//void init_mersenne();



	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/



	////
	//// Includes
	////



	////
	//// Variables
	////

	public static final int[][] MgPST =
	{
		{, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 166, 192, 204, 216, 216, 204, 192, 166, 166, 192, 210, 242, 242, 210, 192, 166, 166, 192, 220, 268, 268, 220, 192, 166, 166, 192, 220, 242, 242, 220, 192, 166, 166, 192, 210, 216, 216, 210, 192, 166, 166, 192, 204, 216, 216, 204, 192, 166, 0, 0, 0, 0, 0, 0, 0, 0},
		{704, 730, 756, 768, 768, 756, 730, 704, 743, 768, 794, 807, 807, 794, 768, 743, 781, 807, 832, 844, 844, 832, 807, 781, 807, 832, 857, 870, 870, 857, 832, 807, 820, 844, 870, 883, 883, 870, 844, 820, 820, 844, 870, 883, 883, 870, 844, 820, 781, 807, 832, 844, 844, 832, 807, 781, 650, 768, 794, 807, 807, 794, 768, 650},
		{786, 786, 792, 797, 797, 792, 786, 786, 812, 832, 827, 832, 832, 827, 832, 812, 817, 827, 842, 837, 837, 842, 827, 817, 822, 832, 837, 852, 852, 837, 832, 822, 822, 832, 837, 852, 852, 837, 832, 822, 817, 827, 842, 837, 837, 842, 827, 817, 812, 832, 827, 832, 832, 827, 832, 812, 812, 812, 817, 822, 822, 817, 812, 812},
		{1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267, 1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267, 1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267, 1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267, 1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267, 1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267, 1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267, 1267, 1275, 1282, 1289, 1289, 1282, 1275, 1267},
		{2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560, 2560},
		{302, 328, 276, 225, 225, 276, 328, 302, 276, 302, 251, 200, 200, 251, 302, 276, 225, 251, 200, 149, 149, 200, 251, 225, 200, 225, 175, 124, 124, 175, 225, 200, 175, 200, 149, 98, 98, 149, 200, 175, 149, 175, 124, 72, 72, 124, 175, 149, 124, 149, 98, 47, 47, 98, 149, 124, 98, 124, 72, 21, 21, 72, 124, 98}
	};


	public static final int[][] EgPST =
	{
		{, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 0, 0, 0, 0, 0, 0, 0, 0},
		{730, 756, 781, 794, 794, 781, 756, 730, 756, 781, 807, 820, 820, 807, 781, 756, 781, 807, 832, 844, 844, 832, 807, 781, 794, 820, 844, 857, 857, 844, 820, 794, 794, 820, 844, 857, 857, 844, 820, 794, 781, 807, 832, 844, 844, 832, 807, 781, 756, 781, 807, 820, 820, 807, 781, 756, 730, 756, 781, 794, 794, 781, 756, 730},
		{786, 802, 809, 817, 817, 809, 802, 786, 802, 817, 825, 832, 832, 825, 817, 802, 809, 825, 832, 839, 839, 832, 825, 809, 817, 832, 839, 847, 847, 839, 832, 817, 817, 832, 839, 847, 847, 839, 832, 817, 809, 825, 832, 839, 839, 832, 825, 809, 802, 817, 825, 832, 832, 825, 817, 802, 786, 802, 809, 817, 817, 809, 802, 786},
		{1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282, 1282},
		{2499, 2520, 2530, 2540, 2540, 2530, 2520, 2499, 2520, 2540, 2550, 2560, 2560, 2550, 2540, 2520, 2530, 2550, 2560, 2570, 2570, 2560, 2550, 2530, 2540, 2560, 2570, 2580, 2580, 2570, 2560, 2540, 2540, 2560, 2570, 2580, 2580, 2570, 2560, 2540, 2530, 2550, 2560, 2570, 2570, 2560, 2550, 2530, 2520, 2540, 2550, 2560, 2560, 2550, 2540, 2520, 2499, 2520, 2530, 2540, 2540, 2530, 2520, 2499},
		{16, 78, 108, 139, 139, 108, 78, 16, 78, 139, 170, 200, 200, 170, 139, 78, 108, 170, 200, 230, 230, 200, 170, 108, 139, 200, 230, 261, 261, 230, 200, 139, 139, 200, 230, 261, 261, 230, 200, 139, 108, 170, 200, 230, 230, 200, 170, 108, 78, 139, 170, 200, 200, 170, 139, 78, 16, 78, 108, 139, 139, 108, 78, 16}
	};





	////
	//// Inline functions
	////

	public static Value apply_scale_factor(Value v, ScaleFactor f)
	{
	  return Value((v * f) / ScaleFactor.SCALE_FACTOR_NORMAL.getValue());
	}



	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




	////
	//// Includes
	////



	////
	//// Constants and variables
	////

	public static final int THREAD_MAX = 8;
}