public class MoveStack
{
  public Move move;
  public int score;
}