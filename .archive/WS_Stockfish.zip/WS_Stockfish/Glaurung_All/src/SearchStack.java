////
//// Types
////

/// The SearchStack struct keeps track of the information we need to remember
/// from nodes shallower and deeper in the tree during the search.  Each
/// search thread has its own array of SearchStack objects, indexed by the
/// current ply.

public class SearchStack
{
  public Move[] pv = new Move[PLY_MAX];
  public Move currentMove;
  public Value currentMoveCaptureValue;
  public Move mateKiller;
  public Move killer1;
  public Move killer2;
  public Move threatMove;
  public Depth reduction;
}