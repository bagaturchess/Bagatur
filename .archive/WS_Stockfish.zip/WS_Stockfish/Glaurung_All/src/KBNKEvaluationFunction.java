import java.io.*;

// KBN vs K:
public class KBNKEvaluationFunction extends EndgameEvaluationFunction
{
  public KBNKEvaluationFunction(Color c)
  {
	  super(c);
  }


  /// Mate with KBN vs K.  This is similar to KX vs K, but we have to drive the
  /// defending king towards a corner square of the right color.

  @Override
  public final Value apply(Position pos)
  {

	assert pos.non_pawn_material(weakerSide) == Value(0);
	assert pos.pawn_count(weakerSide) == Value(0);
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.KnightValueMidgame + GlobalMembers.BishopValueMidgame;
	assert pos.bishop_count(strongerSide) == 1;
	assert pos.knight_count(strongerSide) == 1;
	assert pos.pawn_count(strongerSide) == 0;

	Square winnerKSq = pos.king_square(strongerSide);
	Square loserKSq = pos.king_square(weakerSide);
	Square bishopSquare = pos.bishop_list(strongerSide, 0);

	if (GlobalMembers.square_color(bishopSquare) == Color.BLACK)
	{
	  winnerKSq = GlobalMembers.flop_square(winnerKSq);
	  loserKSq = GlobalMembers.flop_square(loserKSq);
	}

	Value result = Value.VALUE_KNOWN_WIN + GlobalMembers.distance_bonus(GlobalMembers.square_distance(winnerKSq, loserKSq)) + GlobalMembers.kbnk_mate_table(loserKSq);

	return (strongerSide == pos.side_to_move())? result : -result;
  }
}