import java.io.*;

// KP vs K:
public class KPKEvaluationFunction extends EndgameEvaluationFunction
{
  public KPKEvaluationFunction(Color c)
  {
	  super(c);
  }


  /// KP vs K.  This endgame is evaluated with the help of a bitbase.

  @Override
  public final Value apply(Position pos)
  {

	assert pos.non_pawn_material(strongerSide) == Value(0);
	assert pos.non_pawn_material(weakerSide) == Value(0);
	assert pos.pawn_count(strongerSide) == 1;
	assert pos.pawn_count(weakerSide) == 0;

	Square wksq;
	Square bksq;
	Square wpsq;
	Color stm;

	if (strongerSide == Color.WHITE)
	{
	  wksq = pos.king_square(Color.WHITE);
	  bksq = pos.king_square(Color.BLACK);
	  wpsq = pos.pawn_list(Color.WHITE, 0);
	  stm = pos.side_to_move();
	}
	else
	{
	  wksq = GlobalMembers.flip_square(pos.king_square(Color.BLACK));
	  bksq = GlobalMembers.flip_square(pos.king_square(Color.WHITE));
	  wpsq = GlobalMembers.flip_square(pos.pawn_list(Color.BLACK, 0));
	  stm = GlobalMembers.opposite_color(pos.side_to_move());
	}

	if (GlobalMembers.square_file(wpsq) >= File.FILE_E.getValue())
	{
	  wksq = GlobalMembers.flop_square(wksq);
	  bksq = GlobalMembers.flop_square(bksq);
	  wpsq = GlobalMembers.flop_square(wpsq);
	}

	if (GlobalMembers.probe_kpk(wksq, wpsq, bksq, stm) != 0)
	{
	  Value result = Value.VALUE_KNOWN_WIN + GlobalMembers.PawnValueEndgame + Value(GlobalMembers.square_rank(wpsq));
	  return (strongerSide == pos.side_to_move())? result : -result;
	}

	return Value.VALUE_DRAW;
  }
}