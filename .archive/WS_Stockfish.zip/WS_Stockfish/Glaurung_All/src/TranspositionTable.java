import java.io.*;

/// The transposition table class.  This is basically just a huge array
/// containing TTEntry objects, and a few methods for writing new entries
/// and reading new ones.

public class TranspositionTable implements Closeable
{


  ////
  //// Functions
  ////

  /// Constructor

  public TranspositionTable(int mbSize)
  {
	size = 0;
	generation = 0;
	writes = 0;
	entries = null;
	this.set_size(mbSize);
  }


  /// Destructor

  public final void close()
  {
	Arrays.deleteArray(entries);
  }


  /// TranspositionTable::set_size sets the size of the transposition table,
  /// measured in megabytes.

  public final void set_size(int mbSize)
  {
	int newSize;

	assert mbSize >= 4 && mbSize <= 1024;

//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	for (newSize = 1024; newSize * 4 * (sizeof(TTEntry)) <= (mbSize << 20); newSize *= 2)
	{
		;
	}
	newSize /= 2;

	if (newSize != size)
	{
	  size = newSize;
	  entries = null;
	  entries = tangible.Arrays.initializeWithDefaultTTEntryInstances(size * 4);
	  if (entries == null)
	  {
		std::cerr << "Failed to allocate " << mbSize << " MB for transposition table." << std::endl;
		System.exit(1);
	  }
	  this.clear();
	}
  }


  /// TranspositionTable::clear overwrites the entire transposition table
  /// with zeroes.  It is called whenever the table is resized, or when the
  /// user asks the program to clear the table (from the UCI interface).
  /// Perhaps we should also clear it when the "ucinewgame" command is recieved?

  public final void clear()
  {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memset(entries, 0, size * 4 * sizeof(TTEntry));
  }


  /// TranspositionTable::store writes a new entry containing a position,
  /// a value, a value type, a search depth, and a best move to the
  /// transposition table.  The transposition table is organized in clusters
  /// of four TTEntry objects, and when a new entry is written, it replaces
  /// the least valuable of the four entries in a cluster.  A TTEntry t1 is
  /// considered to be more valuable than a TTEntry t2 if t1 is from the
  /// current search and t2 is from a previous search, or if the depth of t1
  /// is bigger than the depth of t2.

  public final void store(Position pos, Value v, Depth d, Move m, ValueType type)
  {
	TTEntry tte;
	TTEntry replace;

	tte = replace = entries + (int)(pos.get_key() & (size - 1)) * 4;
	for (int i = 0; i < 4; i++)
	{
	  if ((tte + i).key() == pos.get_key())
	  {
		if (m == Move.MOVE_NONE)
		{
		  m = (tte + i).move();
		}
		*(tte + i) = new TTEntry(pos.get_key(), v, type, d, m, generation);
		return;
	  }
	  if (replace.generation() == generation)
	  {
		if ((tte + i).generation() != generation || (tte + i).depth() < replace.depth())
		{
		  replace = tte + i;
		}
	  }
	  else if ((tte + i).generation() != generation && (tte + i).depth() < replace.depth())
	  {
		replace = tte + i;
	  }
	}
	replace = new TTEntry(pos.get_key(), v, type, d, m, generation);
	writes++;
  }


  /// TranspositionTable::retrieve looks up the current position in the
  /// transposition table, and extracts the value, value type, depth and
  /// best move if the position is found.  The return value is true if
  /// the position is found, and false if it isn't.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean retrieve(const Position &pos, Value *value, Depth *d, Move *move, ValueType *type) const
  public final boolean retrieve(Position pos, Value value, Depth d, Move move, ValueType type)
  {
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
	TTEntry * tte = new TTEntry();
	boolean found = false;

//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: tte = entries + int(pos.get_key() & (size - 1)) * 4;
	tte.copyFrom(entries + (int)(pos.get_key() & (size - 1)) * 4);
	for (int i = 0; i < 4 && !found ; i++)
	{
	  if ((tte + i).key() == pos.get_key())
	  {
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: tte = tte + i;
		tte.copyFrom(tte + i);
		found = true;
	  }
	}
	if (!found)
	{
	  move = Move.MOVE_NONE;
	  return false;
	}

	value = tte.value();
	type = tte.type();
	d = tte.depth();
	move = tte.move();

	return true;
  }


  /// TranspositionTable::new_search() is called at the beginning of every new
  /// search.  It increments the "generation" variable, which is used to
  /// distinguish transposition table entries from previous searches from
  /// entries from the current search.

  public final void new_search()
  {
	generation++;
	writes = 0;
  }


  /// TranspositionTable::insert_pv() is called at the end of a search 
  /// iteration, and inserts the PV back into the PV.  This makes sure the
  /// old PV moves are searched first, even if the old TT entries have been
  /// overwritten.

  public final void insert_pv(Position pos, Move[] pv)
  {
	UndoInfo u = new UndoInfo();
	Position p = new Position(pos);

	for (int i = 0; pv[i] != Move.MOVE_NONE; i++)
	{
	  this.store(p, Value.VALUE_NONE, Depth(0), pv[i], ValueType.VALUE_TYPE_NONE);
	  p.do_move(pv[i], u);
	}
  }


  /// TranspositionTable::full() returns the permill of all transposition table
  /// entries which have received at least one write during the current search.
  /// It is used to display the "info hashfull ..." information in UCI.

  public final int full()
  {
	double N = (double)size * 4.0;
	return (int)(1000 * (1 - Math.exp(writes * Math.log(1.0 - 1.0 / N))));
  }

  private int size;
  private int writes;
  private TTEntry entries;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned char generation;
  private byte generation;
}