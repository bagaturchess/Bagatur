////
//// Local definitions
////


  /// Types

  public enum Ambiguity
  {
	AMBIGUITY_NONE,
	AMBIGUITY_FILE,
	AMBIGUITY_RANK,
	AMBIGUITY_BOTH;

	  public static final int SIZE = java.lang.Integer.SIZE;

	  public int getValue()
	  {
		  return this.ordinal();
	  }

	  public static Ambiguity forValue(int value)
	  {
		  return values()[value];
	  }
  }