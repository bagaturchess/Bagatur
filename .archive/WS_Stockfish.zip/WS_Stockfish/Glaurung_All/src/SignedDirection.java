public enum SignedDirection
{
  SIGNED_DIR_E(0),
  SIGNED_DIR_W(1),
  SIGNED_DIR_N(2),
  SIGNED_DIR_S(3),
  SIGNED_DIR_NE(4),
  SIGNED_DIR_SW(5),
  SIGNED_DIR_NW(6),
  SIGNED_DIR_SE(7),
  SIGNED_DIR_NONE(8);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, SignedDirection> mappings;
	private static java.util.HashMap<Integer, SignedDirection> getMappings()
	{
		if (mappings == null)
		{
			synchronized (SignedDirection.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, SignedDirection>();
				}
			}
		}
		return mappings;
	}

	private SignedDirection(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static SignedDirection forValue(int value)
	{
		return getMappings().get(value);
	}
}