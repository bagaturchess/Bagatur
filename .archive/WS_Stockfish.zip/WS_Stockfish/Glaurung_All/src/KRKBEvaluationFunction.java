import java.io.*;

// KR vs KB:
public class KRKBEvaluationFunction extends EndgameEvaluationFunction
{
  public KRKBEvaluationFunction(Color c)
  {
	  super(c);
  }


  /// KR vs KB.  This is very simple, and always returns drawish scores.  The
  /// score is slightly bigger when the defending king is close to the edge.

  @Override
  public final Value apply(Position pos)
  {

	assert pos.non_pawn_material(strongerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(strongerSide) == 0;
	assert pos.non_pawn_material(weakerSide) == GlobalMembers.BishopValueMidgame;
	assert pos.pawn_count(weakerSide) == 0;
	assert pos.bishop_count(weakerSide) == 1;

	Value result = GlobalMembers.mate_table(pos.king_square(weakerSide));
	return (pos.side_to_move() == strongerSide)? result : -result;
  }
}