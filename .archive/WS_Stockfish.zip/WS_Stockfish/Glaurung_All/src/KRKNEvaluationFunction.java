import java.io.*;

// KR vs KN:
public class KRKNEvaluationFunction extends EndgameEvaluationFunction
{
  public KRKNEvaluationFunction(Color c)
  {
	  super(c);
  }


  /// KR vs KN.  The attacking side has slightly better winning chances than
  /// in KR vs KB, particularly if the king and the knight are far apart.

  @Override
  public final Value apply(Position pos)
  {

	assert pos.non_pawn_material(strongerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(strongerSide) == 0;
	assert pos.non_pawn_material(weakerSide) == GlobalMembers.KnightValueMidgame;
	assert pos.pawn_count(weakerSide) == 0;
	assert pos.knight_count(weakerSide) == 1;

	Square defendingKSq = pos.king_square(weakerSide);
	Square nSq = pos.knight_list(weakerSide, 0);

	Value result = Value(10) + GlobalMembers.mate_table(defendingKSq) + GlobalMembers.krkn_king_knight_distance_penalty(GlobalMembers.square_distance(defendingKSq, nSq));

	return (strongerSide == pos.side_to_move())? result : -result;
  }
}