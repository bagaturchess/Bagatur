import java.io.*;

/// The MaterialInfoTable class represents a pawn hash table.  It is basically
/// just an array of MaterialInfo objects and a few methods for accessing these
/// objects.  The most important method is get_material_info, which looks up a
/// position in the table and returns a pointer to a MaterialInfo object.

public class MaterialInfoTable implements Closeable
{


  /// Constructor for the MaterialInfoTable class.

  public MaterialInfoTable(int numOfEntries)
  {
	size = numOfEntries;
	entries = tangible.Arrays.initializeWithDefaultMaterialInfoInstances(size);
	if (entries == null)
	{
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	  std::cerr << "Failed to allocate " << (numOfEntries * sizeof(MaterialInfo)) << " bytes for material hash table." << std::endl;
	  System.exit(1);
	}
	this.clear();
  }


  /// Destructor for the MaterialInfoTable class.

  public final void close()
  {
	Arrays.deleteArray(entries);
  }


  /// MaterialInfoTable::clear() clears a material hash table by setting
  /// all entries to 0.

  public final void clear()
  {
//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	memset(entries, 0, size * sizeof(MaterialInfo));
  }


  /// MaterialInfoTable::get_material_info() takes a position object as input,
  /// computes or looks up a MaterialInfo object, and returns a pointer to it.
  /// If the material configuration is not already present in the table, it
  /// is stored there, so we don't have to recompute everything when the 
  /// same material configuration occurs again.

  public final MaterialInfo get_material_info(Position pos)
  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long key = pos.get_material_key();
	long key = pos.get_material_key();
	int index = (int)(key & (size - 1));
	MaterialInfo mi = entries + index;

	// If mi->key matches the position's material hash key, it means that we
	// have analysed this material configuration before, and we can simply
	// return the information we found the last time instead of recomputing it:
	if (mi.key == key)
	{
	  return mi;
	}

	// Clear the MaterialInfo object, and set its key:
	mi.clear();
	mi.key = key;

	// A special case before looking for a specialized evaluation function:
	// KNN vs K is a draw:
	if (key == GlobalMembers.KNNKMaterialKey || key == GlobalMembers.KKNNMaterialKey)
	{
	  mi.factor[Color.WHITE.getValue()] = mi.factor[Color.BLACK.getValue()] = 0;
	  return mi;
	}

	// Let's look if we have a specialized evaluation function for this
	// particular material configuration:
	if (key == GlobalMembers.KPKMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKPK;
	  return mi;
	}
	else if (key == GlobalMembers.KKPMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKKP;
	  return mi;
	}
	else if (key == GlobalMembers.KBNKMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKBNK;
	  return mi;
	}
	else if (key == GlobalMembers.KKBNMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKKBN;
	  return mi;
	}
	else if (key == GlobalMembers.KRKPMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKRKP;
	  return mi;
	}
	else if (key == GlobalMembers.KPKRMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKPKR;
	  return mi;
	}
	else if (key == GlobalMembers.KRKBMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKRKB;
	  return mi;
	}
	else if (key == GlobalMembers.KBKRMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKBKR;
	  return mi;
	}
	else if (key == GlobalMembers.KRKNMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKRKN;
	  return mi;
	}
	else if (key == GlobalMembers.KNKRMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKNKR;
	  return mi;
	}
	else if (key == GlobalMembers.KQKRMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKQKR;
	  return mi;
	}
	else if (key == GlobalMembers.KRKQMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKRKQ;
	  return mi;
	}
	else if (key == GlobalMembers.KBBKNMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKBBKN;
	  return mi;
	}
	else if (key == GlobalMembers.KNKBBMaterialKey)
	{
	  mi.evaluationFunction = &EvaluateKNKBB;
	  return mi;
	}
	else if (pos.non_pawn_material(Color.BLACK) == Value(0) && pos.pawn_count(Color.BLACK) == 0 && pos.non_pawn_material(Color.WHITE) >= GlobalMembers.RookValueEndgame.getValue())
	{
	  mi.evaluationFunction = &EvaluateKXK;
	  return mi;
	}
	else if (pos.non_pawn_material(Color.WHITE) == Value(0) && pos.pawn_count(Color.WHITE) == 0 && pos.non_pawn_material(Color.BLACK) >= GlobalMembers.RookValueEndgame.getValue())
	{
	  mi.evaluationFunction = &EvaluateKKX;
	  return mi;
	}
	else if (pos.pawns() == GlobalMembers.EmptyBoardBB && pos.rooks() == GlobalMembers.EmptyBoardBB && pos.queens() == GlobalMembers.EmptyBoardBB)
	{
	  // Minor piece endgame with at least one minor piece per side,
	  // and no pawns.
	  assert pos.knights(Color.WHITE) | pos.bishops(Color.WHITE);
	  assert pos.knights(Color.BLACK) | pos.bishops(Color.BLACK);

	  if (pos.bishop_count(Color.WHITE) + pos.knight_count(Color.WHITE) <= 2 && pos.bishop_count(Color.BLACK) + pos.knight_count(Color.BLACK) <= 2)
	  {
		mi.evaluationFunction = &EvaluateKmmKm;
		return mi;
	  }
	}

	// OK, we didn't find any special evaluation function for the current
	// material configuration.  Is there a suitable scaling function?
	//
	// The code below is rather messy, and it could easily get worse later,
	// if we decide to add more special cases.  We face problems when there
	// are several conflicting applicable scaling functions and we need to
	// decide which one to use.

	if (key == GlobalMembers.KRPKRMaterialKey)
	{
	  mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKRPKR;
	  return mi;
	}
	if (key == GlobalMembers.KRKRPMaterialKey)
	{
	  mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKRKRP;
	  return mi;
	}
	if (key == GlobalMembers.KRPPKRPMaterialKey)
	{
	  mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKRPPKRP;
	  return mi;
	}
	else if (key == GlobalMembers.KRPKRPPMaterialKey)
	{
	  mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKRPKRPP;
	  return mi;
	}
	if (key == GlobalMembers.KBPKBMaterialKey)
	{
	  mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKBPKB;
	  return mi;
	}
	if (key == GlobalMembers.KBKBPMaterialKey)
	{
	  mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKBKBP;
	  return mi;
	}
	if (key == GlobalMembers.KBPKNMaterialKey)
	{
	  mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKBPKN;
	  return mi;
	}
	if (key == GlobalMembers.KNKBPMaterialKey)
	{
	  mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKNKBP;
	  return mi;
	}
	if (key == GlobalMembers.KNPKMaterialKey)
	{
	  mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKNPK;
	  return mi;
	}
	if (key == GlobalMembers.KKNPMaterialKey)
	{
	  mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKKNP;
	  return mi;
	}

	if (pos.non_pawn_material(Color.WHITE) == GlobalMembers.BishopValueMidgame && pos.bishop_count(Color.WHITE) == 1 && pos.pawn_count(Color.WHITE) >= 1)
	{
	  mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKBPK;
	}
	if (pos.non_pawn_material(Color.BLACK) == GlobalMembers.BishopValueMidgame && pos.bishop_count(Color.BLACK) == 1 && pos.pawn_count(Color.BLACK) >= 1)
	{
	  mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKKBP;
	}

	if (pos.pawn_count(Color.WHITE) == 0 && pos.non_pawn_material(Color.WHITE) == GlobalMembers.QueenValueMidgame && pos.queen_count(Color.WHITE) == 1 && pos.rook_count(Color.BLACK) == 1 && pos.pawn_count(Color.BLACK) >= 1)
	{
	  mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKQKRP;
	}
	else if (pos.pawn_count(Color.BLACK) == 0 && pos.non_pawn_material(Color.BLACK) == GlobalMembers.QueenValueMidgame && pos.queen_count(Color.BLACK) == 1 && pos.rook_count(Color.WHITE) == 1 && pos.pawn_count(Color.WHITE) >= 1)
	{
	  mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKRPKQ;
	}

	if (pos.non_pawn_material(Color.WHITE) + pos.non_pawn_material(Color.BLACK) == Value(0).getValue() != 0)
	{
	  if (pos.pawn_count(Color.BLACK) == 0)
	  {
		assert pos.pawn_count(Color.WHITE) >= 2;
		mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKPsK;
	  }
	  else if (pos.pawn_count(Color.WHITE) == 0)
	  {
		assert pos.pawn_count(Color.BLACK) >= 2;
		mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKKPs;
	  }
	  else if (pos.pawn_count(Color.WHITE) == 1 && pos.pawn_count(Color.BLACK) == 1)
	  {
		mi.scalingFunction[Color.WHITE.getValue()] = &ScaleKPKPw;
		mi.scalingFunction[Color.BLACK.getValue()] = &ScaleKPKPb;
	  }
	}

	// Compute the space weight
	if (pos.non_pawn_material(Color.WHITE) + pos.non_pawn_material(Color.BLACK) >= 2 * GlobalMembers.QueenValueMidgame + 4 * GlobalMembers.RookValueMidgame + 2 * GlobalMembers.KnightValueMidgame.getValue() != 0)
	{
	  int minorPieceCount = pos.knight_count(Color.WHITE) + pos.knight_count(Color.BLACK) + pos.bishop_count(Color.WHITE) + pos.bishop_count(Color.BLACK);
	  mi.spaceWeight = minorPieceCount * minorPieceCount;
	}

	// Evaluate the material balance.

	Color c;
	int sign;
	Value egValue = Value.forValue(0);
	Value mgValue = Value.forValue(0);

	for (c = Color.WHITE, sign = 1; c.getValue() <= Color.BLACK.getValue(); c++, sign = -sign)
	{

	  // No pawns makes it difficult to win, even with a material advantage:
	  if (pos.pawn_count(c) == 0 && pos.non_pawn_material(c) - pos.non_pawn_material(GlobalMembers.opposite_color(c)) <= GlobalMembers.BishopValueMidgame.getValue().getValue() != 0)
	  {
		if (pos.non_pawn_material(c) == pos.non_pawn_material(GlobalMembers.opposite_color(c)))
		{
		  mi.factor[c.getValue()] = 0;
		}
		else if (pos.non_pawn_material(c) < GlobalMembers.RookValueMidgame.getValue())
		{
		  mi.factor[c.getValue()] = 0;
		}
		else
		{
		  switch (pos.bishop_count(c))
		  {
		  case 2:
			mi.factor[c.getValue()] = 32;
			break;
		  case 1:
			mi.factor[c.getValue()] = 12;
			break;
		  case 0:
			mi.factor[c.getValue()] = 6;
			break;
		  }
		}
	  }

	  // Bishop pair:
	  if (pos.bishop_count(c) >= 2)
	  {
		mgValue += sign * GlobalMembers.BishopPairMidgameBonus.getValue();
		egValue += sign * GlobalMembers.BishopPairEndgameBonus.getValue();
	  }

	  // Knights are stronger when there are many pawns on the board.  The
	  // formula is taken from Larry Kaufman's paper "The Evaluation of Material
	  // Imbalances in Chess":
	  // http://mywebpages.comcast.net/danheisman/Articles/evaluation_of_material_imbalance.htm
	  mgValue += sign * Value(pos.knight_count(c) * (pos.pawn_count(c) - 5) * 16);
	  egValue += sign * Value(pos.knight_count(c) * (pos.pawn_count(c) - 5) * 16);

	  // Redundancy of major pieces, again based on Kaufman's paper:
	  if (pos.rook_count(c) >= 1)
	  {
		Value v = (pos.rook_count(c) - 1) * 32 + pos.queen_count(c) * 16;
		mgValue -= sign * v.getValue();
		egValue -= sign * v.getValue();
	  }

	}

	mi.mgValue = int16_t(mgValue);
	mi.egValue = int16_t(egValue);

	return mi;
  }

  private int size;
  private MaterialInfo entries;
}