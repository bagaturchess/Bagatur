final class DefineConstants
{
	public static final int N = 624;
	public static final int M = 397;
	public static final int MATRIX_A = 0x9908b0df; // constant vector a
	public static final int UPPER_MASK = 0x80000000; // most significant w-r bits
	public static final int LOWER_MASK = 0x7fffffff; // least significant r bits
}