import java.io.*;

/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


////
//// Includes
////


/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/



////
//// Includes
////



////
//// Types
////

/// The TTEntry class is the class of transposition table entries.

public class TTEntry
{


  /// Constructors

  public TTEntry()
  {
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: TTEntry(unsigned long long k, Value v, ValueType t, Depth d, Move m, int generation);
  public TTEntry(long k, Value v, ValueType t, Depth d, Move m, int generation)
  {
	key_ = k;
	data = (m & 0x7FFFF) | (t.getValue() << 20) | (generation << 23);
	value_ = v.getValue();
	depth_ = int16_t(d);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long key() const;

  /// Functions for extracting data from TTEntry objects.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong key() const
  public final long key()
  {
	return key_;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Depth depth() const
  public final Depth depth()
  {
	return Depth(depth_);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Move move() const
  public final Move move()
  {
	return Move(data & 0x7FFFF);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: Value value() const
  public final Value value()
  {
	return Value(value_);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ValueType type() const
  public final ValueType type()
  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	return ValueType((data >>> 20) & 3);
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int generation() const
  public final int generation()
  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	return (data >>> 23);
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long key_;
  private long key_;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long data;
  private int data;
  private short value_;
  private short depth_;
}