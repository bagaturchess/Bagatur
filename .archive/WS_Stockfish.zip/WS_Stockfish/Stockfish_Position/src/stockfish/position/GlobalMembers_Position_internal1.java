package stockfish.position;

public class GlobalMembers_Position_internal1
{
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
//  extern Score psq[PIECE_NB][SQUARE_NB];
}