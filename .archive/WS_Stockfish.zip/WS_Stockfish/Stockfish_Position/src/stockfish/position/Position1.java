package stockfish.position;
public class Position
{
//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
	public Position set(string fenStr, boolean isChess960, StateInfo si, Thread th)
	{
	/*
	   A FEN string defines a particular position using only the ASCII character set.
	
	   A FEN string contains six fields separated by a space. The fields are:
	
	   1) Piece placement (from white's perspective). Each rank is described, starting
	      with rank 8 and ending with rank 1. Within each rank, the contents of each
	      square are described from file A through file H. Following the Standard
	      Algebraic Notation (SAN), each piece is identified by a single letter taken
	      from the standard English names. White pieces are designated using upper-case
	      letters ("PNBRQK") whilst Black uses lowercase ("pnbrqk"). Blank squares are
	      noted using digits 1 through 8 (the number of blank squares), and "/"
	      separates ranks.
	
	   2) Active color. "w" means white moves next, "b" means black.
	
	   3) Castling availability. If neither side can castle, this is "-". Otherwise,
	      this has one or more letters: "K" (White can castle kingside), "Q" (White
	      can castle queenside), "k" (Black can castle kingside), and/or "q" (Black
	      can castle queenside).
	
	   4) En passant target square (in algebraic notation). If there's no en passant
	      target square, this is "-". If a pawn has just made a 2-square move, this
	      is the position "behind" the pawn. This is recorded only if there is a pawn
	      in position to make an en passant capture, and if there really is a pawn
	      that might have advanced two squares.
	
	   5) Halfmove clock. This is the number of halfmoves since the last pawn advance
	      or capture. This is used to determine if a draw can be claimed under the
	      fifty-move rule.
	
	   6) Fullmove number. The number of the full move. It starts at 1, and is
	      incremented after Black's move.
	*/
    
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char col, row, token;
	  byte col;
	  byte row;
	  byte token;
	  size_t idx = new size_t();
	  Square sq = Square.SQ_A8;
	  std::istringstream ss = new std::istringstream(fenStr);
    
	//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
	  memset(this, 0, sizeof(Position));
	//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
	  memset(si, 0, sizeof(StateInfo));
	//C++ TO JAVA CONVERTER WARNING: This 'sizeof' ratio was replaced with a direct reference to the array length:
	//ORIGINAL LINE: std::fill_n(&pieceList[0][0], sizeof(pieceList) / sizeof(Square), SQ_NONE);
	  std::fill_n(pieceList[0][0], pieceList.length, Square.SQ_NONE);
	  st = si;
    
	//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  ss >> std::noskipws;
    
	  // 1. Piece placement
	//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  while ((ss >> token) != 0 && !isspace(token))
	  {
		  if (isdigit(token))
		  {
			  sq += (token - '0') * Direction.EAST; // Advance the given number of files
		  }
    
		  else if (token == (byte)'/')
		  {
			  sq += 2 * Direction.SOUTH;
		  }
    
		  else if ((idx = PieceToChar.find(token)) != -1)
		  {
			  put_piece(Piece(idx), sq);
			  ++sq;
		  }
	  }
    
	  // 2. Active color
	//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  ss >> token;
	  sideToMove = (token == (byte)'w' ? Color.WHITE : Color.BLACK);
	//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  ss >> token;
    
	  // 3. Castling availability. Compatible with 3 standards: Normal FEN standard,
	  // Shredder-FEN that uses the letters of the columns on which the rooks began
	  // the game instead of KQkq and also X-FEN standard that, in case of Chess960,
	  // if an inner rook is associated with the castling right, the castling tag is
	  // replaced by the file letter of the involved rook, as for the Shredder-FEN.
	//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  while ((ss >> token) != 0 && !isspace(token))
	  {
		  Square rsq;
		  Color c = islower(token) ? Color.BLACK : Color.WHITE;
		  Piece rook = make_piece(c, PieceType.ROOK);
    
		  token = (char)toupper(token);
    
		  if (token == (byte)'K')
		  {
			  for (rsq = relative_square(c, Square.SQ_H1); piece_on(rsq) != rook; --rsq)
			  {
			  }
		  }
    
		  else if (token == (byte)'Q')
		  {
			  for (rsq = relative_square(c, Square.SQ_A1); piece_on(rsq) != rook; ++rsq)
			  {
			  }
		  }
    
		  else if (token >= (byte)'A' && token <= (byte)'H')
		  {
			  rsq = make_square(File(token - 'A'), relative_rank(c, Rank.RANK_1));
		  }
    
		  else
		  {
			  continue;
		  }
    
		  set_castling_right(c, rsq);
	  }
    
	  // 4. En passant square. Ignore if no pawn capture is possible
	//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  if (((ss >> col) && (col >= (byte)'a' && col <= (byte)'h')) && ((ss >> row) && (row == (byte)'3' || row == (byte)'6')))
	  {
		  st.epSquare = make_square(File(col - 'a'), Rank(row - '1'));
    
		  if ((attackers_to(st.epSquare) & pieces(sideToMove, PieceType.PAWN)) == 0 || (pieces(~sideToMove, PieceType.PAWN) & (st.epSquare + pawn_push(~sideToMove))) == 0)
		  {
			  st.epSquare = Square.SQ_NONE;
		  }
	  }
	  else
	  {
		  st.epSquare = Square.SQ_NONE;
	  }
    
	  // 5-6. Halfmove clock and fullmove number
	//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  ss >> std::skipws >> st.rule50 >> gamePly;
    
	  // Convert from fullmove starting from 1 to gamePly starting from 0,
	  // handle also common incorrect FEN with fullmove = 0.
	  gamePly = Math.max(2 * (gamePly - 1), 0) + (sideToMove == Color.BLACK);
    
	  chess960 = isChess960;
	  thisThread = th;
	  set_state(st);
    
	  assert pos_is_ok();
    
	  return this;
	}

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
	public Position set(string code, Color c, StateInfo si)
	{
    
	  assert code.length() > 0 && code.length() < 8;
	  assert code.charAt(0) == 'K';
    
	  string[] sides = {code.substring(code.indexOf('K', 1)), code.substring(0, code.indexOf('K', 1))};
    
	  sides[c.getValue()] = sides[c.getValue()].toLowerCase();
    
	  string fenStr = "8/" + sides[0] + (char)(8 - sides[0].length() + '0') + "/8/8/8/8/"
						   + sides[1] + (char)(8 - sides[1].length() + '0') + "/8 w - - 0 10";
    
	  return set(fenStr, false, si, null);
	}
}