package stockfish.position;

import stockfish.bitboard.Arrays;
import stockfish.types.CastlingRight;
import stockfish.types.File;
import stockfish.types.Piece;
import stockfish.types.Square;

public class GlobalMembers_Position_Internal2
{
  public static long[][] psq = new long[Piece.PIECE_NB.getValue()][Square.SQUARE_NB.getValue()];
  public static long[] enpassant = Arrays.initializeWithDefaultuint64_tInstances(File.FILE_NB.getValue());
  public static long[] castling = Arrays.initializeWithDefaultuint64_tInstances(CastlingRight.CASTLING_RIGHT_NB.getValue());
  public static long side = 0l;
  public static long noPawns = 0l;
}