package stockfish.position;

import stockfish.types.Piece;
import stockfish.types.PieceType;

public class GlobalMembers_Position
{


/// operator<<(Position) returns an ASCII representation of the position


	private std::ostream leftShift(std::ostream os, Position pos)
	{

	  os << "\n +---+---+---+---+---+---+---+---+\n";

	  for (Rank r = Rank.RANK_8; r.getValue() >= Rank.RANK_1.getValue(); --r)
	  {
		  for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); ++f)
		  {
			  os << " | " << PieceToChar[pos.piece_on(make_square(f, r)).getValue()];
		  }

		  os << " |\n +---+---+---+---+---+---+---+---+\n";
	  }

	  os << "\nFen: " << pos.fen() << "\nKey: " << std::hex << std::uppercase << std::setfill('0') << std::setw(16) << pos.key() << std::setfill(' ') << std::dec << "\nCheckers: ";

	  for (uint64_t b = pos.checkers(); b;)
	  {
		  os << UCI.square(pop_lsb(b)) << " ";
	  }

	  if ((int)Tablebases.MaxCardinality >= popcount(pos.pieces()) && pos.can_castle(CastlingRight.ANY_CASTLING) == 0)
	  {
		  StateInfo st = new StateInfo();
		  Position p = new Position();
		  p.set(pos.fen(), pos.is_chess960(), st, pos.this_thread());
		  Tablebases.ProbeState s1;
		  Tablebases.ProbeState s2;
		  Tablebases.WDLScore wdl = Tablebases.probe_wdl(p, s1);
		  int dtz = Tablebases.probe_dtz(p, s2);
		  os << "\nTablebases WDL: " << std::setw(4) << wdl.getValue() << " (" << s1.getValue() << ")" << "\nTablebases DTZ: " << std::setw(4) << dtz << " (" << s2.getValue() << ")";
	  }

	  return os;
	}

	public static final Piece[] Pieces = {Piece.W_PAWN, Piece.W_KNIGHT, Piece.W_BISHOP, Piece.W_ROOK, Piece.W_QUEEN, Piece.W_KING, Piece.B_PAWN, Piece.B_KNIGHT, Piece.B_BISHOP, Piece.B_ROOK, Piece.B_QUEEN, Piece.B_KING};

	// min_attacker() is a helper function used by see_ge() to locate the least
	// valuable attacker for the side to move, remove the attacker we just found
	// from the bitboards and scan for new X-ray attacks behind it.

//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<int Pt>
	public static <int Pt> PieceType min_attacker(uint64_t[] byTypeBB, Square to, uint64_t stmAttackers, uint64_t occupied, uint64_t attackers)
	{

	  uint64_t b = stmAttackers & byTypeBB[Pt];
	  if (b == null)
	  {
		  return min_attacker < Pt + 1>(byTypeBB, to, stmAttackers, occupied, attackers);
	  }

	  occupied ^= lsb(new uint64_t(b)); // Remove the attacker from occupied

	  // Add any X-ray attack behind the just removed piece. For instance with
	  // rooks in a8 and a7 attacking a1, after removing a7 we add rook in a8.
	  // Note that new added attackers can be of any color.
	  if (Pt == PieceType.PAWN || Pt == PieceType.BISHOP || Pt == PieceType.QUEEN)
	  {
		  attackers |= GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(to, occupied) & (byTypeBB[PieceType.BISHOP.getValue()] | byTypeBB[PieceType.QUEEN.getValue()]);
	  }

	  if (Pt == PieceType.ROOK || Pt == PieceType.QUEEN)
	  {
		  attackers |= GlobalMembers.<PieceType.ROOK.getValue()>attacks_bb(to, occupied) & (byTypeBB[PieceType.ROOK.getValue()] | byTypeBB[PieceType.QUEEN.getValue()]);
	  }

	  // X-ray may add already processed pieces because byTypeBB[] is constant: in
	  // the rook example, now attackers contains _again_ rook in a7, so remove it.
	  attackers &= occupied;
	  return PieceType.forValue(Pt);
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: PieceType min_attacker<KING>(const uint64_t*, Square, uint64_t, uint64_t&, uint64_t&)
	public static PieceType min_attacker(uint64_t UnnamedParameter, Square UnnamedParameter2, uint64_t UnnamedParameter3, uint64_t UnnamedParameter4, uint64_t UnnamedParameter5)
	{
	  return PieceType.KING; // No need to update bitboards: it is the last cycle
	}



	// Marcel van Kervinck's cuckoo algorithm for fast detection of "upcoming repetition"
	// situations. Description of the algorithm in the following paper:
	// https://marcelk.net/2013-04-06/paper/upcoming-rep-v2.pdf

	// First and second hash functions for indexing the cuckoo tables
	public static int H1(uint64_t h)
	{
		return h & 0x1fff;
	}
	public static int H2(uint64_t h)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		return (h >> 16) & 0x1fff;
	}

	// Cuckoo tables with Zobrist hashes of valid reversible moves, and the moves themselves
	public static uint64_t[] cuckoo = tangible.Arrays.initializeWithDefaultuint64_tInstances(8192);
	public static Move[] cuckooMove = new Move[8192];
}