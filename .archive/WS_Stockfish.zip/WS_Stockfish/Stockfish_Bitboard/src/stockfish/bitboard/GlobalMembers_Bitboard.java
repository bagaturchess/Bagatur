package stockfish.bitboard;


import stockfish.types.Color;
import stockfish.types.Direction;
import stockfish.types.File;
import stockfish.types.PieceType;
import stockfish.types.Rank;
import stockfish.types.Square;


public class GlobalMembers_Bitboard
{
	public static final long AllSquares = ~0;
	public static final long DarkSquares = 0xAA55AA55AA55AA55l;

	public static final long FileABB = 0x0101010101010101l;
	public static final long FileBBB = FileABB << 1;
	public static final long FileCBB = FileABB << 2;
	public static final long FileDBB = FileABB << 3;
	public static final long FileEBB = FileABB << 4;
	public static final long FileFBB = FileABB << 5;
	public static final long FileGBB = FileABB << 6;
	public static final long FileHBB = FileABB << 7;

	public static final long Rank1BB = 0xFF;
	public static final long Rank2BB = Rank1BB << (8 * 1);
	public static final long Rank3BB = Rank1BB << (8 * 2);
	public static final long Rank4BB = Rank1BB << (8 * 3);
	public static final long Rank5BB = Rank1BB << (8 * 4);
	public static final long Rank6BB = Rank1BB << (8 * 5);
	public static final long Rank7BB = Rank1BB << (8 * 6);
	public static final long Rank8BB = Rank1BB << (8 * 7);

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern int SquareDistance[SQUARE_NB][SQUARE_NB];

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long SquareBB[SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long FileBB[FILE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long RankBB[RANK_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long AdjacentFilesBB[FILE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long ForwardRanksBB[COLOR_NB][RANK_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long BetweenBB[SQUARE_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long LineBB[SQUARE_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long DistanceRingBB[SQUARE_NB][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long ForwardFileBB[COLOR_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long PassedPawnMask[COLOR_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long PawnAttackSpan[COLOR_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long PseudoAttacks[PIECE_TYPE_NB][SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern long PawnAttacks[COLOR_NB][SQUARE_NB];

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Magic RookMagics[SQUARE_NB];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Magic BishopMagics[SQUARE_NB];


	/// Overloads of bitwise operators between a Bitboard and a Square for testing
	/// whether a given bit is set in a bitboard, and for setting and clearing bits.

	private long bitwiseAnd(long b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b & SquareBB[s.getValue()];
	}

	private long bitwiseOr(long b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b | SquareBB[s.getValue()];
	}

	private long exclusiveOr(long b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b ^ SquareBB[s.getValue()];
	}

	private long bitwiseOrAssignment(long b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b |= SquareBB[s.getValue()];
	}

	private long exclusiveOrAssignment(long b, Square s)
	{
	  assert s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	  return b ^= SquareBB[s.getValue()];
	}

	public static boolean more_than_one(long b)
	{
	  return (b & (b - 1)) != 0;
	}

	/// rank_bb() and file_bb() return a bitboard representing all the squares on
	/// the given file or rank.

	public static long rank_bb(Rank r)
	{
	  return RankBB[r.getValue()];
	}

	public static long rank_bb(Square s)
	{
	  return RankBB[rank_of(s).getValue()];
	}

	public static long file_bb(File f)
	{
	  return FileBB[f.getValue()];
	}

	public static long file_bb(Square s)
	{
	  return FileBB[file_of(s).getValue()];
	}


	/// shift() moves a bitboard one step along direction D (mainly for pawns)

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Direction D>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename D>
	public static <D> long shift(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return D == Direction.NORTH ? b << 8 : D == Direction.SOUTH ? b >> 8 : D == Direction.EAST ? (b & ~FileHBB) << 1 : D == Direction.WEST ? (b & ~FileABB) >> 1 : D == Direction.NORTH_EAST ? (b & ~FileHBB) << 9 : D == Direction.NORTH_WEST ? (b & ~FileABB) << 7 : D == Direction.SOUTH_EAST ? (b & ~FileHBB) >> 7 : D == Direction.SOUTH_WEST ? (b & ~FileABB) >> 9 : 0;
	}


	/// pawn_attacks_bb() returns the pawn attacks for the given color from the
	/// squares in the given bitboard.

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color C>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename C>
	public static <C> long pawn_attacks_bb(long b)
	{
	  return C == Color.WHITE ? GlobalMembers.<Direction.NORTH_WEST.getValue()>shift(b) | GlobalMembers.<Direction.NORTH_EAST.getValue()>shift(b) : GlobalMembers.<Direction.SOUTH_WEST.getValue()>shift(b) | GlobalMembers.<Direction.SOUTH_EAST.getValue()>shift(b);
	}


	/// adjacent_files_bb() returns a bitboard representing all the squares on the
	/// adjacent files of the given one.

	public static long adjacent_files_bb(File f)
	{
	  return AdjacentFilesBB[f.getValue()];
	}


	/// between_bb() returns a bitboard representing all the squares between the two
	/// given ones. For instance, between_bb(SQ_C4, SQ_F7) returns a bitboard with
	/// the bits for square d5 and e6 set. If s1 and s2 are not on the same rank, file
	/// or diagonal, 0 is returned.

	public static long between_bb(Square s1, Square s2)
	{
	  return BetweenBB[s1.getValue()][s2.getValue()];
	}


	/// forward_ranks_bb() returns a bitboard representing the squares on all the ranks
	/// in front of the given one, from the point of view of the given color. For instance,
	/// forward_ranks_bb(BLACK, SQ_D3) will return the 16 squares on ranks 1 and 2.

	public static long forward_ranks_bb(Color c, Square s)
	{
	  return ForwardRanksBB[c.getValue()][rank_of(s).getValue()];
	}


	/// forward_file_bb() returns a bitboard representing all the squares along the line
	/// in front of the given one, from the point of view of the given color:
	///      ForwardFileBB[c][s] = forward_ranks_bb(c, s) & file_bb(s)

	public static long forward_file_bb(Color c, Square s)
	{
	  return ForwardFileBB[c.getValue()][s.getValue()];
	}


	/// pawn_attack_span() returns a bitboard representing all the squares that can be
	/// attacked by a pawn of the given color when it moves along its file, starting
	/// from the given square:
	///      PawnAttackSpan[c][s] = forward_ranks_bb(c, s) & adjacent_files_bb(file_of(s));

	public static long pawn_attack_span(Color c, Square s)
	{
	  return PawnAttackSpan[c.getValue()][s.getValue()];
	}


	/// passed_pawn_mask() returns a bitboard mask which can be used to test if a
	/// pawn of the given color and on the given square is a passed pawn:
	///      PassedPawnMask[c][s] = pawn_attack_span(c, s) | forward_file_bb(c, s)

	public static long passed_pawn_mask(Color c, Square s)
	{
	  return PassedPawnMask[c.getValue()][s.getValue()];
	}


	/// aligned() returns true if the squares s1, s2 and s3 are aligned either on a
	/// straight or on a diagonal line.

	public static boolean aligned(Square s1, Square s2, Square s3)
	{
	  return (LineBB[s1.getValue()][s2.getValue()] & s3.getValue()) != 0;
	}


	/// distance() functions return the distance between x and y, defined as the
	/// number of steps for a king in x to reach y. Works with squares, ranks, files.

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
	public static <T> int distance(T x, T y)
	{
		return x < y ? y - x : x - y;
	}
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline int distance<Square>(Square x, Square y)
	public static int distance(Square x, Square y)
	{
		return SquareDistance[x.getValue()][y.getValue()];
	}

//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T1, typename T2>
//C++ TO JAVA CONVERTER TODO TASK: The implementation of the following method could not be found:
	//<T1, T2> int distance(T2 x, T2 y);
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline int distance<File>(Square x, Square y)
	public static int distance(Square x, Square y)
	{
		return distance(file_of(x), file_of(y));
	}
//C++ TO JAVA CONVERTER TODO TASK: C++ template specialization was removed by C++ to Java Converter:
//ORIGINAL LINE: inline int distance<Rank>(Square x, Square y)
	public static int distance(Square x, Square y)
	{
		return distance(rank_of(x), rank_of(y));
	}


	/// attacks_bb() returns a bitboard representing all the squares attacked by a
	/// piece of type Pt (bishop or rook) placed on 's'.

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<PieceType Pt>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Pt>
	public static <Pt> long attacks_bb(Square s, long occupied)
	{

	  final Magic m = Pt == PieceType.ROOK ? RookMagics[s.getValue()] : BishopMagics[s.getValue()];
	  return new long(m.attacks[m.index(new long(occupied))]);
	}

	public static long attacks_bb(PieceType pt, Square s, long occupied)
	{

	  assert pt != PieceType.PAWN;

	  switch (pt)
	  {
	  case BISHOP:
		  return GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s, occupied);
	  case ROOK :
		  return GlobalMembers.< PieceType.ROOK.getValue()>attacks_bb(s, occupied);
	  case QUEEN :
		  return GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s, occupied) | GlobalMembers.<PieceType.ROOK.getValue()>attacks_bb(s, occupied);
	  default :
		  return new long(PseudoAttacks[pt.getValue()][s.getValue()]);
	  }
	}
	//{
	//	long bb;
	//	uint16_t u[4];
	//}
	public static int popcount(long b)
	{

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! USE_POPCNT

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//  extern uint8_t PopCnt16[1 << 16];
	   v = {b};
	  return PopCnt16[v.u[0]] + PopCnt16[v.u[1]] + PopCnt16[v.u[2]] + PopCnt16[v.u[3]];

	///#elif _MSC_VER || __INTEL_COMPILER

	  return (int)_mm_popcnt_u64(b);

	///#else // Assumed gcc or compatible compiler

	  return __builtin_popcountll(b);

	///#endif
	}


	/// lsb() and msb() return the least/most significant bit in a non-zero bitboard

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if __GNUC__ // GCC, Clang, ICC

	public static Square lsb(long b)
	{
	  assert b;
	  return Square(__builtin_ctzll(b));
	}

	public static Square msb(long b)
	{
	  assert b;
	  return Square(63 ^ __builtin_clzll(b));
	}

	///#elif _MSC_VER // MSVC

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if _WIN64 // MSVC, WIN64

	public static Square lsb(long b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;
  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
	  _BitScanForward64(tempRef_idx, new long(b));
	  idx = tempRef_idx.argValue;
	  return Square.forValue(idx);
	}

	public static Square msb(long b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;
  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
	  _BitScanReverse64(tempRef_idx, new long(b));
	  idx = tempRef_idx.argValue;
	  return Square.forValue(idx);
	}

	///#else // MSVC, WIN32

	public static Square lsb(long b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;

	  if (b & 0xffffffff != null)
	  {
	  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
		  _BitScanForward(tempRef_idx, int32_t(b));
		  idx = tempRef_idx.argValue;
		  return Square(idx);
	  }
	  else
	  {
	  tangible.RefObject<Integer> tempRef_idx2 = new tangible.RefObject<Integer>(idx);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  _BitScanForward(tempRef_idx2, int32_t(b >> 32));
		  idx = tempRef_idx2.argValue;
		  return Square(idx + 32);
	  }
	}

	public static Square msb(long b)
	{
	  assert b;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long idx;
	  int idx;

//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  if ((b >> 32) != 0)
	  {
	  tangible.RefObject<Integer> tempRef_idx = new tangible.RefObject<Integer>(idx);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  _BitScanReverse(tempRef_idx, int32_t(b >> 32));
		  idx = tempRef_idx.argValue;
		  return Square(idx + 32);
	  }
	  else
	  {
	  tangible.RefObject<Integer> tempRef_idx2 = new tangible.RefObject<Integer>(idx);
		  _BitScanReverse(tempRef_idx2, int32_t(b));
		  idx = tempRef_idx2.argValue;
		  return Square(idx);
	  }
	}

	///#endif

	///#else // Compiler is neither GCC nor MSVC compatible

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#error "Compiler not supported."

	///#endif


	/// pop_lsb() finds and clears the least significant bit in a non-zero bitboard

	public static Square pop_lsb(long b)
	{
	  final Square s = lsb(b);
	  b &= b - 1;
	  return s;
	}


	/// frontmost_sq() and backmost_sq() return the square corresponding to the
	/// most/least advanced bit relative to the given color.

	public static Square frontmost_sq(Color c, long b)
	{
		return c == Color.WHITE ? msb(new long(b)) : lsb(new long(b));
	}
	public static Square backmost_sq(Color c, long b)
	{
		return c == Color.WHITE ? lsb(new long(b)) : msb(new long(b));
	}



	public static long[] PopCnt16 = stockfish.bitboard.Arrays.initializeWithDefaultuint8_tInstances(1 << 16);
	public static int[][] SquareDistance = new int[Square.SQUARE_NB.getValue()][Square.SQUARE_NB.getValue()];

	public static long[] SquareBB = stockfish.bitboard.Arrays.initializeWithDefaultuint64_tInstances(Square.SQUARE_NB.getValue());
	public static long[] FileBB = stockfish.bitboard.Arrays.initializeWithDefaultuint64_tInstances(File.FILE_NB.getValue());
	public static long[] RankBB = stockfish.bitboard.Arrays.initializeWithDefaultuint64_tInstances(Rank.RANK_NB.getValue());
	public static long[] AdjacentFilesBB = stockfish.bitboard.Arrays.initializeWithDefaultuint64_tInstances(File.FILE_NB.getValue());
	public static long[][] ForwardRanksBB = new long[Color.COLOR_NB.getValue()][Rank.RANK_NB.getValue()];
	public static long[][] BetweenBB = new long[Square.SQUARE_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static long[][] LineBB = new long[Square.SQUARE_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static long[][] DistanceRingBB = new long[Square.SQUARE_NB.getValue()][8];
	public static long[][] ForwardFileBB = new long[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static long[][] PassedPawnMask = new long[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static long[][] PawnAttackSpan = new long[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static long[][] PseudoAttacks = new long[PieceType.PIECE_TYPE_NB.getValue()][Square.SQUARE_NB.getValue()];
	public static long[][] PawnAttacks = new long[Color.COLOR_NB.getValue()][Square.SQUARE_NB.getValue()];

	public static Magic[] RookMagics = stockfish.bitboard.Arrays.initializeWithDefaultMagicInstances(Square.SQUARE_NB.getValue());
	public static Magic[] BishopMagics = stockfish.bitboard.Arrays.initializeWithDefaultMagicInstances(Square.SQUARE_NB.getValue());


	  public static long[] RookTable = stockfish.bitboard.Arrays.initializeWithDefaultuint64_tInstances(0x19000); // To store rook attacks
	  public static long[] BishopTable = stockfish.bitboard.Arrays.initializeWithDefaultuint64_tInstances(0x1480); // To store bishop attacks

  // init_magics() computes all rook and bishop attacks at startup. Magic
  // bitboards are used to look up attacks of sliding pieces. As a reference see
  // chessprogramming.wikispaces.com/Magic+Bitboards. In particular, here we
  // use the so called "fancy" approach.


	  public static void init_magics(long[] table, Magic[] magics, Direction[] directions)
	  {

		// Optimal PRNG seeds to pick the correct magics in the shortest time
		int[][] seeds =
		{
			{8977, 44560, 54343, 38998, 5731, 95205, 104912, 17020},
			{728, 10316, 55013, 32803, 12281, 15100, 16645, 255}
		};

		long[] occupancy = stockfish.bitboard.Arrays.initializeWithDefaultlongInstances(4096);
		long[] reference = stockfish.bitboard.Arrays.initializeWithDefaultlongInstances(4096);
		long edges = 0l;
		long b = 0l;
		int[] epoch = new int[4096];
		int cnt = 0;
		int size = 0;

		for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
		{
			// Board edges are not considered in the relevant occupancies
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: edges = ((Rank1BB | Rank8BB) & ~rank_bb(s)) | ((FileABB | FileHBB) & ~file_bb(s));
			edges.copyFrom(((Rank1BB | Rank8BB) & ~rank_bb(s)) | ((FileABB | FileHBB) & ~file_bb(s)));

			// Given a square 's', the mask is the bitboard of sliding attacks from
			// 's' computed on an empty board. The index must be big enough to contain
			// all the attacks for each possible subset of the mask and so is 2 power
			// the number of 1s of the mask. Hence we deduce the size of the shift to
			// apply to the 64 or 32 bits word to get the index.
			Magic m = magics[s.getValue()];
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: m.mask = sliding_attack(directions, s, 0) & ~edges;
			m.mask.copyFrom(sliding_attack(directions, s, 0) & ~edges);
			m.shift = (Is64Bit ? 64 : 32) - popcount(m.mask);

			// Set the offset for the attacks table of the square. We have individual
			// table sizes for each square with "Fancy Magic Bitboards".
			m.attacks = s == Square.SQ_A1 ? table : magics[s.getValue() - 1].attacks + size;

			// Use Carry-Rippler trick to enumerate all subsets of masks[s] and
			// store the corresponding sliding attack bitboard in reference[].
			b = size = 0;
			do
			{
				occupancy[size] = b;
				reference[size] = sliding_attack(directions, s, b);

				if (HasPext)
				{
					m.attacks[(b, m) 0(b, m.mask)] = reference[size];
				}

				size++;
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = (b - m.mask) & m.mask;
				b.copyFrom((b - m.mask) & m.mask);
			} while (b != null);

			if (HasPext)
			{
				continue;
			}

			PRNG rng = new PRNG(seeds[Is64Bit][rank_of(s).getValue()]);

			// Find a magic for square 's' picking up an (almost) random number
			// until we find the one that passes the verification test.
			for (int i = 0; i < size;)
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				for (m.magic = 0; popcount((m.magic * m.mask) >> 56) < 6;)
				{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: m.magic = rng.sparse_rand<long>();
					m.magic.copyFrom(rng.<long>sparse_rand());
				}

				// A good magic must map every possible occupancy to an index that
				// looks up the correct sliding attack in the attacks[s] database.
				// Note that we build up the database for square 's' as a side
				// effect of verifying the magic. Keep track of the attempt count
				// and save it in epoch[], little speed-up trick to avoid resetting
				// m.attacks[] after every failed attempt.
				for (++cnt, i = 0; i < size; ++i)
				{
					int idx = m.index(occupancy[i]);

					if (epoch[idx] < cnt)
					{
						epoch[idx] = cnt;
						m.attacks[idx] = reference[i];
					}
					else if (m.attacks[idx] != reference[i])
					{
						break;
					}
				}
			}
		}
	  }

	  // popcount16() counts the non-zero bits using SWAR-Popcount algorithm

	  public static int popcount16(int u)
	  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		u -= (u >>> 1) & 0x5555;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		u = (int)(((u >>> 2) & 0x3333) + (u & 0x3333));
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		u = ((u >>> 4) + u) & 0x0F0F;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		return (u * 0x0101) >>> 8;
	  }



	  public static long sliding_attack(Direction[] directions, Square sq, long occupied)
	  {

		long attack = 0;

		for (int i = 0; i < 4; ++i)
		{
			for (Square s = sq + directions[i].getValue(); is_ok(s) && distance(s, s - directions[i]) == 1; s += directions[i])
			{
				attack |= s;

				if (occupied & s != null)
				{
					break;
				}
			}
		}

		return attack;
	  }

}