package stockfish.bitboard;


//----------------------------------------------------------------------------------------
//	Copyright © 2006 - 2019 Tangible Software Solutions, Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to initialize and delete array elements.
//----------------------------------------------------------------------------------------
public final class Arrays
{
	public static long[] initializeWithDefaultuint8_tInstances(int length)
	{
		long[] array = new long[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = 0l;
		}
		return array;
	}

	public static long[] initializeWithDefaultuint64_tInstances(int length)
	{
		long[] array = new long[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = 0l;
		}
		return array;
	}

	public static Magic[] initializeWithDefaultMagicInstances(int length)
	{
		Magic[] array = new Magic[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new Magic();
		}
		return array;
	}
}