package stockfish.bitboard.bb;

import stockfish.bitboard.GlobalMembers;
import stockfish.types.Color;
import stockfish.types.Direction;
import stockfish.types.File;
import stockfish.types.Rank;
import stockfish.types.Square;


public class GlobalMembers_Bitboard_internal
{


	/// Bitboards::init() initializes various bitboard tables. It is called at
	/// startup and relies on global objects to be already zero-initialized.




	public static void init()
	{

	  for (int i = 0; i < (1 << 16); ++i)
	  {
		  GlobalMembers.PopCnt16[i] = (uint8_t) GlobalMembers.popcount16(i);
	  }

	  for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
	  {
		  GlobalMembers.SquareBB[s.getValue()] = (1 << s.getValue());
	  }

	  for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); ++f)
	  {
		  GlobalMembers.FileBB[f.getValue()] = f.getValue() > File.FILE_A.getValue() ? GlobalMembers.FileBB[f.getValue() - 1] << 1 : GlobalMembers.FileABB;
	  }

	  for (Rank r = Rank.RANK_1; r.getValue() <= Rank.RANK_8.getValue(); ++r)
	  {
		  GlobalMembers.RankBB[r.getValue()] = r.getValue() > Rank.RANK_1.getValue() ? GlobalMembers.RankBB[r.getValue() - 1] << 8 : GlobalMembers.Rank1BB;
	  }

	  for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); ++f)
	  {
		  GlobalMembers.AdjacentFilesBB[f.getValue()] = (f.getValue() > File.FILE_A.getValue() ? GlobalMembers.FileBB[f.getValue() - 1] : 0) | (f.getValue() < File.FILE_H.getValue() ? GlobalMembers.FileBB[f.getValue() + 1] : 0);
	  }

	  for (Rank r = Rank.RANK_1; r.getValue() < Rank.RANK_8.getValue(); ++r)
	  {
		  GlobalMembers.ForwardRanksBB[Color.WHITE.getValue()][r.getValue()] = ~(GlobalMembers.ForwardRanksBB[Color.BLACK.getValue()][r.getValue() + 1] = GlobalMembers.ForwardRanksBB[Color.BLACK.getValue()][r.getValue()] | GlobalMembers.RankBB[r.getValue()]);
	  }

	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); ++c)
	  {
		  for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
		  {
			  GlobalMembers.ForwardFileBB [c.getValue()][s.getValue()] = GlobalMembers.ForwardRanksBB[c.getValue()][GlobalMembers.rank_of(s).getValue()] & GlobalMembers.FileBB[GlobalMembers.file_of(s).getValue()];
			  GlobalMembers.PawnAttackSpan[c.getValue()][s.getValue()] = GlobalMembers.ForwardRanksBB[c.getValue()][GlobalMembers.rank_of(s).getValue()] & GlobalMembers.AdjacentFilesBB[GlobalMembers.file_of(s).getValue()];
			  GlobalMembers.PassedPawnMask[c.getValue()][s.getValue()] = GlobalMembers.ForwardFileBB [c.getValue()][s.getValue()] | GlobalMembers.PawnAttackSpan[c.getValue()][s.getValue()];
		  }
	  }

	  for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_H8.getValue(); ++s1)
	  {
		  for (Square s2 = Square.SQ_A1; s2.getValue() <= Square.SQ_H8.getValue(); ++s2)
		  {
			  if (s1 != s2)
			  {
				  GlobalMembers.SquareDistance[s1.getValue()][s2.getValue()] = Math.max(GlobalMembers.<File>distance(s1, s2), GlobalMembers.<Rank>distance(s1, s2));
				  GlobalMembers.DistanceRingBB[s1.getValue()][GlobalMembers.SquareDistance[s1.getValue()][s2.getValue()]] |= s2;
			  }
		  }
	  }

	  int[][] steps =
	  {
		  {, 0, 0, 0, 0},
		  {7, 9, 0, 0, 0},
		  {6, 10, 15, 17, 0},
		  {, 0, 0, 0, 0},
		  {, 0, 0, 0, 0},
		  {, 0, 0, 0, 0},
		  {1, 7, 8, 9, 0}
	  };

	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); ++c)
	  {
		  for (PieceType pt : {PieceType.PAWN, PieceType.KNIGHT, PieceType.KING})
		  {
			  for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
			  {
				  for (int i = 0; steps[pt.getValue()][i]; ++i)
				  {
					  Square to = s + Direction(c == Color.WHITE ? steps[pt.getValue()][i] : -steps[pt.getValue()][i]);

					  if (GlobalMembers.is_ok(to) && GlobalMembers.distance(s, to) < 3)
					  {
						  if (pt == PieceType.PAWN)
						  {
							  GlobalMembers.PawnAttacks[c.getValue()][s.getValue()] |= to;
						  }
						  else
						  {
							  GlobalMembers.PseudoAttacks[pt.getValue()][s.getValue()] |= to;
						  }
					  }
				  }
			  }
		  }
	  }

	  Direction[] RookDirections = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
	  Direction[] BishopDirections = {Direction.NORTH_EAST, Direction.SOUTH_EAST, Direction.SOUTH_WEST, Direction.NORTH_WEST};

	  GlobalMembers.init_magics(GlobalMembers.RookTable, GlobalMembers.RookMagics, RookDirections);
	  GlobalMembers.init_magics(GlobalMembers.BishopTable, GlobalMembers.BishopMagics, BishopDirections);

	  for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_H8.getValue(); ++s1)
	  {
		  GlobalMembers.PseudoAttacks[PieceType.QUEEN.getValue()][s1.getValue()] = GlobalMembers.PseudoAttacks[PieceType.BISHOP.getValue()][s1.getValue()] = GlobalMembers.<PieceType.BISHOP.getValue()>attacks_bb(s1, 0);
		  GlobalMembers.PseudoAttacks[PieceType.QUEEN.getValue()][s1.getValue()] |= GlobalMembers.PseudoAttacks[PieceType.ROOK.getValue()][s1.getValue()] = GlobalMembers.< PieceType.ROOK.getValue()>attacks_bb(s1, 0);

		  for (PieceType pt : {PieceType.BISHOP, PieceType.ROOK})
		  {
			  for (Square s2 = Square.SQ_A1; s2.getValue() <= Square.SQ_H8.getValue(); ++s2)
			  {
				  if ((GlobalMembers.PseudoAttacks[pt.getValue()][s1.getValue()] & s2) == null)
				  {
					  continue;
				  }

				  GlobalMembers.LineBB[s1.getValue()][s2.getValue()] = (GlobalMembers.attacks_bb(pt, s1, 0) & GlobalMembers.attacks_bb(pt, s2, 0)) | s1 | s2;
				  GlobalMembers.BetweenBB[s1.getValue()][s2.getValue()] = GlobalMembers.attacks_bb(pt, s1, GlobalMembers.SquareBB[s2.getValue()]) & GlobalMembers.attacks_bb(pt, s2, GlobalMembers.SquareBB[s1.getValue()]);
			  }
		  }
	  }
	}

	/// Bitboards::pretty() returns an ASCII representation of a bitboard suitable
	/// to be printed to standard output. Useful for debugging.


	public static String pretty(uint64_t b)
	{

	  String s = "+---+---+---+---+---+---+---+---+\n";

	  for (Rank r = Rank.RANK_8; r.getValue() >= Rank.RANK_1.getValue(); --r)
	  {
		  for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); ++f)
		  {
			  s += b & GlobalMembers.make_square(f, r) != null ? "| X " : "|   ";
		  }

		  s += "|\n+---+---+---+---+---+---+---+---+\n";
	  }

	  return s;
	}
}