package stockfish.pawns;
public class GlobalMembers_Pawns
{
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define V Value
	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define S(mg, eg) make_score(mg, eg)

	  // Pawn penalties
	  public static final Score Backward = make_score(9, 24);
	  public static final Score Doubled = make_score(11, 56);
	  public static final Score Isolated = make_score(5, 15);

	  // Connected pawn bonus by opposed, phalanx, #support and rank
	  public static Score[][][][] Connected = new Score[2][2][3][Rank.RANK_NB.getValue()];

	  // Strength of pawn shelter for our king by [distance from edge][rank].
	  // RANK_1 = 0 is used for files where we have no pawn, or pawn is behind our king.
//C++ TO JAVA CONVERTER TODO TASK: The following statement was not recognized, possibly due to an unrecognized macro:
	  constexpr Value ShelterStrength[int(FILE_NB) / 2][RANK_NB] =
	  {
		  {Value(-6), Value(81), Value(93), Value(58), Value(39), Value(18), Value(25)},
		  {Value(-43), Value(61), Value(35), Value(-49), Value(-29), Value(-11), Value(-63)},
		  {Value(-10), Value(75), Value(23), Value(-2), Value(32), Value(3), Value(-45)},
		  {Value(-39), Value(-13), Value(-29), Value(-52), Value(-48), Value(-67), Value(-166)}
	  };

	  // Danger of enemy pawns moving toward our king by [distance from edge][rank].
	  // RANK_1 = 0 is used for files where the enemy has no pawn, or their pawn
	  // is behind our king.
//C++ TO JAVA CONVERTER TODO TASK: The following statement was not recognized, possibly due to an unrecognized macro:
	  constexpr Value UnblockedStorm[int(FILE_NB) / 2][RANK_NB] =
	  {
		  {Value(89), Value(107), Value(123), Value(93), Value(57), Value(45), Value(51)},
		  {Value(44), Value(-18), Value(123), Value(46), Value(39), Value(-7), Value(23)},
		  {Value(4), Value(52), Value(162), Value(37), Value(7), Value(-14), Value(-2)},
		  {Value(-10), Value(-14), Value(90), Value(15), Value(2), Value(-7), Value(-16)}
	  };

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	  ///#undef S
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	  ///#undef V

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color Us>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on the parameter 'e', so pointers on this parameter are left unchanged:
	  public static <Us> Score evaluate(Position pos, Pawns.Entry * e)
	  {

		final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);
		final Direction Up = (Us == Color.WHITE ? Direction.NORTH : Direction.SOUTH);

		uint64_t b = new uint64_t();
		uint64_t neighbours = new uint64_t();
		uint64_t stoppers = new uint64_t();
		uint64_t doubled = new uint64_t();
		uint64_t supported = new uint64_t();
		uint64_t phalanx = new uint64_t();
		uint64_t lever = new uint64_t();
		uint64_t leverPush = new uint64_t();
		Square s;
		boolean opposed;
		boolean backward;
		Score score = Score.SCORE_ZERO;
//C++ TO JAVA CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged:
		Square * pl = pos.<PieceType.PAWN.getValue()>squares(Us);

		uint64_t ourPawns = pos.pieces(Us, PieceType.PAWN);
		uint64_t theirPawns = pos.pieces(Them, PieceType.PAWN);

		e.passedPawns[Us] = e.pawnAttacksSpan[Us] = e.weakUnopposed[Us] = 0;
		e.semiopenFiles[Us] = 0xFF;
		e.kingSquares[Us] = Square.SQ_NONE;
		e.pawnAttacks[Us] = GlobalMembers.<Us>pawn_attacks_bb(new uint64_t(ourPawns));
		e.pawnsOnSquares[Us][Color.BLACK.getValue()] = popcount(ourPawns & DarkSquares);
		e.pawnsOnSquares[Us][Color.WHITE.getValue()] = pos.<PieceType.PAWN.getValue()>count(Us) - e.pawnsOnSquares[Us][Color.BLACK.getValue()];

		// Loop through all pawns of the current color and score each pawn
		while ((s = *pl++) != Square.SQ_NONE)
		{
			assert pos.piece_on(s) == make_piece(Us, PieceType.PAWN);

			File f = file_of(s);

			e.semiopenFiles[Us] &= ~(1 << f.getValue());
			e.pawnAttacksSpan[Us] |= pawn_attack_span(Us, s);

			// Flag the pawn
			opposed = theirPawns & forward_file_bb(Us, s) != null;
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: stoppers = theirPawns & passed_pawn_mask(Us, s);
			stoppers.copyFrom(theirPawns & passed_pawn_mask(Us, s));
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: lever = theirPawns & PawnAttacks[Us][s];
			lever.copyFrom(theirPawns & PawnAttacks[Us][s.getValue()]);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: leverPush = theirPawns & PawnAttacks[Us][s + Up];
			leverPush.copyFrom(theirPawns & PawnAttacks[Us][s.getValue() + Up]);
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: doubled = ourPawns & (s - Up);
			doubled.copyFrom(ourPawns & (s - Up));
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: neighbours = ourPawns & adjacent_files_bb(f);
			neighbours.copyFrom(ourPawns & adjacent_files_bb(f));
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: phalanx = neighbours & rank_bb(s);
			phalanx.copyFrom(neighbours & rank_bb(s));
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: supported = neighbours & rank_bb(s - Up);
			supported.copyFrom(neighbours & rank_bb(s - Up));

			// A pawn is backward when it is behind all pawns of the same color
			// on the adjacent files and cannot be safely advanced.
			backward = (ourPawns & pawn_attack_span(Them, s + Up)) == null && (stoppers & (leverPush | (s + Up))) != null;

			// Passed pawns will be properly scored in evaluation because we need
			// full attack info to evaluate them. Include also not passed pawns
			// which could become passed after one or two pawn pushes when are
			// not attacked more times than defended.
			if ((stoppers ^ lever ^ leverPush) == null && popcount(new uint64_t(supported)) >= popcount(new uint64_t(lever)) - 1 && popcount(new uint64_t(phalanx)) >= popcount(new uint64_t(leverPush)))
			{
				e.passedPawns[Us] |= s;
			}

			else if (stoppers == SquareBB[s.getValue() + Up] && relative_rank(Us, s) >= Rank.RANK_5.getValue())
			{
//C++ TO JAVA CONVERTER TODO TASK: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'copyFrom' method should be created:
//ORIGINAL LINE: b = shift<Up>(supported) & ~theirPawns;
				b.copyFrom(GlobalMembers.<Up>shift(new uint64_t(supported)) & ~theirPawns);
				while (b != null)
				{
					if (!more_than_one(theirPawns & PawnAttacks[Us][pop_lsb(b).getValue()]))
					{
						e.passedPawns[Us] |= s;
					}
				}
			}

			// Score this pawn
			if (supported | phalanx != null)
			{
				score += Connected[opposed][(boolean)phalanx][popcount(new uint64_t(supported))][relative_rank(Us, s).getValue()];
			}

			else if (!neighbours)
			{
				score -= Isolated, e.weakUnopposed[Us] += !opposed;
			}

			else if (backward)
			{
				score -= Backward, e.weakUnopposed[Us] += !opposed;
			}

			if (doubled != null && supported == null)
			{
				score -= Doubled;
			}
		}

		return score;
	  }
}