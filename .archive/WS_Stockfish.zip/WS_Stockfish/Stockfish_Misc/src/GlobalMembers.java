public class GlobalMembers
{


/// engine_info() returns the full name of the current Stockfish version. This
/// will be either "Stockfish <Tag> DD-MM-YY" (where DD-MM-YY is the date when
/// the program was compiled) or "Stockfish <Version>", depending on whether
/// Version is empty.

public static String engine_info()
{
	return engine_info(false);
}


	/*
	  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
	  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
	  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
	  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad
	
	  Stockfish is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	
	  Stockfish is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: const String engine_info(boolean to_uci = false)
	public static String engine_info(boolean to_uci)
	{

	  String months = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec";
	  String month;
	  String day;
	  String year;
	//C++ TO JAVA CONVERTER TODO TASK: There is no direct equivalent in Java to the following C++ macro:
	  stringstream ss = new stringstream(); // From compiler, format is "Sep 21 2008"
	  stringstream date = new stringstream(__DATE__);

	  ss << "Stockfish " << Version << setfill('0');

	  if (Version.length() == 0)
	  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  date >> month >> day >> year;
		  ss << setw(2) << day << setw(2) << (1 + months.indexOf(month) / 4) << year.substring(2);
	  }

	  ss << (Is64Bit ? " 64" : "") << (HasPext ? " BMI2" : (HasPopCnt ? " POPCNT" : "")) << (to_uci ? "\nid author ": " by ") << "T. Romstad, M. Costalba, J. Kiiski, G. Linscott";

	  return ss.str();
	}

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if NO_PREFETCH
	public static void prefetch(Object addr)
	{
	}
	///#endif

	public static void prefetch2(Object addr)
	{

	  prefetch(addr);
	  prefetch((byte)addr + 64);
	}

/// Trampoline helper to avoid moving Logger to misc.h

	public static void start_logger(String fname)
	{
		Logger.start(fname);
	}

	public static void dbg_hit_on(boolean b)
	{
		++hits[0];
		if (b)
		{
			++hits[1];
		}
	}

	public static void dbg_hit_on(boolean c, boolean b)
	{
		if (c)
		{
			dbg_hit_on(b);
		}
	}

	public static void dbg_mean_of(int v)
	{
		++means[0];
		means[1] += v;
	}

	public static void dbg_print()
	{

	  if (hits[0] != 0)
	  {
		  cerr << "Total " << hits[0] << " Hits " << hits[1] << " hit rate (%) " << 100 * hits[1] / hits[0] << "\n";
	  }

	  if (means[0] != 0)
	  {
		  cerr << "Total " << means[0] << " Mean " << (double)means[1] / means[0] << "\n";
	  }
	}


	//C++ TO JAVA CONVERTER TODO TASK: There is no equivalent in Java to 'static_assert':
	//static_assert(sizeof(std::chrono::milliseconds::rep) == sizeof(int64_t), "TimePoint should be 64 bits");

	public static std::chrono.milliseconds.rep now()
	{
	  return std::chrono.<std::chrono.milliseconds>duration_cast (std::chrono.steady_clock.now().time_since_epoch()).count();
	}

//C++ TO JAVA CONVERTER TODO TASK: C++ template specifiers with non-type parameters cannot be converted to Java:
//ORIGINAL LINE: template<class Entry, int Size>

/// Used to serialize access to std::cout to avoid multiple threads writing at
/// the same time.

	//C++ TO JAVA CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in Java):
	public static Object operator << _m = new Object();

	private std::ostream leftShift(std::ostream os, SyncCout sc)
	{

	//C++ TO JAVA CONVERTER NOTE: This static local variable declaration (not allowed in Java) has been moved just prior to the method:
	//  static Object m;

	  if (sc == SyncCout.IO_LOCK)
	  {
		  operator << _m.lock();
	  }

	  if (sc == SyncCout.IO_UNLOCK)
	  {
		  operator << _m.unlock();
	  }

	  return os;
	}





	/// Version number. If Version is left empty, then compile date in the format
	/// DD-MM-YY and show in engine_info.
	public static final String Version = "10";



	/// Debug functions used mainly to collect run-time statistics
	public static long[] hits = new long[2];
	public static long[] means = new long[2];


	/// prefetch() preloads the given address in L1/L2 cache. This is a non-blocking
	/// function that doesn't stall the CPU waiting for data to be loaded from memory,
	/// which can be quite slow.

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if ! NO_PREFETCH

	public static void prefetch(Object addr)
	{

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if __INTEL_COMPILER
	   // This hack prevents prefetches from being optimized away by
	   // Intel compiler. Both MSVC and gcc seem not be affected by this.
	   __asm__("");
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if __INTEL_COMPILER || _MSC_VER
	  _mm_prefetch((String)addr, _MM_HINT_T0);
	///#else
	  __builtin_prefetch(addr);
	///#endif
	}

	///#endif
}