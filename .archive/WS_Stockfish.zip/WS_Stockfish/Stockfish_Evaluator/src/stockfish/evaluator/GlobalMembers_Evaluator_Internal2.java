package stockfish.evaluator;


import stockfish.types.Color;
import stockfish.types.Score;
import stockfish.types.Value;

public class GlobalMembers_Evaluator_Internal2
{
  public static Score[][] scores = new Score[Term.TERM_NB.getValue()][Color.COLOR_NB.getValue()];

  public static double to_cp(Value v)
  {
	  return (double)v.getValue() / Value.PawnValueEg.getValue();
  }

  public static void add(int idx, Color c, Score s)
  {
	scores[idx][c.getValue()] = s;
  }
  public static void add(int idx, Score w)
  {
	  add(idx, w, Score.SCORE_ZERO);
  }

//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: void add(int idx, Score w, Score b = SCORE_ZERO)
  public static void add(int idx, Score w, Score b)
  {
	scores[idx][Color.WHITE.getValue()] = w;
	scores[idx][Color.BLACK.getValue()] = b;
  }
}