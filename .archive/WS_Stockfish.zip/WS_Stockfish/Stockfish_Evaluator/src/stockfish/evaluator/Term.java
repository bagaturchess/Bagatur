package stockfish.evaluator;


  public enum Term
  { // The first 8 entries are reserved for PieceType
	MATERIAL(8),
	IMBALANCE(9),
	MOBILITY(10),
	THREAT(11),
	PASSED(12),
	SPACE(13),
	INITIATIVE(14),
	TOTAL(15),
	TERM_NB(16);

	  public static final int SIZE = java.lang.Integer.SIZE;

	  private int intValue;
	  private static java.util.HashMap<Integer, Term> mappings;
	  private static java.util.HashMap<Integer, Term> getMappings()
	  {
		  if (mappings == null)
		  {
			  synchronized (Term.class)
			  {
				  if (mappings == null)
				  {
					  mappings = new java.util.HashMap<Integer, Term>();
				  }
			  }
		  }
		  return mappings;
	  }

	  private Term(int value)
	  {
		  intValue = value;
		  getMappings().put(value, this);
	  }

	  public int getValue()
	  {
		  return intValue;
	  }

	  public static Term forValue(int value)
	  {
		  return getMappings().get(value);
	  }
  }