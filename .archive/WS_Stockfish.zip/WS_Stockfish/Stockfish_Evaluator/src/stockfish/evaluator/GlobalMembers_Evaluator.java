package stockfish.evaluator;
import stockfish.bitboard.GlobalMembers_Bitboard;
import stockfish.types.Score;
import stockfish.types.Value;

public class GlobalMembers_Evaluator
{
	  public static final long QueenSide = GlobalMembers_Bitboard.FileABB | GlobalMembers_Bitboard.FileBBB | GlobalMembers_Bitboard.FileCBB | GlobalMembers_Bitboard.FileDBB;
	  public static final long CenterFiles = GlobalMembers_Bitboard.FileCBB | GlobalMembers_Bitboard.FileDBB | GlobalMembers_Bitboard.FileEBB | GlobalMembers_Bitboard.FileFBB;
	  public static final long KingSide = GlobalMembers_Bitboard.FileEBB | GlobalMembers_Bitboard.FileFBB | GlobalMembers_Bitboard.FileGBB | GlobalMembers_Bitboard.FileHBB;
	  public static final long Center = (GlobalMembers_Bitboard.FileDBB | GlobalMembers_Bitboard.FileEBB) & (GlobalMembers_Bitboard.Rank4BB | GlobalMembers_Bitboard.Rank5BB);

	  public static final long[] KingFlank = {QueenSide ^ GlobalMembers_Bitboard.FileDBB, QueenSide, QueenSide, CenterFiles, CenterFiles, KingSide, KingSide, KingSide ^ GlobalMembers_Bitboard.FileEBB};

	  // Threshold for lazy and space evaluation
	  public static final int LazyThreshold = 1500;
	  public static final int SpaceThreshold = 12222;

	  // KingAttackWeights[PieceType] contains king attack weights by piece type
	  public static final int[] KingAttackWeights = {0, 0, 77, 55, 44, 10};

	  // Penalties for enemy's safe checks
	  public static final int QueenSafeCheck = 780;
	  public static final int RookSafeCheck = 880;
	  public static final int BishopSafeCheck = 435;
	  public static final int KnightSafeCheck = 790;

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define S(mg, eg) make_score(mg, eg)

	  // MobilityBonus[PieceType-2][attacked] contains bonuses for middle and end game,
	  // indexed by piece type and number of attacked squares in the mobility area.
	  public static final Score[][] MobilityBonus =
	  {
		  {make_score(-62, -81), make_score(-53, -56), make_score(-12, -30), make_score(-4, -14), make_score(3, 8), make_score(13, 15), make_score(22, 23), make_score(28, 27), make_score(33, 33), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		  {make_score(-48, -59), make_score(-20, -23), make_score(16, -3), make_score(26, 13), make_score(38, 24), make_score(51, 42), make_score(55, 54), make_score(63, 57), make_score(63, 65), make_score(68, 73), make_score(81, 78), make_score(81, 86), make_score(91, 88), make_score(98, 97), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		  {make_score(-58, -76), make_score(-27, -18), make_score(-15, 28), make_score(-10, 55), make_score(-5, 69), make_score(-2, 82), make_score(9, 112), make_score(16, 118), make_score(30, 132), make_score(29, 142), make_score(32, 155), make_score(38, 165), make_score(46, 166), make_score(48, 169), make_score(58, 171), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		  {make_score(-39, -36), make_score(-21, -15), make_score(3, 8), make_score(3, 18), make_score(14, 34), make_score(22, 54), make_score(28, 61), make_score(41, 73), make_score(43, 79), make_score(48, 92), make_score(56, 94), make_score(60, 104), make_score(60, 113), make_score(66, 120), make_score(67, 123), make_score(70, 126), make_score(71, 133), make_score(73, 136), make_score(79, 140), make_score(88, 143), make_score(88, 148), make_score(99, 166), make_score(102, 170), make_score(102, 175), make_score(106, 184), make_score(109, 191), make_score(113, 206), make_score(116, 212), null, null, null, null}
	  };

	  // Outpost[knight/bishop][supported by pawn] contains bonuses for minor
	  // pieces if they occupy or can reach an outpost square, bigger if that
	  // square is supported by a pawn.
	  public static final Score[][] Outpost =
	  {
		  {make_score(22, 6), make_score(36, 12)},
		  {make_score(9, 2), make_score(15, 5)}
	  };

	  // RookOnFile[semiopen/open] contains bonuses for each rook when there is
	  // no (friendly) pawn on the rook file.
	  public static final Score[] RookOnFile = {make_score(18, 7), make_score(44, 20)};

	  // ThreatByMinor/ByRook[attacked PieceType] contains bonuses according to
	  // which piece type attacks which one. Attacks on lesser pieces which are
	  // pawn-defended are not considered.
	  public static final Score[] ThreatByMinor = {make_score(0, 0), make_score(0, 31), make_score(39, 42), make_score(57, 44), make_score(68, 112), make_score(62, 120)};

	  public static final Score[] ThreatByRook = {make_score(0, 0), make_score(0, 24), make_score(38, 71), make_score(38, 61), make_score(0, 38), make_score(51, 38)};

	  // PassedRank[Rank] contains a bonus according to the rank of a passed pawn
	  public static final Score[] PassedRank = {make_score(0, 0), make_score(5, 18), make_score(12, 23), make_score(10, 31), make_score(57, 62), make_score(163, 167), make_score(271, 250)};

	  // PassedFile[File] contains a bonus according to the file of a passed pawn
	  public static final Score[] PassedFile = {make_score(-1, 7), make_score(0, 9), make_score(-9, -8), make_score(-30, -14), make_score(-30, -14), make_score(-9, -8), make_score(0, 9), make_score(-1, 7)};

	  // Assorted bonuses and penalties
	  public static final Score BishopPawns = make_score(3, 8);
	  public static final Score CloseEnemies = make_score(7, 0);
	  public static final Score CorneredBishop = make_score(50, 50);
	  public static final Score Hanging = make_score(62, 34);
	  public static final Score KingProtector = make_score(6, 7);
	  public static final Score KnightOnQueen = make_score(20, 12);
	  public static final Score LongDiagonalBishop = make_score(44, 0);
	  public static final Score MinorBehindPawn = make_score(16, 0);
	  public static final Score Overload = make_score(12, 6);
	  public static final Score PawnlessFlank = make_score(18, 94);
	  public static final Score RestrictedPiece = make_score(7, 6);
	  public static final Score RookOnPawn = make_score(10, 28);
	  public static final Score SliderOnQueen = make_score(49, 21);
	  public static final Score ThreatByKing = make_score(21, 84);
	  public static final Score ThreatByPawnPush = make_score(48, 42);
	  public static final Score ThreatByRank = make_score(14, 3);
	  public static final Score ThreatBySafePawn = make_score(169, 99);
	  public static final Score TrappedRook = make_score(98, 5);
	  public static final Score WeakQueen = make_score(51, 10);
	  public static final Score WeakUnopposedPawn = make_score(14, 20);

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef S

	  // Evaluation class computes and stores attacks tables and other working data
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Tracing T>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
}