package stockfish.evaluator;


import stockfish.position.Position;
import stockfish.types.Value;


public class GlobalMembers_Evaluator_Internal1
{
	public static final int Tempo = 20; // Must be visible to search

	public static Value evaluate(Position pos)
	{
	  return new Evaluation(pos).value();
	}
}