package glaurung.types;
////
//// Types
////

/// Castle rights, encoded as bit fields:

public enum CastleRights
{
  NO_CASTLES(0),
  WHITE_OO(1),
  BLACK_OO(2),
  WHITE_OOO(4),
  BLACK_OOO(8),
  ALL_CASTLES(15);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, CastleRights> mappings;
	private static java.util.HashMap<Integer, CastleRights> getMappings()
	{
		if (mappings == null)
		{
			synchronized (CastleRights.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, CastleRights>();
				}
			}
		}
		return mappings;
	}

	private CastleRights(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static CastleRights forValue(int value)
	{
		return getMappings().get(value);
	}
}