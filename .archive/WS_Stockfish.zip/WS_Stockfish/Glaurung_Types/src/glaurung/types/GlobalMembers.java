package glaurung.types;


public class GlobalMembers
{
	////
	//// Inline functions
	////

	public static int apply_scale_factor(int v, ScaleFactor f)
	{
	  return (v * f.getValue() / ScaleFactor.SCALE_FACTOR_NORMAL.getValue());
	}
	

	public static Color opposite_color(Color c)
	{
	  return c == Color.WHITE ? Color.BLACK : Color.WHITE;
	}

////
//// Functions
////

/// color_is_ok(), for debugging:



	////
	//// Prototypes
	////

	public static boolean color_is_ok(Color c)
	{
	  return c == Color.WHITE || c == Color.BLACK;
	}




	////
	//// Variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned char DirectionTable[64][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern byte DirectionTable[64][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned char SignedDirectionTable[64][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern byte SignedDirectionTable[64][64];


	////
	//// Inline functions
	////

	public static Direction direction_between_squares(Square s1, Square s2)
	{
	  return Direction(DirectionTable[s1.getValue()][s2.getValue()]);
	}

	public static SignedDirection signed_direction_between_squares(Square s1, Square s2)
	{
	  return new SignedDirection(SignedDirectionTable[s1.getValue()][s2.getValue()]);
	}

////
//// Functions
////



	////
	//// Prototypes
	////

	public static void init_direction_table()
	{
	  SquareDelta[] deltas = {SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_S, SquareDelta.DELTA_NE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NW, SquareDelta.DELTA_SE};
	  for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_H8.getValue(); s1++)
	  {
		for (Square s2 = Square.SQ_A1; s2.getValue() <= Square.SQ_H8.getValue(); s2++)
		{
		  DirectionTable[s1.getValue()][s2.getValue()] = uint8_t(Direction.DIR_NONE);
		  SignedDirectionTable[s1.getValue()][s2.getValue()] = uint8_t(SignedDirection.SIGNED_DIR_NONE);
		  if (s1 == s2)
		  {
			  continue;
		  }
		  for (SignedDirection d = SignedDirection.SIGNED_DIR_E; d.getValue() <= SignedDirection.SIGNED_DIR_SE.getValue(); d++)
		  {
			SquareDelta delta = deltas[d.getValue()];
			Square s3;
			Square s4;
			for (s4 = s1 + delta, s3 = s1; square_distance(s4, s3) == 1 && s4 != s2 && square_is_ok(s4); s3 = s4, s4 += delta)
			{
				;
			}
			if (s4 == s2 && square_distance(s4, s3) == 1)
			{
			  SignedDirectionTable[s1.getValue()][s2.getValue()] = uint8_t(d);
			  DirectionTable[s1.getValue()][s2.getValue()] = uint8_t(d / 2);
			  break;
			}
		  }
		}
	  }
	}





	////
	//// Variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char DirectionTable[64][64];
	public static byte[][] DirectionTable = new byte[64][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char SignedDirectionTable[64][64];
	public static byte[][] SignedDirectionTable = new byte[64][64];



	////
	//// Inline functions
	////

	public static Square move_from(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square((m.getValue() >> 6) & 077);
	}

	public static Square move_to(Move m)
	{
	  return Square(m & 077);
	}

	public static PieceType move_promotion(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return PieceType((m.getValue() >> 12) & 7);
	}

	public static boolean move_is_ep(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return (boolean)((m.getValue() >> 15) & 1);
	}

	public static boolean move_is_castle(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return (boolean)((m.getValue() >> 16) & 1);
	}

	public static boolean move_is_short_castle(Move m)
	{
	  return move_is_castle(m) && (move_to(m) > move_from(m));
	}

	public static boolean move_is_long_castle(Move m)
	{
	  return move_is_castle(m) && (move_to(m) < move_from(m));
	}

	public static Move make_promotion_move(Square from, Square to, PieceType promotion)
	{
	  return Move(to.getValue() | (from.getValue() << 6) | (promotion.getValue() << 12));
	}

	public static Move make_move(Square from, Square to)
	{
	  return Move(to.getValue() | (from.getValue() << 6));
	}

	public static Move make_castle_move(Square from, Square to)
	{
	  return Move(to.getValue() | (from.getValue() << 6) | (1 << 16));
	}

	public static Move make_ep_move(Square from, Square to)
	{
	  return Move(to.getValue() | (from.getValue() << 6) | (1 << 15));
	}

/// Overload the << operator, to make it easier to print moves.



	////
	//// Prototypes
	////


////
//// Functions
////

/// move_from_string() takes a position and a string as input, and attempts to
/// convert the string to a move, using simple coordinate notation (g1f3,
/// a7a8q, etc.).  In order to correctly parse en passant captures and castling
/// moves, we need the position.  This function is not robust, and expects that
/// the input move is legal and correctly formatted.


	public static Move move_from_string(Position pos, String str)
	{
	  Square from;
	  Square to;
	  Piece piece;
	  Color us = pos.side_to_move();

	  if (str.length() < 4)
	  {
		  return Move.MOVE_NONE;
	  }

	  // Read the from and to squares:
	  from = square_from_string(str.substring(0, 2));
	  to = square_from_string(str.substring(2, 6));

	  // Find the moving piece:
	  piece = pos.piece_on(from);

	  // If the string has more than 4 characters, try to interpret the 5th
	  // character as a promotion:
	  if (type_of_piece(piece) == PieceType.PAWN && str.length() >= 5)
	  {
		switch (str.charAt(4))
		{
		case 'n':
	case 'N':
		  return make_promotion_move(from, to, PieceType.KNIGHT);
		case 'b':
	case 'B':
		  return make_promotion_move(from, to, PieceType.BISHOP);
		case 'r':
	case 'R':
		  return make_promotion_move(from, to, PieceType.ROOK);
		case 'q':
	case 'Q':
		  return make_promotion_move(from, to, PieceType.QUEEN);
		}
	  }

	  if (piece == king_of_color(us))
	  {
		// Is this a castling move?  A king move is assumed to be a castling
		// move if the destination square is occupied by a friendly rook, or
		// if the distance between the source and destination squares is more
		// than 1.
		if (pos.piece_on(to) == rook_of_color(us))
		{
		  return make_castle_move(from, to);
		}
		else if (square_distance(from, to) > 1)
		{
		  // This is a castling move, but we have to translate it to the
		  // internal "king captures rook" representation.
		  SquareDelta delta = (to.getValue() > from.getValue())? SquareDelta.DELTA_E : SquareDelta.DELTA_W;
		  Square s;
		  for (s = from + delta; pawn_rank(us, s) == Rank.RANK_1 && pos.piece_on(s) != rook_of_color(us); s += delta)
		  {
			  ;
		  }
		  if (pawn_rank(us, s) == Rank.RANK_1 && pos.piece_on(s) == rook_of_color(us))
		  {
			return make_castle_move(from, s);
		  }
		}
	  }
	  else if (piece == pawn_of_color(us))
	  {
		// En passant move?  We assume that a pawn move is an en passant move
		// without further testing if the destination square is epSquare.
		if (to == pos.ep_square())
		{
		  return make_ep_move(from, to);
		}
	  }

	  return make_move(from, to);
	}

/// move_to_string() converts a move to a string in coordinate notation
/// (g1f3, a7a8q, etc.).  The only special case is castling moves, where we
/// print in the e1g1 notation in normal chess mode, and in e1h1 notation in
/// Chess960 mode.


	public static String move_to_string(Move move)
	{
	  String str;

	  if (move == Move.MOVE_NONE)
	  {
		str = "(none)";
	  }
	  else if (move == Move.MOVE_NULL)
	  {
		str = "0000";
	  }
	  else
	  {
		if (!Chess960)
		{
		  if (move_from(move) == Square.SQ_E1 && move_is_short_castle(move))
		  {
			str = "e1g1";
			return str;
		  }
		  else if (move_from(move) == Square.SQ_E1 && move_is_long_castle(move))
		  {
			str = "e1c1";
			return str;
		  }
		  if (move_from(move) == Square.SQ_E8 && move_is_short_castle(move))
		  {
			str = "e8g8";
			return str;
		  }
		  else if (move_from(move) == Square.SQ_E8 && move_is_long_castle(move))
		  {
			str = "e8c8";
			return str;
		  }
		}
		str = square_to_string(move_from(move)) + square_to_string(move_to(move));
		if (move_promotion(move).getValue() != 0)
		{
		  str += piece_type_to_char(move_promotion(move), false);
		}
	  }
	  return str;
	}

/// move_is_ok(), for debugging.


	public static boolean move_is_ok(Move m)
	{
	  return square_is_ok(move_from(m)) && square_is_ok(move_to(m));
	}




	////
	//// Constants and variables
	////

	public static final PieceType PieceTypeMin = PieceType.PAWN;
	public static final PieceType PieceTypeMax = PieceType.KING;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const int SlidingArray[18];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const SquareDelta Directions[16][16];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const SquareDelta PawnPush[2];


	//// 
	//// Inline functions
	////

	public static PieceType type_of_piece(Piece p)
	{
	  return PieceType(p.getValue() & 7);
	}

	public static Color color_of_piece(Piece p)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Color(p.getValue() >> 3);
	}

	public static Piece piece_of_color_and_type(Color c, PieceType pt)
	{
	  return Piece((c.getValue() << 3) | pt.getValue());
	}

	public static Piece pawn_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.PAWN);
	}

	public static Piece knight_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.KNIGHT);
	}

	public static Piece bishop_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.BISHOP);
	}

	public static Piece rook_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.ROOK);
	}

	public static Piece queen_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.QUEEN);
	}

	public static Piece king_of_color(Color c)
	{
	  return piece_of_color_and_type(c, PieceType.KING);
	}

	public static int piece_is_slider(Piece p)
	{
	  return SlidingArray[p.getValue()];
	}

	public static int piece_type_is_slider(PieceType pt)
	{
	  return SlidingArray[pt.getValue()];
	}

	public static SquareDelta pawn_push(Color c)
	{
	  return PawnPush[c.getValue()];
	}
public static char piece_type_to_char(PieceType pt)
{
	return piece_type_to_char(pt, false);
}


	////
	//// Prototypes
	////

//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: char piece_type_to_char(PieceType pt, boolean upcase = false)
	public static char piece_type_to_char(PieceType pt, boolean upcase)
	{
	  return upcase? toupper(PieceChars.charAt(pt)) : PieceChars.charAt(pt);
	}

	public static PieceType piece_type_from_char(char c)
	{
//C++ TO JAVA CONVERTER TODO TASK: Java does not have an equivalent to pointers to value types:
//ORIGINAL LINE: const char *ch = strchr(PieceChars, tolower(c));
	  char ch = glaurung.types.StringFunctions.strChr(PieceChars, tolower(c));
	  return ch? PieceType(ch - PieceChars) : PieceType.NO_PIECE_TYPE;
	}

/// piece_is_ok() and piece_type_is_ok(), for debugging:


	public static boolean piece_is_ok(Piece pc)
	{
	  return piece_type_is_ok(type_of_piece(pc)) && color_is_ok(color_of_piece(pc));
	}

	public static boolean piece_type_is_ok(PieceType pc)
	{
	  return pc.getValue() >= PieceType.PAWN.getValue() && pc.getValue() <= PieceType.KING.getValue();
	}





	////
	//// Constants and variables
	////

	public static final int[] SlidingArray = {0, 0, 0, 1, 2, 3, 0, 0, 0, 0, 0, 1, 2, 3, 0, 0, 0, 0};

	public static final SquareDelta[][] Directions =
	{
		{SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_NW, SquareDelta.DELTA_NE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SSW, SquareDelta.DELTA_SSE, SquareDelta.DELTA_SWW, SquareDelta.DELTA_SEE, SquareDelta.DELTA_NWW, SquareDelta.DELTA_NEE, SquareDelta.DELTA_NNW, SquareDelta.DELTA_NNE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SW, SquareDelta.DELTA_SE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SSW, SquareDelta.DELTA_SSE, SquareDelta.DELTA_SWW, SquareDelta.DELTA_SEE, SquareDelta.DELTA_NWW, SquareDelta.DELTA_NEE, SquareDelta.DELTA_NNW, SquareDelta.DELTA_NNE, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null},
		{SquareDelta.DELTA_S, SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_SE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NE, SquareDelta.DELTA_NW, SquareDelta.DELTA_ZERO, null, null, null, null, null, null, null}
	};

	public static final SquareDelta[] PawnPush = {SquareDelta.DELTA_N, SquareDelta.DELTA_S};


	////
	//// Functions
	////

	/// Translating piece types to/from English piece letters:

	public static final String PieceChars = " pnbrqk";



	////
	//// Constants
	////

	public static final int FlipMask = 070;
	public static final int FlopMask = 07;


	//// 
	//// Inline functions
	////



	public static Square make_square(File f, Rank r)
	{
	  return Square(f.getValue() | (r.getValue() << 3));
	}

	public static File square_file(Square s)
	{
	  return File(s.getValue() & 7);
	}

	public static Rank square_rank(Square s)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Rank(s.getValue() >> 3);
	}

	public static Square flip_square(Square s)
	{
	  return Square(s.getValue() ^ FlipMask);
	}

	public static Square flop_square(Square s)
	{
	  return Square(s.getValue() ^ FlopMask);
	}

	public static Square relative_square(Color c, Square s)
	{
	  return Square(s.getValue() ^ (c.getValue() * FlipMask));
	}

	public static Rank pawn_rank(Color c, Square s)
	{
	  return square_rank(relative_square(c, s));
	}

	public static Color square_color(Square s)
	{
	  return Color((square_file(s).getValue() + square_rank(s).getValue()) & 1);
	}

	public static int file_distance(File f1, File f2)
	{
	  return Math.abs(f1.getValue() - f2.getValue());
	}

	public static int file_distance(Square s1, Square s2)
	{
	  return file_distance(square_file(s1), square_file(s2));
	}

	public static int rank_distance(Rank r1, Rank r2)
	{
	  return Math.abs(r1.getValue() - r2.getValue());
	}

	public static int rank_distance(Square s1, Square s2)
	{
	  return rank_distance(square_rank(s1), square_rank(s2));
	}

	public static int square_distance(Square s1, Square s2)
	{
	  return (((file_distance(s1, s2)) < (rank_distance(s1, s2)))? (rank_distance(s1, s2)) : (file_distance(s1, s2)));
	}

////
//// Functions
////


/// Translating files, ranks and squares to/from characters and strings:



	//// 
	//// Prototypes
	////

	public static File file_from_char(char c)
	{
	  return File(c - 'a') + File.FILE_A;
	}

	public static char file_to_char(File f)
	{
	  return (char)(f - File.FILE_A) + 'a';
	}

	public static Rank rank_from_char(char c)
	{
	  return Rank(c - '1') + Rank.RANK_1;
	}

	public static char rank_to_char(Rank r)
	{
	  return (char)(r - Rank.RANK_1) + '1';
	}

	public static Square square_from_string(String str)
	{
	  return make_square(file_from_char(str.charAt(0)), rank_from_char(str.charAt(1)));
	}

	public static String square_to_string(Square s)
	{
	  String str;
	  str += file_to_char(square_file(s));
	  str += rank_to_char(square_rank(s));
	  return str;
	}

/// file_is_ok(), rank_is_ok() and square_is_ok(), for debugging:


	public static boolean file_is_ok(File f)
	{
	  return f.getValue() >= File.FILE_A.getValue() && f.getValue() <= File.FILE_H.getValue();
	}

	public static boolean rank_is_ok(Rank r)
	{
	  return r.getValue() >= Rank.RANK_1.getValue() && r.getValue() <= Rank.RANK_8.getValue();
	}

	public static boolean square_is_ok(Square s)
	{
	  return file_is_ok(square_file(s)) && rank_is_ok(square_rank(s));
	}




	////
	//// Constants and variables
	////

	/// Piece values, middle game and endgame

	/// Important: If the material values are changed, one must also
	/// adjust the piece square tables, and the method game_phase() in the
	/// Position class!

	public static final Value PawnValueMidgame = new Value(0xCC);
	public static final Value PawnValueEndgame = new Value(0x100);
	public static final Value KnightValueMidgame = new Value(0x340);
	public static final Value KnightValueEndgame = new Value(0x340);
	public static final Value BishopValueMidgame = new Value(0x340);
	public static final Value BishopValueEndgame = new Value(0x340);
	public static final Value RookValueMidgame = new Value(0x505);
	public static final Value RookValueEndgame = new Value(0x505);
	public static final Value QueenValueMidgame = new Value(0xA00);
	public static final Value QueenValueEndgame = new Value(0xA00);

	public static final Value[] PieceValueMidgame = {Value(0), PawnValueMidgame, KnightValueMidgame, BishopValueMidgame, RookValueMidgame, QueenValueMidgame, Value(0), Value(0), Value(0), PawnValueMidgame, KnightValueMidgame, BishopValueMidgame, RookValueMidgame, QueenValueMidgame, Value(0), Value(0), Value(0)};

	public static final Value[] PieceValueEndgame = {Value(0), PawnValueEndgame, KnightValueEndgame, BishopValueEndgame, RookValueEndgame, QueenValueEndgame, Value(0), Value(0), Value(0), PawnValueEndgame, KnightValueEndgame, BishopValueEndgame, RookValueEndgame, QueenValueEndgame, Value(0), Value(0), Value(0)};

	/// Bonus for having the side to move

	public static final Value TempoValueMidgame = 50;
	public static final Value TempoValueEndgame = 20;


	////
	//// Inline functions
	////

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator + (Value v, int i)
	{
		return Value(v.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator + (Value v1, Value v2)
	{
		return Value(v1.getValue() + v2.getValue());
	}
	private void addAssignment (glaurung.types.RefObject<Value> v1, Value v2)
	{
	  v1.argValue = Value(v1.argValue.getValue() + v2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator - (Value v, int i)
	{
		return Value(v.getValue() - i);
	}
	private Value subtract (Value v)
	{
		return Value(-v.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator - (Value v1, Value v2)
	{
		return Value(v1.getValue() - v2.getValue());
	}
	private void subtractAssignment (glaurung.types.RefObject<Value> v1, Value v2)
	{
	  v1.argValue = Value(v1.argValue.getValue() - v2.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator * (Value v, int i)
	{
		return Value(v.getValue() * i);
	}
	private void multiplyAssignment (glaurung.types.RefObject<Value> v, int i)
	{
		v.argValue = Value(v.argValue.getValue() * i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Value operator * (int i, Value v)
	{
		return Value(v.getValue() * i);
	}
	private Value divide (Value v, int i)
	{
		return Value(v.getValue() / i);
	}
	private void divideAssignment (glaurung.types.RefObject<Value> v, int i)
	{
		v.argValue = Value(v.argValue.getValue() / i);
	}


	public static Value value_mate_in(int ply)
	{
	  return Value(Value.VALUE_MATE - Value(ply));
	}

	public static Value value_mated_in(int ply)
	{
	  return Value(-Value.VALUE_MATE + Value(ply));
	}

	public static boolean is_upper_bound(ValueType vt)
	{
	  return (vt.getValue() & ValueType.VALUE_TYPE_UPPER.getValue()) != 0;
	}

	public static boolean is_lower_bound(ValueType vt)
	{
	  return (vt.getValue() & ValueType.VALUE_TYPE_LOWER.getValue()) != 0;
	}

	public static Value piece_value_midgame(PieceType pt)
	{
	  return PieceValueMidgame[pt.getValue()];
	}

	public static Value piece_value_endgame(PieceType pt)
	{
	  return PieceValueEndgame[pt.getValue()];
	}

	public static Value piece_value_midgame(Piece p)
	{
	  return PieceValueMidgame[p.getValue()];
	}

	public static Value piece_value_endgame(Piece p)
	{
	  return PieceValueEndgame[p.getValue()];
	}

////
//// Functions
////

/// value_to_tt() adjusts a mate score from "plies to mate from the root" to
/// "plies to mate from the current ply".  Non-mate scores are unchanged.
/// The function is called before storing a value to the transposition table.



	////
	//// Prototypes
	////

	public static Value value_to_tt(Value v, int ply)
	{
	  if (v.getValue() >= value_mate_in(100))
	  {
		return v + ply;
	  }
	  else if (v.getValue() <= value_mated_in(100))
	  {
		return v - ply;
	  }
	  else
	  {
		return v;
	  }
	}

/// value_from_tt() is the inverse of value_to_tt():  It adjusts a mate score
/// from the transposition table to a mate score corrected for the current
/// ply depth.


	public static Value value_from_tt(Value v, int ply)
	{
	  if (v.getValue() >= value_mate_in(100))
	  {
		return v - ply;
	  }
	  else if (v.getValue() <= value_mated_in(100))
	  {
		return v + ply;
	  }
	  else
	  {
		return v;
	  }
	}

/// value_to_centipawns() converts a value from Glaurung's somewhat unusual
/// scale of pawn = 256 to the more conventional pawn = 100.


	public static int value_to_centipawns(Value v)
	{
	  return (v.getValue() * 100) / PawnValueMidgame.getValue();
	}

/// value_from_centipawns() converts a centipawn value to Glaurung's internal
/// evaluation scale.  It's used when reading the values of UCI options
/// containing material values (e.g. futility pruning margins).


	public static Value value_from_centipawns(int cp)
	{
	  return Value((cp * 256) / 100);
	}

/// value_to_string() converts a value to a string suitable for use with the
/// UCI protocol.


	public static String value_to_string(Value v)
	{
	  std::stringstream s = new std::stringstream();

	  if (Math.abs(v) < Value.VALUE_MATE.getValue() - 200)
	  {
		s << "cp " << value_to_centipawns(v);
	  }
	  else
	  {
		s << "mate ";
		if (v.getValue() > 0)
		{
		  s << (Value.VALUE_MATE - v + 1) / 2;
		}
		else
		{
		  s << -(Value.VALUE_MATE + v) / 2;
		}
	  }
	  return s.str();
	}




	////
	//// Constants
	////

	/// Note: If OnePly is changed, the constant HistoryMax in history.h should
	/// probably also be changed.

	public static final Depth OnePly = 2;


	////
	//// Inline functions
	////

//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator + (Depth d, int i)
	{
		return Depth(d.getValue() + i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator + (Depth d1, Depth d2)
	{
		return Depth(d1.getValue() + d2.getValue());
	}
	private void addAssignment (glaurung.types.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() + i);
	}
	private void addAssignment (Depth d1, Depth d2)
	{
		d1 += d2.getValue();
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator - (Depth d, int i)
	{
		return Depth(d.getValue() - i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator - (Depth d1, Depth d2)
	{
		return Depth(d1.getValue() - d2.getValue());
	}
	private void subtractAssignment (glaurung.types.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() - i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator * (Depth d, int i)
	{
		return Depth(d.getValue() * i);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Depth operator * (int i, Depth d)
	{
		return Depth(d.getValue() * i);
	}
	private void multiplyAssignment (glaurung.types.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() * i);
	}
	private Depth divide (Depth d, int i)
	{
		return Depth(d.getValue() / i);
	}
	private void divideAssignment (glaurung.types.RefObject<Depth> d, int i)
	{
		d.argValue = Depth(d.argValue.getValue() / i);
	}



}