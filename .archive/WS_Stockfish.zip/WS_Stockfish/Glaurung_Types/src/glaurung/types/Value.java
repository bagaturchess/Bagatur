package glaurung.types;
public class Value
{

	public static Value VALUE_DRAW = new Value(0);
	public static Value VALUE_KNOWN_WIN = new Value(15000);
	public static Value VALUE_MATE = new Value(30000);
	public static Value VALUE_INFINITE = new Value(30001);
	public static Value VALUE_NONE = new Value(30002);
			  
	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;

	public Value(int value)
	{
		intValue = value;
	}

	public int getValue()
	{
		return intValue;
	}
}