package glaurung.bitboard;

import glaurung.types.*;


public class GlobalMembers
{
	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/


	////
	//// Includes
	////


	/*
	  Glaurung, a UCI chess playing engine.
	  Copyright (C) 2004-2008 Tord Romstad
	
	  Glaurung is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	  
	  Glaurung is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




	////
	//// Defines
	////

	///#define USE_COMPACT_ROOK_ATTACKS
	///#define USE_32BIT_ATTACKS 
	///#define USE_FOLDED_BITSCAN

	///#define BITCOUNT_SWAR_64
	///#define BITCOUNT_SWAR_32
	///#define BITCOUNT_LOOP



	////
	//// Includes
	////



	////
	//// Types
	////



	////
	//// Constants and variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long EmptyBoardBB = 0ULL;
	public static final long EmptyBoardBB = 0;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long WhiteSquaresBB = 0x55AA55AA55AA55AAULL;
	public static final long WhiteSquaresBB = 0x55AA55AA55AA55AAl;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long BlackSquaresBB = 0xAA55AA55AA55AA55ULL;
	public static final long BlackSquaresBB = 0xAA55AA55AA55AA55l;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long SquaresByColorBB[2];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong SquaresByColorBB[2];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileABB = 0x0101010101010101ULL;
	public static final long FileABB = 0x0101010101010101l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileBBB = 0x0202020202020202ULL;
	public static final long FileBBB = 0x0202020202020202l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileCBB = 0x0404040404040404ULL;
	public static final long FileCBB = 0x0404040404040404l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileDBB = 0x0808080808080808ULL;
	public static final long FileDBB = 0x0808080808080808l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileEBB = 0x1010101010101010ULL;
	public static final long FileEBB = 0x1010101010101010l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileFBB = 0x2020202020202020ULL;
	public static final long FileFBB = 0x2020202020202020l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileGBB = 0x4040404040404040ULL;
	public static final long FileGBB = 0x4040404040404040l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileHBB = 0x8080808080808080ULL;
	public static final long FileHBB = 0x8080808080808080l;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long FileBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong FileBB[8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long NeighboringFilesBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong NeighboringFilesBB[8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long ThisAndNeighboringFilesBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong ThisAndNeighboringFilesBB[8];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank1BB = 0xFFULL;
	public static final long Rank1BB = 0xFF;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank2BB = 0xFF00ULL;
	public static final long Rank2BB = 0xFF00;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank3BB = 0xFF0000ULL;
	public static final long Rank3BB = 0xFF0000;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank4BB = 0xFF000000ULL;
	public static final long Rank4BB = 0xFF000000;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank5BB = 0xFF00000000ULL;
	public static final long Rank5BB = 0xFF00000000l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank6BB = 0xFF0000000000ULL;
	public static final long Rank6BB = 0xFF0000000000l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank7BB = 0xFF000000000000ULL;
	public static final long Rank7BB = 0xFF000000000000l;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long Rank8BB = 0xFF00000000000000ULL;
	public static final long Rank8BB = 0xFF00000000000000l;

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long RankBB[8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong RankBB[8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long RelativeRankBB[2][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong RelativeRankBB[2][8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long InFrontBB[2][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong InFrontBB[2][8];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long SetMaskBB[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong SetMaskBB[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long ClearMaskBB[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong ClearMaskBB[64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long StepAttackBB[16][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong StepAttackBB[16][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RayBB[64][8];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RayBB[64][8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BetweenBB[64][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BetweenBB[64][64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long PassedPawnMask[2][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong PassedPawnMask[2][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long OutpostMask[2][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong OutpostMask[2][64];

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RankAttacks[8][64], FileAttacks[8][64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RankAttacks[8][64], FileAttacks[8][64];
	///#else
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long RMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong RMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const int RShift[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern int RAttackIndex[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RAttacks[0x19000];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RAttacks[0x19000];
	///#endif // defined(USE_COMPACT_ROOK_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern const unsigned long long BMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const ulong BMult[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern const int BShift[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BMask[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern int BAttackIndex[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BAttacks[0x1480];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BAttacks[0x1480];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long BishopPseudoAttacks[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong BishopPseudoAttacks[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long RookPseudoAttacks[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong RookPseudoAttacks[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern unsigned long long QueenPseudoAttacks[64];
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern ulong QueenPseudoAttacks[64];


	////
	//// Inline functions
	////

	/// Functions for testing whether a given bit is set in a bitboard, and for 
	/// setting and clearing bits.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long set_mask_bb(Square s)
	public static long set_mask_bb(Square s)
	{
	  //  return 1ULL << s;
	  return SetMaskBB[s.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long clear_mask_bb(Square s)
	public static long clear_mask_bb(Square s)
	{
	  //  return ~set_mask_bb(s);
	  return ClearMaskBB[s.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long bit_is_set(unsigned long long b, Square s)
	public static long bit_is_set(long b, Square s)
	{
	  return b & set_mask_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline void set_bit(unsigned long long *b, Square s)
	public static void set_bit(glaurung.bitboard.RefObject<Long> b, Square s)
	{
	  b.argValue |= set_mask_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline void clear_bit(unsigned long long *b, Square s)
	public static void clear_bit(glaurung.bitboard.RefObject<Long> b, Square s)
	{
	  b.argValue &= clear_mask_bb(s);
	}


	/// rank_bb() and file_bb() gives a bitboard containing all squares on a given
	/// file or rank.  It is also possible to pass a square as input to these
	/// functions.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rank_bb(Rank r)
	public static long rank_bb(Rank r)
	{
	  return RankBB[r.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rank_bb(Square s)
	public static long rank_bb(Square s)
	{
	  return rank_bb(square_rank(s));
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long file_bb(File f)
	public static long file_bb(File f)
	{
	  return FileBB[f.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long file_bb(Square s)
	public static long file_bb(Square s)
	{
	  return file_bb(square_file(s));
	}


	/// neighboring_files_bb takes a file or a square as input, and returns a
	/// bitboard representing all squares on the neighboring files.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long neighboring_files_bb(File f)
	public static long neighboring_files_bb(File f)
	{
	  return NeighboringFilesBB[f.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long neighboring_files_bb(Square s)
	public static long neighboring_files_bb(Square s)
	{
	  return neighboring_files_bb(square_file(s));
	}


	/// this_and_neighboring_files_bb takes a file or a square as input, and
	/// returns a bitboard representing all squares on the given and neighboring
	/// files.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long this_and_neighboring_files_bb(File f)
	public static long this_and_neighboring_files_bb(File f)
	{
	  return ThisAndNeighboringFilesBB[f.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long this_and_neighboring_files_bb(Square s)
	public static long this_and_neighboring_files_bb(Square s)
	{
	  return this_and_neighboring_files_bb(square_file(s));
	}


	/// relative_rank_bb() takes a color and a rank as input, and returns a bitboard
	/// representing all squares on the given rank from the given color's point of
	/// view.  For instance, relative_rank_bb(WHITE, 7) gives all squares on the
	/// 7th rank, while relative_rank_bb(BLACK, 7) gives all squares on the 2nd
	/// rank.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long relative_rank_bb(Color c, Rank r)
	public static long relative_rank_bb(Color c, Rank r)
	{
	  return RelativeRankBB[c.getValue()][r.getValue()];
	}


	/// in_front_bb() takes a color and a rank or square as input, and returns a
	/// bitboard representing all the squares on all ranks in front of the rank
	/// (or square), from the given color's point of view.  For instance,
	/// in_front_bb(WHITE, RANK_5) will give all squares on ranks 6, 7 and 8, while
	/// in_front_bb(BLACK, SQ_D3) will give all squares on ranks 1 and 2.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long in_front_bb(Color c, Rank r)
	public static long in_front_bb(Color c, Rank r)
	{
	  return InFrontBB[c.getValue()][r.getValue()];
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long in_front_bb(Color c, Square s)
	public static long in_front_bb(Color c, Square s)
	{
	  return in_front_bb(c, square_rank(s));
	}


	/// ray_bb() gives a bitboard representing all squares along the ray in a
	/// given direction from a given square.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long ray_bb(Square s, SignedDirection d)
	public static long ray_bb(Square s, SignedDirection d)
	{
	  return RayBB[s.getValue()][d.getValue()];
	}


	/// Functions for computing sliding attack bitboards.  rook_attacks_bb(),
	/// bishop_attacks_bb() and queen_attacks_bb() all take a square and a
	/// bitboard of occupied squares as input, and return a bitboard representing
	/// all squares attacked by a rook, bishop or queen on the given square.

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long file_attacks_bb(Square s, unsigned long long blockers)
	public static long file_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = (blockers >> square_file(s)) & 0x01010101010100ULL;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  long b = (long)((blockers >>> square_file(s)) & 0x01010101010100);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return FileAttacks[square_rank(s).getValue()][(b * 0xd6e8802041d0c441) >> 58] & file_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rank_attacks_bb(Square s, unsigned long long blockers)
	public static long rank_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = (blockers >> ((s & 56) + 1)) & 63;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  long b = (long)((blockers >>> ((s & 56) + 1)) & 63);
	  return RankAttacks[square_file(s).getValue()][b] & rank_bb(s);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rook_attacks_bb(Square s, unsigned long long blockers)
	public static long rook_attacks_bb(Square s, long blockers)
	{
	  return file_attacks_bb(s, blockers) | rank_attacks_bb(s, blockers);
	}

	///#elif USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rook_attacks_bb(Square s, unsigned long long blockers)
	public static long rook_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & RMask[s];
	  long b = blockers & RMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return RAttacks[RAttackIndex[s.getValue()] + (int((int)b * (int)RMult[s.getValue()] ^ (int)(b >>> 32) * (int)(RMult[s.getValue()] >>> 32)) >>> RShift[s.getValue()])];
	}

	///#else

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long rook_attacks_bb(Square s, unsigned long long blockers)
	public static long rook_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & RMask[s];
	  long b = blockers & RMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return RAttacks[RAttackIndex[s.getValue()] + ((b * RMult[s.getValue()]) >>> RShift[s.getValue()])];
	}

	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long bishop_attacks_bb(Square s, unsigned long long blockers)
	public static long bishop_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & BMask[s];
	  long b = blockers & BMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return BAttacks[BAttackIndex[s.getValue()] + (int((int)b * (int)BMult[s.getValue()] ^ (int)(b >>> 32) * (int)(BMult[s.getValue()] >>> 32)) >>> BShift[s.getValue()])];
	}

	///#else // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long bishop_attacks_bb(Square s, unsigned long long blockers)
	public static long bishop_attacks_bb(Square s, long blockers)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = blockers & BMask[s];
	  long b = blockers & BMask[s.getValue()];
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return BAttacks[BAttackIndex[s.getValue()] + ((b * BMult[s.getValue()]) >>> BShift[s.getValue()])];
	}

	///#endif // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long queen_attacks_bb(Square s, unsigned long long blockers)
	public static long queen_attacks_bb(Square s, long blockers)
	{
	  return rook_attacks_bb(s, blockers) | bishop_attacks_bb(s, blockers);
	}


	/// squares_between returns a bitboard representing all squares between
	/// two squares.  For instance, squares_between(SQ_C4, SQ_F7) returns a
	/// bitboard with the bits for square d5 and e6 set.  If s1 and s2 are not
	/// on the same line, file or diagonal, EmptyBoardBB is returned.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long squares_between(Square s1, Square s2)
	public static long squares_between(Square s1, Square s2)
	{
	  return BetweenBB[s1.getValue()][s2.getValue()];
	}


	/// squares_in_front_of takes a color and a square as input, and returns a 
	/// bitboard representing all squares along the line in front of the square,
	/// from the point of view of the given color.  For instance, 
	/// squares_in_front_of(BLACK, SQ_E4) returns a bitboard with the squares
	/// e3, e2 and e1 set.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long squares_in_front_of(Color c, Square s)
	public static long squares_in_front_of(Color c, Square s)
	{
	  return in_front_bb(c, s) & file_bb(s);
	}


	/// squares_behind is similar to squares_in_front, but returns the squares
	/// behind the square instead of in front of the square.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long squares_behind(Color c, Square s)
	public static long squares_behind(Color c, Square s)
	{
	  return in_front_bb(opposite_color(c), s) & file_bb(s);
	}


	/// passed_pawn_mask takes a color and a square as input, and returns a 
	/// bitboard mask which can be used to test if a pawn of the given color on 
	/// the given square is a passed pawn.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long passed_pawn_mask(Color c, Square s)
	public static long passed_pawn_mask(Color c, Square s)
	{
	  return PassedPawnMask[c.getValue()][s.getValue()];
	}


	/// outpost_mask takes a color and a square as input, and returns a bitboard
	/// mask which can be used to test whether a piece on the square can possibly
	/// be driven away by an enemy pawn.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long outpost_mask(Color c, Square s)
	public static long outpost_mask(Color c, Square s)
	{
	  return OutpostMask[c.getValue()][s.getValue()];
	}


	/// isolated_pawn_mask takes a square as input, and returns a bitboard mask 
	/// which can be used to test whether a pawn on the given square is isolated.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline unsigned long long isolated_pawn_mask(Square s)
	public static long isolated_pawn_mask(Square s)
	{
	  return neighboring_files_bb(s);
	}


	/// count_1s() counts the number of nonzero bits in a bitboard.

	///#elif BITCOUNT_SWAR_64

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s(unsigned long long b)
	public static int count_1s(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b -= ((b>>>1) & 0x5555555555555555);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b = (long)(((b>>>2) & 0x3333333333333333) + (b & 0x3333333333333333));
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b = (long)(((b>>>4) + b) & 0x0F0F0F0F0F0F0F0F);
	  b *= 0x0101010101010101;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return (int)(b >>> 56);
	}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: inline int count_1s_max_15(unsigned long long b)
	public static int count_1s_max_15(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b -= (b>>>1) & 0x5555555555555555;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  b = (long)(((b>>>2) & 0x3333333333333333) + (b & 0x3333333333333333));
	  b *= 0x1111111111111111;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  return (int)(b >>> 60);
	}

	///#endif // BITCOUNT

////
//// Functions
////

/// print_bitboard() prints a bitboard in an easily readable format to the
/// standard output.  This is sometimes useful for debugging.



	////
	//// Prototypes
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: extern void print_bitboard(unsigned long long b);
	public static void print_bitboard(long b)
	{
	  for (Rank r = Rank.RANK_8; r.getValue() >= Rank.RANK_1.getValue(); r--)
	  {
		System.out.print("+---+---+---+---+---+---+---+---+");
		System.out.print("\n");
		for (File f = File.FILE_A; f.getValue() <= File.FILE_H.getValue(); f++)
		{
		  System.out.print("| ");
		  System.out.print((bit_is_set(b, make_square(f, r)) != 0? 'X' : ' '));
		  System.out.print(' ');
		}
		System.out.print("|");
		System.out.print("\n");
	  }
	  System.out.print("+---+---+---+---+---+---+---+---+");
	  System.out.print("\n");
	}

/// init_bitboards() initializes various bitboard arrays.  It is called during
/// program initialization.


	public static void init_bitboards()
	{
	  int[][] rookDeltas =
	  {
		  {0, 1},
		  {0, -1},
		  {1, 0},
		  {-1, 0}
	  };
	  int[][] bishopDeltas =
	  {
		  {1, 1},
		  {-1, 1},
		  {1, -1},
		  {-1, -1}
	  };
	  init_masks();
	  init_ray_bitboards();
	  init_attacks();
	  init_between_bitboards();
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	  init_file_and_rank_attacks();
	///#else
	  init_sliding_attacks(RAttacks, RAttackIndex, RMask, RShift, RMult, rookDeltas);
	///#endif
	  init_sliding_attacks(BAttacks, BAttackIndex, BMask, BShift, BMult, bishopDeltas);
	  init_pseudo_attacks();
	}

/// first_1() finds the least significant nonzero bit in a nonzero bitboard.





	////
	//// Constants and variables
	////

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long SquaresByColorBB[2] = {BlackSquaresBB, WhiteSquaresBB};
	public static final long[] SquaresByColorBB = {BlackSquaresBB, WhiteSquaresBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long FileBB[8] = { FileABB, FileBBB, FileCBB, FileDBB, FileEBB, FileFBB, FileGBB, FileHBB };
	public static final long[] FileBB = {FileABB, FileBBB, FileCBB, FileDBB, FileEBB, FileFBB, FileGBB, FileHBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long NeighboringFilesBB[8] = { FileBBB, FileABB|FileCBB, FileBBB|FileDBB, FileCBB|FileEBB, FileDBB|FileFBB, FileEBB|FileGBB, FileFBB|FileHBB, FileGBB };
	public static final long[] NeighboringFilesBB = {FileBBB, FileABB | FileCBB, FileBBB | FileDBB, FileCBB | FileEBB, FileDBB | FileFBB, FileEBB | FileGBB, FileFBB | FileHBB, FileGBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long ThisAndNeighboringFilesBB[8] = { FileABB|FileBBB, FileABB|FileBBB|FileCBB, FileBBB|FileCBB|FileDBB, FileCBB|FileDBB|FileEBB, FileDBB|FileEBB|FileFBB, FileEBB|FileFBB|FileGBB, FileFBB|FileGBB|FileHBB, FileGBB|FileHBB };
	public static final long[] ThisAndNeighboringFilesBB = {FileABB | FileBBB, FileABB | FileBBB | FileCBB, FileBBB | FileCBB | FileDBB, FileCBB | FileDBB | FileEBB, FileDBB | FileEBB | FileFBB, FileEBB | FileFBB | FileGBB, FileFBB | FileGBB | FileHBB, FileGBB | FileHBB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RankBB[8] = { Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB };
	public static final long[] RankBB = {Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RelativeRankBB[2][8] = { { Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB }, { Rank8BB, Rank7BB, Rank6BB, Rank5BB, Rank4BB, Rank3BB, Rank2BB, Rank1BB } };
	public static final long[][] RelativeRankBB =
	{
		{Rank1BB, Rank2BB, Rank3BB, Rank4BB, Rank5BB, Rank6BB, Rank7BB, Rank8BB},
		{Rank8BB, Rank7BB, Rank6BB, Rank5BB, Rank4BB, Rank3BB, Rank2BB, Rank1BB}
	};

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long InFrontBB[2][8] = { { Rank2BB | Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank6BB | Rank7BB | Rank8BB, Rank7BB | Rank8BB, Rank8BB, EmptyBoardBB }, { EmptyBoardBB, Rank1BB, Rank2BB | Rank1BB, Rank3BB | Rank2BB | Rank1BB, Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank7BB | Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB } };
	public static final long[][] InFrontBB =
	{
		{Rank2BB | Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank3BB | Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank4BB | Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank5BB | Rank6BB | Rank7BB | Rank8BB, Rank6BB | Rank7BB | Rank8BB, Rank7BB | Rank8BB, Rank8BB, EmptyBoardBB},
		{EmptyBoardBB, Rank1BB, Rank2BB | Rank1BB, Rank3BB | Rank2BB | Rank1BB, Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB, Rank7BB | Rank6BB | Rank5BB | Rank4BB | Rank3BB | Rank2BB | Rank1BB}
	};

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RankAttacks[8][64], FileAttacks[8][64];
	public static long[][] RankAttacks = new long[8][64];
	public static long[][] FileAttacks = new long[8][64];

	///#elif USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RMult[64] = { 0xd7445cdec88002c0ULL, 0xd0a505c1f2001722ULL, 0xe065d1c896002182ULL, 0x9a8c41e75a000892ULL, 0x8900b10c89002aa8ULL, 0x9b28d1c1d60005a2ULL, 0x15d6c88de002d9aULL, 0xb1dbfc802e8016a9ULL, 0x149a1042d9d60029ULL, 0xb9c08050599e002fULL, 0x132208c3af300403ULL, 0xc1000ce2e9c50070ULL, 0x9d9aa13c99020012ULL, 0xb6b078daf71e0046ULL, 0x9d880182fb6e002eULL, 0x52889f467e850037ULL, 0xda6dc008d19a8480ULL, 0x468286034f902420ULL, 0x7140ac09dc54c020ULL, 0xd76ffffa39548808ULL, 0xea901c4141500808ULL, 0xc91004093f953a02ULL, 0x2882afa8f6bb402ULL, 0xaebe335692442c01ULL, 0xe904a22079fb91eULL, 0x13a514851055f606ULL, 0x76c782018c8fe632ULL, 0x1dc012a9d116da06ULL, 0x3c9e0037264fffa6ULL, 0x2036002853c6e4a2ULL, 0xe3fe08500afb47d4ULL, 0xf38af25c86b025c2ULL, 0xc0800e2182cf9a40ULL, 0x72002480d1f60673ULL, 0x2500200bae6e9b53ULL, 0xc60018c1eefca252ULL, 0x600590473e3608aULL, 0x46002c4ab3fe51b2ULL, 0xa200011486bcc8d2ULL, 0xb680078095784c63ULL, 0x2742002639bf11aeULL, 0xc7d60021a5bdb142ULL, 0xc8c04016bb83d820ULL, 0xbd520028123b4842ULL, 0x9d1600344ac2a832ULL, 0x6a808005631c8a05ULL, 0x604600a148d5389aULL, 0xe2e40103d40dea65ULL, 0x945b5a0087c62a81ULL, 0x12dc200cd82d28eULL, 0x2431c600b5f9ef76ULL, 0xfb142a006a9b314aULL, 0x6870e00a1c97d62ULL, 0x2a9db2004a2689a2ULL, 0xd3594600caf5d1a2ULL, 0xee0e4900439344a7ULL, 0x89c4d266ca25007aULL, 0x3e0013a2743f97e3ULL, 0x180e31a0431378aULL, 0x3a9e465a4d42a512ULL, 0x98d0a11a0c0d9cc2ULL, 0x8e711c1aba19b01eULL, 0x8dcdc836dd201142ULL, 0x5ac08a4735370479ULL, };
	public static final long[] RMult = {0xd7445cdec88002c0, 0xd0a505c1f2001722, 0xe065d1c896002182, 0x9a8c41e75a000892, 0x8900b10c89002aa8, 0x9b28d1c1d60005a2, 0x15d6c88de002d9a, 0xb1dbfc802e8016a9, 0x149a1042d9d60029, 0xb9c08050599e002f, 0x132208c3af300403, 0xc1000ce2e9c50070, 0x9d9aa13c99020012, 0xb6b078daf71e0046, 0x9d880182fb6e002e, 0x52889f467e850037, 0xda6dc008d19a8480, 0x468286034f902420, 0x7140ac09dc54c020, 0xd76ffffa39548808, 0xea901c4141500808, 0xc91004093f953a02, 0x2882afa8f6bb402, 0xaebe335692442c01, 0xe904a22079fb91e, 0x13a514851055f606, 0x76c782018c8fe632, 0x1dc012a9d116da06, 0x3c9e0037264fffa6, 0x2036002853c6e4a2, 0xe3fe08500afb47d4, 0xf38af25c86b025c2, 0xc0800e2182cf9a40, 0x72002480d1f60673, 0x2500200bae6e9b53, 0xc60018c1eefca252, 0x600590473e3608a, 0x46002c4ab3fe51b2, 0xa200011486bcc8d2, 0xb680078095784c63, 0x2742002639bf11ae, 0xc7d60021a5bdb142, 0xc8c04016bb83d820, 0xbd520028123b4842, 0x9d1600344ac2a832, 0x6a808005631c8a05, 0x604600a148d5389a, 0xe2e40103d40dea65, 0x945b5a0087c62a81, 0x12dc200cd82d28e, 0x2431c600b5f9ef76, 0xfb142a006a9b314a, 0x6870e00a1c97d62, 0x2a9db2004a2689a2, 0xd3594600caf5d1a2, 0xee0e4900439344a7, 0x89c4d266ca25007a, 0x3e0013a2743f97e3, 0x180e31a0431378a, 0x3a9e465a4d42a512, 0x98d0a11a0c0d9cc2, 0x8e711c1aba19b01e, 0x8dcdc836dd201142, 0x5ac08a4735370479};

	public static final int[] RShift = {20, 21, 21, 21, 21, 21, 21, 20, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 21, 22, 22, 22, 22, 22, 22, 21, 20, 21, 21, 21, 21, 21, 21, 20};

	///#else // if defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long RMult[64] = { 0xa8002c000108020ULL, 0x4440200140003000ULL, 0x8080200010011880ULL, 0x380180080141000ULL, 0x1a00060008211044ULL, 0x410001000a0c0008ULL, 0x9500060004008100ULL, 0x100024284a20700ULL, 0x802140008000ULL, 0x80c01002a00840ULL, 0x402004282011020ULL, 0x9862000820420050ULL, 0x1001448011100ULL, 0x6432800200800400ULL, 0x40100010002000cULL, 0x2800d0010c080ULL, 0x90c0008000803042ULL, 0x4010004000200041ULL, 0x3010010200040ULL, 0xa40828028001000ULL, 0x123010008000430ULL, 0x24008004020080ULL, 0x60040001104802ULL, 0x582200028400d1ULL, 0x4000802080044000ULL, 0x408208200420308ULL, 0x610038080102000ULL, 0x3601000900100020ULL, 0x80080040180ULL, 0xc2020080040080ULL, 0x80084400100102ULL, 0x4022408200014401ULL, 0x40052040800082ULL, 0xb08200280804000ULL, 0x8a80a008801000ULL, 0x4000480080801000ULL, 0x911808800801401ULL, 0x822a003002001894ULL, 0x401068091400108aULL, 0x4a10a00004cULL, 0x2000800640008024ULL, 0x1486408102020020ULL, 0x100a000d50041ULL, 0x810050020b0020ULL, 0x204000800808004ULL, 0x20048100a000cULL, 0x112000831020004ULL, 0x9000040810002ULL, 0x440490200208200ULL, 0x8910401000200040ULL, 0x6404200050008480ULL, 0x4b824a2010010100ULL, 0x4080801810c0080ULL, 0x400802a0080ULL, 0x8224080110026400ULL, 0x40002c4104088200ULL, 0x1002100104a0282ULL, 0x1208400811048021ULL, 0x3201014a40d02001ULL, 0x5100019200501ULL, 0x101000208001005ULL, 0x2008450080702ULL, 0x1002080301d00cULL, 0x410201ce5c030092ULL };
	public static final long[] RMult = {0xa8002c000108020, 0x4440200140003000, 0x8080200010011880, 0x380180080141000, 0x1a00060008211044, 0x410001000a0c0008, 0x9500060004008100, 0x100024284a20700, 0x802140008000, 0x80c01002a00840, 0x402004282011020, 0x9862000820420050, 0x1001448011100, 0x6432800200800400, 0x40100010002000c, 0x2800d0010c080, 0x90c0008000803042, 0x4010004000200041, 0x3010010200040, 0xa40828028001000, 0x123010008000430, 0x24008004020080, 0x60040001104802, 0x582200028400d1, 0x4000802080044000, 0x408208200420308, 0x610038080102000, 0x3601000900100020, 0x80080040180, 0xc2020080040080, 0x80084400100102, 0x4022408200014401, 0x40052040800082, 0xb08200280804000, 0x8a80a008801000, 0x4000480080801000, 0x911808800801401, 0x822a003002001894, 0x401068091400108a, 0x4a10a00004c, 0x2000800640008024, 0x1486408102020020, 0x100a000d50041, 0x810050020b0020, 0x204000800808004, 0x20048100a000c, 0x112000831020004, 0x9000040810002, 0x440490200208200, 0x8910401000200040, 0x6404200050008480, 0x4b824a2010010100, 0x4080801810c0080, 0x400802a0080, 0x8224080110026400, 0x40002c4104088200, 0x1002100104a0282, 0x1208400811048021, 0x3201014a40d02001, 0x5100019200501, 0x101000208001005, 0x2008450080702, 0x1002080301d00c, 0x410201ce5c030092};

	public static final int[] RShift = {52, 53, 53, 53, 53, 53, 53, 52, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 53, 54, 54, 54, 54, 54, 54, 53, 52, 53, 53, 53, 53, 53, 53, 52};

	///#endif // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if !USE_COMPACT_ROOK_ATTACKS
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RMask[64];
	public static long[] RMask = new long[64];
	public static int[] RAttackIndex = new int[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RAttacks[0x19000];
	public static long[] RAttacks = new long[0x19000];
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_32BIT_ATTACKS

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long BMult[64] = { 0x54142844c6a22981ULL, 0x710358a6ea25c19eULL, 0x704f746d63a4a8dcULL, 0xbfed1a0b80f838c5ULL, 0x90561d5631e62110ULL, 0x2804260376e60944ULL, 0x84a656409aa76871ULL, 0xf0267f64c28b6197ULL, 0x70764ebb762f0585ULL, 0x92aa09e0cfe161deULL, 0x41ee1f6bb266f60eULL, 0xddcbf04f6039c444ULL, 0x5a3fab7bac0d988aULL, 0xd3727877fa4eaa03ULL, 0xd988402d868ddaaeULL, 0x812b291afa075c7cULL, 0x94faf987b685a932ULL, 0x3ed867d8470d08dbULL, 0x92517660b8901de8ULL, 0x2d97e43e058814b4ULL, 0x880a10c220b25582ULL, 0xc7c6520d1f1a0477ULL, 0xdbfc7fbcd7656aa6ULL, 0x78b1b9bfb1a2b84fULL, 0x2f20037f112a0bc1ULL, 0x657171ea2269a916ULL, 0xc08302b07142210eULL, 0x880a4403064080bULL, 0x3602420842208c00ULL, 0x852800dc7e0b6602ULL, 0x595a3fbbaa0f03b2ULL, 0x9f01411558159d5eULL, 0x2b4a4a5f88b394f2ULL, 0x4afcbffc292dd03aULL, 0x4a4094a3b3f10522ULL, 0xb06f00b491f30048ULL, 0xd5b3820280d77004ULL, 0x8b2e01e7c8e57a75ULL, 0x2d342794e886c2e6ULL, 0xc302c410cde21461ULL, 0x111f426f1379c274ULL, 0xe0569220abb31588ULL, 0x5026d3064d453324ULL, 0xe2076040c343cd8aULL, 0x93efd1e1738021eeULL, 0xb680804bed143132ULL, 0x44e361b21986944cULL, 0x44c60170ef5c598cULL, 0xf4da475c195c9c94ULL, 0xa3afbb5f72060b1dULL, 0xbc75f410e41c4ffcULL, 0xb51c099390520922ULL, 0x902c011f8f8ec368ULL, 0x950b56b3d6f5490aULL, 0x3909e0635bf202d0ULL, 0x5744f90206ec10ccULL, 0xdc59fd76317abbc1ULL, 0x881c7c67fcbfc4f6ULL, 0x47ca41e7e440d423ULL, 0xeb0c88112048d004ULL, 0x51c60e04359aef1aULL, 0x1aa1fe0e957a5554ULL, 0xdd9448db4f5e3104ULL, 0xdc01f6dca4bebbdcULL, };
	public static final long[] BMult = {0x54142844c6a22981, 0x710358a6ea25c19e, 0x704f746d63a4a8dc, 0xbfed1a0b80f838c5, 0x90561d5631e62110, 0x2804260376e60944, 0x84a656409aa76871, 0xf0267f64c28b6197, 0x70764ebb762f0585, 0x92aa09e0cfe161de, 0x41ee1f6bb266f60e, 0xddcbf04f6039c444, 0x5a3fab7bac0d988a, 0xd3727877fa4eaa03, 0xd988402d868ddaae, 0x812b291afa075c7c, 0x94faf987b685a932, 0x3ed867d8470d08db, 0x92517660b8901de8, 0x2d97e43e058814b4, 0x880a10c220b25582, 0xc7c6520d1f1a0477, 0xdbfc7fbcd7656aa6, 0x78b1b9bfb1a2b84f, 0x2f20037f112a0bc1, 0x657171ea2269a916, 0xc08302b07142210e, 0x880a4403064080b, 0x3602420842208c00, 0x852800dc7e0b6602, 0x595a3fbbaa0f03b2, 0x9f01411558159d5e, 0x2b4a4a5f88b394f2, 0x4afcbffc292dd03a, 0x4a4094a3b3f10522, 0xb06f00b491f30048, 0xd5b3820280d77004, 0x8b2e01e7c8e57a75, 0x2d342794e886c2e6, 0xc302c410cde21461, 0x111f426f1379c274, 0xe0569220abb31588, 0x5026d3064d453324, 0xe2076040c343cd8a, 0x93efd1e1738021ee, 0xb680804bed143132, 0x44e361b21986944c, 0x44c60170ef5c598c, 0xf4da475c195c9c94, 0xa3afbb5f72060b1d, 0xbc75f410e41c4ffc, 0xb51c099390520922, 0x902c011f8f8ec368, 0x950b56b3d6f5490a, 0x3909e0635bf202d0, 0x5744f90206ec10cc, 0xdc59fd76317abbc1, 0x881c7c67fcbfc4f6, 0x47ca41e7e440d423, 0xeb0c88112048d004, 0x51c60e04359aef1a, 0x1aa1fe0e957a5554, 0xdd9448db4f5e3104, 0xdc01f6dca4bebbdc};

	public static final int[] BShift = {26, 27, 27, 27, 27, 27, 27, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 25, 25, 25, 25, 27, 27, 27, 27, 25, 23, 23, 25, 27, 27, 27, 27, 25, 23, 23, 25, 27, 27, 27, 27, 25, 25, 25, 25, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 26, 27, 27, 27, 27, 27, 27, 26};

	///#else // if defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long BMult[64] = { 0x440049104032280ULL, 0x1021023c82008040ULL, 0x404040082000048ULL, 0x48c4440084048090ULL, 0x2801104026490000ULL, 0x4100880442040800ULL, 0x181011002e06040ULL, 0x9101004104200e00ULL, 0x1240848848310401ULL, 0x2000142828050024ULL, 0x1004024d5000ULL, 0x102044400800200ULL, 0x8108108820112000ULL, 0xa880818210c00046ULL, 0x4008008801082000ULL, 0x60882404049400ULL, 0x104402004240810ULL, 0xa002084250200ULL, 0x100b0880801100ULL, 0x4080201220101ULL, 0x44008080a00000ULL, 0x202200842000ULL, 0x5006004882d00808ULL, 0x200045080802ULL, 0x86100020200601ULL, 0xa802080a20112c02ULL, 0x80411218080900ULL, 0x200a0880080a0ULL, 0x9a01010000104000ULL, 0x28008003100080ULL, 0x211021004480417ULL, 0x401004188220806ULL, 0x825051400c2006ULL, 0x140c0210943000ULL, 0x242800300080ULL, 0xc2208120080200ULL, 0x2430008200002200ULL, 0x1010100112008040ULL, 0x8141050100020842ULL, 0x822081014405ULL, 0x800c049e40400804ULL, 0x4a0404028a000820ULL, 0x22060201041200ULL, 0x360904200840801ULL, 0x881a08208800400ULL, 0x60202c00400420ULL, 0x1204440086061400ULL, 0x8184042804040ULL, 0x64040315300400ULL, 0xc01008801090a00ULL, 0x808010401140c00ULL, 0x4004830c2020040ULL, 0x80005002020054ULL, 0x40000c14481a0490ULL, 0x10500101042048ULL, 0x1010100200424000ULL, 0x640901901040ULL, 0xa0201014840ULL, 0x840082aa011002ULL, 0x10010840084240aULL, 0x420400810420608ULL, 0x8d40230408102100ULL, 0x4a00200612222409ULL, 0xa08520292120600ULL };
	public static final long[] BMult = {0x440049104032280, 0x1021023c82008040, 0x404040082000048, 0x48c4440084048090, 0x2801104026490000, 0x4100880442040800, 0x181011002e06040, 0x9101004104200e00, 0x1240848848310401, 0x2000142828050024, 0x1004024d5000, 0x102044400800200, 0x8108108820112000, 0xa880818210c00046, 0x4008008801082000, 0x60882404049400, 0x104402004240810, 0xa002084250200, 0x100b0880801100, 0x4080201220101, 0x44008080a00000, 0x202200842000, 0x5006004882d00808, 0x200045080802, 0x86100020200601, 0xa802080a20112c02, 0x80411218080900, 0x200a0880080a0, 0x9a01010000104000, 0x28008003100080, 0x211021004480417, 0x401004188220806, 0x825051400c2006, 0x140c0210943000, 0x242800300080, 0xc2208120080200, 0x2430008200002200, 0x1010100112008040, 0x8141050100020842, 0x822081014405, 0x800c049e40400804, 0x4a0404028a000820, 0x22060201041200, 0x360904200840801, 0x881a08208800400, 0x60202c00400420, 0x1204440086061400, 0x8184042804040, 0x64040315300400, 0xc01008801090a00, 0x808010401140c00, 0x4004830c2020040, 0x80005002020054, 0x40000c14481a0490, 0x10500101042048, 0x1010100200424000, 0x640901901040, 0xa0201014840, 0x840082aa011002, 0x10010840084240a, 0x420400810420608, 0x8d40230408102100, 0x4a00200612222409, 0xa08520292120600};

	public static final int[] BShift = {58, 59, 59, 59, 59, 59, 59, 58, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 57, 57, 57, 57, 59, 59, 59, 59, 57, 55, 55, 57, 59, 59, 59, 59, 57, 55, 55, 57, 59, 59, 59, 59, 57, 57, 57, 57, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 58, 59, 59, 59, 59, 59, 59, 58};

	///#endif // defined(USE_32BIT_ATTACKS)

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BMask[64];
	public static long[] BMask = new long[64];
	public static int[] BAttackIndex = new int[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BAttacks[0x1480];
	public static long[] BAttacks = new long[0x1480];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long SetMaskBB[64];
	public static long[] SetMaskBB = new long[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long ClearMaskBB[64];
	public static long[] ClearMaskBB = new long[64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long StepAttackBB[16][64];
	public static long[][] StepAttackBB = new long[16][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RayBB[64][8];
	public static long[][] RayBB = new long[64][8];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BetweenBB[64][64];
	public static long[][] BetweenBB = new long[64][64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long PassedPawnMask[2][64];
	public static long[][] PassedPawnMask = new long[2][64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long OutpostMask[2][64];
	public static long[][] OutpostMask = new long[2][64];

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long BishopPseudoAttacks[64];
	public static long[] BishopPseudoAttacks = new long[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long RookPseudoAttacks[64];
	public static long[] RookPseudoAttacks = new long[64];
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long QueenPseudoAttacks[64];
	public static long[] QueenPseudoAttacks = new long[64];

  // All functions below are used to precompute various bitboards during
  // program initialization.  Some of the functions may be difficult to
  // understand, but they all seem to work correctly, and it should never
  // be necessary to touch any of them.



	////
	//// Local definitions
	////

	  public static void init_masks()
	  {
		for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
		{
		  SetMaskBB[s.getValue()] = (long)(1 << s.getValue());
		  ClearMaskBB[s.getValue()] = ~SetMaskBB[s.getValue()];
		}
		for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c++)
		{
		  for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
		  {
			PassedPawnMask[c.getValue()][s.getValue()] = in_front_bb(c, s) & this_and_neighboring_files_bb(s);
			OutpostMask[c.getValue()][s.getValue()] = in_front_bb(c, s) & neighboring_files_bb(s);
		  }
		}
	  }

	  public static void init_ray_bitboards()
	  {
		int[] d = {1, -1, 16, -16, 17, -17, 15, -15};
		for (int i = 0; i < 128; i = i + 9 & ~8)
		{
		  for (int j = 0; j < 8; j++)
		  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			RayBB[(i & 7) | ((i >> 4) << 3)][j] = EmptyBoardBB;
			for (int k = i + d[j]; (k & 0x88) == 0; k += d[j])
			{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			  set_bit((RayBB[(i & 7) | ((i >> 4)<<3)][j]), Square((k & 7) | ((k>>4) << 3)));
			}
		  }
		}
	  }

	  public static void init_attacks()
	  {
		int i;
		int j;
		int k;
		int l;
		int[][] step =
		{
			{0, 0, 0, 0, 0, 0, 0, 0},
			{7, 9, 0, 0, 0, 0, 0, 0},
			{17, 15, 10, 6, -6, -10, -15, -17},
			{9, 7, -7, -9, 0, 0, 0, 0},
			{8, 1, -1, -8, 0, 0, 0, 0},
			{9, 7, -7, -9, 8, 1, -1, -8},
			{9, 7, -7, -9, 8, 1, -1, -8},
			{0, 0, 0, 0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0, 0, 0, 0},
			{-7, -9, 0, 0, 0, 0, 0, 0},
			{17, 15, 10, 6, -6, -10, -15, -17},
			{9, 7, -7, -9, 0, 0, 0, 0},
			{8, 1, -1, -8, 0, 0, 0, 0},
			{9, 7, -7, -9, 8, 1, -1, -8},
			{9, 7, -7, -9, 8, 1, -1, -8}
		};

		for (i = 0; i < 64; i++)
		{
		  for (j = 0; j <= Piece.BK.getValue(); j++)
		  {
			StepAttackBB[j][i] = EmptyBoardBB;
			for (k = 0; k < 8 && step[j][k] != 0; k++)
			{
			  l = i + step[j][k];
			  if (l >= 0 && l < 64 && Math.abs((i & 7) - (l & 7)) < 3)
			  {
				StepAttackBB[j][i] |= (1 << l);
			  }
			}
		  }
		}
	  }

	  public static void init_between_bitboards()
	  {
		SquareDelta[] step = {SquareDelta.DELTA_E, SquareDelta.DELTA_W, SquareDelta.DELTA_N, SquareDelta.DELTA_S, SquareDelta.DELTA_NE, SquareDelta.DELTA_SW, SquareDelta.DELTA_NW, SquareDelta.DELTA_SE};
		SignedDirection d;
		for (Square s1 = Square.SQ_A1; s1.getValue() <= Square.SQ_H8.getValue(); s1++)
		{
		  for (Square s2 = Square.SQ_A1; s2.getValue() <= Square.SQ_H8.getValue(); s2++)
		  {
			BetweenBB[s1.getValue()][s2.getValue()] = EmptyBoardBB;
			d = signed_direction_between_squares(s1, s2);
			if (d != SignedDirection.SIGNED_DIR_NONE)
			{
			  for (Square s3 = s1 + step[d.getValue()]; s3 != s2; s3 += step[d.getValue()])
			  {
				set_bit((BetweenBB[s1.getValue()][s2.getValue()]), s3);
			  }
			}
		  }
		}
	  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin, int fmax, int rmin)
  {
	  return sliding_attacks(sq, block, dirs, deltas, fmin, fmax, rmin, 7);
  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin, int fmax)
  {
	  return sliding_attacks(sq, block, dirs, deltas, fmin, fmax, 0, 7);
  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin)
  {
	  return sliding_attacks(sq, block, dirs, deltas, fmin, 7, 0, 7);
  }
  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas)
  {
	  return sliding_attacks(sq, block, dirs, deltas, 0, 7, 0, 7);
  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long sliding_attacks(int sq, unsigned long long block, int dirs, int deltas[][2], int fmin, int fmax, int rmin, int rmax);
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: ulong sliding_attacks(int sq, ulong block, int dirs, int deltas[][2], int fmin=0, int fmax=7, int rmin=0, int rmax=7)
	  public static long sliding_attacks(int sq, long block, int dirs, int[][] deltas, int fmin, int fmax, int rmin, int rmax)
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long result = 0ULL;
		long result = 0;
		int rk = sq / 8;
		int fl = sq % 8;
		int r;
		int f;
		int i;
		for (i = 0; i < dirs; i++)
		{
		  int dx = deltas[i][0];
		  int dy = deltas[i][1];
		  for (f = fl + dx, r = rk + dy; (dx == 0 || (f >= fmin && f <= fmax)) && (dy == 0 || (r >= rmin && r <= rmax)); f += dx, r += dy)
		  {
			result |= (1 << (f + r * 8));
			if ((block & (1 << (f + r * 8))) != 0)
			{
				break;
			}
		  }
		}
		return result;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long index_to_bitboard(int index, unsigned long long mask);
	  public static long index_to_bitboard(int index, long mask)
	  {
		int i;
		int j;
		int bits = count_1s(mask);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long result = 0ULL;
		long result = 0;
		for (i = 0; i < bits; i++)
		{
	  glaurung.bitboard.RefObject<Long> tempRef_mask = new glaurung.bitboard.RefObject<Long>(mask);
		  j = pop_1st_bit(tempRef_mask).getValue();
		  mask = tempRef_mask.argValue;
		  if ((index & (1 << i)) != 0)
		  {
			  result |= (1 << j);
		  }
		}
		return result;
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: void init_sliding_attacks(unsigned long long attacks[], int attackIndex[], unsigned long long mask[], const int shift[2], const unsigned long long mult[], int deltas[][2]);
	  public static void init_sliding_attacks(long[] attacks, int[] attackIndex, long[] mask, int[] shift, long[] mult, int[][] deltas)
	  {
		int i;
		int j;
		int k;
		int index = 0;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;
		for (i = 0; i < 64; i++)
		{
		  attackIndex[i] = index;
		  mask[i] = sliding_attacks(i, 0, 4, deltas, 1, 6, 1, 6);
		  j = (1 << (64 - shift[i]));
		  for (k = 0; k < j; k++)
		  {
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_32BIT_ATTACKS
			b = index_to_bitboard(k, mask[i]);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			attacks[index + (int((int)b * (int)mult[i] ^ (int)(b >>> 32) * (int)(mult[i] >>> 32)) >>> shift[i])] = sliding_attacks(i, b, 4, deltas);
	///#else
			b = index_to_bitboard(k, mask[i]);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
			attacks[index + ((b * mult[i]) >>> shift[i])] = sliding_attacks(i, b, 4, deltas);
	///#endif
		  }
		  index += j;
		}
	  }

	  public static void init_pseudo_attacks()
	  {
		Square s;
		for (s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); s++)
		{
		  BishopPseudoAttacks[s.getValue()] = bishop_attacks_bb(s, EmptyBoardBB);
		  RookPseudoAttacks[s.getValue()] = rook_attacks_bb(s, EmptyBoardBB);
		  QueenPseudoAttacks[s.getValue()] = queen_attacks_bb(s, EmptyBoardBB);
		}
	  }

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_COMPACT_ROOK_ATTACKS
	  public static void init_file_and_rank_attacks()
	  {
		int i;
		int j;
		int k;
		int l;
		int m;
		int s;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b1, b2;
		long b1;
		long b2;
		for (i = 0; i < 64; i++)
		{

		  for (m = 0; m <= 1; m++)
		  {
			b1 = 0;
			for (j = 0; j < 6; j++)
			{
				if ((i & (1 << j)) != 0)
				{
					b1 |= (1 << ((j + 1) * (1 + m * 7)));
				}
			}
			for (j = 0; j < 8; j++)
			{
			  b2 = 0;
			  for (k = 0, s = 1; k < 2; k++, s *= -1)
			  {
				for (l = j + s; l >= 0 && l <= 7; l += s)
				{
				  b2 |= (m != 0? RankBB[l] : FileBB[l]);
				  if ((b1 & (1 << (l * (1 + m * 7)))) != 0)
				  {
					  break;
				  }
				}
			  }
			  if (m != 0)
			  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
				  FileAttacks[j][(b1 * 0xd6e8802041d0c441) >> 58] = b2;
			  }
			  else
			  {
				  RankAttacks[j][i] = b2;
			  }
			}
		  }
		}
	  }
	///#endif

	///#endif


	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_FOLDED_BITSCAN

	public static final int[] BitTable = {63, 30, 3, 32, 25, 41, 22, 33, 15, 50, 42, 13, 11, 53, 19, 34, 61, 29, 2, 51, 21, 43, 45, 10, 18, 47, 1, 54, 9, 57, 0, 35, 62, 31, 40, 4, 49, 5, 52, 26, 60, 6, 23, 44, 46, 27, 56, 16, 7, 39, 48, 24, 59, 14, 12, 55, 38, 28, 58, 20, 37, 17, 36, 8};

	///#else

	public static final int[] BitTable = {0, 1, 2, 7, 3, 13, 8, 19, 4, 25, 14, 28, 9, 34, 20, 40, 5, 17, 26, 38, 15, 46, 29, 48, 10, 31, 35, 54, 21, 50, 41, 57, 63, 6, 12, 18, 24, 27, 33, 39, 16, 37, 45, 47, 30, 53, 49, 56, 62, 11, 23, 32, 36, 44, 52, 55, 61, 22, 43, 51, 60, 42, 59, 58};


	/// first_1() finds the least significant nonzero bit in a nonzero bitboard.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: Square first_1(unsigned long long b)
	public static Square first_1(long b)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square(BitTable[((b & -b) * 0x218a392cd3d5dbf) >> 58]);
	}


	/// pop_1st_bit() finds and clears the least significant nonzero bit in a
	/// nonzero bitboard.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: Square pop_1st_bit(unsigned long long *b)
	public static Square pop_1st_bit(glaurung.types.RefObject<Long> b)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = *b;
	  long bb = b.argValue;
	  b.argValue &= (b.argValue - 1);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square(BitTable[((bb & -bb) * 0x218a392cd3d5dbf) >> 58]);
	}

	///#endif // defined(USE_FOLDED_BITSCAN)
}