package PSQT;

public class GlobalMembers
{
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef S

	public static Score[][] psq = new Score[Piece.PIECE_NB.getValue()][Square.SQUARE_NB.getValue()];

	// init() initializes piece-square tables: the white halves of the tables are
	// copied from Bonus[] adding the piece value, then the black halves of the
	// tables are initialized by flipping and changing the sign of the white scores.
	public static void init()
	{

	  for (Piece pc = Piece.W_PAWN; pc.getValue() <= Piece.W_KING.getValue(); ++pc)
	  {
		  GlobalMembers.PieceValue[Phase.MG.getValue()][~pc] = GlobalMembers.PieceValue[Phase.MG.getValue()][pc.getValue()];
		  GlobalMembers.PieceValue[Phase.EG.getValue()][~pc] = GlobalMembers.PieceValue[Phase.EG.getValue()][pc.getValue()];

		  Score score = GlobalMembers.make_score(GlobalMembers.PieceValue[Phase.MG.getValue()][pc.getValue()].getValue(), GlobalMembers.PieceValue[Phase.EG.getValue()][pc.getValue()].getValue());

		  for (Square s = Square.SQ_A1; s.getValue() <= Square.SQ_H8.getValue(); ++s)
		  {
			  File f = Math.min(GlobalMembers.file_of(s), ~GlobalMembers.file_of(s));
			  psq[pc.getValue()][s.getValue()] = score + Bonus[pc.getValue()][GlobalMembers.rank_of(s).getValue()][f.getValue()];
			  psq[~pc][~s] = -psq[pc.getValue()][s.getValue()];
		  }
	  }
	}
}