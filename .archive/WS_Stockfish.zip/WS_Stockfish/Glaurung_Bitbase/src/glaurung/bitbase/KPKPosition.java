package glaurung.bitbase;
import glaurung.types.Color;
import glaurung.types.Square;

  public class KPKPosition
  {
	public final void from_index(int index)
	{
	  int s;
	  sideToMove = Color(index % 2);
	  blackKingSquare = Square((index / 2) % 64);
	  whiteKingSquare = Square((index / 128) % 64);
	  s = (index / 8192) % 24;
	  pawnSquare = GlobalMembers.make_square(File(s % 4), Rank(s / 4 + 1));
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: int to_index() const
	public final int to_index()
	{
	  return GlobalMembers.compute_index(whiteKingSquare, blackKingSquare, pawnSquare, sideToMove);
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean is_legal() const
	public final boolean is_legal()
	{
	  if (whiteKingSquare == pawnSquare || whiteKingSquare == blackKingSquare || pawnSquare == blackKingSquare)
	  {
		return false;
	  }
	  if (sideToMove == Color.WHITE)
	  {
		if (GlobalMembers.bit_is_set(this.wk_attacks(), blackKingSquare) != 0)
		{
		  return false;
		}
		if (GlobalMembers.bit_is_set(this.pawn_attacks(), blackKingSquare) != 0)
		{
		  return false;
		}
	  }
	  else
	  {
		if (GlobalMembers.bit_is_set(this.bk_attacks(), whiteKingSquare) != 0)
		{
		  return false;
		}
	  }
	  return true;
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean is_immediate_draw() const
	public final boolean is_immediate_draw()
	{
	  if (sideToMove == Color.BLACK)
	  {
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long wka = this->wk_attacks();
		long wka = this.wk_attacks();
  //C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
  //ORIGINAL LINE: unsigned long long bka = this->bk_attacks();
		long bka = this.bk_attacks();

		// Case 1: Stalemate
		if ((bka & ~(wka | this.pawn_attacks())) == GlobalMembers.EmptyBoardBB)
		{
		  return true;
		}

		// Case 2: King can capture pawn
		if (GlobalMembers.bit_is_set(bka, pawnSquare) != 0 && GlobalMembers.bit_is_set(wka, pawnSquare) == 0)
		{
		  return true;
		}
	  }
	  else
	  {
		// Case 1: Stalemate
		if (whiteKingSquare == Square.SQ_A8 && pawnSquare == Square.SQ_A7 && (blackKingSquare == Square.SQ_C7 || blackKingSquare == Square.SQ_C8))
		{
		  return true;
		}
	  }

	  return false;
	}

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: boolean is_immediate_win() const
	public final boolean is_immediate_win()
	{
	  // The position is an immediate win if it is white to move and the white
	  // pawn can be promoted without getting captured:
	  return sideToMove == Color.WHITE && GlobalMembers.square_rank(pawnSquare) == Rank.RANK_7 && (GlobalMembers.square_distance(blackKingSquare, pawnSquare + SquareDelta.DELTA_N) > 1 || GlobalMembers.bit_is_set(this.wk_attacks(), pawnSquare + SquareDelta.DELTA_N) != 0);
	}

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long wk_attacks() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong wk_attacks() const
	public final long wk_attacks()
	{
	  return StepAttackBB[Piece.WK.getValue()][whiteKingSquare.getValue()];
	}

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long bk_attacks() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong bk_attacks() const
	public final long bk_attacks()
	{
	  return StepAttackBB[Piece.BK.getValue()][blackKingSquare.getValue()];
	}

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long pawn_attacks() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: ulong pawn_attacks() const
	public final long pawn_attacks()
	{
	  return StepAttackBB[Piece.WP.getValue()][pawnSquare.getValue()];
	}

	public Square whiteKingSquare;
	public Square blackKingSquare;
	public Square pawnSquare;
	public Color sideToMove;
  }