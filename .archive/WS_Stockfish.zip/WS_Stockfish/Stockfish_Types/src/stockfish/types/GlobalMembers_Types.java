package stockfish.types;


import stockfish.types.Score;


public class GlobalMembers_Types
{
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_POPCNT
	public static final boolean HasPopCnt = true;
	///#else
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if USE_PEXT
	public static final boolean HasPext = true;
	///#else
	///#endif

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#if IS_64BIT
	public static final boolean Is64Bit = true;
	///#else
	///#endif


	public static final int MAX_MOVES = 256;
	public static final int MAX_PLY = 128;

//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern Value PieceValue[PHASE_NB][PIECE_NB];

	public static Score make_score(int mg, int eg)
	{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: return Score((int)((unsigned int)eg << 16) + mg);
	  return new Score((int)((int)eg << 16) + mg);
	}
	//{
	//	uint16_t u;
	//	int16_t s;
	//}
	public static Value eg_value(Score s)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	   eg = {uint16_t(int(s + 0x8000) >>> 16)};
	  return Value(eg.s);
	}
	//{
	//	uint16_t u;
	//	int16_t s;
	//}
	public static Value mg_value(Score s)
	{
	  long mg = s.getValue();
	  return new Value(s);
	}

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define ENABLE_BASE_OPERATORS_ON(T) constexpr T operator+(T d1, T d2) { return T(int(d1) + int(d2)); } constexpr T operator-(T d1, T d2) { return T(int(d1) - int(d2)); } constexpr T operator-(T d) { return T(-int(d)); } inline T& operator+=(T& d1, T d2) { return d1 = d1 + d2; } inline T& operator-=(T& d1, T d2) { return d1 = d1 - d2; }

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define ENABLE_INCR_OPERATORS_ON(T) inline T& operator++(T& d) { return d = T(int(d) + 1); } inline T& operator--(T& d) { return d = T(int(d) - 1); }

	//C++ TO JAVA CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define ENABLE_FULL_OPERATORS_ON(T) ENABLE_BASE_OPERATORS_ON(T) ENABLE_INCR_OPERATORS_ON(T) constexpr T operator*(int i, T d) { return T(i * int(d)); } constexpr T operator*(T d, int i) { return T(int(d) * i); } constexpr T operator/(T d, int i) { return T(int(d) / i); } constexpr int operator/(T d1, T d2) { return int(d1) / int(d2); } inline T& operator*=(T& d, int i) { return d = T(int(d) * i); } inline T& operator/=(T& d, int i) { return d = T(int(d) / i); }

	private Value subtract(Value d)
	{
		return Value(-d.getValue());
	}
	private Value addAssignment(Value d1, Value d2)
	{
		return d1 = d1 + d2;
	}
	private Value subtractAssignment(Value d1, Value d2)
	{
		return d1 = d1 - d2;
	}
	private Value increment(Value d)
	{
		return d = Value(d.getValue() + 1);
	}
	private Value decrement(Value d)
	{
		return d = Value(d.getValue() - 1);
	}
	private Value divide(Value d, int i)
	{
		return Value(d.getValue() / i);
	}
	private int divide(Value d1, Value d2)
	{
		return d1.getValue() / d2.getValue();
	}
	private Value multiplyAssignment(Value d, int i)
	{
		return d = Value(d.getValue() * i);
	}
	private Value divideAssignment(Value d, int i)
	{
		return d = Value(d.getValue() / i);
	}
	private Depth subtract(Depth d)
	{
		return Depth(-d.getValue());
	}
	private Depth addAssignment(Depth d1, Depth d2)
	{
		return d1 = d1 + d2;
	}
	private Depth subtractAssignment(Depth d1, Depth d2)
	{
		return d1 = d1 - d2;
	}
	private Depth increment(Depth d)
	{
		return d = Depth(d.getValue() + 1);
	}
	private Depth decrement(Depth d)
	{
		return d = Depth(d.getValue() - 1);
	}
	private Depth divide(Depth d, int i)
	{
		return Depth(d.getValue() / i);
	}
	private int divide(Depth d1, Depth d2)
	{
		return d1.getValue() / d2.getValue();
	}
	private Depth multiplyAssignment(Depth d, int i)
	{
		return d = Depth(d.getValue() * i);
	}
	private Depth divideAssignment(Depth d, int i)
	{
		return d = Depth(d.getValue() / i);
	}
	private Direction subtract(Direction d)
	{
		return Direction(-d.getValue());
	}
	private Direction addAssignment(Direction d1, Direction d2)
	{
		return d1 = d1 + d2;
	}
	private Direction subtractAssignment(Direction d1, Direction d2)
	{
		return d1 = d1 - d2;
	}
	private Direction increment(Direction d)
	{
		return d = Direction(d.getValue() + 1);
	}
	private Direction decrement(Direction d)
	{
		return d = Direction(d.getValue() - 1);
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Direction operator * (int i, Direction d)
	{
		return Direction(i * d.getValue());
	}
//C++ TO JAVA CONVERTER TODO TASK: The following operator cannot be converted to Java:
	Direction operator * (Direction d, int i)
	{
		return Direction(d.getValue() * i);
	}
	private Direction divide(Direction d, int i)
	{
		return Direction(d.getValue() / i);
	}
	private int divide(Direction d1, Direction d2)
	{
		return d1.getValue() / d2.getValue();
	}
	private Direction multiplyAssignment(Direction d, int i)
	{
		return d = Direction(d.getValue() * i);
	}
	private Direction divideAssignment(Direction d, int i)
	{
		return d = Direction(d.getValue() / i);
	}

	private PieceType increment(PieceType d)
	{
		return d = PieceType(d.getValue() + 1);
	}
	private PieceType decrement(PieceType d)
	{
		return d = PieceType(d.getValue() - 1);
	}
	private Piece increment(Piece d)
	{
		return d = Piece(d.getValue() + 1);
	}
	private Piece decrement(Piece d)
	{
		return d = Piece(d.getValue() - 1);
	}
	private Color increment(Color d)
	{
		return d = Color(d.getValue() + 1);
	}
	private Color decrement(Color d)
	{
		return d = Color(d.getValue() - 1);
	}
	private Square increment(Square d)
	{
		return d = Square(d.getValue() + 1);
	}
	private Square decrement(Square d)
	{
		return d = Square(d.getValue() - 1);
	}
	private File increment(File d)
	{
		return d = File(d.getValue() + 1);
	}
	private File decrement(File d)
	{
		return d = File(d.getValue() - 1);
	}
	private Rank increment(Rank d)
	{
		return d = Rank(d.getValue() + 1);
	}
	private Rank decrement(Rank d)
	{
		return d = Rank(d.getValue() - 1);
	}
	private Score subtract(Score d)
	{
		return Score(-d.getValue());
	}
	private Score addAssignment(Score d1, Score d2)
	{
		return d1 = d1 + d2;
	}
	private Score subtractAssignment(Score d1, Score d2)
	{
		return d1 = d1 - d2;
	}

	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef ENABLE_FULL_OPERATORS_ON
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef ENABLE_INCR_OPERATORS_ON
	//C++ TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
	///#undef ENABLE_BASE_OPERATORS_ON

	private Value addAssignment(Value v, int i)
	{
		return v = v + i;
	}
	private Value subtractAssignment(Value v, int i)
	{
		return v = v - i;
	}
	private Square addAssignment(Square s, Direction d)
	{
		return s = s + d;
	}
	private Square subtractAssignment(Square s, Direction d)
	{
		return s = s - d;
	}

	/// Only declared but not defined. We don't want to multiply two scores due to
	/// a very high risk of overflow. So user should explicitly convert to integer.
//C++ TO JAVA CONVERTER TODO TASK: Java has no equivalent to ' = delete':
	//Score operator *(Score, Score) = delete;

	/// Division of a Score must be handled separately for each term
	private Score divide(Score s, int i)
	{
	  return make_score(mg_value(s).getValue() / i, eg_value(s).getValue() / i);
	}

	private Color onesComplement(Color c)
	{
	  return Color(c ^ Color.BLACK); // Toggle color
	}

	private Square onesComplement(Square s)
	{
	  return Square(s ^ Square.SQ_A8); // Vertical flip SQ_A1 -> SQ_A8
	}

	private File onesComplement(File f)
	{
	  return File(f ^ File.FILE_H); // Horizontal flip FILE_A -> FILE_H
	}

	private Piece onesComplement(Piece pc)
	{
	  return Piece(pc ^ 8); // Swap color of piece B_KNIGHT -> W_KNIGHT
	}

	private CastlingRight bitwiseOr(Color c, CastlingSide s)
	{
	  return CastlingRight(CastlingRight.WHITE_OO.getValue() << ((s == CastlingSide.QUEEN_SIDE) + 2 * c));
	}

	public static int mate_in(int ply)
	{
	  return Value.VALUE_MATE.getValue() - ply;
	}

	public static int mated_in(int ply)
	{
	  return -Value.VALUE_MATE.getValue() + ply;
	}

	public static Square make_square(File f, Rank r)
	{
	  return Square((r.getValue() << 3) + f);
	}

	public static Piece make_piece(Color c, PieceType pt)
	{
	  return Piece((c.getValue() << 3) + pt);
	}

	public static PieceType type_of(Piece pc)
	{
	  return PieceType(pc & 7);
	}

	public static Color color_of(Piece pc)
	{
	  assert pc != Piece.NO_PIECE;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Color(pc.getValue() >> 3);
	}

	public static boolean is_ok(Square s)
	{
	  return s.getValue() >= Square.SQ_A1.getValue() && s.getValue() <= Square.SQ_H8.getValue();
	}

	public static File file_of(Square s)
	{
	  return File(s & 7);
	}

	public static Rank rank_of(Square s)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Rank(s.getValue() >> 3);
	}

	public static Square relative_square(Color c, Square s)
	{
	  return Square(s ^ (c * 56));
	}

	public static Rank relative_rank(Color c, Rank r)
	{
	  return Rank(r ^ (c * 7));
	}

	public static Rank relative_rank(Color c, Square s)
	{
	  return relative_rank(c, rank_of(s));
	}

	public static boolean opposite_colors(Square s1, Square s2)
	{
	  int s = s1.getValue() ^ s2.getValue();
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return (((s >> 3) ^ s) & 1) != 0;
	}

	public static Direction pawn_push(Color c)
	{
	  return c == Color.WHITE ? Direction.NORTH : Direction.SOUTH;
	}

	public static Square from_sq(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return Square((m.getValue() >> 6) & 0x3F);
	}

	public static Square to_sq(Move m)
	{
	  return Square(m & 0x3F);
	}

	public static int from_to(Move m)
	{
	 return (m & 0xFFF).getValue();
	}

	public static MoveType type_of(Move m)
	{
	  return MoveType(m & (3 << 14));
	}

	public static PieceType promotion_type(Move m)
	{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
	  return PieceType(((m.getValue() >> 12) & 3) + PieceType.KNIGHT);
	}

	public static Move make_move(Square from, Square to)
	{
	  return Move((from.getValue() << 6) + to);
	}

	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<MoveType T>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename T>
public static <T> Move make(Square from, Square to)
{
	return make(from, to, PieceType.KNIGHT);
}
//C++ TO JAVA CONVERTER NOTE: Java does not allow default values for parameters. Overloaded methods are inserted above:
//ORIGINAL LINE: constexpr Move make(Square from, Square to, PieceType pt = KNIGHT)
	public static <T> Move make(Square from, Square to, PieceType pt)
	{
	  return Move(T + ((pt - PieceType.KNIGHT) << 12) + (from.getValue() << 6) + to);
	}

	public static boolean is_ok(Move m)
	{
	  return from_sq(m) != to_sq(m); // Catch MOVE_NULL and MOVE_NONE
	}


}