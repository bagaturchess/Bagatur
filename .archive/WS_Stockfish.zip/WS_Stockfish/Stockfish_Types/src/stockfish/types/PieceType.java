package stockfish.types;
public enum PieceType
{
  NO_PIECE_TYPE(0),
  PAWN(1),
  KNIGHT(2),
  BISHOP(3),
  ROOK(4),
  QUEEN(5),
  KING(6),
  ALL_PIECES(0),
  PIECE_TYPE_NB(8);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, PieceType> mappings;
	private static java.util.HashMap<Integer, PieceType> getMappings()
	{
		if (mappings == null)
		{
			synchronized (PieceType.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, PieceType>();
				}
			}
		}
		return mappings;
	}

	private PieceType(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static PieceType forValue(int value)
	{
		return getMappings().get(value);
	}
}