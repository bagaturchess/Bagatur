package stockfish.types;
public enum CastlingRight
{
  NO_CASTLING(0),
  WHITE_OO(1),
  WHITE_OOO(1 << 1),
  BLACK_OO(1 << 2),
  BLACK_OOO(1 << 3),
  ANY_CASTLING(1 | 1 << 1 | 1 << 2 | 1 << 3),
  CASTLING_RIGHT_NB(16);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, CastlingRight> mappings;
	private static java.util.HashMap<Integer, CastlingRight> getMappings()
	{
		if (mappings == null)
		{
			synchronized (CastlingRight.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, CastlingRight>();
				}
			}
		}
		return mappings;
	}

	private CastlingRight(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static CastlingRight forValue(int value)
	{
		return getMappings().get(value);
	}
}