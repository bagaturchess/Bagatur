package stockfish.types;
public enum ScaleFactor
{
  SCALE_FACTOR_DRAW(0),
  SCALE_FACTOR_NORMAL(64),
  SCALE_FACTOR_MAX(128),
  SCALE_FACTOR_NONE(255);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, ScaleFactor> mappings;
	private static java.util.HashMap<Integer, ScaleFactor> getMappings()
	{
		if (mappings == null)
		{
			synchronized (ScaleFactor.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, ScaleFactor>();
				}
			}
		}
		return mappings;
	}

	private ScaleFactor(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static ScaleFactor forValue(int value)
	{
		return getMappings().get(value);
	}
}