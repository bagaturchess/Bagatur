package stockfish.types;
public enum MoveType
{
  NORMAL(0),
  PROMOTION(1 << 14),
  ENPASSANT(2 << 14),
  CASTLING(3 << 14);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, MoveType> mappings;
	private static java.util.HashMap<Integer, MoveType> getMappings()
	{
		if (mappings == null)
		{
			synchronized (MoveType.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, MoveType>();
				}
			}
		}
		return mappings;
	}

	private MoveType(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static MoveType forValue(int value)
	{
		return getMappings().get(value);
	}
}