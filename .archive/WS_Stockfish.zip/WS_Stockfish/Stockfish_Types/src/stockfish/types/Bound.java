package stockfish.types;
public enum Bound
{
  BOUND_NONE(0),
  BOUND_UPPER(1),
  BOUND_LOWER(2),
  BOUND_EXACT(1 | 2);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Bound> mappings;
	private static java.util.HashMap<Integer, Bound> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Bound.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Bound>();
				}
			}
		}
		return mappings;
	}

	private Bound(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Bound forValue(int value)
	{
		return getMappings().get(value);
	}
}