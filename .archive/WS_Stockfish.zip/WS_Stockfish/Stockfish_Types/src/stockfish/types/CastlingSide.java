package stockfish.types;
public enum CastlingSide
{
  KING_SIDE(0),
  QUEEN_SIDE(1),
  CASTLING_SIDE_NB(2);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, CastlingSide> mappings;
	private static java.util.HashMap<Integer, CastlingSide> getMappings()
	{
		if (mappings == null)
		{
			synchronized (CastlingSide.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, CastlingSide>();
				}
			}
		}
		return mappings;
	}

	private CastlingSide(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static CastlingSide forValue(int value)
	{
		return getMappings().get(value);
	}
}