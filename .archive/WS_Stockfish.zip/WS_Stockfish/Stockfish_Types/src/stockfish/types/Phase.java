package stockfish.types;
public enum Phase
{
  PHASE_ENDGAME(0),
  PHASE_MIDGAME(128),
  MG(0),
  EG(1),
  PHASE_NB(2);

	public static final int SIZE = java.lang.Integer.SIZE;

	private int intValue;
	private static java.util.HashMap<Integer, Phase> mappings;
	private static java.util.HashMap<Integer, Phase> getMappings()
	{
		if (mappings == null)
		{
			synchronized (Phase.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, Phase>();
				}
			}
		}
		return mappings;
	}

	private Phase(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static Phase forValue(int value)
	{
		return getMappings().get(value);
	}
}