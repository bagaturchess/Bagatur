package glaurung.endgame;
import glaurung.position.GlobalMembers;
import glaurung.position.Position;
import glaurung.types.ScaleFactor;

import java.io.*;

// KNP vs K:
public class KNPKScalingFunction extends ScalingFunction
{
  public KNPKScalingFunction(Color c)
  {
	  super(c);
  }


  /// KNPKScalingFunction scales KNP vs K endgames.  There is a single rule:
  /// If the pawn is a rook pawn on the 7th rank and the defending king prevents
  /// the pawn from advancing, the position is drawn.

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.KnightValueMidgame;
	assert pos.knight_count(strongerSide) == 1;
	assert pos.pawn_count(strongerSide) == 1;
	assert pos.non_pawn_material(weakerSide) == Value(0);
	assert pos.pawn_count(weakerSide) == 0;

	Square pawnSq = pos.pawn_list(strongerSide, 0);
	Square weakerKingSq = pos.king_square(weakerSide);

	if (pawnSq == GlobalMembers.relative_square(strongerSide, Square.SQ_A7) && GlobalMembers.square_distance(weakerKingSq, GlobalMembers.relative_square(strongerSide, Square.SQ_A8)) <= 1)
	{
	  return ScaleFactor(0);
	}

	if (pawnSq == GlobalMembers.relative_square(strongerSide, Square.SQ_H7) && GlobalMembers.square_distance(weakerKingSq, GlobalMembers.relative_square(strongerSide, Square.SQ_H8)) <= 1)
	{
	  return ScaleFactor(0);
	}

	return ScaleFactor.SCALE_FACTOR_NONE;
  }
}