package glaurung.endgame;
import glaurung.position.GlobalMembers;
import glaurung.position.Position;

import java.io.*;

// KQ vs KR:
public class KQKREvaluationFunction extends EndgameEvaluationFunction
{
  public KQKREvaluationFunction(Color c)
  {
	  super(c);
  }


  /// KQ vs KR.  This is almost identical to KX vs K:  We give the attacking
  /// king a bonus for having the kings close together, and for forcing the
  /// defending king towards the edge.  If we also take care to avoid null move
  /// for the defending side in the search, this is usually sufficient to be
  /// able to win KQ vs KR.

  @Override
  public final Value apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.QueenValueMidgame;
	assert pos.pawn_count(strongerSide) == 0;
	assert pos.non_pawn_material(weakerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(weakerSide) == 0;

	Square winnerKSq = pos.king_square(strongerSide);
	Square loserKSq = pos.king_square(weakerSide);

	Value result = GlobalMembers.QueenValueEndgame - GlobalMembers.RookValueEndgame + GlobalMembers.mate_table(loserKSq) + GlobalMembers.distance_bonus(GlobalMembers.square_distance(winnerKSq, loserKSq));

	return (strongerSide == pos.side_to_move())? result : -result;
  }
}