package glaurung.endgame;
import glaurung.position.GlobalMembers;
import glaurung.position.Position;

import java.io.*;

// KR vs KP:
public class KRKPEvaluationFunction extends EndgameEvaluationFunction
{
  public KRKPEvaluationFunction(Color c)
  {
	  super(c);
  }


  /// KR vs KP.  This is a somewhat tricky endgame to evaluate precisely without
  /// a bitbase.  The function below returns drawish scores when the pawn is
  /// far advanced with support of the king, while the attacking king is far
  /// away.

  @Override
  public final Value apply(Position pos)
  {

	assert pos.non_pawn_material(strongerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(strongerSide) == 0;
	assert pos.non_pawn_material(weakerSide) == 0;
	assert pos.pawn_count(weakerSide) == 1;

	Square wksq;
	Square wrsq;
	Square bksq;
	Square bpsq;
	int tempo = (pos.side_to_move() == strongerSide);

	wksq = pos.king_square(strongerSide);
	wrsq = pos.rook_list(strongerSide, 0);
	bksq = pos.king_square(weakerSide);
	bpsq = pos.pawn_list(weakerSide, 0);

	if (strongerSide == Color.BLACK)
	{
	  wksq = GlobalMembers.flip_square(wksq);
	  wrsq = GlobalMembers.flip_square(wrsq);
	  bksq = GlobalMembers.flip_square(bksq);
	  bpsq = GlobalMembers.flip_square(bpsq);
	}

	Square queeningSq = GlobalMembers.make_square(GlobalMembers.square_file(bpsq), Rank.RANK_1);
	Value result;

	// If the stronger side's king is in front of the pawn, it's a win:
	if (wksq.getValue() < bpsq.getValue() && GlobalMembers.square_file(wksq) == GlobalMembers.square_file(bpsq))
	{
	  result = GlobalMembers.RookValueEndgame - Value(GlobalMembers.square_distance(wksq, bpsq));
	}

	// If the weaker side's king is too far from the pawn and the rook,
	// it's a win:
	else if (GlobalMembers.square_distance(bksq, bpsq) - (tempo ^ 1) >= 3 && GlobalMembers.square_distance(bksq, wrsq) >= 3)
	{
	  result = GlobalMembers.RookValueEndgame - Value(GlobalMembers.square_distance(wksq, bpsq));
	}

	// If the pawn is far advanced and supported by the defending king,
	// the position is drawish:
	else if (GlobalMembers.square_rank(bksq) <= Rank.RANK_3.getValue() && GlobalMembers.square_distance(bksq, bpsq) == 1 && GlobalMembers.square_rank(wksq) >= Rank.RANK_4.getValue() && GlobalMembers.square_distance(wksq, bpsq) - tempo > 2)
	{
	  result = Value(80 - GlobalMembers.square_distance(wksq, bpsq) * 8);
	}

	else
	{
	  result = Value(200) - Value(GlobalMembers.square_distance(wksq, bpsq + SquareDelta.DELTA_S) * 8) + Value(GlobalMembers.square_distance(bksq, bpsq + SquareDelta.DELTA_S) * 8) + Value(GlobalMembers.square_distance(bpsq, queeningSq) * 8);
	}

	return (strongerSide == pos.side_to_move())? result : -result;
  }
}