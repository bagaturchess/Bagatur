package glaurung.endgame;
import glaurung.types.Color;

public class GlobalMembers
{
	////
	//// Constants and variables
	////

	// Generic "mate lone king" eval:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KXKEvaluationFunction EvaluateKXK, EvaluateKKX;

	// KBN vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBNKEvaluationFunction EvaluateKBNK, EvaluateKKBN;

	// KP vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KPKEvaluationFunction EvaluateKPK, EvaluateKKP;

	// KR vs KP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRKPEvaluationFunction EvaluateKRKP, EvaluateKPKR;

	// KR vs KB:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRKBEvaluationFunction EvaluateKRKB, EvaluateKBKR;

	// KR vs KN:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRKNEvaluationFunction EvaluateKRKN, EvaluateKNKR;

	// KQ vs KR:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KQKREvaluationFunction EvaluateKQKR, EvaluateKRKQ;

	// KBB vs KN:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBBKNEvaluationFunction EvaluateKBBKN, EvaluateKNKBB;

	// K and two minors vs K and one or two minors:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KmmKmEvaluationFunction EvaluateKmmKm;


	// KBP vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBPKScalingFunction ScaleKBPK, ScaleKKBP;

	// KQ vs KRP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KQKRPScalingFunction ScaleKQKRP, ScaleKRPKQ;

	// KRP vs KR:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRPKRScalingFunction ScaleKRPKR, ScaleKRKRP;

	// KRPP vs KRP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KRPPKRPScalingFunction ScaleKRPPKRP, ScaleKRPKRPP;

	// King and pawns vs king:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KPsKScalingFunction ScaleKPsK, ScaleKKPs;

	// KBP vs KB:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBPKBScalingFunction ScaleKBPKB, ScaleKBKBP;

	// KBP vs KN:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KBPKNScalingFunction ScaleKBPKN, ScaleKNKBP;

	// KNP vs K:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KNPKScalingFunction ScaleKNPK, ScaleKKNP;

	// KP vs KP:
//C++ TO JAVA CONVERTER NOTE: 'extern' variable declarations are not required in Java:
	//extern KPKPScalingFunction ScaleKPKPw, ScaleKPKPb;

/// init_bitbases() is called during program initialization, and simply loads
/// bitbases from disk into memory.  At the moment, there is only the bitbase
/// for KP vs K, but we may decide to add other bitbases later.



	////
	//// Prototypes
	////

	public static void init_bitbases()
	{
	  generate_kpk_bitbase(KPKBitbase);
	}





	////
	//// Constants and variables
	////

	/// Evaluation functions

	// Generic "mate lone king" eval:
	public static KXKEvaluationFunction EvaluateKXK = new KXKEvaluationFunction(Color.WHITE);
	public static KXKEvaluationFunction EvaluateKKX = new KXKEvaluationFunction(Color.BLACK);

	// KBN vs K:
	public static KBNKEvaluationFunction EvaluateKBNK = new KBNKEvaluationFunction(Color.WHITE);
	public static KBNKEvaluationFunction EvaluateKKBN = new KBNKEvaluationFunction(Color.BLACK);

	// KP vs K:
	public static KPKEvaluationFunction EvaluateKPK = new KPKEvaluationFunction(Color.WHITE);
	public static KPKEvaluationFunction EvaluateKKP = new KPKEvaluationFunction(Color.BLACK);

	// KR vs KP:
	public static KRKPEvaluationFunction EvaluateKRKP = new KRKPEvaluationFunction(Color.WHITE);
	public static KRKPEvaluationFunction EvaluateKPKR = new KRKPEvaluationFunction(Color.BLACK);

	// KR vs KB:
	public static KRKBEvaluationFunction EvaluateKRKB = new KRKBEvaluationFunction(Color.WHITE);
	public static KRKBEvaluationFunction EvaluateKBKR = new KRKBEvaluationFunction(Color.BLACK);

	// KR vs KN:
	public static KRKNEvaluationFunction EvaluateKRKN = new KRKNEvaluationFunction(Color.WHITE);
	public static KRKNEvaluationFunction EvaluateKNKR = new KRKNEvaluationFunction(Color.BLACK);

	// KQ vs KR:
	public static KQKREvaluationFunction EvaluateKQKR = new KQKREvaluationFunction(Color.WHITE);
	public static KQKREvaluationFunction EvaluateKRKQ = new KQKREvaluationFunction(Color.BLACK);

	// KBB vs KN:
	public static KBBKNEvaluationFunction EvaluateKBBKN = new KBBKNEvaluationFunction(Color.WHITE);
	public static KBBKNEvaluationFunction EvaluateKNKBB = new KBBKNEvaluationFunction(Color.BLACK);

	// K and two minors vs K and one or two minors:
	public static KmmKmEvaluationFunction EvaluateKmmKm = new KmmKmEvaluationFunction(Color.WHITE);


	/// Scaling functions

	// KBP vs K:
	public static KBPKScalingFunction ScaleKBPK = new KBPKScalingFunction(Color.WHITE);
	public static KBPKScalingFunction ScaleKKBP = new KBPKScalingFunction(Color.BLACK);

	// KQ vs KRP:
	public static KQKRPScalingFunction ScaleKQKRP = new KQKRPScalingFunction(Color.WHITE);
	public static KQKRPScalingFunction ScaleKRPKQ = new KQKRPScalingFunction(Color.BLACK);

	// KRP vs KR:
	public static KRPKRScalingFunction ScaleKRPKR = new KRPKRScalingFunction(Color.WHITE);
	public static KRPKRScalingFunction ScaleKRKRP = new KRPKRScalingFunction(Color.BLACK);

	// KRPP vs KRP:
	public static KRPPKRPScalingFunction ScaleKRPPKRP = new KRPPKRPScalingFunction(Color.WHITE);
	public static KRPPKRPScalingFunction ScaleKRPKRPP = new KRPPKRPScalingFunction(Color.BLACK);

	// King and pawns vs king:
	public static KPsKScalingFunction ScaleKPsK = new KPsKScalingFunction(Color.WHITE);
	public static KPsKScalingFunction ScaleKKPs = new KPsKScalingFunction(Color.BLACK);

	// KBP vs KB:
	public static KBPKBScalingFunction ScaleKBPKB = new KBPKBScalingFunction(Color.WHITE);
	public static KBPKBScalingFunction ScaleKBKBP = new KBPKBScalingFunction(Color.BLACK);

	// KBP vs KN:
	public static KBPKNScalingFunction ScaleKBPKN = new KBPKNScalingFunction(Color.WHITE);
	public static KBPKNScalingFunction ScaleKNKBP = new KBPKNScalingFunction(Color.BLACK);

	// KNP vs K:
	public static KNPKScalingFunction ScaleKNPK = new KNPKScalingFunction(Color.WHITE);
	public static KNPKScalingFunction ScaleKKNP = new KNPKScalingFunction(Color.BLACK);

	// KPKP
	public static KPKPScalingFunction ScaleKPKPw = new KPKPScalingFunction(Color.WHITE);
	public static KPKPScalingFunction ScaleKPKPb = new KPKPScalingFunction(Color.BLACK);


	////
	//// Local definitions
	////


	  // Table used to drive the defending king towards the edge of the board
	  // in KX vs K and KQ vs KR endgames:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned char MateTable[64] = { 100, 90, 80, 70, 70, 80, 90, 100, 90, 70, 60, 50, 50, 60, 70, 90, 80, 60, 40, 30, 30, 40, 60, 80, 70, 50, 30, 20, 20, 30, 50, 70, 70, 50, 30, 20, 20, 30, 50, 70, 80, 60, 40, 30, 30, 40, 60, 80, 90, 70, 60, 50, 50, 60, 70, 90, 100, 90, 80, 70, 70, 80, 90, 100, };
	  public static final byte[] MateTable = {100, 90, 80, 70, 70, 80, 90, 100, 90, 70, 60, 50, 50, 60, 70, 90, 80, 60, 40, 30, 30, 40, 60, 80, 70, 50, 30, 20, 20, 30, 50, 70, 70, 50, 30, 20, 20, 30, 50, 70, 80, 60, 40, 30, 30, 40, 60, 80, 90, 70, 60, 50, 50, 60, 70, 90, 100, 90, 80, 70, 70, 80, 90, 100};

	  // Table used to drive the defending king towards a corner square of the
	  // right color in KBN vs K endgames:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned char KBNKMateTable[64] = { 200, 190, 180, 170, 160, 150, 140, 130, 190, 180, 170, 160, 150, 140, 130, 140, 180, 170, 155, 140, 140, 125, 140, 150, 170, 160, 140, 120, 110, 140, 150, 160, 160, 150, 140, 110, 120, 140, 160, 170, 150, 140, 125, 140, 140, 155, 170, 180, 140, 130, 140, 150, 160, 170, 180, 190, 130, 140, 150, 160, 170, 180, 190, 200 };
	  public static final byte[] KBNKMateTable = {(byte)200, (byte)190, (byte)180, (byte)170, (byte)160, (byte)150, (byte)140, (byte)130, (byte)190, (byte)180, (byte)170, (byte)160, (byte)150, (byte)140, (byte)130, (byte)140, (byte)180, (byte)170, (byte)155, (byte)140, (byte)140, 125, (byte)140, (byte)150, (byte)170, (byte)160, (byte)140, 120, 110, (byte)140, (byte)150, (byte)160, (byte)160, (byte)150, (byte)140, 110, 120, (byte)140, (byte)160, (byte)170, (byte)150, (byte)140, 125, (byte)140, (byte)140, (byte)155, (byte)170, (byte)180, (byte)140, (byte)130, (byte)140, (byte)150, (byte)160, (byte)170, (byte)180, (byte)190, (byte)130, (byte)140, (byte)150, (byte)160, (byte)170, (byte)180, (byte)190, (byte)200};

	  // The attacking side is given a descending bonus based on distance between
	  // the two kings in basic endgames:
	  public static final int[] DistanceBonus = {0, 0, 100, 80, 60, 40, 20, 10};

	  // Bitbase for KP vs K:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char KPKBitbase[24576];
	  public static byte[] KPKBitbase = new byte[24576];

	  // Penalty for big distance between king and knight for the defending king
	  // and knight in KR vs KN endgames:
	  public static final int[] KRKNKingKnightDistancePenalty = {0, 0, 4, 10, 20, 32, 48, 70};

	  // Various inline functions for accessing the above arrays:

	  public static Value mate_table(Square s)
	  {
		return Value(MateTable[s.getValue()]);
	  }

	  public static Value kbnk_mate_table(Square s)
	  {
		return Value(KBNKMateTable[s.getValue()]);
	  }

	  public static Value distance_bonus(int d)
	  {
		return Value(DistanceBonus[d]);
	  }

	  public static Value krkn_king_knight_distance_penalty(int d)
	  {
		return Value(KRKNKingKnightDistancePenalty[d]);
	  }

  // Probe the KP vs K bitbase:


	  // Function for probing the KP vs K bitbase:
	  public static int probe_kpk(Square wksq, Square wpsq, Square bksq, Color stm)
	  {
		int wp = square_file(wpsq).getValue() + (square_rank(wpsq).getValue() - 1) * 4;
		int index = stm.getValue() + 2 * bksq.getValue() + 128 * wksq.getValue() + 8192 * wp;

		assert index >= 0 && index < 24576 * 8;
		return KPKBitbase[index / 8] & (1 << (index & 7));
	  }
}