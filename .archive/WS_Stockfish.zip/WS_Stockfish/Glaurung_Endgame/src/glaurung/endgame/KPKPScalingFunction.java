package glaurung.endgame;
import glaurung.position.GlobalMembers;
import glaurung.position.Position;
import glaurung.types.ScaleFactor;

import java.io.*;

// KP vs KP:
public class KPKPScalingFunction extends ScalingFunction
{
  public KPKPScalingFunction(Color c)
  {
	  super(c);
  }


  /// KPKPScalingFunction scales KP vs KP endgames.  This is done by removing
  /// the weakest side's pawn and probing the KP vs K bitbase:  If the weakest
  /// side has a draw without the pawn, she probably has at least a draw with
  /// the pawn as well.  The exception is when the stronger side's pawn is far
  /// advanced and not on a rook file; in this case it is often possible to win
  /// (e.g. 8/4k3/3p4/3P4/6K1/8/8/8 w - - 0 1).

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == Value(0);
	assert pos.non_pawn_material(weakerSide) == Value(0);
	assert pos.pawn_count(Color.WHITE) == 1;
	assert pos.pawn_count(Color.BLACK) == 1;

	Square wksq;
	Square bksq;
	Square wpsq;
	Color stm;

	if (strongerSide == Color.WHITE)
	{
	  wksq = pos.king_square(Color.WHITE);
	  bksq = pos.king_square(Color.BLACK);
	  wpsq = pos.pawn_list(Color.WHITE, 0);
	  stm = pos.side_to_move();
	}
	else
	{
	  wksq = GlobalMembers.flip_square(pos.king_square(Color.BLACK));
	  bksq = GlobalMembers.flip_square(pos.king_square(Color.WHITE));
	  wpsq = GlobalMembers.flip_square(pos.pawn_list(Color.BLACK, 0));
	  stm = GlobalMembers.opposite_color(pos.side_to_move());
	}

	if (GlobalMembers.square_file(wpsq) >= File.FILE_E.getValue())
	{
	  wksq = GlobalMembers.flop_square(wksq);
	  bksq = GlobalMembers.flop_square(bksq);
	  wpsq = GlobalMembers.flop_square(wpsq);
	}

	// If the pawn has advanced to the fifth rank or further, and is not a
	// rook pawn, it's too dangerous to assume that it's at least a draw.
	if (GlobalMembers.square_rank(wpsq) >= Rank.RANK_5.getValue() && GlobalMembers.square_file(wpsq) != File.FILE_A)
	{
	  return ScaleFactor.SCALE_FACTOR_NONE;
	}

	// Probe the KPK bitbase with the weakest side's pawn removed.  If it's a
	// draw, it's probably at least a draw even with the pawn.
	if (GlobalMembers.probe_kpk(wksq, wpsq, bksq, stm) != 0)
	{
	  return ScaleFactor.SCALE_FACTOR_NONE;
	}
	else
	{
	  return ScaleFactor(0);
	}
  }
}