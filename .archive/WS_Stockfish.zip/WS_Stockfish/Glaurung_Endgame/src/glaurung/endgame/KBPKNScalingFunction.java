package glaurung.endgame;
import glaurung.position.GlobalMembers;
import glaurung.position.Position;
import glaurung.types.ScaleFactor;

import java.io.*;

// KBP vs KN:
public class KBPKNScalingFunction extends ScalingFunction
{
  public KBPKNScalingFunction(Color c)
  {
	  super(c);
  }


  /// KBPKNScalingFunction scales KBP vs KN endgames.  There is a single rule:
  /// If the defending king is somewhere along the path of the pawn, and the
  /// square of the king is not of the same color as the stronger side's bishop,
  /// it's a draw.

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.BishopValueMidgame;
	assert pos.bishop_count(strongerSide) == 1;
	assert pos.pawn_count(strongerSide) == 1;
	assert pos.non_pawn_material(weakerSide) == GlobalMembers.KnightValueMidgame;
	assert pos.knight_count(weakerSide) == 1;
	assert pos.pawn_count(weakerSide) == 0;

	Square pawnSq = pos.pawn_list(strongerSide, 0);
	Square strongerBishopSq = pos.bishop_list(strongerSide, 0);
	Square weakerKingSq = pos.king_square(weakerSide);

	if (GlobalMembers.square_file(weakerKingSq) == GlobalMembers.square_file(pawnSq) && GlobalMembers.pawn_rank(strongerSide, pawnSq) < GlobalMembers.pawn_rank(strongerSide, weakerKingSq) && (GlobalMembers.square_color(weakerKingSq) != GlobalMembers.square_color(strongerBishopSq) || GlobalMembers.pawn_rank(strongerSide, weakerKingSq) <= Rank.RANK_6.getValue()))
	{
	  return ScaleFactor(0);
	}

	return ScaleFactor.SCALE_FACTOR_NONE;
  }
}