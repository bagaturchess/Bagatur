package glaurung.endgame;


import glaurung.position.Position;
import glaurung.types.Color;
import glaurung.types.ScaleFactor;

import java.io.*;

/// Abstract base class for all evaluation scaling functions:

public abstract class ScalingFunction implements Closeable
{
  public ScalingFunction(Color c)
  {
	strongerSide = c;
	weakerSide = glaurung.types.GlobalMembers.opposite_color(c);
  }

  public void close()
  {
  }

  public abstract ScaleFactor apply(Position pos);

  protected Color strongerSide;
  protected Color weakerSide;
}