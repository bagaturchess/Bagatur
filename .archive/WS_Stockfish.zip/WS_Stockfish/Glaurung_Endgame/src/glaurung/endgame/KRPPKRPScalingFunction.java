package glaurung.endgame;
import glaurung.position.GlobalMembers;
import glaurung.position.Position;
import glaurung.types.ScaleFactor;

import java.io.*;

// KRPP vs KRP:
public class KRPPKRPScalingFunction extends ScalingFunction
{
  public KRPPKRPScalingFunction(Color c)
  {
	  super(c);
  }


  /// KRPPKRPScalingFunction scales KRPP vs KRP endgames.  There is only a
  /// single pattern:  If the stronger side has no pawns and the defending king
  /// is actively placed, the position is drawish.

  @Override
  public final ScaleFactor apply(Position pos)
  {
	assert pos.non_pawn_material(strongerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(strongerSide) == 2;
	assert pos.non_pawn_material(weakerSide) == GlobalMembers.RookValueMidgame;
	assert pos.pawn_count(weakerSide) == 1;

	Square wpsq1 = pos.pawn_list(strongerSide, 0);
	Square wpsq2 = pos.pawn_list(strongerSide, 1);
	Square bksq = pos.king_square(weakerSide);

	// Does the stronger side have a passed pawn?
	if (pos.pawn_is_passed(strongerSide, wpsq1) || pos.pawn_is_passed(strongerSide, wpsq2))
	{
	  return ScaleFactor.SCALE_FACTOR_NONE;
	}

	Rank r = (((GlobalMembers.pawn_rank(strongerSide, wpsq1)) < (GlobalMembers.pawn_rank(strongerSide, wpsq2)))? (GlobalMembers.pawn_rank(strongerSide, wpsq2)) : (GlobalMembers.pawn_rank(strongerSide, wpsq1)));

	if (GlobalMembers.file_distance(bksq, wpsq1) <= 1 && GlobalMembers.file_distance(bksq, wpsq2) <= 1 && GlobalMembers.pawn_rank(strongerSide, bksq) > r.getValue())
	{
	  switch (r)
	  {

	  case RANK_2:
		  return ScaleFactor(10);
	  case RANK_3:
		  return ScaleFactor(10);
	  case RANK_4:
		  return ScaleFactor(15);
	  case RANK_5:
		  return ScaleFactor(20);
	  case RANK_6:
		  return ScaleFactor(40);
	  default:
		  assert false;

	  }
	}
	return ScaleFactor.SCALE_FACTOR_NONE;
  }
}