package glaurung.endgame;
import glaurung.position.Position;

import java.io.*;

// K and two minors vs K and one or two minors:
public class KmmKmEvaluationFunction extends EndgameEvaluationFunction
{
  public KmmKmEvaluationFunction(Color c)
  {
	  super(c);
  }

  @Override
  public final Value apply(Position pos)
  {
	return Value(0);
  }
}