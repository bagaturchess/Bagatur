package glaurung.pawns;
import glaurung.types.Color;
import glaurung.types.File;


/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


////
//// Includes
////


/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/



////
//// Includes
////



////
//// Types
////

/// PawnInfo is a class which contains various information about a pawn 
/// structure.  Currently, it only includes a middle game and an end game
/// pawn structure evaluation, and a bitboard of passed pawns.  We may want
/// to add further information in the future.  A lookup to the pawn hash table
/// (performed by calling the get_pawn_info method in a PawnInfoTable object)
/// returns a pointer to a PawnInfo object.

public class PawnInfo
{

//C++ TO JAVA CONVERTER TODO TASK: Java has no concept of a 'friend' class:
//  friend class PawnInfoTable;


  ////
  //// Inline functions
  ////

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value mg_value() const
  public final int mg_value()
  {
	return mgValue;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value eg_value() const
  public final int eg_value()
  {
	return egValue;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value kingside_storm_value(Color c) const
  public final int kingside_storm_value(Color c)
  {
	return ksStormValue[c.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value queenside_storm_value(Color c) const
  public final int queenside_storm_value(Color c)
  {
	return qsStormValue[c.getValue()];
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long passed_pawns() const;
//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ulong passed_pawns() const
  public final long passed_pawns()
  {
	return passedPawns;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean file_is_half_open(Color c, File f) const
  public final boolean file_is_half_open(Color c, File f)
  {
	return (halfOpenFiles[c.getValue()] & (1 << f.getValue())) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean has_open_file_to_left(Color c, File f) const
  public final boolean has_open_file_to_left(Color c, File f)
  {
	return (halfOpenFiles[c.getValue()] & ((1 << f.getValue()) - 1)) != 0;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean has_open_file_to_right(Color c, File f) const
  public final boolean has_open_file_to_right(Color c, File f)
  {
	return (halfOpenFiles[c.getValue()] & ~((1 << (int)(f.getValue() + 1)) - 1)) != 0;
  }

  private void clear()
  {
	mgValue = egValue = 0;
	passedPawns = 0l;
	
	ksStormValue = glaurung.pawns.StringFunctions.changeCharacter(ksStormValue, Color.WHITE.getValue(), ksStormValue[Color.BLACK.getValue()]);
	qsStormValue = glaurung.pawns.StringFunctions.changeCharacter(qsStormValue, Color.WHITE.getValue(), qsStormValue[Color.BLACK.getValue()]);
	ksStormValue[Color.BLACK.getValue()] = 0;
	qsStormValue[Color.BLACK.getValue()] = 0;
	
	halfOpenFiles[Color.WHITE.getValue()] = halfOpenFiles[Color.BLACK.getValue()] = (byte)0xFF;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long key;
  private long key;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long passedPawns;
  private long passedPawns;
  private short mgValue;
  private short egValue;
  private char[] ksStormValue = new char[2];
  private char[] qsStormValue = new char[2];
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned char halfOpenFiles[2];
  private byte[] halfOpenFiles = new byte[2];
}