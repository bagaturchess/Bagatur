package glaurung.pawns;
public class GlobalMembers
{
	////
	//// Local definitions
	////


	  /// Constants and variables

	  // Doubled pawn penalty by file, middle game.
	  public static final Value[] DoubledPawnMidgamePenalty = {Value(20), Value(30), Value(34), Value(34), Value(34), Value(34), Value(30), Value(20)};

	  // Doubled pawn penalty by file, endgame.
	  public static final Value[] DoubledPawnEndgamePenalty = {Value(35), Value(40), Value(40), Value(40), Value(40), Value(40), Value(40), Value(35)};

	  // Isolated pawn penalty by file, middle game.
	  public static final Value[] IsolatedPawnMidgamePenalty = {Value(20), Value(30), Value(34), Value(34), Value(34), Value(34), Value(30), Value(20)};

	  // Isolated pawn penalty by file, endgame.
	  public static final Value[] IsolatedPawnEndgamePenalty = {Value(35), Value(40), Value(40), Value(40), Value(40), Value(40), Value(40), Value(35)};

	  // Backward pawn penalty by file, middle game.
	  public static final Value[] BackwardPawnMidgamePenalty = {Value(16), Value(24), Value(27), Value(27), Value(27), Value(27), Value(24), Value(16)};

	  // Backward pawn penalty by file, endgame.
	  public static final Value[] BackwardPawnEndgamePenalty = {Value(28), Value(32), Value(32), Value(32), Value(32), Value(32), Value(32), Value(28)};

	  // Pawn chain membership bonus by file, middle game. 
	  public static final Value[] ChainMidgameBonus = {Value(14), Value(16), Value(17), Value(18), Value(18), Value(17), Value(16), Value(14)};

	  // Pawn chain membership bonus by file, endgame. 
	  public static final Value[] ChainEndgameBonus = {Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16), Value(16)};

	  // Candidate passed pawn bonus by rank, middle game.
	  public static final Value[] CandidateMidgameBonus = {Value(0), Value(12), Value(12), Value(20), Value(40), Value(90), Value(0), Value(0)};

	  // Candidate passed pawn bonus by rank, endgame.
	  public static final Value[] CandidateEndgameBonus = {Value(0), Value(24), Value(24), Value(40), Value(80), Value(180), Value(0), Value(0)};

	  // Pawn storm tables for positions with opposite castling:
	  public static final int[] QStormTable = {0, 0, 0, 0, 0, 0, 0, 0, -22, -22, -22, -13, -4, 0, 0, 0, -4, -9, -9, -9, -4, 0, 0, 0, 9, 18, 22, 18, 9, 0, 0, 0, 22, 31, 31, 22, 0, 0, 0, 0, 31, 40, 40, 31, 0, 0, 0, 0, 31, 40, 40, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	  public static final int[] KStormTable = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -4, -13, -22, -27, -27, 0, 0, 0, -4, -9, -13, -18, -18, 0, 0, 0, 0, 9, 9, 9, 9, 0, 0, 0, 0, 9, 18, 27, 27, 0, 0, 0, 0, 9, 27, 40, 36, 0, 0, 0, 0, 0, 31, 40, 31, 0, 0, 0, 0, 0, 0, 0, 0};

	  // Pawn storm open file bonuses by file:
	  public static final int[] KStormOpenFileBonus = {45, 45, 30, 0, 0, 0, 0, 0};

	  public static final int[] QStormOpenFileBonus = {0, 0, 0, 0, 0, 30, 45, 30};


}