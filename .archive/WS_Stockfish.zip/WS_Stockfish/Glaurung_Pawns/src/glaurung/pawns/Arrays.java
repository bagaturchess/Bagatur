package glaurung.pawns;

//----------------------------------------------------------------------------------------
//	Copyright © 2006 - 2019 Tangible Software Solutions, Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to initialize and delete array elements.
//----------------------------------------------------------------------------------------
public final class Arrays
{
	public static PawnInfo[] initializeWithDefaultPawnInfoInstances(int length)
	{
		PawnInfo[] array = new PawnInfo[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new PawnInfo();
		}
		return array;
	}

	public static <T extends java.io.Closeable> void deleteArray(T[] array)
	{
		for (T element : array)
		{
			if (element != null)
				element.close();
		}
	}
}