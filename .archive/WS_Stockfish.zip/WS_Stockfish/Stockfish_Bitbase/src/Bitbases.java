public class Bitbases
{
//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
	public boolean probe(Square wksq, Square wpsq, Square bksq, Color us)
	{
    
	  assert file_of(wpsq) <= File.FILE_D.getValue();
    
	  uint idx = index(us, bksq, wksq, wpsq);
	  return KPKBitbase[idx / 32] & (1 << (idx & 0x1F)) != null;
	}

//C++ TO JAVA CONVERTER WARNING: The original C++ declaration of the following method implementation was not found:
	public void init()
	{
    
	  ArrayList<KPKPosition> db = new ArrayList<KPKPosition>(MAX_INDEX);
	  uint idx;
	  uint repeat = 1;
    
	  // Initialize db with known win / draw positions
	  for (idx = 0; idx < MAX_INDEX; ++idx)
	  {
		  db.set(idx, new KPKPosition(idx));
	  }
    
	  // Iterate through the positions until none of the unknown positions can be
	  // changed to either wins or draws (15 cycles needed).
	  while (repeat != 0)
	  {
		  for (repeat = idx = 0; idx < MAX_INDEX; ++idx)
		  {
			  repeat |= (db.get(idx) == Result.UNKNOWN && db.get(idx).classify(db) != Result.UNKNOWN);
		  }
	  }
    
	  // Map 32 results into one KPKBitbase[] entry
	  for (idx = 0; idx < MAX_INDEX; ++idx)
	  {
		  if (db.get(idx) == Result.WIN)
		  {
			  KPKBitbase[idx / 32] |= 1 << (idx & 0x1F);
		  }
	  }
	}
}