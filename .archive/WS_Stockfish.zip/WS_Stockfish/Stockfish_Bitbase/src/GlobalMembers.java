public class GlobalMembers
{
	/*
	  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
	  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
	  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
	  Copyright (C) 2015-2019 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad
	
	  Stockfish is free software: you can redistribute it and/or modify
	  it under the terms of the GNU General Public License as published by
	  the Free Software Foundation, either version 3 of the License, or
	  (at your option) any later version.
	
	  Stockfish is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	*/




	  // There are 24 possible pawn squares: the first 4 files and ranks from 2 to 7
	  public static final int MAX_INDEX = 2 * 24 * 64 * 64; // stm * psq * wksq * bksq = 196608

	  // Each uint32_t stores results of 32 positions, one per bit
	  public static uint32_t[] KPKBitbase = tangible.Arrays.initializeWithDefaultuint32_tInstances(MAX_INDEX / 32);

	  // A KPK bitbase index is an integer in [0, IndexMax] range
	  //
	  // Information is mapped in a way that minimizes the number of iterations:
	  //
	  // bit  0- 5: white king square (from SQ_A1 to SQ_H8)
	  // bit  6-11: black king square (from SQ_A1 to SQ_H8)
	  // bit    12: side to move (WHITE or BLACK)
	  // bit 13-14: white pawn file (from FILE_A to FILE_D)
	  // bit 15-17: white pawn RANK_7 - rank (from RANK_7 - RANK_7 to RANK_7 - RANK_2)
	  public static int index(Color us, Square bksq, Square wksq, Square psq)
	  {
		return (wksq | (bksq.getValue() << 6) | (us.getValue() << 12) | (file_of(psq) << 13) | ((Rank.RANK_7 - rank_of(psq)) << 15)).getValue();
	  }

	  private Result bitwiseOrAssignment(Result r, Result v)
	  {
		  return r = Result(r | v);
	  }
}