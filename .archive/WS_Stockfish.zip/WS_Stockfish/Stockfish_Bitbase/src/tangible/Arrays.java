package tangible;

//----------------------------------------------------------------------------------------
//	Copyright © 2006 - 2019 Tangible Software Solutions, Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to initialize and delete array elements.
//----------------------------------------------------------------------------------------
public final class Arrays
{
	public static uint32_t[] initializeWithDefaultuint32_tInstances(int length)
	{
		uint32_t[] array = new uint32_t[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = new uint32_t();
		}
		return array;
	}

	public static <T extends java.io.Closeable> void deleteArray(T[] array)
	{
		for (T element : array)
		{
			if (element != null)
				element.close();
		}
	}
}