package glaurung.material;

import glaurung.types.Value;

public class GlobalMembers
{
	////
	//// Local definitions
	////


	  public static final Value BishopPairMidgameBonus = new Value(100);
	  public static final Value BishopPairEndgameBonus = new Value(100);

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KPKMaterialKey, KKPMaterialKey;
	  public static long KPKMaterialKey;
	  public static long KKPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBNKMaterialKey, KKBNMaterialKey;
	  public static long KBNKMaterialKey;
	  public static long KKBNMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRKPMaterialKey, KPKRMaterialKey;
	  public static long KRKPMaterialKey;
	  public static long KPKRMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRKBMaterialKey, KBKRMaterialKey;
	  public static long KRKBMaterialKey;
	  public static long KBKRMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRKNMaterialKey, KNKRMaterialKey;
	  public static long KRKNMaterialKey;
	  public static long KNKRMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KQKRMaterialKey, KRKQMaterialKey;
	  public static long KQKRMaterialKey;
	  public static long KRKQMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBBKNMaterialKey, KNKBBMaterialKey;
	  public static long KBBKNMaterialKey;
	  public static long KNKBBMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRPKRMaterialKey, KRKRPMaterialKey;
	  public static long KRPKRMaterialKey;
	  public static long KRKRPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KRPPKRPMaterialKey, KRPKRPPMaterialKey;
	  public static long KRPPKRPMaterialKey;
	  public static long KRPKRPPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KNNKMaterialKey, KKNNMaterialKey;
	  public static long KNNKMaterialKey;
	  public static long KKNNMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBPKBMaterialKey, KBKBPMaterialKey;
	  public static long KBPKBMaterialKey;
	  public static long KBKBPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KBPKNMaterialKey, KNKBPMaterialKey;
	  public static long KBPKNMaterialKey;
	  public static long KNKBPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KNPKMaterialKey, KKNPMaterialKey;
	  public static long KNPKMaterialKey;
	  public static long KKNPMaterialKey;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long KPKPMaterialKey;
	  public static long KPKPMaterialKey;


}