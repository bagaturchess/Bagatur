package glaurung.material;


import glaurung.endgame.EndgameEvaluationFunction;
import glaurung.endgame.ScalingFunction;
import glaurung.position.Position;
import glaurung.types.Color;
import glaurung.types.PieceType;
import glaurung.types.ScaleFactor;
import glaurung.types.Value;

/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/


////
//// Includes
////


/*
  Glaurung, a UCI chess playing engine.
  Copyright (C) 2004-2008 Tord Romstad

  Glaurung is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Glaurung is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http: //www.gnu.org/licenses/>.
*/



////
//// Includes
////



////
//// Types
////

/// MaterialInfo is a class which contains various information about a
/// material configuration.  It contains a material balance evaluation,
/// a function pointer to a special endgame evaluation function (which in
/// most cases is NULL, meaning that the standard evaluation function will
/// be used), and "scale factors" for black and white.
///
/// The scale factors are used to scale the evaluation score up or down.
/// For instance, in KRB vs KR endgames, the score is scaled down by a factor
/// of 4, which will result in scores of absolute value less than one pawn.

public class MaterialInfo
{

//C++ TO JAVA CONVERTER TODO TASK: Java has no concept of a 'friend' class:
//  friend class MaterialInfoTable;


  ////
  //// Inline functions
  ////

  /// MaterialInfo::mg_value and MaterialInfo::eg_value simply returns the
  /// material balance evaluation for the middle game and the endgame.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value mg_value() const
  public final int mg_value()
  {
	return mgValue;
  }

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value eg_value() const
  public final int eg_value()
  {
	return egValue;
  }


  /// MaterialInfo::scale_factor takes a position and a color as input, and
  /// returns a scale factor for the given color.  We have to provide the
  /// position in addition to the color, because the scale factor need not
  /// be a constant:  It can also be a function which should be applied to
  /// the position.  For instance, in KBP vs K endgames, a scaling function
  /// which checks for draws with rook pawns and wrong-colored bishops.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline ScaleFactor scale_factor(const Position &pos, Color c) const
  public final ScaleFactor scale_factor(Position pos, Color c)
  {
	if (scalingFunction[c.getValue()] != null)
	{
	  ScaleFactor sf = scalingFunction[c.getValue()].apply(pos);
	  if (sf != ScaleFactor.SCALE_FACTOR_NONE)
	  {
		return sf;
	  }
	}
	return new ScaleFactor(factor[c.getValue()]);
  }


  /// MaterialInfo::space_weight() simply returns the weight for the space
  /// evaluation for this material configuration.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline int space_weight() const
  public final int space_weight()
  {
	return (int)spaceWeight;
  }


  /// MaterialInfo::specialized_eval_exists decides whether there is a
  /// specialized evaluation function for the current material configuration,
  /// or if the normal evaluation function should be used.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline boolean specialized_eval_exists() const
  public final boolean specialized_eval_exists()
  {
	return evaluationFunction != null;
  }


  /// MaterialInfo::evaluate applies a specialized evaluation function to a
  /// given position object.  It should only be called when
  /// this->specialized_eval_exists() returns 'true'.

//C++ TO JAVA CONVERTER WARNING: 'const' methods are not available in Java:
//ORIGINAL LINE: inline Value evaluate(const Position &pos) const
  public final Value evaluate(Position pos)
  {
	return evaluationFunction.apply(pos);
  }


  ////
  //// Functions
  ////

  /// MaterialInfo::init() is called during program initialization.  It 
  /// precomputes material hash keys for a few basic endgames, in order
  /// to make it easy to recognize such endgames when they occur.

  public static void init()
  {
	GlobalMembers.KPKMaterialKey = Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1];
	GlobalMembers.KKPMaterialKey = Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1];
	GlobalMembers.KBNKMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.KNIGHT.getValue()][1]);
	GlobalMembers.KKBNMaterialKey = (long)(Position.zobMaterial[Color.BLACK.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.KNIGHT.getValue()][1]);
	GlobalMembers.KRKPMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KPKRMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1]);
	GlobalMembers.KRKBMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.BISHOP.getValue()][1]);
	GlobalMembers.KBKRMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1]);
	GlobalMembers.KRKNMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.KNIGHT.getValue()][1]);
	GlobalMembers.KNKRMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.KNIGHT.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1]);
	GlobalMembers.KQKRMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.QUEEN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1]);
	GlobalMembers.KRKQMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.QUEEN.getValue()][1]);
	GlobalMembers.KRPKRMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1]);
	GlobalMembers.KRKRPMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KRPPKRPMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][2] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KRPKRPPMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.ROOK.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][2]);
	GlobalMembers.KNNKMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.KNIGHT.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.KNIGHT.getValue()][2]);
	GlobalMembers.KKNNMaterialKey = (long)(Position.zobMaterial[Color.BLACK.getValue()][PieceType.KNIGHT.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.KNIGHT.getValue()][2]);
	GlobalMembers.KBPKBMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.BISHOP.getValue()][1]);
	GlobalMembers.KBKBPMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KBPKNMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.KNIGHT.getValue()][1]);
	GlobalMembers.KNKBPMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.KNIGHT.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.BISHOP.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KNPKMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.KNIGHT.getValue()][1] ^ Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KKNPMaterialKey = (long)(Position.zobMaterial[Color.BLACK.getValue()][PieceType.KNIGHT.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KPKPMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.PAWN.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.PAWN.getValue()][1]);
	GlobalMembers.KBBKNMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.BISHOP.getValue()][2] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.KNIGHT.getValue()][1]);
	GlobalMembers.KNKBBMaterialKey = (long)(Position.zobMaterial[Color.WHITE.getValue()][PieceType.KNIGHT.getValue()][1] ^ Position.zobMaterial[Color.BLACK.getValue()][PieceType.BISHOP.getValue()][2]);
  }


  /// MaterialInfo::clear() resets a MaterialInfo object to an empty state,
  /// with all slots at their default values.

  private void clear()
  {
	mgValue = egValue = 0;
	factor[Color.WHITE.getValue()] = factor[Color.BLACK.getValue()] = (byte) ScaleFactor.SCALE_FACTOR_NORMAL.getValue();
	spaceWeight = 0;
	evaluationFunction = null;
	scalingFunction[Color.WHITE.getValue()] = scalingFunction[Color.BLACK.getValue()] = null;
  }

//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned long long key;
  private long key;
  private short mgValue;
  private short egValue;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned char spaceWeight;
  private byte spaceWeight;
//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
//ORIGINAL LINE: unsigned char factor[2];
  private byte[] factor = new byte[2];
  private EndgameEvaluationFunction evaluationFunction;
  private ScalingFunction[] scalingFunction = glaurung.material.Arrays.initializeWithDefaultScalingFunctionInstances(2);
}