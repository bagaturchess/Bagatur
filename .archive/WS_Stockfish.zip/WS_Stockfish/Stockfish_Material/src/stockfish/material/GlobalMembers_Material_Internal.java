package stockfish.material;

import stockfish.position.Position;
import stockfish.types.Color;
import stockfish.types.PieceType;

public class GlobalMembers_Material_Internal
{


	/// Material::probe() looks up the current position's material configuration in
	/// the material hash table. It returns a pointer to the Entry if the position
	/// is found. Otherwise a new Entry is computed and stored there, so we don't
	/// have to recompute all when the same material configuration occurs again.



	public static Entry probe(Position pos)
	{

	  long key = pos.material_key();
	  Entry e = pos.this_thread().materialTable[key];

	  if (e.key == key)
	  {
		  return e;
	  }

//C++ TO JAVA CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in Java:
//C++ TO JAVA CONVERTER TODO TASK: There is no Java equivalent to 'sizeof':
	  memset(e, 0, sizeof(Entry));
	  e.key = key;
	  e.factor[Color.WHITE.getValue()] = e.factor[Color.BLACK.getValue()] = (byte)ScaleFactor.SCALE_FACTOR_NORMAL.getValue();

	  Value npm_w = pos.non_pawn_material(Color.WHITE);
	  Value npm_b = pos.non_pawn_material(Color.BLACK);
	  Value npm = Math.max(Value.EndgameLimit, Math.min(npm_w + npm_b, Value.MidgameLimit));

	  // Map total non-pawn material into [PHASE_ENDGAME, PHASE_MIDGAME]
	  e.gamePhase = Phase(((npm - Value.EndgameLimit) * Phase.PHASE_MIDGAME) / (Value.MidgameLimit - Value.EndgameLimit));

	  // Let's look if we have a specialized evaluation function for this particular
	  // material configuration. Firstly we look for a fixed configuration one, then
	  // for a generic one if the previous search failed.
	  if ((e.evaluationFunction = pos.this_thread().endgames.<Value>probe(key)) != null)
	  {
		  return e;
	  }

	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); ++c)
	  {
		  if (GlobalMembers.is_KXK(pos, c))
		  {
			  e.evaluationFunction = GlobalMembers.EvaluateKXK[c.getValue()];
			  return e;
		  }
	  }

	  // OK, we didn't find any special evaluation function for the current material
	  // configuration. Is there a suitable specialized scaling function?
	  EndgameBase<ScaleFactor> sf;

	  if ((sf = pos.this_thread().endgames.<ScaleFactor>probe(key)) != null)
	  {
		  e.scalingFunction[sf.strongSide.getValue()] = sf; // Only strong color assigned
		  return e;
	  }

	  // We didn't find any specialized scaling function, so fall back on generic
	  // ones that refer to more than one material distribution. Note that in this
	  // case we don't return after setting the function.
	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); ++c)
	  {
		if (GlobalMembers.is_KBPsK(pos, c))
		{
			e.scalingFunction[c.getValue()] = GlobalMembers.ScaleKBPsK[c.getValue()];
		}

		else if (GlobalMembers.is_KQKRPs(pos, c))
		{
			e.scalingFunction[c.getValue()] = GlobalMembers.ScaleKQKRPs[c.getValue()];
		}
	  }

	  if (npm_w + npm_b == Value.VALUE_ZERO.getValue() != 0 && pos.pieces(PieceType.PAWN) != null) // Only pawns on the board
	  {
		  if ((pos.<PieceType.PAWN.getValue()>count(Color.BLACK)) == 0)
		  {
			  assert pos.<PieceType.PAWN.getValue()>count(Color.WHITE) >= 2;

			  e.scalingFunction[Color.WHITE.getValue()] = GlobalMembers.ScaleKPsK[Color.WHITE.getValue()];
		  }
		  else if (!pos.<PieceType.PAWN.getValue()>count(Color.WHITE))
		  {
			  assert pos.<PieceType.PAWN.getValue()>count(Color.BLACK) >= 2;

			  e.scalingFunction[Color.BLACK.getValue()] = GlobalMembers.ScaleKPsK[Color.BLACK.getValue()];
		  }
		  else if (pos.<PieceType.PAWN.getValue()>count(Color.WHITE) == 1 && pos.<PieceType.PAWN.getValue()>count(Color.BLACK) == 1)
		  {
			  // This is a special case because we set scaling functions
			  // for both colors instead of only one.
			  e.scalingFunction[Color.WHITE.getValue()] = GlobalMembers.ScaleKPKP[Color.WHITE.getValue()];
			  e.scalingFunction[Color.BLACK.getValue()] = GlobalMembers.ScaleKPKP[Color.BLACK.getValue()];
		  }
	  }

	  // Zero or just one pawn makes it difficult to win, even with a small material
	  // advantage. This catches some trivial draws like KK, KBK and KNK and gives a
	  // drawish scale factor for cases such as KRKBP and KmmKm (except for KBBKN).
	  if ((pos.<PieceType.PAWN.getValue()>count(Color.WHITE)) == 0 && npm_w - npm_b.getValue() <= Value.BishopValueMg.getValue().getValue() != 0)
	  {
		  e.factor[Color.WHITE.getValue()] = (byte)(npm_w.getValue() < Value.RookValueMg.getValue() ? ScaleFactor.SCALE_FACTOR_DRAW : npm_b.getValue() <= Value.BishopValueMg.getValue() ? 4 : 14);
	  }

	  if ((pos.<PieceType.PAWN.getValue()>count(Color.BLACK)) == 0 && npm_b - npm_w.getValue() <= Value.BishopValueMg.getValue().getValue() != 0)
	  {
		  e.factor[Color.BLACK.getValue()] = (byte)(npm_b.getValue() < Value.RookValueMg.getValue() ? ScaleFactor.SCALE_FACTOR_DRAW : npm_w.getValue() <= Value.BishopValueMg.getValue() ? 4 : 14);
	  }

	  // Evaluate the material imbalance. We use PIECE_TYPE_NONE as a place holder
	  // for the bishop pair "extended piece", which allows us to be more flexible
	  // in defining bishop pair bonuses.
	  final int[][] pieceCount =
	  {
		  {pos.<PieceType.BISHOP.getValue()>count(Color.WHITE) > 1, pos.<PieceType.PAWN.getValue()>count(Color.WHITE), pos.<PieceType.KNIGHT.getValue()>count(Color.WHITE), pos.<PieceType.BISHOP.getValue()>count(Color.WHITE), pos.<PieceType.ROOK.getValue()>count(Color.WHITE), pos.<PieceType.QUEEN.getValue() >count(Color.WHITE)},
		  {pos.<PieceType.BISHOP.getValue()>count(Color.BLACK) > 1, pos.<PieceType.PAWN.getValue()>count(Color.BLACK), pos.<PieceType.KNIGHT.getValue()>count(Color.BLACK), pos.<PieceType.BISHOP.getValue()>count(Color.BLACK), pos.<PieceType.ROOK.getValue()>count(Color.BLACK), pos.<PieceType.QUEEN.getValue() >count(Color.BLACK)}
	  };

	  e.value = (short)((GlobalMembers.<Color.WHITE.getValue()>imbalance(pieceCount) - GlobalMembers.<Color.BLACK.getValue()>imbalance(pieceCount)) / 16);
	  return e;
	}
}