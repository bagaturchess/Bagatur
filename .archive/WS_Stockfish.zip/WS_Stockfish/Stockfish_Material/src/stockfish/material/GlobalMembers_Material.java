package stockfish.material;
public class GlobalMembers_Material
{
	  // Polynomial material imbalance parameters

	  public static final int[][] QuadraticOurs =
	  {
		  {1438},
		  {40, 38},
		  {32, 255, -62},
		  {0, 104, 4, 0},
		  {-26, -2, 47, 105, -208},
		  {-189, 24, 117, 133, -134, -6}
	  };

	  public static final int[][] QuadraticTheirs =
	  {
		  {0},
		  {36, 0},
		  {9, 63, 0},
		  {59, 65, 42, 0},
		  {46, 39, 24, -24, 0},
		  {97, 100, -42, 137, 268, 0}
	  };

	  // Endgame evaluation and scaling functions are accessed directly and not through
	  // the function maps because they correspond to more than one material hash key.
	  public static Endgame<EndgameCode.KXK>[] EvaluateKXK = {Endgame<EndgameCode.KXK.getValue()>(Color.WHITE), Endgame<EndgameCode.KXK.getValue()>(Color.BLACK)};

	  public static Endgame<EndgameCode.KBPsK>[] ScaleKBPsK = {Endgame<EndgameCode.KBPsK.getValue()>(Color.WHITE), Endgame<EndgameCode.KBPsK.getValue()>(Color.BLACK)};
	  public static Endgame<EndgameCode.KQKRPs>[] ScaleKQKRPs = {Endgame<EndgameCode.KQKRPs.getValue()>(Color.WHITE), Endgame<EndgameCode.KQKRPs.getValue()>(Color.BLACK)};
	  public static Endgame<EndgameCode.KPsK>[] ScaleKPsK = {Endgame<EndgameCode.KPsK.getValue()>(Color.WHITE), Endgame<EndgameCode.KPsK.getValue()>(Color.BLACK)};
	  public static Endgame<EndgameCode.KPKP>[] ScaleKPKP = {Endgame<EndgameCode.KPKP.getValue()>(Color.WHITE), Endgame<EndgameCode.KPKP.getValue()>(Color.BLACK)};

	  // Helper used to detect a given material distribution
	  public static boolean is_KXK(Position pos, Color us)
	  {
		return !more_than_one(pos.pieces(~us)) && pos.non_pawn_material(us) >= Value.RookValueMg.getValue();
	  }

	  public static boolean is_KBPsK(Position pos, Color us)
	  {
		return pos.non_pawn_material(us) == Value.BishopValueMg && pos.<PieceType.BISHOP.getValue()>count(us) == 1 && pos.<PieceType.PAWN.getValue() >count(us) >= 1;
	  }

	  public static boolean is_KQKRPs(Position pos, Color us)
	  {
		return (pos.<PieceType.PAWN.getValue()>count(us)) == 0 && pos.non_pawn_material(us) == Value.QueenValueMg && pos.<PieceType.QUEEN.getValue()>count(us) == 1 && pos.<PieceType.ROOK.getValue()>count(~us) == 1 && pos.<PieceType.PAWN.getValue()>count(~us) >= 1;
	  }

	  /// imbalance() calculates the imbalance by comparing the piece count of each
	  /// piece type for both colors.
	//C++ TO JAVA CONVERTER TODO TASK: C++ 'constraints' are not converted by C++ to Java Converter:
	//ORIGINAL LINE: template<Color Us>
//C++ TO JAVA CONVERTER TODO TASK: The original C++ template specifier was replaced with a Java generic specifier, which may not produce the same behavior:
//ORIGINAL LINE: template<typename Us>
	  public static <Us> int imbalance(int[][] pieceCount)
	  {

		final Color Them = (Us == Color.WHITE ? Color.BLACK : Color.WHITE);

		int bonus = 0;

		// Second-degree polynomial material imbalance, by Tord Romstad
		for (int pt1 = PieceType.NO_PIECE_TYPE.getValue(); pt1 <= PieceType.QUEEN.getValue(); ++pt1)
		{
			if (pieceCount[Us][pt1] == 0)
			{
				continue;
			}

			int v = 0;

			for (int pt2 = PieceType.NO_PIECE_TYPE.getValue(); pt2 <= pt1; ++pt2)
			{
				v += QuadraticOurs[pt1][pt2] * pieceCount[Us][pt2] + QuadraticTheirs[pt1][pt2] * pieceCount[Them.getValue()][pt2];
			}

			bonus += pieceCount[Us][pt1] * v;
		}

		return bonus;
	  }
}