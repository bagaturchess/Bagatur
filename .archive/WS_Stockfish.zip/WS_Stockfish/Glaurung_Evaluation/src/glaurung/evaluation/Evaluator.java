package glaurung.evaluation;
import glaurung.material.MaterialInfoTable;
import glaurung.pawns.PawnInfoTable;
import glaurung.position.Position;
import glaurung.types.Color;
import glaurung.types.File;
import glaurung.types.Move;
import glaurung.types.Phase;
import glaurung.types.Piece;
import glaurung.types.PieceType;
import glaurung.types.Rank;
import glaurung.types.RefObject;
import glaurung.types.Square;
import glaurung.types.Value;
import glaurung.types.ScaleFactor;


public class Evaluator
{

	private static final int THREAD_MAX = 1;

////
//// Functions
////

/// evaluate() is the main evaluation function.  It always computes two
/// values, an endgame score and a middle game score, and interpolates
/// between them based on the remaining material.



	////
	//// Prototypes
	////

	public static Value evaluate(Position pos, EvalInfo ei, int threadID)
	{
	  Color stm;
	  ScaleFactor[] factor = {ScaleFactor.SCALE_FACTOR_NORMAL, ScaleFactor.SCALE_FACTOR_NORMAL};
	  Phase phase;
	  
	  assert pos.is_ok();

	  stm = pos.side_to_move();

	  // Initialize by reading the incrementally updated scores included in the
	  // position object (material + piece square tables):
	  ei.mgValue = pos.mg_value();
	  ei.egValue = pos.mg_value();

	  // Probe the material hash table:
	  ei.mi = MaterialTable[threadID].get_material_info(pos);
	  ei.mgValue += ei.mi.mg_value();
	  ei.egValue += ei.mi.eg_value();

	  factor[Color.WHITE.getValue()] = ei.mi.scale_factor(pos, Color.WHITE);
	  factor[Color.BLACK.getValue()] = ei.mi.scale_factor(pos, Color.BLACK);

	  // If we have a specialized evaluation function for the current material
	  // configuration, call it and return:
	  if (ei.mi.specialized_eval_exists())
	  {
		return ei.mi.evaluate(pos);
	  }

	  phase = pos.game_phase();

	  // Probe the pawn hash table:
	  ei.pi = PawnTable[threadID].get_pawn_info(pos);
	  ei.mgValue += apply_weight(ei.pi.mg_value(), WeightPawnStructureMidgame);
	  ei.egValue += apply_weight(ei.pi.eg_value(), WeightPawnStructureEndgame);

	  // Initialize king attack bitboards and king attack zones for both sides:
	  ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()] = pos.king_attacks(pos.king_square(Color.WHITE));
	  ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()] = pos.king_attacks(pos.king_square(Color.BLACK));
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  ei.attackZone[Color.WHITE.getValue()] = ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()] | (ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()] >>> 8);
	  ei.attackZone[Color.BLACK.getValue()] = ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()] | (ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()] << 8);

	  // Initialize pawn attack bitboards for both sides:
	  ei.attackedBy[Color.WHITE.getValue()][PieceType.PAWN.getValue()] = ((pos.pawns(Color.WHITE) << 9) & ~glaurung.bitboard.GlobalMembers.FileABB) | ((pos.pawns(Color.WHITE) << 7) & ~glaurung.bitboard.GlobalMembers.FileHBB);
	  ei.attackCount[Color.WHITE.getValue()] += glaurung.bitboard.GlobalMembers.count_1s_max_15(ei.attackedBy[Color.WHITE.getValue()][PieceType.PAWN.getValue()] & ei.attackedBy[Color.BLACK.getValue()][PieceType.KING.getValue()]) / 2;
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
	  ei.attackedBy[Color.BLACK.getValue()][PieceType.PAWN.getValue()] = ((pos.pawns(Color.BLACK) >>> 7) & ~glaurung.bitboard.GlobalMembers.FileABB) | ((pos.pawns(Color.BLACK) >>> 9) & ~glaurung.bitboard.GlobalMembers.FileHBB);
	  ei.attackCount[Color.BLACK.getValue()] += glaurung.bitboard.GlobalMembers.count_1s_max_15(ei.attackedBy[Color.BLACK.getValue()][PieceType.PAWN.getValue()] & ei.attackedBy[Color.WHITE.getValue()][PieceType.KING.getValue()]) / 2;

	  // Evaluate pieces:
	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c = (c == Color.WHITE ? Color.BLACK : Color.COLOR_NONE) )
	  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b;
		long b;

		// Knights
		for (int i = 0; i < pos.knight_count(c); i++)
		{
		  evaluate_knight(pos, pos.knight_list(c, i), c, ei);
		}

		// Bishops
		for (int i = 0; i < pos.bishop_count(c); i++)
		{
		  evaluate_bishop(pos, pos.bishop_list(c, i), c, ei);
		}

		// Rooks
		for (int i = 0; i < pos.rook_count(c); i++)
		{
		  evaluate_rook(pos, pos.rook_list(c, i), c, ei);
		}

		// Queens
		for (int i = 0; i < pos.queen_count(c); i++)
		{
		  evaluate_queen(pos, pos.queen_list(c, i), c, ei);
		}

		// Some special patterns:

		// Trapped bishops on a7/h7/a2/h2
		b = pos.bishops(c) & MaskA7H7[c.getValue()];
		while (b != 0)
		{
			glaurung.types.RefObject<Long> tempRef_b = new glaurung.types.RefObject<Long>(b);
			evaluate_trapped_bishop_a7h7(pos, glaurung.bitboard.GlobalMembers.pop_1st_bit(tempRef_b), c, ei);
			b = tempRef_b.argValue;
		}

		ei.attackedBy[c.getValue()][0] = ei.attackedBy[c.getValue()][PieceType.PAWN.getValue()] | ei.attackedBy[c.getValue()][PieceType.KNIGHT.getValue()] | ei.attackedBy[c.getValue()][PieceType.BISHOP.getValue()] | ei.attackedBy[c.getValue()][PieceType.ROOK.getValue()] | ei.attackedBy[c.getValue()][PieceType.QUEEN.getValue()] | ei.attackedBy[c.getValue()][PieceType.KING.getValue()];
	  }

	  // Kings.  Kings are evaluated after all other pieces for both sides,
	  // because we need complete attack information for all pieces when computing
	  // the king safety evaluation.
	  for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c = (c == Color.WHITE ? Color.BLACK : Color.COLOR_NONE))
	  {
		evaluate_king(pos, pos.king_square(c), c, ei);
	  }

	  // Evaluate passed pawns.  We evaluate passed pawns for both sides at once,
	  // because we need to know which side promotes first in positions where
	  // both sides have an unstoppable passed pawn.
	  if (ei.pi.passed_pawns() != 0)
	  {
		evaluate_passed_pawns(pos, ei);
	  }

	  // Middle-game specific evaluation terms
	  if (phase.getValue() > Phase.PHASE_ENDGAME.getValue())
	  {

		// Pawn storms in positions with opposite castling.
		if (glaurung.types.GlobalMembers.square_file(pos.king_square(Color.WHITE)).getValue() >= File.FILE_E.getValue()
				&& glaurung.types.GlobalMembers.square_file(pos.king_square(Color.BLACK)).getValue() <= File.FILE_D.getValue())
		{
		  ei.mgValue += ei.pi.queenside_storm_value(Color.WHITE) - ei.pi.kingside_storm_value(Color.BLACK);
		}
		else if (glaurung.types.GlobalMembers.square_file(pos.king_square(Color.WHITE)).getValue() <= File.FILE_D.getValue()
				&& glaurung.types.GlobalMembers.square_file(pos.king_square(Color.BLACK)).getValue() >= File.FILE_E.getValue())
		{
		  ei.mgValue += ei.pi.kingside_storm_value(Color.WHITE) - ei.pi.queenside_storm_value(Color.BLACK);
		}

		// Evaluate space for both sides.
		if (ei.mi.space_weight() > 0)
		{
		  evaluate_space(pos, Color.WHITE, ei);
		  evaluate_space(pos, Color.BLACK, ei);
		}
	  }

	  // Mobility
	  ei.mgValue += apply_weight(ei.mgMobility, WeightMobilityMidgame);
	  ei.egValue += apply_weight(ei.egMobility, WeightMobilityEndgame);

	  // If we don't already have an unusual scale factor, check for opposite
	  // colored bishop endgames, and use a lower scale for those:
	  if (phase.getValue() < Phase.PHASE_MIDGAME.getValue() && pos.opposite_colored_bishops()
			  && ((factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL && ei.egValue > 0)
					  || (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL && ei.egValue < 0)))
	  {
		if (pos.non_pawn_material(Color.WHITE) + pos.non_pawn_material(Color.BLACK) == 2 * glaurung.types.GlobalMembers.BishopValueMidgame.getValue())
		{
		  // Only the two bishops
		  if (pos.pawn_count(Color.WHITE) + pos.pawn_count(Color.BLACK) == 1)
		  {
			// KBP vs KB with only a single pawn; almost certainly a draw.
			if (factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.WHITE.getValue()] = new ScaleFactor(8);
			}
			if (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.BLACK.getValue()] = new ScaleFactor(8);
			}
		  }
		  else
		  {
			// At least two pawns
			if (factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.WHITE.getValue()] = new ScaleFactor(32);
			}
			if (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
			{
			  factor[Color.BLACK.getValue()] = new ScaleFactor(32);
			}
		  }
		}
		else
		{
		  // Endgame with opposite-colored bishops, but also other pieces.
		  // Still a bit drawish, but not as drawish as with only the two
		  // bishops.
		  if (factor[Color.WHITE.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
		  {
			factor[Color.WHITE.getValue()] = new ScaleFactor(50);
		  }
		  if (factor[Color.BLACK.getValue()] == ScaleFactor.SCALE_FACTOR_NORMAL)
		  {
			factor[Color.BLACK.getValue()] = new ScaleFactor(50);
		  }
		}
	  }

	  // Interpolate between the middle game and the endgame score, and
	  // return:
	  int value = scale_by_game_phase(ei.mgValue, ei.egValue, phase, factor);

	  if (ei.mateThreat[stm.getValue()] != Move.MOVE_NONE)
	  {
		return new Value(8 * glaurung.types.GlobalMembers.QueenValueMidgame.getValue() - Sign[stm.getValue()] * value);
	  }
	  else
	  {
		return new Value(Sign[stm.getValue()] * value);
	  }
	}

/// quick_evaluate() does a very approximate evaluation of the current position.
/// It currently considers only material and piece square table scores.  Perhaps
/// we should add scores from the pawn and material hash tables?


	public static Value quick_evaluate(Position pos)
	{
	  Color stm;
	  int mgValue;
	  int egValue;
	  ScaleFactor[] factor = {ScaleFactor.SCALE_FACTOR_NORMAL, ScaleFactor.SCALE_FACTOR_NORMAL};
	  Phase phase;

	  assert pos.is_ok();

	  stm = pos.side_to_move();

	  mgValue = pos.mg_value();
	  egValue = pos.mg_value();
	  phase = pos.game_phase();

	  int value = scale_by_game_phase(mgValue, egValue, phase, factor);

	  return new Value(Sign[stm.getValue()] * value);
	}

/// init_eval() initializes various tables used by the evaluation function.


	public static void init_eval(int threads)
	{
	  assert threads <= THREAD_MAX;

	  for (int i = 0; i < threads; i++)
	  {
		if (PawnTable[i] == null)
		{
		  PawnTable[i] = new PawnInfoTable(PawnTableSize);
		}
		if (MaterialTable[i] == null)
		{
		  MaterialTable[i] = new MaterialInfoTable(MaterialTableSize);
		}
	  }
	  for (int i = threads; i < THREAD_MAX; i++)
	  {
		if (PawnTable[i] != null)
		{
		  if (PawnTable[i] != null)
		  {
		  PawnTable[i].close();
		  }
		  PawnTable[i] = null;
		}
		if (MaterialTable[i] != null)
		{
		  if (MaterialTable[i] != null)
		  {
		  MaterialTable[i].close();
		  }
		  MaterialTable[i] = null;
		}
	  }

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: for(unsigned long long b = 0ULL; b < 256ULL; b++)
	  for (long b = 0; b < 256; b++)
	  {
		BitCount8Bit[(int) b] = (byte)glaurung.bitboard.GlobalMembers.count_1s(b);
	  }
	}

/// quit_eval() releases heap-allocated memory at program termination.


	public static void quit_eval()
	{
	  for (int i = 0; i < THREAD_MAX; i++)
	  {
		if (PawnTable[i] != null)
		{
		PawnTable[i].close();
		}
		if (MaterialTable[i] != null)
		{
		MaterialTable[i].close();
		}
	  }
	}

/// read_weights() reads evaluation weights from the corresponding UCI
/// parameters.


	public static void read_weights(Color sideToMove)
	{
	  WeightMobilityMidgame = compute_weight(0, WeightMobilityMidgameInternal);
	  WeightMobilityEndgame = compute_weight(0, WeightMobilityEndgameInternal);
	  WeightPawnStructureMidgame = compute_weight(0, WeightPawnStructureMidgameInternal);
	  WeightPawnStructureEndgame = compute_weight(0, WeightPawnStructureEndgameInternal);
	  WeightPassedPawnsMidgame = compute_weight(0, WeightPassedPawnsMidgameInternal);
	  WeightPassedPawnsEndgame = compute_weight(0, WeightPassedPawnsEndgameInternal);
	  WeightKingSafety[sideToMove.getValue()] = compute_weight(0, WeightKingSafetyInternal);
	  WeightKingSafety[glaurung.types.GlobalMembers.opposite_color(sideToMove).getValue()] = compute_weight(0, WeightKingSafetyInternal);
	  WeightSpace = compute_weight(0, WeightSpaceInternal);

	  init_safety();
	}





	////
	//// Local definitions
	////


	  public static final int[] Sign = {1, -1};

	  // Evaluation grain size, must be a power of 2.
	  public static final int GrainSize = 4;

	  // Evaluation weights
	  public static int WeightMobilityMidgame = 0x100;
	  public static int WeightMobilityEndgame = 0x100;
	  public static int WeightPawnStructureMidgame = 0x100;
	  public static int WeightPawnStructureEndgame = 0x100;
	  public static int WeightPassedPawnsMidgame = 0x100;
	  public static int WeightPassedPawnsEndgame = 0x100;
	  public static int[] WeightKingSafety = {0x100, 0x100};
	  public static int WeightSpace;

	  // Internal evaluation weights.  These are applied on top of the evaluation
	  // weights read from UCI parameters.  The purpose is to be able to change
	  // the evaluation weights while keeping the default values of the UCI
	  // parameters at 100, which looks prettier.
	  public static final int WeightMobilityMidgameInternal = 0x100;
	  public static final int WeightMobilityEndgameInternal = 0x100;
	  public static final int WeightPawnStructureMidgameInternal = 0x100;
	  public static final int WeightPawnStructureEndgameInternal = 0x100;
	  public static final int WeightPassedPawnsMidgameInternal = 0x100;
	  public static final int WeightPassedPawnsEndgameInternal = 0x100;
	  public static final int WeightKingSafetyInternal = 0x110;
	  public static final int WeightSpaceInternal = 0x30;

	  // Knight mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly piecess.
	  public static final Value[] MidgameKnightMobilityBonus = {new Value(-30), new Value(-20), new Value(-10), new Value(0), new Value(10), new Value(20), new Value(25), new Value(30), new Value(30)};

	  public static final Value[] EndgameKnightMobilityBonus = {new Value(-30), new Value(-20), new Value(-10), new Value(0), new Value(10), new Value(20), new Value(25), new Value(30), new Value(30)};

	  // Bishop mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly pieces.  X-ray attacks through
	  // queens are also included.
	  public static final Value[] MidgameBishopMobilityBonus = {new Value(-30), new Value(-15), new Value(0), new Value(15), new Value(30), new Value(45), new Value(58), new Value(66), new Value(72), new Value(76), new Value(78), new Value(80), new Value(81), new Value(82), new Value(83), new Value(83)};

	  public static final Value[] EndgameBishopMobilityBonus = {new Value(-30), new Value(-15), new Value(0), new Value(15), new Value(30), new Value(45), new Value(58), new Value(66), new Value(72), new Value(76), new Value(78), new Value(80), new Value(81), new Value(82), new Value(83), new Value(83)};

	  // Rook mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly pieces.  X-ray attacks through
	  // queens and rooks are also included.
	  public static final Value[] MidgameRookMobilityBonus = {new Value(-18), new Value(-12), new Value(-6), new Value(0), new Value(6), new Value(12), new Value(16), new Value(21), new Value(24), new Value(27), new Value(28), new Value(29), new Value(30), new Value(31), new Value(32), new Value(33)};

	  public static final Value[] EndgameRookMobilityBonus = {new Value(-30), new Value(-18), new Value(-6), new Value(6), new Value(18), new Value(30), new Value(42), new Value(54), new Value(66), new Value(74), new Value(78), new Value(80), new Value(81), new Value(82), new Value(83), new Value(83)};

	  // Queen mobility bonus in middle game and endgame, indexed by the number
	  // of attacked squares not occupied by friendly pieces.
	  public static final Value[] MidgameQueenMobilityBonus = {new Value(-10), new Value(-8), new Value(-6), new Value(-4), new Value(-2), new Value(0), new Value(2), new Value(4), new Value(6), new Value(8), new Value(10), new Value(12), new Value(13), new Value(14), new Value(15), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16), new Value(16)};

	  public static final Value[] EndgameQueenMobilityBonus = {new Value(-20), new Value(-15), new Value(-10), new Value(-5), new Value(0), new Value(5), new Value(10), new Value(15), new Value(19), new Value(23), new Value(27), new Value(29), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30), new Value(30)};


	  // Outpost bonuses for knights and bishops, indexed by square (from white's
	  // point of view).
	  public static final Value[] KnightOutpostBonus = {new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(5), new Value(10), new Value(10), new Value(5), new Value(0), new Value(0), new Value(0), new Value(5), new Value(20), new Value(30), new Value(30), new Value(20), new Value(5), new Value(0), new Value(0), new Value(10), new Value(30), new Value(40), new Value(40), new Value(30), new Value(10), new Value(0), new Value(0), new Value(5), new Value(20), new Value(20), new Value(20), new Value(20), new Value(5), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0)};

	  public static final Value[] BishopOutpostBonus = {new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(5), new Value(5), new Value(5), new Value(5), new Value(0), new Value(0), new Value(0), new Value(5), new Value(10), new Value(10), new Value(10), new Value(10), new Value(5), new Value(0), new Value(0), new Value(10), new Value(20), new Value(20), new Value(20), new Value(20), new Value(10), new Value(0), new Value(0), new Value(5), new Value(8), new Value(8), new Value(8), new Value(8), new Value(5), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0), new Value(0)};

	  // Bonus for unstoppable passed pawns:
	  public static final Value UnstoppablePawnValue = new Value(0x500);

	  // Rooks and queens on the 7th rank:
	  public static final Value MidgameRookOn7thBonus = new Value(50);
	  public static final Value EndgameRookOn7thBonus = new Value(100);
	  public static final Value MidgameQueenOn7thBonus = new Value(25);
	  public static final Value EndgameQueenOn7thBonus = new Value(50);

	  // Rooks on open files:
	  public static final Value RookOpenFileBonus = new Value(40);
	  public static final Value RookHalfOpenFileBonus = new Value(20);

	  // Penalty for rooks trapped inside a friendly king which has lost the
	  // right to castle:
	  public static final Value TrappedRookPenalty = new Value(180);

	  // Penalty for a bishop on a7/h7 (a2/h2 for black) which is trapped by
	  // enemy pawns:
	  public static final Value TrappedBishopA7H7Penalty = new Value(300);

	  // Bitboard masks for detecting trapped bishops on a7/h7 (a2/h2 for black):
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long MaskA7H7[2] = { ((1ULL << SQ_A7) | (1ULL << SQ_H7)), ((1ULL << SQ_A2) | (1ULL << SQ_H2)) };
	  public static final long[] MaskA7H7 = {(long)((1 << Square.SQ_A7.getValue()) | (1 << Square.SQ_H7.getValue())), (long)((1 << Square.SQ_A2.getValue()) | (1 << Square.SQ_H2.getValue()))};

	  // Penalty for a bishop on a1/h1 (a8/h8 for black) which is trapped by
	  // a friendly pawn on b2/g2 (b7/g7 for black).  This can obviously only
	  // happen in Chess960 games.
	  public static final Value TrappedBishopA1H1Penalty = new Value(100);

	  // Bitboard masks for detecting trapped bishops on a1/h1 (a8/h8 for black):
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long MaskA1H1[2] = { ((1ULL << SQ_A1) | (1ULL << SQ_H1)), ((1ULL << SQ_A8) | (1ULL << SQ_H8)) };
	  public static final long[] MaskA1H1 = {(long)((1 << Square.SQ_A1.getValue()) | (1 << Square.SQ_H1.getValue())), (long)((1 << Square.SQ_A8.getValue()) | (1 << Square.SQ_H8.getValue()))};

	  // The SpaceMask[color] contains area of the board which is consdered by
	  // the space evaluation.  In the middle game, each side is given a bonus
	  // based on how many squares inside this area are safe and available for
	  // friendly minor pieces.
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: const unsigned long long SpaceMask[2] = { (1ULL<<SQ_C2) | (1ULL<<SQ_D2) | (1ULL<<SQ_E2) | (1ULL<<SQ_F2) | (1ULL<<SQ_C3) | (1ULL<<SQ_D3) | (1ULL<<SQ_E3) | (1ULL<<SQ_F3) | (1ULL<<SQ_C4) | (1ULL<<SQ_D4) | (1ULL<<SQ_E4) | (1ULL<<SQ_F4), (1ULL<<SQ_C7) | (1ULL<<SQ_D7) | (1ULL<<SQ_E7) | (1ULL<<SQ_F7) | (1ULL<<SQ_C6) | (1ULL<<SQ_D6) | (1ULL<<SQ_E6) | (1ULL<<SQ_F6) | (1ULL<<SQ_C5) | (1ULL<<SQ_D5) | (1ULL<<SQ_E5) | (1ULL<<SQ_F5) };
	  public static final long[] SpaceMask = {(long)((1 << Square.SQ_C2.getValue()) | (1 << Square.SQ_D2.getValue()) | (1 << Square.SQ_E2.getValue()) | (1 << Square.SQ_F2.getValue()) | (1 << Square.SQ_C3.getValue()) | (1 << Square.SQ_D3.getValue()) | (1 << Square.SQ_E3.getValue()) | (1 << Square.SQ_F3.getValue()) | (1 << Square.SQ_C4.getValue()) | (1 << Square.SQ_D4.getValue()) | (1 << Square.SQ_E4.getValue()) | (1 << Square.SQ_F4.getValue())), (long)((1 << Square.SQ_C7.getValue()) | (1 << Square.SQ_D7.getValue()) | (1 << Square.SQ_E7.getValue()) | (1 << Square.SQ_F7.getValue()) | (1 << Square.SQ_C6.getValue()) | (1 << Square.SQ_D6.getValue()) | (1 << Square.SQ_E6.getValue()) | (1 << Square.SQ_F6.getValue()) | (1 << Square.SQ_C5.getValue()) | (1 << Square.SQ_D5.getValue()) | (1 << Square.SQ_E5.getValue()) | (1 << Square.SQ_F5.getValue()))};


	  /// King safety constants and variables.  The king safety scores are taken
	  /// from the array SafetyTable[].  Various little "meta-bonuses" measuring
	  /// the strength of the attack are added up into an integer, which is used
	  /// as an index to SafetyTable[].

	  // Attack weights for each piece type.
	  public static final int QueenAttackWeight = 5;
	  public static final int RookAttackWeight = 3;
	  public static final int BishopAttackWeight = 2;
	  public static final int KnightAttackWeight = 2;

	  // Bonuses for safe checks for each piece type.  
	  public static int QueenContactCheckBonus = 3;
	  public static int QueenCheckBonus = 2;
	  public static int RookCheckBonus = 1;
	  public static int BishopCheckBonus = 1;
	  public static int KnightCheckBonus = 1;
	  public static int DiscoveredCheckBonus = 3;

	  // Scan for queen contact mates?
	  public static final boolean QueenContactMates = true;

	  // Bonus for having a mate threat.
	  public static int MateThreatBonus = 3;

	  // InitKingDanger[] contains bonuses based on the position of the defending
	  // king.
	  public static final int[] InitKingDanger = {2, 0, 2, 5, 5, 2, 0, 2, 2, 2, 4, 8, 8, 4, 2, 2, 7, 10, 12, 12, 12, 12, 10, 7, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 0, 0, 0, 0, 0, 0};

	  // SafetyTable[] contains the actual king safety scores.  It is initialized
	  // in init_safety().
	  public static Value[] SafetyTable = new Value[100];


	  // Sizes of pawn and material hash tables:
	  public static final int PawnTableSize = 16384;
	  public static final int MaterialTableSize = 1024;
	  
	  // Pawn and material hash tables, indexed by the current thread id:
	  public static PawnInfoTable[] PawnTable =
	  {
		  new PawnInfoTable(PawnTableSize),
		  new PawnInfoTable(PawnTableSize),
		  new PawnInfoTable(PawnTableSize),
		  new PawnInfoTable(PawnTableSize)
	  };
	  public static MaterialInfoTable[] MaterialTable =
	  {
		  new MaterialInfoTable(MaterialTableSize),
		  new MaterialInfoTable(MaterialTableSize),
		  new MaterialInfoTable(MaterialTableSize),
		  new MaterialInfoTable(MaterialTableSize)
	  };

	  // Array which gives the number of nonzero bits in an 8-bit integer:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned char BitCount8Bit[256];
	  public static byte[] BitCount8Bit = new byte[256];

  // evaluate_knight() assigns bonuses and penalties to a knight of a given
  // color on a given square.


	  // Function prototypes:
	  public static void evaluate_knight(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = glaurung.types.GlobalMembers.opposite_color(us);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = p.knight_attacks(s);
		long b = p.knight_attacks(s);
		ei.attackedBy[us.getValue()][PieceType.KNIGHT.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += KnightAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += glaurung.bitboard.GlobalMembers.count_1s_max_15(bb);
		  }
		}

		// Mobility
		int mob = glaurung.bitboard.GlobalMembers.count_1s_max_15(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameKnightMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameKnightMobilityBonus[mob].getValue();

		// Knight outposts:
		if (p.square_is_weak(s, them))
		{
		  int v;
		  int bonus;

		  // Initial bonus based on square:
		  v = bonus = KnightOutpostBonus[glaurung.types.GlobalMembers.relative_square(us, s).getValue()].getValue();

		  // Increase bonus if supported by pawn, especially if the opponent has
		  // no minor piece which can exchange the outpost piece:
		  if (v != 0 && (p.pawn_attacks(them, s) & p.pawns(us)) != 0)
		  {
			bonus += v / 2;
			if (p.knight_count(them) == 0 && (long)(glaurung.bitboard.GlobalMembers.SquaresByColorBB[glaurung.types.GlobalMembers.square_color(s).getValue()] & p.bishops(them)) == glaurung.bitboard.GlobalMembers.EmptyBoardBB)
			{
			  bonus += v;
			}
		  }

		  ei.mgValue += Sign[us.getValue()] * bonus;
		  ei.egValue += Sign[us.getValue()] * bonus;
		}
	  }

  // evaluate_bishop() assigns bonuses and penalties to a bishop of a given
  // color on a given square.


	  public static void evaluate_bishop(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = glaurung.types.GlobalMembers.opposite_color(us);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = bishop_attacks_bb(s, p.occupied_squares() & ~p.queens(us));
		long b = glaurung.bitboard.GlobalMembers.bishop_attacks_bb(s, p.occupied_squares() & ~p.queens(us));

		ei.attackedBy[us.getValue()][PieceType.BISHOP.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += BishopAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += glaurung.bitboard.GlobalMembers.count_1s_max_15(bb);
		  }
		}

		// Mobility:
		int mob = glaurung.bitboard.GlobalMembers.count_1s_max_15(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameBishopMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameBishopMobilityBonus[mob].getValue();

		// Bishop outposts:
		if (p.square_is_weak(s, them))
		{
		  int v;
		  int bonus;

		  // Initial bonus based on square:
		  v = bonus = BishopOutpostBonus[glaurung.types.GlobalMembers.relative_square(us, s).getValue()].getValue();

		  // Increase bonus if supported by pawn, especially if the opponent has
		  // no minor piece which can exchange the outpost piece:
		  if (v != 0 && (p.pawn_attacks(them, s) & p.pawns(us)) != 0)
		  {
			bonus += v / 2;
			if (p.knight_count(them) == 0 && (long)(glaurung.bitboard.GlobalMembers.SquaresByColorBB[glaurung.types.GlobalMembers.square_color(s).getValue()] & p.bishops(them)) == glaurung.bitboard.GlobalMembers.EmptyBoardBB)
			{
			  bonus += v;
			}
		  }

		  ei.mgValue += Sign[us.getValue()] * bonus;
		  ei.egValue += Sign[us.getValue()] * bonus;
		}
	  }

  // evaluate_rook() assigns bonuses and penalties to a rook of a given
  // color on a given square.


	  public static void evaluate_rook(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = glaurung.types.GlobalMembers.opposite_color(us);

		// Open and half-open files:
		File f = glaurung.types.GlobalMembers.square_file(s);
		if (ei.pi.file_is_half_open(us, f))
		{
		  if (ei.pi.file_is_half_open(them, f))
		  {
			ei.mgValue += Sign[us.getValue()] * RookOpenFileBonus.getValue();
			ei.egValue += Sign[us.getValue()] * RookOpenFileBonus.getValue();
		  }
		  else
		  {
			ei.mgValue += Sign[us.getValue()] * RookHalfOpenFileBonus.getValue();
			ei.egValue += Sign[us.getValue()] * RookHalfOpenFileBonus.getValue();
		  }
		}

		// Rook on 7th rank:
		if (glaurung.types.GlobalMembers.pawn_rank(us, s) == Rank.RANK_7 && glaurung.types.GlobalMembers.pawn_rank(us, p.king_square(them)) == Rank.RANK_8)
		{
		  ei.mgValue += Sign[us.getValue()] * MidgameRookOn7thBonus.getValue();
		  ei.egValue += Sign[us.getValue()] * EndgameRookOn7thBonus.getValue();
		}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = rook_attacks_bb(s, p.occupied_squares() & ~p.rooks_and_queens(us));
		long b = glaurung.bitboard.GlobalMembers.rook_attacks_bb(s, p.occupied_squares() & ~p.rooks_and_queens(us));
		ei.attackedBy[us.getValue()][PieceType.ROOK.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += RookAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += glaurung.bitboard.GlobalMembers.count_1s_max_15(bb);
		  }
		}

		// Mobility
		int mob = glaurung.bitboard.GlobalMembers.count_1s_max_15(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameRookMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameRookMobilityBonus[mob].getValue();

		// Penalize rooks which are trapped inside a king which has lost the
		// right to castle:
		if (mob <= 6 && !ei.pi.file_is_half_open(us, f))
		{
		  Square ksq = p.king_square(us);
		  if (glaurung.types.GlobalMembers.square_file(ksq).getValue() >= File.FILE_E.getValue()
				  && glaurung.types.GlobalMembers.square_file(s).getValue() > glaurung.types.GlobalMembers.square_file(ksq).getValue()
				  && (glaurung.types.GlobalMembers.pawn_rank(us, ksq) == Rank.RANK_1 || glaurung.types.GlobalMembers.square_rank(ksq) == glaurung.types.GlobalMembers.square_rank(s)))
		  {
			// Is there a half-open file between the king and the edge of the
			// board?
			if (!(ei.pi.has_open_file_to_right(us, glaurung.types.GlobalMembers.square_file(ksq))))
			{
			  ei.mgValue -= p.can_castle(us)? Sign[us.getValue()] * ((TrappedRookPenalty.getValue() - mob * 16) / 2) : Sign[us.getValue()] * (TrappedRookPenalty.getValue() - mob * 16);
			}
		  }
		  else if (glaurung.types.GlobalMembers.square_file(ksq).getValue() <= File.FILE_D.getValue()
				  && glaurung.types.GlobalMembers.square_file(s).getValue() < glaurung.types.GlobalMembers.square_file(ksq).getValue() 
				  && (glaurung.types.GlobalMembers.pawn_rank(us, ksq) == Rank.RANK_1 || glaurung.types.GlobalMembers.square_rank(ksq) == glaurung.types.GlobalMembers.square_rank(s)))
		  {
			// Is there a half-open file between the king and the edge of the
			// board?
			if (!(ei.pi.has_open_file_to_left(us, glaurung.types.GlobalMembers.square_file(ksq))))
			{
			  ei.mgValue -= p.can_castle(us)? Sign[us.getValue()] * ((TrappedRookPenalty.getValue() - mob * 16) / 2) : Sign[us.getValue()] * (TrappedRookPenalty. getValue()- mob * 16);
			}
		  }
		}
	  }

  // evaluate_queen() assigns bonuses and penalties to a queen of a given
  // color on a given square.


	  public static void evaluate_queen(Position p, Square s, Color us, EvalInfo ei)
	  {

		Color them = glaurung.types.GlobalMembers.opposite_color(us);

		// Queen on 7th rank:
		if (glaurung.types.GlobalMembers.pawn_rank(us, s) == Rank.RANK_7 && glaurung.types.GlobalMembers.pawn_rank(us, p.king_square(them)) == Rank.RANK_8)
		{
		  ei.mgValue += Sign[us.getValue()] * MidgameQueenOn7thBonus.getValue();
		  ei.egValue += Sign[us.getValue()] * EndgameQueenOn7thBonus.getValue();
		}

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = p.queen_attacks(s);
		long b = p.queen_attacks(s);
		ei.attackedBy[us.getValue()][PieceType.QUEEN.getValue()] |= b;

		// King attack
		if ((b & ei.attackZone[us.getValue()]) != 0)
		{
		  ei.attackCount[us.getValue()]++;
		  ei.attackWeight[us.getValue()] += QueenAttackWeight;
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long bb = (b & ei.attackedBy[them][KING]);
		  long bb = (b & ei.attackedBy[them.getValue()][PieceType.KING.getValue()]);
		  if (bb != 0)
		  {
			  ei.attacked[us.getValue()] += glaurung.bitboard.GlobalMembers.count_1s_max_15(bb);
		  }
		}

		// Mobility
		int mob = glaurung.bitboard.GlobalMembers.count_1s(b & ~p.pieces_of_color(us));
		ei.mgMobility += Sign[us.getValue()] * MidgameQueenMobilityBonus[mob].getValue();
		ei.egMobility += Sign[us.getValue()] * EndgameQueenMobilityBonus[mob].getValue();
	  }

  // evaluate_king() assigns bonuses and penalties to a king of a given
  // color on a given square.


	  public static void evaluate_king(Position p, Square s, Color us, EvalInfo ei)
	  {

		int shelter = 0;
		int sign = Sign[us.getValue()];

		// King shelter.
		if (glaurung.types.GlobalMembers.pawn_rank(us, s).getValue() <= Rank.RANK_4.getValue())
		{
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long pawns = p.pawns(us) & this_and_neighboring_files_bb(s);
		  long pawns = p.pawns(us) & glaurung.bitboard.GlobalMembers.this_and_neighboring_files_bb(s);
		  Rank r = glaurung.types.GlobalMembers.square_rank(s);
		  for (int i = 0; i < 3; i++)
		  {
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
			shelter += count_1s_8bit(pawns >>> ((r.getValue() + (i + 1) * sign) * 8)) * (64 >> i);
		  }
		  ei.mgValue += sign * shelter;
		}

		// King safety.  This is quite complicated, and is almost certainly far
		// from optimally tuned.
		Color them = glaurung.types.GlobalMembers.opposite_color(us);
		if (p.queen_count(them) >= 1 && ei.attackCount[them.getValue()] >= 2 && p.non_pawn_material(them) >= glaurung.types.GlobalMembers.QueenValueMidgame.getValue() + glaurung.types.GlobalMembers.RookValueMidgame.getValue() && ei.attacked[them.getValue()] != 0)
		{

		  // Is it the attackers turn to move?
		  boolean sente = (them == p.side_to_move());

		  // Find the attacked squares around the king which has no defenders
		  // apart from the king itself:
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long undefended = ei.attacked_by(them) & ~ei.attacked_by(us, PAWN) & ~ei.attacked_by(us, KNIGHT) & ~ei.attacked_by(us, BISHOP) & ~ei.attacked_by(us, ROOK) & ~ei.attacked_by(us, QUEEN) & ei.attacked_by(us, KING);
		  long undefended = (long)(ei.attacked_by(them) & ~ei.attacked_by(us, PieceType.PAWN) & ~ei.attacked_by(us, PieceType.KNIGHT) & ~ei.attacked_by(us, PieceType.BISHOP) & ~ei.attacked_by(us, PieceType.ROOK) & ~ei.attacked_by(us, PieceType.QUEEN) & ei.attacked_by(us, PieceType.KING));
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long occ = p.occupied_squares(), b, b2;
		  long occ = p.occupied_squares();
		  long b;
		  long b2;

		  // Initialize the 'attackUnits' variable, which is used later on as an
		  // index to the SafetyTable[] array.  The initial value is based on the
		  // number and types of the attacking pieces, the number of attacked and
		  // undefended squares around the king, the square of the king, and the
		  // quality of the pawn shelter.
//C++ TO JAVA CONVERTER WARNING: The right shift operator was not replaced by Java's logical right shift operator since the left operand was not confirmed to be of an unsigned type, but you should review whether the logical right shift operator (>>>) is more appropriate:
		  int attackUnits = ((((ei.attackCount[them.getValue()] * ei.attackWeight[them.getValue()]) / 2) < (25))? ((ei.attackCount[them.getValue()] * ei.attackWeight[them.getValue()]) / 2) : (25)) + (ei.attacked[them.getValue()] + glaurung.bitboard.GlobalMembers.count_1s_max_15(undefended)) * 3 + InitKingDanger[glaurung.types.GlobalMembers.relative_square(us, s).getValue()] - (shelter >> 5);

		  // Analyse safe queen contact checks:
		  b = (long)(undefended & ei.attacked_by(them, PieceType.QUEEN) & ~p.pieces_of_color(them));
		  if (b != 0)
		  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long attackedByOthers = ei.attacked_by(them, PAWN) | ei.attacked_by(them, KNIGHT) | ei.attacked_by(them, BISHOP) | ei.attacked_by(them, ROOK);
			long attackedByOthers = ei.attacked_by(them, PieceType.PAWN) | ei.attacked_by(them, PieceType.KNIGHT) | ei.attacked_by(them, PieceType.BISHOP) | ei.attacked_by(them, PieceType.ROOK);
			b &= attackedByOthers;
			if (b != 0)
			{
			  // The bitboard b now contains the squares available for safe queen
			  // contact checks.
			  int count = glaurung.bitboard.GlobalMembers.count_1s_max_15(b);
			  attackUnits += QueenContactCheckBonus * count * (sente? 2 : 1);

			  // Is there a mate threat?
			  if (QueenContactMates && !p.is_check())
			  {
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long escapeSquares = p.king_attacks(s) & ~p.pieces_of_color(us) & ~attackedByOthers;
				long escapeSquares = (long)(p.king_attacks(s) & ~p.pieces_of_color(us) & ~attackedByOthers);
				while (b != 0)
				{
				  Square from;
			  RefObject<Long> tempRef_b = new RefObject<Long>(b);
				  Square to = glaurung.bitboard.GlobalMembers.pop_1st_bit(tempRef_b);
				  b = tempRef_b.argValue;
				  if ((escapeSquares & ~glaurung.bitboard.GlobalMembers.queen_attacks_bb(to, occ & glaurung.bitboard.GlobalMembers.clear_mask_bb(s))) == 0)
				  {
					// We have a mate, unless the queen is pinned or there
					// is an X-ray attack through the queen.
					for (int i = 0; i < p.queen_count(them); i++)
					{
					  from = p.queen_list(them, i);
					  if (glaurung.bitboard.GlobalMembers.bit_is_set(p.queen_attacks(from), to) != 0 && glaurung.bitboard.GlobalMembers.bit_is_set(p.pinned_pieces(them), from) == 0
							  && (glaurung.bitboard.GlobalMembers.rook_attacks_bb(to, occ & glaurung.bitboard.GlobalMembers.clear_mask_bb(from)) & p.rooks_and_queens(us)) == 0
							  && (glaurung.bitboard.GlobalMembers.rook_attacks_bb(to, occ & glaurung.bitboard.GlobalMembers.clear_mask_bb(from)) & p.rooks_and_queens(us)) == 0)
					  {
						//TODO: commented ei.mateThreat[them.getValue()] = make_move(from, to);
					  }
					}
				  }
				}
			  }
			}
		  }

		  // Analyse safe distance checks:
		  if (QueenCheckBonus > 0 || RookCheckBonus > 0)
		  {
			b = (long)(p.rook_attacks(s) & ~p.pieces_of_color(them) & ~ei.attacked_by(us));

			// Queen checks
			b2 = b & ei.attacked_by(them, PieceType.QUEEN);
			if (b2 != 0)
			{
				attackUnits += QueenCheckBonus * glaurung.bitboard.GlobalMembers.count_1s_max_15(b2);
			}

			// Rook checks
			b2 = b & ei.attacked_by(them, PieceType.ROOK);
			if (b2 != 0)
			{
				attackUnits += RookCheckBonus * glaurung.bitboard.GlobalMembers.count_1s_max_15(b2);
			}
		  }
		  if (QueenCheckBonus > 0 || BishopCheckBonus > 0)
		  {
			b = (long)(p.bishop_attacks(s) & ~p.pieces_of_color(them) & ~ei.attacked_by(us));
			// Queen checks
			b2 = b & ei.attacked_by(them, PieceType.QUEEN);
			if (b2 != 0)
			{
				attackUnits += QueenCheckBonus * glaurung.bitboard.GlobalMembers.count_1s_max_15(b2);
			}

			// Bishop checks
			b2 = b & ei.attacked_by(them, PieceType.BISHOP);
			if (b2 != 0)
			{
				attackUnits += BishopCheckBonus * glaurung.bitboard.GlobalMembers.count_1s_max_15(b2);
			}
		  }
		  if (KnightCheckBonus > 0)
		  {
			b = (long)(p.knight_attacks(s) & ~p.pieces_of_color(them) & ~ei.attacked_by(us));
			// Knight checks
			b2 = b & ei.attacked_by(them, PieceType.KNIGHT);
			if (b2 != 0)
			{
				attackUnits += KnightCheckBonus * glaurung.bitboard.GlobalMembers.count_1s_max_15(b2);
			}
		  }

		  // Analyse discovered checks (only for non-pawns right now, consider
		  // adding pawns later).
		  if (DiscoveredCheckBonus != 0)
		  {
			b = (long)(p.discovered_check_candidates(them) & ~p.pawns());
			if (b != 0)
			{
			  attackUnits += DiscoveredCheckBonus * glaurung.bitboard.GlobalMembers.count_1s_max_15(b) * (sente? 2 : 1);
			}
		  }

		  // Has a mate threat been found?  We don't do anything here if the
		  // side with the mating move is the side to move, because in that
		  // case the mating side will get a huge bonus at the end of the main
		  // evaluation function instead.
		  if (ei.mateThreat[them.getValue()] != Move.MOVE_NONE)
		  {
			attackUnits += MateThreatBonus;
		  }

		  // Ensure that attackUnits is between 0 and 99, in order to avoid array
		  // out of bounds errors:
		  if (attackUnits < 0)
		  {
			  attackUnits = 0;
		  }
		  if (attackUnits >= 100)
		  {
			  attackUnits = 99;
		  }

		  // Finally, extract the king safety score from the SafetyTable[] array.
		  // Add the score to the evaluation, and also to ei.futilityMargin.  The
		  // reason for adding the king safety score to the futility margin is
		  // that the king safety scores can sometimes be very big, and that
		  // capturing a single attacking piece can therefore result in a score
		  // change far bigger than the value of the captured piece.
		  Value v = new Value(apply_weight(SafetyTable[attackUnits].getValue(), WeightKingSafety[us.getValue()]));
		  ei.mgValue -= sign * v.getValue();
		  if (us == p.side_to_move())
		  {
			ei.futilityMargin += v.getValue();
		  }
		}
	  }

  // evaluate_passed_pawns() evaluates the passed pawns for both sides.


	  public static void evaluate_passed_pawns(Position pos, EvalInfo ei)
	  {
		boolean[] hasUnstoppable = {false, false};
		int[] movesToGo = {100, 100};

		//for (Color c = Color.WHITE; c.getValue() <= Color.BLACK.getValue(); c = (c == Color.WHITE ? Color.BLACK : Color.COLOR_NONE) )
		for (Color us = Color.WHITE; us.getValue() <= Color.BLACK.getValue(); us = (us == Color.WHITE ? Color.BLACK : Color.COLOR_NONE))
		{
		  Color them = glaurung.types.GlobalMembers.opposite_color(us);
		  Square ourKingSq = pos.king_square(us);
		  Square theirKingSq = pos.king_square(them);
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long b = ei.pi->passed_pawns() & pos.pawns(us), b2, b3, b4;
		  long b = ei.pi.passed_pawns() & pos.pawns(us);
		  long b2;
		  long b3;
		  long b4;

		  while (b != 0)
		  {
			glaurung.types.RefObject<Long> tempRef_b = new glaurung.types.RefObject<Long>(b);
			Square s = glaurung.bitboard.GlobalMembers.pop_1st_bit(tempRef_b);
			b = tempRef_b.argValue;
			assert pos.piece_on(s) == glaurung.types.GlobalMembers.pawn_of_color(us);
			assert pos.pawn_is_passed(us, s);

			int r = glaurung.types.GlobalMembers.pawn_rank(us, s).getValue() - Rank.RANK_2.getValue();
			int tr = (((0) < (r * (r - 1)))? (r * (r - 1)) : (0));
			Square blockSq = s + glaurung.types.GlobalMembers.pawn_push(us).getValue();

			// Base bonus based on rank:
			int mbonus = 20 * tr;
			int ebonus = 10 + r * r * 10;

			// Adjust bonus based on king proximity:
			ebonus -= glaurung.types.GlobalMembers.square_distance(ourKingSq, blockSq) * 3 * tr;
			ebonus -= glaurung.types.GlobalMembers.square_distance(ourKingSq, blockSq + glaurung.types.GlobalMembers.pawn_push(us)) * 1 * tr;
			ebonus += glaurung.types.GlobalMembers.square_distance(theirKingSq, blockSq) * 6 * tr;

			// If the pawn is free to advance, increase bonus:
			if (pos.square_is_empty(blockSq))
			{

			  b2 = glaurung.bitboard.GlobalMembers.squares_in_front_of(us, s);
			  b3 = b2 & ei.attacked_by(them);
			  b4 = b2 & ei.attacked_by(us);

			  // If there is an enemy rook or queen attacking the pawn from behind,
			  // add all X-ray attacks by the rook or queen:
			  if (glaurung.bitboard.GlobalMembers.bit_is_set(ei.attacked_by(them, PieceType.ROOK) | ei.attacked_by(them, PieceType.QUEEN), s) != 0 && (glaurung.bitboard.GlobalMembers.squares_behind(us, s) & pos.rooks_and_queens(them)) != 0)
			  {
				b3 = b2;
			  }

			  if ((b2 & pos.pieces_of_color(them)) == glaurung.bitboard.GlobalMembers.EmptyBoardBB)
			  {
				// There are no enemy pieces in the pawn's path!  Are any of the
				// squares in the pawn's path attacked by the enemy?
				if (b3 == glaurung.bitboard.GlobalMembers.EmptyBoardBB)
				{
				  // No enemy attacks, huge bonus!
				  ebonus += tr * ((b2 == b4)? 17 : 15);
				}
				else
				{
				  // OK, there are enemy attacks.  Are those squares which are
				  // attacked by the enemy also attacked by us?  If yes, big bonus
				  // (but smaller than when there are no enemy attacks), if no,
				  // somewhat smaller bonus.
				  ebonus += tr * (((b3 & b4) == b3)? 13 : 8);
				}
			  }
			  else
			  {
				// There are some enemy pieces in the pawn's path.  While this is
				// sad, we still assign a moderate bonus if all squares in the path
				// which are either occupied by or attacked by enemy pieces are
				// also attacked by us.
				if (((b3 | (b2 & pos.pieces_of_color(them))) & ~b4) == glaurung.bitboard.GlobalMembers.EmptyBoardBB)
				{
				  ebonus += tr * 6;
				}
			  }
			  // At last, add a small bonus when there are no *friendly* pieces
			  // in the pawn's path:
			  if ((b2 & pos.pieces_of_color(us)) == glaurung.bitboard.GlobalMembers.EmptyBoardBB)
			  {
				ebonus += tr;
			  }
			}

			// If the pawn is supported by a friendly pawn, increase bonus.
			b2 = pos.pawns(us) & glaurung.bitboard.GlobalMembers.neighboring_files_bb(s);
			if ((b2 & glaurung.bitboard.GlobalMembers.rank_bb(s)) != 0)
			{
			  ebonus += r * 20;
			}
			else if ((pos.pawn_attacks(them, s) & b2) != 0)
			{
			  ebonus += r * 12;
			}

			// If the other side has only a king, check whether the pawn is
			// unstoppable:
			if (pos.non_pawn_material(them) == 0)
			{
			  Square qsq;
			  int d;

			  qsq = glaurung.types.GlobalMembers.relative_square(us, glaurung.types.GlobalMembers.make_square(glaurung.types.GlobalMembers.square_file(s), Rank.RANK_8));
			  d = glaurung.types.GlobalMembers.square_distance(s, qsq) - glaurung.types.GlobalMembers.square_distance(theirKingSq, qsq) + ((us == pos.side_to_move())? 0 : 1);

			  if (d < 0)
			  {
				int mtg = Rank.RANK_8.getValue() - glaurung.types.GlobalMembers.pawn_rank(us, s).getValue();
				int blockerCount = glaurung.bitboard.GlobalMembers.count_1s_max_15(glaurung.bitboard.GlobalMembers.squares_in_front_of(us, s) & pos.occupied_squares());
				mtg += blockerCount;
				d += blockerCount;
				if (d < 0)
				{
				  hasUnstoppable[us.getValue()] = true;
				  movesToGo[us.getValue()] = (((movesToGo[us.getValue()]) < (mtg))? (movesToGo[us.getValue()]) : (mtg));
				}
			  }
			}
			// Rook pawns are a special case:  They are sometimes worse, and
			// sometimes better than other passed pawns.  It is difficult to find
			// good rules for determining whether they are good or bad.  For now,
			// we try the following:  Increase the value for rook pawns if the
			// other side has no pieces apart from a knight, and decrease the
			// value if the other side has a rook or queen.
			if (glaurung.types.GlobalMembers.square_file(s) == File.FILE_A || glaurung.types.GlobalMembers.square_file(s) == File.FILE_H)
			{
			  if (pos.non_pawn_material(them) == glaurung.types.GlobalMembers.KnightValueMidgame.getValue() && pos.knight_count(them) == 1)
			  {
				ebonus += ebonus / 4;
			  }
			  else if (pos.rooks_and_queens(them) != 0)
			  {
				ebonus -= ebonus / 4;
			  }
			}

			// Add the scores for this pawn to the middle game and endgame eval.
			ei.mgValue += apply_weight(Sign[us.getValue()] * mbonus, WeightPassedPawnsMidgame);
			ei.egValue += apply_weight(Sign[us.getValue()] * ebonus, WeightPassedPawnsEndgame);
		  }
		}

		// Does either side have an unstoppable passed pawn?
		if (hasUnstoppable[Color.WHITE.getValue()] && !hasUnstoppable[Color.BLACK.getValue()])
		{
		  ei.egValue += UnstoppablePawnValue.getValue() - 0x40 * movesToGo[Color.WHITE.getValue()];
		}
		else if (hasUnstoppable[Color.BLACK.getValue()] && !hasUnstoppable[Color.WHITE.getValue()])
		{
		  ei.egValue -= UnstoppablePawnValue.getValue() - 0x40 * movesToGo[Color.BLACK.getValue()];
		}
		else if (hasUnstoppable[Color.BLACK.getValue()] && hasUnstoppable[Color.WHITE.getValue()])
		{
		  // Both sides have unstoppable pawns!  Try to find out who queens
		  // first.  We begin by transforming 'movesToGo' to the number of
		  // plies until the pawn queens for both sides:
		  movesToGo[Color.WHITE.getValue()] *= 2;
		  movesToGo[Color.BLACK.getValue()] *= 2;
		  movesToGo[pos.side_to_move().getValue()]--;

		  // If one side queens at least three plies before the other, that
		  // side wins:
		  if (movesToGo[Color.WHITE.getValue()] <= movesToGo[Color.BLACK.getValue()] - 3)
		  {
			ei.egValue += UnstoppablePawnValue.getValue() - 0x40 * (movesToGo[Color.WHITE.getValue()] / 2);
		  }
		  else if (movesToGo[Color.BLACK.getValue()] <= movesToGo[Color.WHITE.getValue()] - 3)
		  {
			ei.egValue -= UnstoppablePawnValue.getValue() - 0x40 * (movesToGo[Color.BLACK.getValue()] / 2);
		  }

		  // We could also add some rules about the situation when one side
		  // queens exactly one ply before the other:  Does the first queen
		  // check the opponent's king, or attack the opponent's queening square?
		  // This is slightly tricky to get right, because it is possible that
		  // the opponent's king has moved somewhere before the first pawn queens.
		}
	  }

  // evaluate_trapped_bishop_a7h7() determines whether a bishop on a7/h7
  // (a2/h2 for black) is trapped by enemy pawns, and assigns a penalty
  // if it is.


	  public static void evaluate_trapped_bishop_a7h7(Position pos, Square s, Color us, EvalInfo ei)
	  {
		Piece pawn = glaurung.types.GlobalMembers.pawn_of_color(glaurung.types.GlobalMembers.opposite_color(us));
		Square b6;
		Square b8;

		assert glaurung.types.GlobalMembers.square_is_ok(s);
		assert pos.piece_on(s) == glaurung.types.GlobalMembers.bishop_of_color(us);

		if (glaurung.types.GlobalMembers.square_file(s) == File.FILE_A)
		{
		  b6 = glaurung.types.GlobalMembers.relative_square(us, Square.SQ_B6);
		  b8 = glaurung.types.GlobalMembers.relative_square(us, Square.SQ_B8);
		}
		else
		{
		  b6 = glaurung.types.GlobalMembers.relative_square(us, Square.SQ_G6);
		  b8 = glaurung.types.GlobalMembers.relative_square(us, Square.SQ_G8);
		}

		if (pos.piece_on(b6) == pawn && pos.see(s, b6) < 0 && pos.see(s, b8) < 0)
		{
		  ei.mgValue -= Sign[us.getValue()] * TrappedBishopA7H7Penalty.getValue();
		  ei.egValue -= Sign[us.getValue()] * TrappedBishopA7H7Penalty.getValue();
		}

	  }


  // evaluate_space() computes the space evaluation for a given side.  The
  // space evaluation is a simple bonus based on the number of safe squares
  // available for minor pieces on the central four files on ranks 2--4.  Safe
  // squares one, two or three squares behind a friendly pawn are counted
  // twice.  Finally, the space bonus is scaled by a weight taken from the
  // material hash table.


	  public static void evaluate_space(Position pos, Color us, EvalInfo ei)
	  {
		Color them = glaurung.types.GlobalMembers.opposite_color(us);

		// Find the safe squares for our pieces inside the area defined by
		// SpaceMask[us].  A square is unsafe it is attacked by an enemy
		// pawn, or if it is undefended and attacked by an enemy piece.

	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long safeSquares = SpaceMask[us] & ~pos.pawns(us) & ~ei.attacked_by(them, PAWN) & ~(~ei.attacked_by(us) & ei.attacked_by(them));
		long safeSquares = (long)(SpaceMask[us.getValue()] & ~pos.pawns(us) & ~ei.attacked_by(them, PieceType.PAWN) & ~(~ei.attacked_by(us) & ei.attacked_by(them)));

		// Find all squares which are at most three squares behind some friendly
		// pawn.
	//C++ TO JAVA CONVERTER WARNING: Unsigned integer types have no direct equivalent in Java:
	//ORIGINAL LINE: unsigned long long behindFriendlyPawns = pos.pawns(us);
		long behindFriendlyPawns = pos.pawns(us);
		if (us == Color.WHITE)
		{
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		  behindFriendlyPawns |= (behindFriendlyPawns >>> 8);
//C++ TO JAVA CONVERTER WARNING: The right shift operator was replaced by Java's logical right shift operator since the left operand was originally of an unsigned type, but you should confirm this replacement:
		  behindFriendlyPawns |= (behindFriendlyPawns >>> 16);
		}
		else
		{
		  behindFriendlyPawns |= (behindFriendlyPawns << 8);
		  behindFriendlyPawns |= (behindFriendlyPawns << 16);
		}

		int space = glaurung.bitboard.GlobalMembers.count_1s_max_15(safeSquares) + glaurung.bitboard.GlobalMembers.count_1s_max_15(behindFriendlyPawns & safeSquares);

		ei.mgValue += Sign[us.getValue()] * apply_weight(space * ei.mi.space_weight(), WeightSpace);
	  }

  // apply_weight applies() an evaluation weight to a value.


	  public static int apply_weight(int v, int w)
	  {
		return (v * w) / 0x100;
	  }

  // scale_by_game_phase() interpolates between a middle game and an endgame
  // score, based on game phase.  It also scales the return value by a
  // ScaleFactor array.


	  public static int scale_by_game_phase(int mv, int ev, Phase ph, ScaleFactor[] sf)
	  {
		assert mv > -Value.VALUE_INFINITE.getValue() && mv < Value.VALUE_INFINITE.getValue();
		assert ev > -Value.VALUE_INFINITE.getValue() && ev < Value.VALUE_INFINITE.getValue();
		assert ph.getValue() >= Phase.PHASE_ENDGAME.getValue() && ph.getValue() <= Phase.PHASE_MIDGAME.getValue();

		if (ev > 0)
		{
		  ev = glaurung.types.GlobalMembers.apply_scale_factor(ev, sf[Color.WHITE.getValue()]);
		}
		else
		{
		  ev = glaurung.types.GlobalMembers.apply_scale_factor(ev, sf[Color.BLACK.getValue()]);
		}

		int result = (int)((mv * ph.getValue() + ev * (128 - ph.getValue())) / 128);
		return result & ~(GrainSize - 1);
	  }

  // count_1s_8bit() counts the number of nonzero bits in the 8 least
  // significant bits of an integer.  This function is used by the king
  // shield evaluation.


	  public static int count_1s_8bit(long b)
	  {
		return BitCount8Bit[(int) (b & 0xFF)];
	  }

  // compute_weight() computes the value of an evaluation weight, by combining
  // an UCI-configurable weight with an internal weight.


	  public static int compute_weight(int uciWeight, int internalWeight)
	  {
		/*uciWeight = (uciWeight * 0x100) / 100;
		return (uciWeight * internalWeight) / 0x100;*/
		return internalWeight;
	  }

  // init_safety() initizes the king safety evaluation, based on UCI
  // parameters.  It is called from read_weights().


	  public static void init_safety()
	  {
		double a;
		double b;
		int maxSlope;
		int peak;
		int i;
		int j;

		/*QueenContactCheckBonus = get_option_value_int("Queen Contact Check Bonus");
		QueenCheckBonus = get_option_value_int("Queen Check Bonus");
		RookCheckBonus = get_option_value_int("Rook Check Bonus");
		BishopCheckBonus = get_option_value_int("Bishop Check Bonus");
		KnightCheckBonus = get_option_value_int("Knight Check Bonus");
		DiscoveredCheckBonus = get_option_value_int("Discovered Check Bonus");
		MateThreatBonus = get_option_value_int("Mate Threat Bonus");
		 */
		
		a = get_option_value_int("King Safety Coefficient") / 100.0;
		b = get_option_value_int("King Safety X Intercept") * 1.0;
		maxSlope = get_option_value_int("King Safety Max Slope");
		peak = (get_option_value_int("King Safety Max Value") * 256) / 100;

		for (i = 0; i < 100; i++)
		{
		  if (i < b)
		  {
			  SafetyTable[i] = Value(0);
		  }
		  else if (get_option_value_string("King Safety Curve").equals("Quadratic"))
		  {
			SafetyTable[i] = Value((int)(a * (i - b) * (i - b)));
		  }
		  else if (get_option_value_string("King Safety Curve").equals("Linear"))
		  {
			SafetyTable[i] = Value((int)(100 * a * (i - b)));
		  }
		}

		for (i = 0; i < 100; i++)
		{
		  if (SafetyTable[i + 1].getValue() - SafetyTable[i].getValue() > maxSlope)
		  {
			for (j = i + 1; j < 100; j++)
			{
			  SafetyTable[j] = SafetyTable[j - 1] + Value(maxSlope);
			}
		  }
		}
		for (i = 0; i < 100; i++)
		{
		  if (SafetyTable[i].getValue() > Value(peak))
		  {
			SafetyTable[i] = Value(peak);
		  }
		}
	  }
}